namespace UniverseGenTweaks;

public static class PluginInfo
{
	public const string PLUGIN_GUID = "org.soardev.universegentweaks";

	public const string PLUGIN_NAME = "UniverseGenTweaks";

	public const string PLUGIN_VERSION = "1.2.14";
}
