using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using BepInEx.Configuration;
using HarmonyLib;
using UXAssist.Common;
using UnityEngine.UI;

namespace UniverseGenTweaks;

public static class EpicDifficulty
{
	public static ConfigEntry<bool> Enabled;

	public static ConfigEntry<float> ResourceMultiplier;

	public static ConfigEntry<float> OilMultiplier;

	private static Harmony _harmony;

	private static readonly float[] ResourceMultipliers = new float[9] { 0.0001f, 0.0005f, 0.001f, 0.005f, 0.01f, 0.02f, 0.03f, 0.04f, 0.05f };

	private static readonly float[] OilMultipliers = new float[10] { 0.1f, 0.2f, 0.3f, 0.4f, 0.5f, 0.6f, 0.7f, 0.8f, 0.9f, 1f };

	public static void Init()
	{
		I18N.Add("究极少", "Micro", "究极少");
		I18N.Add("史诗难度", "Epic Difficulty !!", "史诗难度 !!");
		I18N.Apply();
		Enabled.SettingChanged += delegate
		{
			Enable(Enabled.Value);
		};
		Enable(Enabled.Value);
	}

	public static void Uninit()
	{
		Enable(on: false);
	}

	private static void Enable(bool on)
	{
		if (on)
		{
			if (_harmony == null)
			{
				_harmony = Harmony.CreateAndPatchAll(typeof(EpicDifficulty));
			}
		}
		else
		{
			_harmony?.UnpatchSelf();
			_harmony = null;
		}
	}

	public static float IndexToResourceMultiplier(int index)
	{
		return ResourceMultipliers[(index >= 0) ? ((index >= ResourceMultipliers.Length) ? (ResourceMultipliers.Length - 1) : index) : 0];
	}

	public static int ResourceMultiplierToIndex(float mult)
	{
		for (int num = ResourceMultipliers.Length - 1; num > 0; num--)
		{
			if (ResourceMultipliers[num] <= mult)
			{
				return num;
			}
		}
		return 0;
	}

	public static int ResourceMultipliersCount()
	{
		return ResourceMultipliers.Length;
	}

	public static float IndexToOilMultiplier(int index)
	{
		return OilMultipliers[(index >= 0) ? ((index >= OilMultipliers.Length) ? (OilMultipliers.Length - 1) : index) : 0];
	}

	public static int OilMultiplierToIndex(float mult)
	{
		for (int num = OilMultipliers.Length - 1; num > 0; num--)
		{
			if (OilMultipliers[num] <= mult)
			{
				return num;
			}
		}
		return 0;
	}

	public static int OilMultipliersCount()
	{
		return OilMultipliers.Length;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIGalaxySelect), "_OnInit")]
	private static void PatchGalaxyUI_OnInit(UIGalaxySelect __instance)
	{
		__instance.resourceMultiplierSlider.maxValue = 11f;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIGalaxySelect), "OnResourceMultiplierValueChange")]
	private static bool UIGalaxySelect_OnResourceMultiplierValueChange_Prefix(UIGalaxySelect __instance, float val)
	{
		float value = __instance.resourceMultiplierSlider.value;
		GameDesc gameDesc = __instance.gameDesc;
		float resourceMultiplier = ((value < 0.5f) ? ResourceMultiplier.Value : ((value < 1.5f) ? 0.1f : ((value < 2.5f) ? 0.3f : ((value < 3.5f) ? 0.5f : ((value < 4.5f) ? 0.8f : ((value < 5.5f) ? 1f : ((value < 6.5f) ? 1.5f : ((value < 7.5f) ? 2f : ((value < 8.5f) ? 3f : ((value < 9.5f) ? 5f : ((!(value < 10.5f)) ? 100f : 8f)))))))))));
		gameDesc.resourceMultiplier = resourceMultiplier;
		__instance.UpdateParametersUIDisplay();
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIGalaxySelect), "UpdateParametersUIDisplay")]
	private static bool UIGalaxySelect_UpdateParametersUIDisplay_Prefix(UIGalaxySelect __instance)
	{
		float resourceMultiplier = __instance.gameDesc.resourceMultiplier;
		string text = "";
		Slider resourceMultiplierSlider = __instance.resourceMultiplierSlider;
		float value = ((resourceMultiplier < 0.09f) ? 0f : ((resourceMultiplier < 0.11f) ? 1f : ((resourceMultiplier < 0.31f) ? 2f : ((resourceMultiplier < 0.51f) ? 3f : ((resourceMultiplier < 0.81f) ? 4f : ((resourceMultiplier < 1.01f) ? 5f : ((resourceMultiplier < 1.51f) ? 6f : ((resourceMultiplier < 2.01f) ? 7f : ((resourceMultiplier < 3.01f) ? 8f : ((resourceMultiplier < 5.01f) ? 9f : ((!(resourceMultiplier < 8.01f)) ? 11f : 10f)))))))))));
		resourceMultiplierSlider.value = value;
		string text2 = ((resourceMultiplier < 100f) ? ((resourceMultiplier > 0.1f) ? (resourceMultiplier + "x") : ((!(resourceMultiplier < 0.09f)) ? "极少".Translate() : "究极少".Translate())) : ((!(resourceMultiplier >= 100f)) ? text : "无限".Translate()));
		text = text2;
		__instance.resourceMultiplierText.text = text;
		__instance.propertyMultiplierText.text = "元数据生成倍率".Translate() + " " + __instance.gameDesc.propertyMultiplier.ToString("P0");
		__instance.addrText.text = __instance.gameDesc.clusterString;
		bool flag = resourceMultiplier < 0.11f && !__instance.gameDesc.isSandboxMode;
		__instance.difficultTipGroup.SetActive(flag);
		if (!flag)
		{
			return false;
		}
		__instance.difficultTipGroup.transform.Find("difficult-tip-text").GetComponent<Text>().text = ((resourceMultiplier < 0.09f) ? "史诗难度" : "非常困难").Translate();
		return false;
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(GameDesc), "oilAmountMultiplier", MethodType.Getter)]
	private static IEnumerable<CodeInstruction> GameDesc_get_oilAmountMultiplier_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
		if (Math.Abs(OilMultiplier.Value - 1f) > 1E-05f)
		{
			Label label = generator.DefineLabel();
			codeMatcher.Start().InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(GameDesc), "resourceMultiplier")), new CodeInstruction(OpCodes.Ldc_R4, 0.05f), new CodeInstruction(OpCodes.Ble_S, label)).End()
				.Advance(1)
				.Insert(new CodeInstruction(OpCodes.Ldc_R4, 0.5f * OilMultiplier.Value).WithLabels(label), new CodeInstruction(OpCodes.Ret));
		}
		return codeMatcher.InstructionEnumeration();
	}
}
