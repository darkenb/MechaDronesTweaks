using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection.Emit;
using BepInEx.Configuration;
using HarmonyLib;
using UXAssist.Common;
using UnityEngine;
using UnityEngine.UI;

namespace UniverseGenTweaks;

public class MoreSettings
{
	private static class PermanentPatch
	{
		[HarmonyPrefix]
		[HarmonyPatch(typeof(GameMain), "Start")]
		private static void GameMain_Start_Prefix()
		{
			if (DSPGame.GameDesc != null)
			{
				if (GameMain.data == null)
				{
					_gameMinDist = _minDist;
					_gameMinStep = _minStep;
					_gameMaxStep = _maxStep;
					_gameFlatten = _flatten;
				}
			}
			else
			{
				_gameMinDist = 2.0;
				_gameMinStep = 2.0;
				_gameMaxStep = 3.2;
				_gameFlatten = 0.18;
			}
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(GalaxyData), MethodType.Constructor)]
		private static IEnumerable<CodeInstruction> GalaxyData_Constructor_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.MatchForward(false, new CodeMatch((CodeInstruction ci) => ci.opcode == OpCodes.Ldc_I4 && ci.OperandIs(25700)));
			codeMatcher.Repeat(delegate(CodeMatcher m)
			{
				m.SetAndAdvance(OpCodes.Ldc_I4, 102500);
			});
			return codeMatcher.InstructionEnumeration();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(SectorModel), "CreateGalaxyAstroBuffer")]
		[HarmonyPatch(typeof(SpaceColliderLogic), "UpdateCollidersPose")]
		private static IEnumerable<CodeInstruction> SectorModel_CreateGalaxyAstroBuffer_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.MatchForward(false, new CodeMatch((CodeInstruction ci) => ci.opcode == OpCodes.Ldc_I4 && ci.OperandIs(25600)));
			codeMatcher.Repeat(delegate(CodeMatcher m)
			{
				m.SetAndAdvance(OpCodes.Ldc_I4, 102500);
			});
			return codeMatcher.InstructionEnumeration();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(UniverseGen), "CreateGalaxy")]
		private static IEnumerable<CodeInstruction> UniverseGen_CreateGalaxy_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			Label label = generator.DefineLabel();
			Label label2 = generator.DefineLabel();
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(UniverseGen), "GenerateTempPoses"))).Advance(-4).RemoveInstructions(4)
				.InsertAndAdvance(new CodeInstruction(OpCodes.Call, AccessTools.PropertyGetter(typeof(UIRoot), "instance")), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(UIRoot), "galaxySelect")), new CodeInstruction(OpCodes.Callvirt, AccessTools.PropertyGetter(typeof(ManualBehaviour), "active")), new CodeInstruction(OpCodes.Brfalse, label), new CodeInstruction(OpCodes.Ldsfld, AccessTools.Field(typeof(MoreSettings), "_minDist")), new CodeInstruction(OpCodes.Ldsfld, AccessTools.Field(typeof(MoreSettings), "_minStep")), new CodeInstruction(OpCodes.Ldsfld, AccessTools.Field(typeof(MoreSettings), "_maxStep")), new CodeInstruction(OpCodes.Ldsfld, AccessTools.Field(typeof(MoreSettings), "_flatten")), new CodeInstruction(OpCodes.Br, label2), new CodeInstruction(OpCodes.Ldsfld, AccessTools.Field(typeof(MoreSettings), "_gameMinDist")).WithLabels(label), new CodeInstruction(OpCodes.Ldsfld, AccessTools.Field(typeof(MoreSettings), "_gameMinStep")), new CodeInstruction(OpCodes.Ldsfld, AccessTools.Field(typeof(MoreSettings), "_gameMaxStep")), new CodeInstruction(OpCodes.Ldsfld, AccessTools.Field(typeof(MoreSettings), "_gameFlatten")));
			codeMatcher.Labels.Add(label2);
			return codeMatcher.InstructionEnumeration();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(UniverseGen), "RandomPoses")]
		private static IEnumerable<CodeInstruction> UniverseGen_RandomPoses_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Mul), new CodeMatch(OpCodes.Ldarg_2));
			codeMatcher.Repeat(delegate(CodeMatcher m)
			{
				m.Advance(1).SetInstructionAndAdvance(new CodeInstruction(OpCodes.Ldarg_3));
			});
			return codeMatcher.InstructionEnumeration();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(UIVirtualStarmap), "_OnLateUpdate")]
		private static IEnumerable<CodeInstruction> UIVirtualStarmap__OnLateUpdate_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			LocalBuilder operand = generator.DeclareLocal(typeof(UIVirtualStarmap.StarNode));
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(UIVirtualStarmap.StarNode), "nameText")), new CodeMatch(OpCodes.Callvirt, AccessTools.PropertyGetter(typeof(Component), "gameObject")), new CodeMatch((CodeInstruction ci) => ci.IsLdloc()), new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(GameObject), "SetActive", new Type[1] { typeof(bool) }))).InsertAndAdvance(new CodeInstruction(OpCodes.Dup), new CodeInstruction(OpCodes.Stloc, operand)).Advance(3)
				.Insert(new CodeInstruction(OpCodes.Ldloc, operand), Transpilers.EmitDelegate<Func<UIVirtualStarmap.StarNode, bool>>(delegate(UIVirtualStarmap.StarNode starNode)
				{
					EStarType? eStarType = starNode?.starData?.type;
					if (eStarType.HasValue)
					{
						EStarType valueOrDefault = eStarType.GetValueOrDefault();
						if ((uint)(valueOrDefault - 3) <= 1u)
						{
							return true;
						}
					}
					return false;
				}), new CodeInstruction(OpCodes.Or));
			return codeMatcher.InstructionEnumeration();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(UIGalaxySelect), "UpdateUIDisplay")]
		private static IEnumerable<CodeInstruction> UIGalaxySelect_UpdateUIDisplay_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			Label? b1 = null;
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch((CodeInstruction ci) => ci.IsStloc()), new CodeMatch((CodeInstruction ci) => ci.Branches(out b1)), new CodeMatch((CodeInstruction ci) => ci.IsLdloc()), new CodeMatch((CodeInstruction ci) => ci.IsLdloc()), new CodeMatch(OpCodes.Ldelem_Ref), new CodeMatch((CodeInstruction ci) => ci.IsStloc()), new CodeMatch((CodeInstruction ci) => ci.IsLdloc())).Advance(7);
			CodeInstruction codeInstruction = codeMatcher.InstructionAt(0);
			codeMatcher.Insert(codeInstruction, new CodeInstruction(OpCodes.Brfalse, b1));
			return codeMatcher.InstructionEnumeration();
		}
	}

	private const double DEFAULT_MIN_DIST = 2.0;

	private const double DEFAULT_MIN_STEP = 2.0;

	private const double DEFAULT_MAX_STEP = 3.2;

	private const double DEFAULT_FLATTEN = 0.18;

	public static ConfigEntry<bool> Enabled;

	public static ConfigEntry<int> MaxStarCount;

	private static double _minDist = 2.0;

	private static double _minStep = 2.0;

	private static double _maxStep = 3.2;

	private static double _flatten = 0.18;

	private static double _gameMinDist = 2.0;

	private static double _gameMinStep = 2.0;

	private static double _gameMaxStep = 3.2;

	private static double _gameFlatten = 0.18;

	private static Text _minDistTitle;

	private static Text _minStepTitle;

	private static Text _maxStepTitle;

	private static Text _flattenTitle;

	private static Slider _minDistSlider;

	private static Slider _minStepSlider;

	private static Slider _maxStepSlider;

	private static Slider _flattenSlider;

	private static Text _minDistText;

	private static Text _minStepText;

	private static Text _maxStepText;

	private static Text _flattenText;

	private static Harmony _patch;

	private static Harmony _permanentPatch;

	private static Transform _detailButton;

	private static Transform _darkFogRow;

	private static Vector3 _detailOffset;

	private static Transform _settingsParent;

	private static RectTransform _starCountRow;

	private static Vector3 _rowOrigin;

	private static Transform[] _settingRows;

	private static float[] _rowTop;

	private static float[] _rowBottom;

	private static float[] _rowY;

	private static bool[] _rowVisible;

	public static void Init()
	{
		I18N.Add("恒星最小距离", "Star Distance Min", "恒星最小距离");
		I18N.Add("步进最小距离", "Step Distance Min", "步进最小距离");
		I18N.Add("步进最大距离", "Step Distance Max", "步进最大距离");
		I18N.Add("扁平度", "Flatness", "扁平度");
		I18N.Apply();
		if (_permanentPatch == null)
		{
			_permanentPatch = Harmony.CreateAndPatchAll(typeof(PermanentPatch));
		}
		Enabled.SettingChanged += delegate
		{
			Enable(Enabled.Value);
		};
		Enable(Enabled.Value);
	}

	public static void Uninit()
	{
		Enable(on: false);
		_permanentPatch?.UnpatchSelf();
		_permanentPatch = null;
	}

	private static void Enable(bool on)
	{
		if (on)
		{
			if (_patch == null)
			{
				_patch = Harmony.CreateAndPatchAll(typeof(MoreSettings));
			}
		}
		else
		{
			_patch?.UnpatchSelf();
			_patch = null;
		}
	}

	private static void CreateSliderWithText(Slider orig, out Text title, out Slider slider, out Text text, out Localizer loc)
	{
		Text component = orig.transform.parent.GetComponent<Text>();
		title = UnityEngine.Object.Instantiate(component, component.transform.parent);
		slider = title.transform.FindChildRecur("Slider").GetComponent<Slider>();
		text = slider.transform.FindChildRecur("Text").GetComponent<Text>();
		loc = title.GetComponent<Localizer>();
	}

	private static void CalculateLayout(float originY, float originBottom, float[] top, float[] bottom, bool[] visible, float[] positions)
	{
		float num = originY;
		float num2 = originBottom;
		for (int i = 0; i < top.Length; i++)
		{
			if (visible[i])
			{
				num = (positions[i] = Math.Min(num - 36f, num + num2 - 10f - top[i]));
				num2 = bottom[i];
			}
		}
	}

	private static void CollectSettingRows(UIGalaxySelect ui)
	{
		List<Transform> list = new List<Transform>
		{
			_minDistTitle.transform,
			_minStepTitle.transform,
			_maxStepTitle.transform,
			_flattenTitle.transform,
			ui.resourceMultiplierSlider.transform.parent,
			ui.sandboxToggle.transform.parent
		};
		foreach (Transform item in _settingsParent)
		{
			if (item.name == "fast-start-mode")
			{
				list.Add(item);
			}
		}
		list.Add(_darkFogRow);
		foreach (Transform item2 in _settingsParent)
		{
			if (item2.name == "void-invasion-toggle")
			{
				list.Add(item2);
			}
		}
		list.Add(ui.addrText.transform.parent);
		list.Add(ui.propertyMultiplierText.transform);
		_settingRows = list.ToArray();
		_rowTop = new float[list.Count];
		_rowBottom = new float[list.Count];
		_rowY = new float[list.Count];
		_rowVisible = new bool[list.Count];
	}

	private static void ApplySettingLayout()
	{
		if (_settingRows == null || _starCountRow == null || !_starCountRow.gameObject.activeSelf)
		{
			return;
		}
		for (int i = 0; i < _settingRows.Length; i++)
		{
			RectTransform rectTransform = _settingRows[i] as RectTransform;
			_rowVisible[i] = rectTransform != null && rectTransform.gameObject.activeSelf;
			if (_rowVisible[i])
			{
				_rowTop[i] = rectTransform.rect.yMax;
				_rowBottom[i] = rectTransform.rect.yMin;
			}
		}
		CalculateLayout(_rowOrigin.y, _starCountRow.rect.yMin, _rowTop, _rowBottom, _rowVisible, _rowY);
		for (int j = 0; j < _settingRows.Length; j++)
		{
			if (_rowVisible[j])
			{
				_settingRows[j].position = _settingsParent.TransformPoint(new Vector3(_rowOrigin.x, _rowY[j], _rowOrigin.z));
			}
		}
	}

	private static void UpdateSliderControls()
	{
		_minDistSlider.minValue = 10f;
		_minDistSlider.maxValue = 50f;
		_minDistSlider.value = (float)(_minDist * 10.0);
		_minStepSlider.minValue = (float)(_minDist * 10.0);
		_minStepSlider.maxValue = (float)(_maxStep * 10.0);
		_minStepSlider.value = (float)(_minStep * 10.0);
		_maxStepSlider.minValue = (float)(_minStep * 10.0);
		_maxStepSlider.maxValue = 100f;
		_maxStepSlider.value = (float)(_maxStep * 10.0);
		_flattenSlider.minValue = 1f;
		_flattenSlider.maxValue = 50f;
		_flattenSlider.value = (float)(_flatten * 50.0);
		_minDistText.text = _minDist.ToString();
		_minStepText.text = _minStep.ToString();
		_maxStepText.text = _maxStep.ToString();
		_flattenText.text = _flatten.ToString();
		UniverseGenTweaks.Logger.LogDebug($"Updated slider controls: {_minStepSlider.minValue}, {_minStepSlider.maxValue}, {_maxStepSlider.minValue}, {_maxStepSlider.maxValue}");
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIGalaxySelect), "_OnCreate")]
	private static void UIGalaxySelect__OnCreate_Postfix(UIGalaxySelect __instance)
	{
		_starCountRow = (RectTransform)__instance.starCountSlider.transform.parent;
		_settingsParent = _starCountRow.parent;
		_rowOrigin = _starCountRow.localPosition;
		_darkFogRow = __instance.darkFogToggle.transform.parent;
		_detailButton = __instance.darkFogDetailBtn.transform;
		_detailOffset = _darkFogRow.InverseTransformPoint(_detailButton.position);
		__instance.starCountSlider.maxValue = MaxStarCount.Value;
		CreateSliderWithText(__instance.starCountSlider, out _minDistTitle, out _minDistSlider, out _minDistText, out var loc);
		CreateSliderWithText(__instance.starCountSlider, out _minStepTitle, out _minStepSlider, out _minStepText, out var loc2);
		CreateSliderWithText(__instance.starCountSlider, out _maxStepTitle, out _maxStepSlider, out _maxStepText, out var loc3);
		CreateSliderWithText(__instance.starCountSlider, out _flattenTitle, out _flattenSlider, out _flattenText, out var loc4);
		loc.stringKey = "恒星最小距离";
		loc2.stringKey = "步进最小距离";
		loc3.stringKey = "步进最大距离";
		loc4.stringKey = "扁平度";
		_minDistTitle.name = "min-dist";
		_minStepTitle.name = "min-step";
		_maxStepTitle.name = "max-step";
		_flattenTitle.name = "flatten";
		CollectSettingRows(__instance);
		ApplySettingLayout();
		RemoveAllListeners();
		UpdateSliderControls();
		AddListeners(__instance);
	}

	[HarmonyPostfix]
	[HarmonyPriority(0)]
	[HarmonyPatch(typeof(UIGalaxySelect), "_OnUpdate")]
	private static void UIGalaxySelect__OnUpdate_Postfix()
	{
		ApplySettingLayout();
		if (!(_detailButton == null) && !(_darkFogRow == null) && !_detailButton.IsChildOf(_darkFogRow))
		{
			_detailButton.position = _darkFogRow.TransformPoint(_detailOffset);
		}
	}

	[HarmonyPostfix]
	[HarmonyPriority(0)]
	[HarmonyPatch(typeof(UIGalaxySelect), "_OnOpen")]
	private static void UIGalaxySelect__OnOpen_Postfix(UIGalaxySelect __instance)
	{
		CollectSettingRows(__instance);
		UIGalaxySelect__OnUpdate_Postfix();
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIGalaxySelect), "_OnOpen")]
	private static void UIGalaxySelect__OnOpen_Prefix(UIGalaxySelect __instance)
	{
		_minDist = 2.0;
		_minStep = 2.0;
		_maxStep = 3.2;
		_flatten = 0.18;
		RemoveAllListeners();
		UpdateSliderControls();
		AddListeners(__instance);
	}

	private static void RemoveAllListeners()
	{
		_minDistSlider.onValueChanged.RemoveAllListeners();
		_minStepSlider.onValueChanged.RemoveAllListeners();
		_maxStepSlider.onValueChanged.RemoveAllListeners();
		_flattenSlider.onValueChanged.RemoveAllListeners();
	}

	private static void AddListeners(UIGalaxySelect uiGalaxySelect)
	{
		_minDistSlider.onValueChanged.AddListener(delegate(float val)
		{
			double minDist = (double)Mathf.Round(val) / 10.0;
			if (!minDist.Equals(_minDist))
			{
				_minDist = minDist;
				_minDistText.text = _minDist.ToString();
				if (_minStep < _minDist)
				{
					_minStep = _minDist;
					_minStepSlider.value = (float)(_minStep * 10.0);
					_minStepText.text = _minStep.ToString();
					if (_maxStep < _minStep)
					{
						_maxStep = _minStep;
						_maxStepSlider.value = (float)(_maxStep * 10.0);
						_maxStepText.text = _maxStep.ToString();
					}
				}
				_minStepSlider.minValue = (float)(_minDist * 10.0);
				uiGalaxySelect.SetStarmapGalaxy();
			}
		});
		_minStepSlider.onValueChanged.AddListener(delegate(float val)
		{
			double num = (double)Mathf.Round(val) / 10.0;
			if (!num.Equals(_minStep))
			{
				_minStep = num;
				_maxStepSlider.minValue = (float)(num * 10.0);
				_minStepText.text = _minStep.ToString();
				uiGalaxySelect.SetStarmapGalaxy();
			}
		});
		_maxStepSlider.onValueChanged.AddListener(delegate(float val)
		{
			double num = (double)Mathf.Round(val) / 10.0;
			if (!num.Equals(_maxStep))
			{
				_maxStep = num;
				_minStepSlider.maxValue = (float)(num * 10.0);
				_maxStepText.text = _maxStep.ToString();
				uiGalaxySelect.SetStarmapGalaxy();
			}
		});
		_flattenSlider.onValueChanged.AddListener(delegate(float val)
		{
			double flatten = (double)Mathf.Round(val) / 50.0;
			if (!flatten.Equals(_flatten))
			{
				_flatten = flatten;
				_flattenText.text = _flatten.ToString();
				uiGalaxySelect.SetStarmapGalaxy();
			}
		});
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIGalaxySelect), "_OnUnregEvent")]
	private static void UIGalaxySelect__OnUnregEvent_Postfix()
	{
		_minDistSlider.onValueChanged.RemoveAllListeners();
		_minStepSlider.onValueChanged.RemoveAllListeners();
		_maxStepSlider.onValueChanged.RemoveAllListeners();
		_flattenSlider.onValueChanged.RemoveAllListeners();
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(UIGalaxySelect), "OnStarCountSliderValueChange")]
	private static IEnumerable<CodeInstruction> UIGalaxySelect_OnStarCountSliderValueChange_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
		codeMatcher.MatchForward(false, new CodeMatch((CodeInstruction ci) => ci.opcode == OpCodes.Ldc_I4_S && ci.OperandIs(80))).SetAndAdvance(OpCodes.Ldsfld, AccessTools.Field(typeof(MoreSettings), "MaxStarCount")).Insert(new CodeInstruction(OpCodes.Call, AccessTools.PropertyGetter(typeof(ConfigEntry<int>), "Value")));
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UICombatSettingsDF), "_OnCreate")]
	private static void UICombatSettingsDF__OnCreate_Postfix(UICombatSettingsDF __instance)
	{
		__instance.initLevelSlider.maxValue = 30f;
		__instance.initGrowthSlider.maxValue = 10f;
		__instance.initOccupiedSlider.maxValue = 10f;
		__instance.growthSpeedSlider.maxValue = 7f;
		__instance.powerThreatSlider.maxValue = 10f;
		__instance.combatThreatSlider.maxValue = 10f;
		__instance.DFExpSlider.maxValue = 10f;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UICombatSettingsDF), "OnInitLevelSliderChanged")]
	private static bool UICombatSettingsDF_OnInitLevelSliderChanged_Prefix(UICombatSettingsDF __instance)
	{
		_ = __instance.combatSettings;
		float value = __instance.initLevelSlider.value;
		float initialLevel = ((value < 0.5f) ? 0f : ((value < 1.5f) ? 1f : ((value < 2.5f) ? 2f : ((value < 3.5f) ? 3f : ((value < 4.5f) ? 4f : ((value < 5.5f) ? 5f : ((value < 6.5f) ? 6f : ((value < 7.5f) ? 7f : ((value < 8.5f) ? 8f : ((value < 9.5f) ? 9f : ((value < 10.5f) ? 10f : ((value < 11.5f) ? 11f : ((value < 12.5f) ? 12f : ((value < 13.5f) ? 13f : ((value < 14.5f) ? 14f : ((value < 15.5f) ? 15f : ((value < 16.5f) ? 16f : ((value < 17.5f) ? 17f : ((value < 18.5f) ? 18f : ((value < 19.5f) ? 19f : ((value < 20.5f) ? 20f : ((value < 21.5f) ? 21f : ((value < 22.5f) ? 22f : ((value < 23.5f) ? 23f : ((value < 24.5f) ? 24f : ((value < 25.5f) ? 25f : ((value < 26.5f) ? 26f : ((value < 27.5f) ? 27f : ((value < 28.5f) ? 28f : ((!(value < 29.5f)) ? 30f : 29f))))))))))))))))))))))))))))));
		__instance.combatSettings.initialLevel = initialLevel;
		__instance.UpdateUIParametersDisplay();
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UICombatSettingsDF), "OnInitGrowthSliderChanged")]
	private static bool UICombatSettingsDF_OnInitGrowthSliderChanged_Prefix(UICombatSettingsDF __instance)
	{
		_ = __instance.combatSettings;
		float value = __instance.initGrowthSlider.value;
		float initialGrowth = ((value < 0.5f) ? 0f : ((value < 1.5f) ? 0.25f : ((value < 2.5f) ? 0.5f : ((value < 3.5f) ? 0.75f : ((value < 4.5f) ? 1f : ((value < 5.5f) ? 1.5f : ((value < 6.5f) ? 2f : ((value < 7.5f) ? 2.5f : ((value < 8.5f) ? 3f : ((!(value < 9.5f)) ? 4f : 3.5f))))))))));
		__instance.combatSettings.initialGrowth = initialGrowth;
		__instance.UpdateUIParametersDisplay();
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UICombatSettingsDF), "OnInitOccupiedSliderChanged")]
	private static bool UICombatSettingsDF_OnInitOccupiedSliderChanged_Prefix(UICombatSettingsDF __instance)
	{
		_ = __instance.combatSettings;
		float value = __instance.initOccupiedSlider.value;
		float initialColonize = ((value < 0.5f) ? 0.01f : ((value < 1.5f) ? 0.25f : ((value < 2.5f) ? 0.5f : ((value < 3.5f) ? 0.75f : ((value < 4.5f) ? 1f : ((value < 5.5f) ? 1.5f : ((value < 6.5f) ? 2f : ((value < 7.5f) ? 2.5f : ((value < 8.5f) ? 3f : ((!(value < 9.5f)) ? 4f : 3.5f))))))))));
		__instance.combatSettings.initialColonize = initialColonize;
		__instance.UpdateUIParametersDisplay();
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UICombatSettingsDF), "OnGrowthSpeedSliderChanged")]
	private static bool UICombatSettingsDF_OnGrowthSpeedSliderChanged_Prefix(UICombatSettingsDF __instance)
	{
		_ = __instance.combatSettings;
		float value = __instance.growthSpeedSlider.value;
		float growthSpeedFactor = ((value < 0.5f) ? 0.25f : ((value < 1.5f) ? 0.5f : ((value < 2.5f) ? 1f : ((value < 3.5f) ? 2f : ((value < 4.5f) ? 3f : ((value < 5.5f) ? 4f : ((!(value < 6.5f)) ? 6f : 5f)))))));
		__instance.combatSettings.growthSpeedFactor = growthSpeedFactor;
		__instance.UpdateUIParametersDisplay();
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UICombatSettingsDF), "OnPowerThreatSliderChanged")]
	private static bool UICombatSettingsDF_OnPowerThreatSliderChanged_Prefix(UICombatSettingsDF __instance)
	{
		_ = __instance.combatSettings;
		float value = __instance.powerThreatSlider.value;
		float powerThreatFactor = ((value < 0.5f) ? 0.01f : ((value < 1.5f) ? 0.1f : ((value < 2.5f) ? 0.2f : ((value < 3.5f) ? 0.5f : ((value < 4.5f) ? 1f : ((value < 5.5f) ? 2f : ((value < 6.5f) ? 5f : ((value < 7.5f) ? 8f : ((value < 8.5f) ? 10f : ((!(value < 9.5f)) ? 20f : 15f))))))))));
		__instance.combatSettings.powerThreatFactor = powerThreatFactor;
		__instance.UpdateUIParametersDisplay();
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UICombatSettingsDF), "OnCombatThreatSliderChanged")]
	private static bool UICombatSettingsDF_OnCombatThreatSliderChanged_Prefix(UICombatSettingsDF __instance)
	{
		_ = __instance.combatSettings;
		float value = __instance.combatThreatSlider.value;
		float battleThreatFactor = ((value < 0.5f) ? 0.01f : ((value < 1.5f) ? 0.1f : ((value < 2.5f) ? 0.2f : ((value < 3.5f) ? 0.5f : ((value < 4.5f) ? 1f : ((value < 5.5f) ? 2f : ((value < 6.5f) ? 5f : ((value < 7.5f) ? 8f : ((value < 8.5f) ? 10f : ((!(value < 9.5f)) ? 20f : 15f))))))))));
		__instance.combatSettings.battleThreatFactor = battleThreatFactor;
		__instance.UpdateUIParametersDisplay();
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UICombatSettingsDF), "OnEXPSliderChanged")]
	private static bool UICombatSettingsDF_OnEXPSliderChanged_Prefix(UICombatSettingsDF __instance)
	{
		_ = __instance.combatSettings;
		float value = __instance.DFExpSlider.value;
		float battleExpFactor = ((value < 0.5f) ? 0.01f : ((value < 1.5f) ? 0.1f : ((value < 2.5f) ? 0.2f : ((value < 3.5f) ? 0.5f : ((value < 4.5f) ? 1f : ((value < 5.5f) ? 2f : ((value < 6.5f) ? 5f : ((value < 7.5f) ? 8f : ((value < 8.5f) ? 10f : ((!(value < 9.5f)) ? 20f : 15f))))))))));
		__instance.combatSettings.battleExpFactor = battleExpFactor;
		__instance.UpdateUIParametersDisplay();
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UICombatSettingsDF), "UpdateUIParametersDisplay")]
	private static bool UICombatSettingsDF_UpdateUIParametersDisplay_Prefix(UICombatSettingsDF __instance)
	{
		string text = "";
		Slider aggresiveSlider = __instance.aggresiveSlider;
		float aggressiveness = __instance.combatSettings.aggressiveness;
		float value = ((aggressiveness < -0.99f) ? 0f : ((aggressiveness < 0.01f) ? 1f : ((aggressiveness < 0.51f) ? 2f : ((aggressiveness < 1.01f) ? 3f : ((!(aggressiveness < 2.01f)) ? 5f : 4f)))));
		aggresiveSlider.value = value;
		text = (int)(__instance.aggresiveSlider.value + 0.5f) switch
		{
			0 => "活靶子".Translate(), 
			1 => "被动".Translate(), 
			2 => "消极".Translate(), 
			3 => "正常".Translate(), 
			4 => "积极".Translate(), 
			5 => "狂暴".Translate(), 
			_ => text, 
		};
		__instance.aggresiveText.text = text;
		float initialLevel = __instance.combatSettings.initialLevel;
		Slider initLevelSlider = __instance.initLevelSlider;
		aggressiveness = ((initialLevel < 0.01f) ? 0f : ((initialLevel < 1.01f) ? 1f : ((initialLevel < 2.01f) ? 2f : ((initialLevel < 3.01f) ? 3f : ((initialLevel < 4.01f) ? 4f : ((initialLevel < 5.01f) ? 5f : ((initialLevel < 6.01f) ? 6f : ((initialLevel < 7.01f) ? 7f : ((initialLevel < 8.01f) ? 8f : ((initialLevel < 9.01f) ? 9f : ((initialLevel < 10.01f) ? 10f : ((initialLevel < 11.01f) ? 11f : ((initialLevel < 12.01f) ? 12f : ((initialLevel < 13.01f) ? 13f : ((initialLevel < 14.01f) ? 14f : ((initialLevel < 15.01f) ? 15f : ((initialLevel < 16.01f) ? 16f : ((initialLevel < 17.01f) ? 17f : ((initialLevel < 18.01f) ? 18f : ((initialLevel < 19.01f) ? 19f : ((initialLevel < 20.01f) ? 20f : ((initialLevel < 21.01f) ? 21f : ((initialLevel < 22.01f) ? 22f : ((initialLevel < 23.01f) ? 23f : ((initialLevel < 24.01f) ? 24f : ((initialLevel < 25.01f) ? 25f : ((initialLevel < 26.01f) ? 26f : ((initialLevel < 27.01f) ? 27f : ((initialLevel < 28.01f) ? 28f : ((!(initialLevel < 29.01f)) ? 30f : 29f))))))))))))))))))))))))))))));
		initLevelSlider.value = aggressiveness;
		__instance.initLevelText.text = initialLevel.ToString();
		initialLevel = __instance.combatSettings.initialGrowth;
		Slider initGrowthSlider = __instance.initGrowthSlider;
		aggressiveness = ((initialLevel < 0.01f) ? 0f : ((initialLevel < 0.26f) ? 1f : ((initialLevel < 0.51f) ? 2f : ((initialLevel < 0.76f) ? 3f : ((initialLevel < 1.01f) ? 4f : ((initialLevel < 1.51f) ? 5f : ((initialLevel < 2.01f) ? 6f : ((initialLevel < 2.51f) ? 7f : ((initialLevel < 3.01f) ? 8f : ((!(initialLevel < 3.51f)) ? 10f : 9f))))))))));
		initGrowthSlider.value = aggressiveness;
		text = initialLevel * 100f + "%";
		__instance.initGrowthText.text = text;
		initialLevel = __instance.combatSettings.initialColonize;
		Slider initOccupiedSlider = __instance.initOccupiedSlider;
		aggressiveness = ((initialLevel < 0.02f) ? 0f : ((initialLevel < 0.26f) ? 1f : ((initialLevel < 0.51f) ? 2f : ((initialLevel < 0.76f) ? 3f : ((initialLevel < 1.01f) ? 4f : ((initialLevel < 1.51f) ? 5f : ((initialLevel < 2.01f) ? 6f : ((initialLevel < 2.51f) ? 7f : ((initialLevel < 3.01f) ? 8f : ((!(initialLevel < 3.51f)) ? 10f : 9f))))))))));
		initOccupiedSlider.value = aggressiveness;
		text = initialLevel * 100f + "%";
		__instance.initOccupiedText.text = text;
		initialLevel = __instance.combatSettings.maxDensity;
		Slider maxDensitySlider = __instance.maxDensitySlider;
		aggressiveness = ((initialLevel < 1.01f) ? 0f : ((initialLevel < 1.51f) ? 1f : ((initialLevel < 2.01f) ? 2f : ((!(initialLevel < 2.51f)) ? 4f : 3f))));
		maxDensitySlider.value = aggressiveness;
		text = initialLevel + "x";
		__instance.maxDensityText.text = text;
		initialLevel = __instance.combatSettings.growthSpeedFactor;
		Slider growthSpeedSlider = __instance.growthSpeedSlider;
		aggressiveness = ((initialLevel < 0.26f) ? 0f : ((initialLevel < 0.51f) ? 1f : ((initialLevel < 1.01f) ? 2f : ((initialLevel < 2.01f) ? 3f : ((initialLevel < 3.01f) ? 4f : ((initialLevel < 4.01f) ? 5f : ((!(initialLevel < 5.01f)) ? 7f : 6f)))))));
		growthSpeedSlider.value = aggressiveness;
		text = initialLevel * 100f + "%";
		__instance.growthSpeedText.text = text;
		initialLevel = __instance.combatSettings.powerThreatFactor;
		Slider powerThreatSlider = __instance.powerThreatSlider;
		aggressiveness = ((initialLevel < 0.02f) ? 0f : ((initialLevel < 0.11f) ? 1f : ((initialLevel < 0.21000001f) ? 2f : ((initialLevel < 0.51f) ? 3f : ((initialLevel < 1.01f) ? 4f : ((initialLevel < 2.01f) ? 5f : ((initialLevel < 5.01f) ? 6f : ((initialLevel < 8.01f) ? 7f : ((initialLevel < 10.01f) ? 8f : ((!(initialLevel < 15.01f)) ? 10f : 9f))))))))));
		powerThreatSlider.value = aggressiveness;
		text = initialLevel * 100f + "%";
		__instance.powerThreatText.text = text;
		initialLevel = __instance.combatSettings.battleThreatFactor;
		Slider combatThreatSlider = __instance.combatThreatSlider;
		aggressiveness = ((initialLevel < 0.02f) ? 0f : ((initialLevel < 0.11f) ? 1f : ((initialLevel < 0.21000001f) ? 2f : ((initialLevel < 0.51f) ? 3f : ((initialLevel < 1.01f) ? 4f : ((initialLevel < 2.01f) ? 5f : ((initialLevel < 5.01f) ? 6f : ((initialLevel < 8.01f) ? 7f : ((initialLevel < 10.01f) ? 8f : ((!(initialLevel < 15.01f)) ? 10f : 9f))))))))));
		combatThreatSlider.value = aggressiveness;
		text = initialLevel * 100f + "%";
		__instance.combatThreatText.text = text;
		initialLevel = __instance.combatSettings.battleExpFactor;
		Slider dFExpSlider = __instance.DFExpSlider;
		aggressiveness = ((initialLevel < 0.02f) ? 0f : ((initialLevel < 0.11f) ? 1f : ((initialLevel < 0.21000001f) ? 2f : ((initialLevel < 0.51f) ? 3f : ((initialLevel < 1.01f) ? 4f : ((initialLevel < 2.01f) ? 5f : ((initialLevel < 5.01f) ? 6f : ((initialLevel < 8.01f) ? 7f : ((initialLevel < 10.01f) ? 8f : ((!(initialLevel < 15.01f)) ? 10f : 9f))))))))));
		dFExpSlider.value = aggressiveness;
		text = initialLevel * 100f + "%";
		__instance.DFExpText.text = text;
		GameDesc gameDesc = new GameDesc();
		float difficulty = __instance.combatSettings.difficulty;
		string arg = ((difficulty >= 9.9999f) ? difficulty.ToString("0.00") : difficulty.ToString("0.000"));
		__instance.difficultyText.text = string.Format("难度系数值".Translate(), arg);
		__instance.difficultTipGroupDF.SetActive((__instance.combatSettings.aggressiveLevel == EAggressiveLevel.Rampage && difficulty > 4.5f) || difficulty > 6f);
		__instance.gameDesc.CopyTo(gameDesc);
		gameDesc.combatSettings = __instance.combatSettings;
		__instance.propertyMultiplierText.text = "元数据生成倍率".Translate() + " " + gameDesc.propertyMultiplier.ToString("0%");
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(CombatSettings), "difficulty", MethodType.Getter)]
	private static bool CombatSettings_difficulty_Getter_Prefix(CombatSettings __instance, ref float __result)
	{
		float aggressiveness = __instance.aggressiveness;
		float num = ((aggressiveness < -0.1f) ? (-0.2f) : ((aggressiveness < 0.25f) ? 0f : ((aggressiveness < 0.75f) ? 0.5f : ((aggressiveness < 1.5f) ? 0.75f : ((!(aggressiveness < 2.5f)) ? 1.125f : 0.875f)))));
		float num2 = num;
		float num3 = __instance.initialLevel * 0.8f;
		num = __instance.initialGrowth;
		aggressiveness = ((num < 0.15f) ? 0f : ((num < 0.3f) ? 0.25f : ((num < 0.65f) ? 0.5f : ((num < 0.8f) ? 0.75f : ((num < 1.15f) ? 1f : ((num < 1.65f) ? 1.25f : ((num < 2.15f) ? 1.5f : ((num < 2.65f) ? 1.75f : ((num < 3.15f) ? 2f : ((!(num < 3.65f)) ? 2.5f : 2.25f))))))))));
		float num4 = aggressiveness;
		aggressiveness = __instance.initialColonize;
		num = ((aggressiveness < 0.15f) ? 0f : ((aggressiveness < 0.3f) ? 0.25f : ((aggressiveness < 0.65f) ? 0.5f : ((aggressiveness < 0.8f) ? 0.75f : ((aggressiveness < 1.15f) ? 1f : ((aggressiveness < 1.65f) ? 1.25f : ((aggressiveness < 2.15f) ? 1.5f : ((aggressiveness < 2.65f) ? 1.75f : ((aggressiveness < 3.15f) ? 2f : ((!(aggressiveness < 3.65f)) ? 2.5f : 2.25f))))))))));
		float num5 = num;
		float num6 = __instance.maxDensity - 1f;
		num = __instance.growthSpeedFactor;
		aggressiveness = ((num < 0.35f) ? 0.3f : ((num < 0.75f) ? 0.7f : ((num < 1.5f) ? 1f : ((num < 2.5f) ? 1.2f : ((num < 3.5f) ? 1.5f : ((num < 4.5f) ? 1.6f : ((!(num < 5.5f)) ? 2f : 1.8f)))))));
		float num7 = aggressiveness;
		aggressiveness = __instance.powerThreatFactor;
		num = ((aggressiveness < 0.05f) ? 0.125f : ((aggressiveness < 0.15f) ? 0.3f : ((aggressiveness < 0.25f) ? 0.6f : ((aggressiveness < 0.55f) ? 0.8f : ((aggressiveness < 1.15f) ? 1f : ((aggressiveness < 2.15f) ? 1.2f : ((aggressiveness < 5.15f) ? 1.5f : ((aggressiveness < 8.15f) ? 1.8f : ((aggressiveness < 10.15f) ? 2f : ((!(aggressiveness < 15.15f)) ? 3f : 2.5f))))))))));
		float num8 = num;
		num = __instance.battleThreatFactor;
		aggressiveness = ((num < 0.05f) ? 0.125f : ((num < 0.15f) ? 0.3f : ((num < 0.25f) ? 0.6f : ((num < 0.55f) ? 0.8f : ((num < 1.15f) ? 1f : ((num < 2.15f) ? 1.2f : ((num < 5.15f) ? 1.5f : ((num < 8.15f) ? 1.8f : ((num < 10.15f) ? 2f : ((!(num < 15.15f)) ? 3f : 2.5f))))))))));
		float num9 = aggressiveness;
		aggressiveness = __instance.battleExpFactor;
		num = ((aggressiveness < 0.05f) ? 0f : ((aggressiveness < 0.15f) ? 1f : ((aggressiveness < 0.25f) ? 3f : ((aggressiveness < 0.55f) ? 6f : ((aggressiveness < 1.15f) ? 10f : ((aggressiveness < 2.15f) ? 12f : ((aggressiveness < 5.15f) ? 14f : ((aggressiveness < 8.15f) ? 16f : ((aggressiveness < 10.15f) ? 18f : ((!(aggressiveness < 15.15f)) ? 20f : 19f))))))))));
		float num10 = num;
		float num11 = ((num2 < 0f) ? 0f : (0.25f + num2 * (num8 * 0.5f + num9 * 0.5f)));
		float num12 = 0.375f + 0.625f * ((num3 + num10) / 10f);
		float num13 = 0.375f + 0.625f * ((num5 * 0.6f + num4 * 0.4f * (num5 * 0.75f + 0.25f)) * 0.6f + num7 * 0.4f * (num5 * 0.8f + 0.2f) + num6 * 0.29f * (num5 * 0.5f + 0.5f));
		__result = (float)(int)(num11 * num12 * num13 * 10000f + 0.5f) / 10000f;
		return false;
	}

	public static void Export(BinaryWriter w)
	{
		w.Write(_gameMinDist);
		w.Write(_gameMinStep);
		w.Write(_gameMaxStep);
		w.Write(_gameFlatten);
	}

	public static void Import(BinaryReader r)
	{
		_gameMinDist = r.ReadDouble();
		_gameMinStep = r.ReadDouble();
		_gameMaxStep = r.ReadDouble();
		_gameFlatten = r.ReadDouble();
	}
}
