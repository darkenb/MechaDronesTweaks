using System;
using System.Collections.Generic;
using BepInEx.Configuration;
using HarmonyLib;
using UXAssist.Common;

namespace UniverseGenTweaks;

public static class BirthPlanetPatch
{
	private struct BackupData
	{
		private bool _inited;

		private int[] _algos;

		private int[] _veinSpot;

		private float[] _veinCount;

		private float[] _veinOpacity;

		private int[] _rareVeins;

		private float[] _rareSettings;

		private float _specifyBirthStarMass;

		private float _specifyBirthStarAge;

		public void FromTheme(ThemeProto theme)
		{
			_algos = theme.Algos.Clone() as int[];
			_veinSpot = theme.VeinSpot.Clone() as int[];
			_veinCount = theme.VeinCount.Clone() as float[];
			_veinOpacity = theme.VeinOpacity.Clone() as float[];
			_rareVeins = theme.RareVeins.Clone() as int[];
			_rareSettings = theme.RareSettings.Clone() as float[];
			_specifyBirthStarMass = StarGen.specifyBirthStarMass;
			_specifyBirthStarAge = StarGen.specifyBirthStarAge;
			_inited = true;
		}

		public void ToTheme(ThemeProto theme)
		{
			if (_inited)
			{
				theme.Algos = _algos.Clone() as int[];
				theme.VeinSpot = _veinSpot.Clone() as int[];
				theme.VeinCount = _veinCount.Clone() as float[];
				theme.VeinOpacity = _veinOpacity.Clone() as float[];
				theme.RareVeins = _rareVeins.Clone() as int[];
				theme.RareSettings = _rareSettings.Clone() as float[];
				StarGen.specifyBirthStarMass = _specifyBirthStarMass;
				StarGen.specifyBirthStarAge = _specifyBirthStarAge;
			}
		}
	}

	public static ConfigEntry<bool> SitiVeinsOnBirthPlanet;

	public static ConfigEntry<bool> FireIceOnBirthPlanet;

	public static ConfigEntry<bool> KimberliteOnBirthPlanet;

	public static ConfigEntry<bool> FractalOnBirthPlanet;

	public static ConfigEntry<bool> OrganicOnBirthPlanet;

	public static ConfigEntry<bool> OpticalOnBirthPlanet;

	public static ConfigEntry<bool> SpiniformOnBirthPlanet;

	public static ConfigEntry<bool> UnipolarOnBirthPlanet;

	public static ConfigEntry<bool> FlatBirthPlanet;

	public static ConfigEntry<bool> HighLuminosityBirthStar;

	private static BackupData _backupData;

	private static bool _initialized;

	private static Harmony _patch;

	public static void Init()
	{
		SitiVeinsOnBirthPlanet.SettingChanged += delegate
		{
			PatchBirthThemeData();
		};
		FireIceOnBirthPlanet.SettingChanged += delegate
		{
			PatchBirthThemeData();
		};
		KimberliteOnBirthPlanet.SettingChanged += delegate
		{
			PatchBirthThemeData();
		};
		FractalOnBirthPlanet.SettingChanged += delegate
		{
			PatchBirthThemeData();
		};
		OrganicOnBirthPlanet.SettingChanged += delegate
		{
			PatchBirthThemeData();
		};
		OpticalOnBirthPlanet.SettingChanged += delegate
		{
			PatchBirthThemeData();
		};
		SpiniformOnBirthPlanet.SettingChanged += delegate
		{
			PatchBirthThemeData();
		};
		UnipolarOnBirthPlanet.SettingChanged += delegate
		{
			PatchBirthThemeData();
		};
		FlatBirthPlanet.SettingChanged += delegate
		{
			PatchBirthThemeData();
		};
		HighLuminosityBirthStar.SettingChanged += delegate
		{
			PatchBirthThemeData();
		};
		PatchBirthThemeData();
		if (_patch == null)
		{
			_patch = Harmony.CreateAndPatchAll(typeof(BirthPlanetPatch));
		}
		GameLogic.OnDataLoaded = (Action)Delegate.Combine(GameLogic.OnDataLoaded, new Action(VFPreload_InvokeOnLoadWorkEnded_Postfix));
	}

	public static void Uninit()
	{
		GameLogic.OnDataLoaded = (Action)Delegate.Remove(GameLogic.OnDataLoaded, new Action(VFPreload_InvokeOnLoadWorkEnded_Postfix));
		_patch?.UnpatchSelf();
		_patch = null;
	}

	private static void VFPreload_InvokeOnLoadWorkEnded_Postfix()
	{
		PatchBirthThemeData();
	}

	private static void PatchBirthThemeData()
	{
		ThemeProto themeProto = LDB.themes.Select(1);
		if (!_initialized)
		{
			_backupData.FromTheme(themeProto);
		}
		else
		{
			_backupData.ToTheme(themeProto);
		}
		if (FlatBirthPlanet.Value)
		{
			themeProto.Algos[0] = 2;
		}
		if (SitiVeinsOnBirthPlanet.Value)
		{
			themeProto.VeinSpot[2] = 2;
			themeProto.VeinSpot[3] = 2;
			themeProto.VeinCount[2] = 0.7f;
			themeProto.VeinCount[3] = 0.7f;
			themeProto.VeinOpacity[2] = 1f;
			themeProto.VeinOpacity[3] = 1f;
		}
		List<int> list = new List<int>();
		List<float> list2 = new List<float>();
		if (FireIceOnBirthPlanet.Value)
		{
			list.Add(8);
			list2.AddRange(new float[4] { 1f, 1f, 0.5f, 1f });
		}
		if (KimberliteOnBirthPlanet.Value)
		{
			list.Add(9);
			list2.AddRange(new float[4] { 1f, 1f, 0.5f, 1f });
		}
		if (FractalOnBirthPlanet.Value)
		{
			list.Add(10);
			list2.AddRange(new float[4] { 1f, 1f, 0.5f, 1f });
		}
		if (OrganicOnBirthPlanet.Value)
		{
			list.Add(11);
			list2.AddRange(new float[4] { 1f, 1f, 0.5f, 1f });
		}
		if (OpticalOnBirthPlanet.Value)
		{
			list.Add(12);
			list2.AddRange(new float[4] { 1f, 1f, 0.5f, 1f });
		}
		if (SpiniformOnBirthPlanet.Value)
		{
			list.Add(13);
			list2.AddRange(new float[4] { 1f, 1f, 0.5f, 1f });
		}
		if (UnipolarOnBirthPlanet.Value)
		{
			list.Add(14);
			list2.AddRange(new float[4] { 1f, 1f, 0.5f, 1f });
		}
		if (list.Count > 0)
		{
			themeProto.RareVeins = list.ToArray();
			themeProto.RareSettings = list2.ToArray();
		}
		if (HighLuminosityBirthStar.Value)
		{
			StarGen.specifyBirthStarMass = 53.81f;
			StarGen.specifyBirthStarAge = 0.01f;
		}
		_initialized = true;
	}
}
