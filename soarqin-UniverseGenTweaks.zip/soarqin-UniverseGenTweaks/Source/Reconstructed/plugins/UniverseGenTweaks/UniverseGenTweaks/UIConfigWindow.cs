using System;
using UXAssist.Common;
using UXAssist.UI;
using UnityEngine;

namespace UniverseGenTweaks;

public static class UIConfigWindow
{
	private static RectTransform _windowTrans;

	public static void Init()
	{
		I18N.Add("UniverseGen", "UniverseGen", "宇宙生成");
		I18N.Add("Birth Star", "Birth Star", "母星系");
		I18N.Add("Enable more settings on UniverseGen", "Enable more settings on UniverseGen", "启用更多宇宙生成设置");
		I18N.Add("* Requires game restart to take effect", "* Requires game restart to take effect", "* 需要重启游戏才能生效");
		I18N.Add("Maximum star count", "Maximum star count", "最大恒星数");
		I18N.Add("Enable Epic difficulty", "Enable Epic difficulty", "启用史诗难度");
		I18N.Add("Resource multiplier", "Resource multiplier", "资源倍率");
		I18N.Add("Oil multiplier (relative to Very Hard)", "Oil multiplier (relative to Very Hard)", "石油倍率（相对于非常困难）");
		I18N.Add("Silicon/Titanium on birth planet", "Silicon/Titanium on birth planet", "母星有硅和钛");
		I18N.Add("Fire ice on birth planet", "Fire ice on birth planet", "母星有可燃冰");
		I18N.Add("Kimberlite on birth planet", "Kimberlite on birth planet", "母星有金伯利矿");
		I18N.Add("Fractal silicon on birth planet", "Fractal silicon on birth planet", "母星有分形硅");
		I18N.Add("Organic crystal on birth planet", "Organic crystal on birth planet", "母星有有机晶体");
		I18N.Add("Optical grating crystal on birth planet", "Optical grating crystal on birth planet", "母星有光栅石");
		I18N.Add("Spiniform stalagmite crystal on birth planet", "Spiniform stalagmite crystal on birth planet", "母星有刺笋结晶");
		I18N.Add("Unipolar magnet on birth planet", "Unipolar magnet on birth planet", "母星有单极磁石");
		I18N.Add("Birth planet is solid flat (no water at all)", "Birth planet is solid flat (no water at all)", "母星是纯平的（没有水）");
		I18N.Add("Birth star has high luminosity", "Birth star has high luminosity", "母星系恒星高亮");
		I18N.Apply();
		MyConfigWindow.OnUICreated = (Action<MyConfigWindow, RectTransform>)Delegate.Combine(MyConfigWindow.OnUICreated, new Action<MyConfigWindow, RectTransform>(CreateUI));
	}

	private static void CreateUI(MyConfigWindow wnd, RectTransform trans)
	{
		_windowTrans = trans;
		float num = 0f;
		float num2 = 10f;
		((MyWindowWithTabs)wnd).AddSplitter(trans, 10f);
		((MyWindowWithTabs)wnd).AddTabGroup(trans, "UniverseGen", "tab-group-galaxygen");
		RectTransform rectTransform = ((MyWindowWithTabs)wnd).AddTab(_windowTrans, "General");
		MyCheckBox.CreateCheckBox(num, num2, rectTransform, MoreSettings.Enabled, "Enable more settings on UniverseGen", 15);
		num += 20f;
		num2 += 26f;
		MyWindow.AddText(num, num2, rectTransform, "* Requires game restart to take effect", 13, "label");
		num -= 20f;
		num2 += 36f;
		num += 10f;
		MyWindow.AddText(num, num2, rectTransform, "Maximum star count", 16, "label");
		num += 20f;
		num2 += 26f;
		MySlider sl0 = MySlider.CreateSlider(num, num2, rectTransform, (float)MoreSettings.MaxStarCount.Value, 64f, 1024f, "G", 240f);
		sl0.OnValueChanged += delegate
		{
			MySlider obj = sl0;
			int num4 = (MoreSettings.MaxStarCount.Value = (Mathf.RoundToInt(sl0.Value) + 7) & -8);
			obj.Value = num4;
		};
		num -= 30f;
		num2 += 36f;
		MyCheckBox.CreateCheckBox(num, num2, rectTransform, EpicDifficulty.Enabled, "Enable Epic difficulty", 15);
		num2 += 36f;
		num += 10f;
		MyWindow.AddText(num, num2, rectTransform, "Resource multiplier", 16, "label");
		num += 20f;
		num2 += 26f;
		int num3 = EpicDifficulty.ResourceMultiplierToIndex(EpicDifficulty.ResourceMultiplier.Value);
		MySlider sl1 = MySlider.CreateSlider(num, num2, rectTransform, (float)num3, 0f, (float)EpicDifficulty.ResourceMultipliersCount() - 1f, "G", 240f);
		sl1.SetLabelText(EpicDifficulty.IndexToResourceMultiplier(Mathf.RoundToInt(sl1.Value)).ToString(sl1.labelFormat));
		sl1.OnValueChanged += delegate
		{
			float value = EpicDifficulty.IndexToResourceMultiplier(Mathf.RoundToInt(sl1.Value));
			EpicDifficulty.ResourceMultiplier.Value = value;
			sl1.SetLabelText(value.ToString(sl1.labelFormat));
		};
		num -= 30f;
		num2 += 31f;
		num += 10f;
		MyWindow.AddText(num, num2, rectTransform, "Oil multiplier (relative to Very Hard)", 16, "label");
		num += 20f;
		num2 += 26f;
		num3 = EpicDifficulty.OilMultiplierToIndex(EpicDifficulty.OilMultiplier.Value);
		MySlider sl2 = MySlider.CreateSlider(num, num2, rectTransform, (float)num3, 0f, (float)EpicDifficulty.OilMultipliersCount() - 1f, "G", 240f);
		sl2.SetLabelText(EpicDifficulty.IndexToOilMultiplier(Mathf.RoundToInt(sl2.Value)).ToString(sl2.labelFormat));
		sl2.OnValueChanged += delegate
		{
			float value = EpicDifficulty.IndexToOilMultiplier(Mathf.RoundToInt(sl2.Value));
			EpicDifficulty.OilMultiplier.Value = value;
			sl2.SetLabelText(value.ToString(sl2.labelFormat));
		};
		RectTransform rectTransform2 = ((MyWindowWithTabs)wnd).AddTab(_windowTrans, "Birth Star");
		num = 0f;
		num2 = 10f;
		MyCheckBox.CreateCheckBox(num, num2, rectTransform2, BirthPlanetPatch.SitiVeinsOnBirthPlanet, "Silicon/Titanium on birth planet", 15);
		num2 += 36f;
		MyCheckBox.CreateCheckBox(num, num2, rectTransform2, BirthPlanetPatch.FireIceOnBirthPlanet, "Fire ice on birth planet", 15);
		num2 += 36f;
		MyCheckBox.CreateCheckBox(num, num2, rectTransform2, BirthPlanetPatch.KimberliteOnBirthPlanet, "Kimberlite on birth planet", 15);
		num2 += 36f;
		MyCheckBox.CreateCheckBox(num, num2, rectTransform2, BirthPlanetPatch.FractalOnBirthPlanet, "Fractal silicon on birth planet", 15);
		num2 += 36f;
		MyCheckBox.CreateCheckBox(num, num2, rectTransform2, BirthPlanetPatch.OrganicOnBirthPlanet, "Organic crystal on birth planet", 15);
		num2 += 36f;
		MyCheckBox.CreateCheckBox(num, num2, rectTransform2, BirthPlanetPatch.OpticalOnBirthPlanet, "Optical grating crystal on birth planet", 15);
		num2 += 36f;
		MyCheckBox.CreateCheckBox(num, num2, rectTransform2, BirthPlanetPatch.SpiniformOnBirthPlanet, "Spiniform stalagmite crystal on birth planet", 15);
		num2 += 36f;
		MyCheckBox.CreateCheckBox(num, num2, rectTransform2, BirthPlanetPatch.UnipolarOnBirthPlanet, "Unipolar magnet on birth planet", 15);
		num = 300f;
		num2 = 10f;
		MyCheckBox.CreateCheckBox(num, num2, rectTransform2, BirthPlanetPatch.FlatBirthPlanet, "Birth planet is solid flat (no water at all)", 15);
		num2 += 36f;
		MyCheckBox.CreateCheckBox(num, num2, rectTransform2, BirthPlanetPatch.HighLuminosityBirthStar, "Birth star has high luminosity", 15);
	}
}
