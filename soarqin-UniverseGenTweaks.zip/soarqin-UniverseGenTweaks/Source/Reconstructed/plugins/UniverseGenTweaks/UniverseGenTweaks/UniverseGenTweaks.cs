using System.IO;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using crecheng.DSPModSave;

namespace UniverseGenTweaks;

[BepInPlugin("org.soardev.universegentweaks", "UniverseGenTweaks", "1.2.14")]
[BepInDependency("org.soardev.uxassist", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[ModSaveSettings(/*Could not decode attribute arguments.*/)]
public class UniverseGenTweaks : BaseUnityPlugin, IModCanSave
{
	public new static readonly ManualLogSource Logger = BepInEx.Logging.Logger.CreateLogSource("UniverseGenTweaks");

	private const ushort ModSaveVersion = 1;

	private void Awake()
	{
		MoreSettings.Enabled = base.Config.Bind("MoreSettings", "Enabled", defaultValue: true, "Enable more settings on Universe Generation");
		MoreSettings.MaxStarCount = base.Config.Bind("MoreSettings", "MaxStarCount", 128, new ConfigDescription("(32 ~ 1024)\nMaximum star count for Universe Generation, enable MoreSettings.Enabled to take effect", new AcceptableValueRange<int>(32, 1024), new { }));
		EpicDifficulty.Enabled = base.Config.Bind("EpicDifficulty", "Enabled", defaultValue: true, "Enable Epic difficulty");
		EpicDifficulty.ResourceMultiplier = base.Config.Bind("EpicDifficulty", "ResourceMultiplier", 0.01f, new ConfigDescription("Resource multiplier for Epic difficulty", new AcceptableValueRange<float>(0.0001f, 0.05f), new { }));
		EpicDifficulty.OilMultiplier = base.Config.Bind("EpicDifficulty", "OilMultiplier", 0.5f, new ConfigDescription("Oil multiplier for Epic difficulty relative to the Very-Hard difficulty", new AcceptableValueRange<float>(0.1f, 1f), new { }));
		BirthPlanetPatch.SitiVeinsOnBirthPlanet = base.Config.Bind("Birth", "SiTiVeinsOnBirthPlanet", defaultValue: false, "Silicon/Titanium on birth planet");
		BirthPlanetPatch.FireIceOnBirthPlanet = base.Config.Bind("Birth", "FireIceOnBirthPlanet", defaultValue: false, "Fire ice on birth planet");
		BirthPlanetPatch.KimberliteOnBirthPlanet = base.Config.Bind("Birth", "KimberliteOnBirthPlanet", defaultValue: false, "Kimberlite on birth planet");
		BirthPlanetPatch.FractalOnBirthPlanet = base.Config.Bind("Birth", "FractalOnBirthPlanet", defaultValue: false, "Fractal silicon on birth planet");
		BirthPlanetPatch.OrganicOnBirthPlanet = base.Config.Bind("Birth", "OrganicOnBirthPlanet", defaultValue: false, "Organic crystal on birth planet");
		BirthPlanetPatch.OpticalOnBirthPlanet = base.Config.Bind("Birth", "OpticalOnBirthPlanet", defaultValue: false, "Optical grating crystal on birth planet");
		BirthPlanetPatch.SpiniformOnBirthPlanet = base.Config.Bind("Birth", "SpiniformOnBirthPlanet", defaultValue: false, "Spiniform stalagmite crystal on birth planet");
		BirthPlanetPatch.UnipolarOnBirthPlanet = base.Config.Bind("Birth", "UnipolarOnBirthPlanet", defaultValue: false, "Unipolar magnet on birth planet");
		BirthPlanetPatch.FlatBirthPlanet = base.Config.Bind("Birth", "FlatBirthPlanet", defaultValue: false, "Birth planet is solid flat (no water at all)");
		BirthPlanetPatch.HighLuminosityBirthStar = base.Config.Bind("Birth", "HighLuminosityBirthStar", defaultValue: false, "Birth star has high luminosity");
		UIConfigWindow.Init();
		MoreSettings.Init();
		EpicDifficulty.Init();
		BirthPlanetPatch.Init();
	}

	private void OnDestroy()
	{
		BirthPlanetPatch.Uninit();
		EpicDifficulty.Uninit();
		MoreSettings.Uninit();
	}

	public void Export(BinaryWriter w)
	{
		w.Write((ushort)1);
		MoreSettings.Export(w);
	}

	public void Import(BinaryReader r)
	{
		if (r.ReadUInt16() > 0)
		{
			MoreSettings.Import(r);
		}
	}

	public void IntoOtherSave()
	{
	}
}
