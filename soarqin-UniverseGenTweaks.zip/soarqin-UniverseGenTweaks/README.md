# soarqin-UniverseGenTweaks

Lay out UGT, Genesis, Battle and native new-game rows together without accumulating offsets or changing settings.

The analysis and proposed fixes in this handoff were developed with assistance from the GPT 6.1 Sol model. English documentation accompanies the code to explain what changed, why it changed, and the available validation results.

[Review map](REVIEW_GUIDE.md) · [Related mods and code references](RELATED_MODS.md) · [Detailed changes](CHANGELOG.md) · [Build/review notes](BUILD.md) · [Assembly metadata](metadata.json)

Prepared for maintainer review on 15 October 2026. This is a local modified build, not an official upstream release, published package or pull request.

Installed plugin version(s): **1.2.14**. Existing package manifest version: **1.2.11**. Manifest, plugin and assembly versions are separate; the original manifest is retained.

## Package layout

- `InstalledPackage/`: recorded installed files, subject to the explicit size exclusions in PACKAGING.md; not a complete installation package.
- `Source/Reconstructed/`: full projects reconstructed from the exact installed assemblies.
- `Source/EarlierWorkingSource/`, `PortedWorkingSource/`, `UpstreamSnapshot/`: source snapshots when available; provenance is recorded separately.
- `Evidence/`: development helpers, focused check sources and structured validation/installation records.
- `Diffs/`: source-port patches and normalized structural IL comparison.
- `Baselines/`: previous binary and its provenance for review, not an automatic rollback.

## Plugin identifiers and declared dependencies

- `org.soardev.universegentweaks` — UniverseGenTweaks 1.2.14; dependencies: org.soardev.uxassist | hard; crecheng.DSPModSave | hard.

## Installed assembly hashes

| Recorded path | SHA-256 |
|---|---|
| `plugins/soarqin-UniverseGenTweaks/UniverseGenTweaks.dll` | `2166a312a4ce92dcb64592bbccc336b102499ca0e44688d78443942d0a2a0c77` |

## Scope and limitations

Not every source project has been rebuilt. Historical compile/test evidence is limited to its recorded hashes. Headless/embedded-Mono checks do not establish real Unity UI, the user's world, all-mod startup, multiplayer or sustained-memory acceptance.

## Compact maintainer review package

Upload the prepared **`soarqin-UniverseGenTweaks.zip`**. Full related-mod copies have been replaced with upstream links, exact versions/hashes and targeted source files under `References/`. See [RELATED_MODS.md](RELATED_MODS.md), [packaging scope and exclusions](PACKAGING.md), and [verification](STANDALONE_VERIFICATION.json). Do not re-ZIP the folder with the ZIP inside it.

All primary development code and recorded validation material are retained. This is a source-review package; external game/mod SDKs and any files explicitly excluded in PACKAGING.md are needed for a full build/runtime test. Historical test results do not establish live-game acceptance.
