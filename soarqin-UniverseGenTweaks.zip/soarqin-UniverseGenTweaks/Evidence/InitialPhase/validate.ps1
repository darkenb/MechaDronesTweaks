param([string]$Original, [string]$Built, [string]$Core, [string]$PhaseRoot)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $Core 'Mono.Cecil.dll')
function Get-SHA256([string]$path) {
    $stream = [IO.File]::OpenRead($path)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '') }
    finally { $sha.Dispose(); $stream.Dispose() }
}
function Get-Types($types) {
    foreach ($type in $types) { $type; Get-Types $type.NestedTypes }
}
function Get-PublicContract($assembly) {
    foreach ($type in (Get-Types $assembly.MainModule.Types)) {
        if (-not ($type.IsPublic -or $type.IsNestedPublic)) { continue }
        'TYPE ' + $type.FullName
        foreach ($method in $type.Methods) {
            if ($method.IsPublic -or $method.IsFamily -or $method.IsFamilyOrAssembly) { 'METHOD ' + $method.FullName }
        }
        foreach ($field in $type.Fields) {
            if ($field.IsPublic -or $field.IsFamily -or $field.IsFamilyOrAssembly) { 'FIELD ' + $field.FullName }
        }
    }
}
$oldAssembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Original)
$newAssembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Built)
try {
    if ($oldAssembly.Name.FullName -ne $newAssembly.Name.FullName) { throw 'Assembly identity changed' }
    $oldContract = @(Get-PublicContract $oldAssembly)
    $newContract = @(Get-PublicContract $newAssembly)
    $missing = @($oldContract | Where-Object { $_ -notin $newContract })
    if ($missing.Count) { throw ('Public API removed: ' + ($missing -join '; ')) }
    $oldIds = @((Get-Types $oldAssembly.MainModule.Types).CustomAttributes | Where-Object { $_.AttributeType.FullName -eq 'BepInEx.BepInPlugin' } | ForEach-Object { $_.ConstructorArguments[0].Value })
    $newIds = @((Get-Types $newAssembly.MainModule.Types).CustomAttributes | Where-Object { $_.AttributeType.FullName -eq 'BepInEx.BepInPlugin' } | ForEach-Object { $_.ConstructorArguments[0].Value })
    if (@(Compare-Object $oldIds $newIds).Count) { throw 'Plugin GUID set changed' }
    $result = [ordered]@{ assembly_identity = $newAssembly.Name.FullName; public_contract_preserved = $oldContract.Count; plugin_guids = $newIds;  original_sha256 = (Get-SHA256 $Original); built_sha256 = (Get-SHA256 $Built); passed = $true }
    $result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $PhaseRoot 'validation.json') -Encoding UTF8
    Write-Output ('PASS assembly identity, {0} public contract entries, {1} plugin GUIDs' -f $oldContract.Count,$newIds.Count)
} finally { $oldAssembly.Dispose(); $newAssembly.Dispose() }
