using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Collections.Generic;
using HarmonyLib;
using UniverseGenTweaks;

static class Check
{
    static void Assert(bool ok, string label) { if (!ok) throw new Exception(label); Console.WriteLine("PASS " + label); }
    static byte[] Export(Type type)
    {
        var stream = new MemoryStream();
        type.GetMethod("Export").Invoke(null, new object[] {new BinaryWriter(stream)});
        return stream.ToArray();
    }
    static void CheckSettingLayout()
    {
        var calculate = AccessTools.Method(typeof(MoreSettings), "CalculateLayout");
        var heights = new float[] {24, 24, 24, 24, 24, 24, 24, 48, 32, 24, 32, 20};
        var pivots = new float[] {1, 1, 1, 1, 1, 1, 1, 0.5f, 1, 1, 1, 0.5f};
        var top = heights.Select((h, i) => h * (1 - pivots[i])).ToArray();
        var bottom = heights.Select((h, i) => -h * pivots[i]).ToArray();
        // Optional fast-start rows, combat/peace, and native rows hidden by GS.
        for (int flags = 0; flags < 64; flags++)
        {
            var visible = Enumerable.Repeat(true, heights.Length).ToArray();
            for (int j = 0; j < 6; j++) visible[new[] {6, 7, 9, 4, 5, 8}[j]] = (flags & (1 << j)) != 0;
            var y = Enumerable.Repeat(12345f, heights.Length).ToArray();
            calculate.Invoke(null, new object[] {-36f, -24f, top, bottom, visible, y});
            float previousY = -36f, previousBottom = -60f;
            for (int i = 0; i < y.Length; i++)
            {
                if (!visible[i]) { if (y[i] != 12345f) throw new Exception("hidden row consumes layout space"); continue; }
                if (y[i] > previousY - 36f || y[i] + top[i] > previousBottom - 10f)
                    throw new Exception("visible settings overlap: flags=" + flags + ", row=" + i);
                foreach (float scale in new[] {0.67f, 1f, 1.5f, 2f})
                    if ((previousBottom - y[i] - top[i]) * scale < 10f * scale - 0.001f)
                        throw new Exception("canvas-scaled row clearance lost");
                previousY = y[i]; previousBottom = y[i] + bottom[i];
            }
            var expected = (float[])y.Clone();
            // Reopen / another mod writes old coordinates: our layout must not drift.
            for (int frame = 0; frame < 100; frame++)
            {
                for (int i = 0; i < y.Length; i++) if (visible[i]) y[i] = -180f - i;
                calculate.Invoke(null, new object[] {-36f, -24f, top, bottom, visible, y});
                if (!y.SequenceEqual(expected)) throw new Exception("layout depends on previous frame coordinates");
            }
        }
        Assert(true, "64 optional/combat/GS visibility combinations keep distinct rows, scaled clearance and stable repeated layout");
        var compactTop = new float[12];
        var compactBottom = Enumerable.Repeat(-24f, 12).ToArray();
        var compactVisible = Enumerable.Repeat(true, 12).ToArray();
        compactVisible[6] = compactVisible[7] = compactVisible[9] = false;
        var compactY = new float[12];
        calculate.Invoke(null, new object[] {-36f, -24f, compactTop, compactBottom, compactVisible, compactY});
        Assert(compactY[8] == -288f && compactY[10] == -324f && compactY[11] == -360f,
            "hidden fast-start and invasion rows leave no blank slots before cluster code and metadata");
    }
    static int Main()
    {
        CheckSettingLayout();
        var old = Assembly.LoadFile(Path.Combine(Environment.CurrentDirectory, "soarqin-UniverseGenTweaks/UniverseGenTweaks.dll"));
        var oldSettings = old.GetType("UniverseGenTweaks.MoreSettings");
        var bytes = Export(oldSettings);
        Assert(bytes.SequenceEqual(Export(typeof(MoreSettings))), "installed save bytes remain identical");
        MoreSettings.Import(new BinaryReader(new MemoryStream(bytes)));
        Assert(bytes.SequenceEqual(Export(typeof(MoreSettings))), "installed save import round trip");
        var permanent = typeof(MoreSettings).GetNestedType("PermanentPatch", BindingFlags.NonPublic);
        var lateUpdate = AccessTools.Method(typeof(UIVirtualStarmap), "_OnLateUpdate");
        var labelPatch = AccessTools.Method(permanent, "UIVirtualStarmap__OnLateUpdate_Transpiler");
        var labelGenerator = new DynamicMethod("labels", typeof(void), Type.EmptyTypes).GetILGenerator();
        var labelNative = PatchProcessor.GetOriginalInstructions(lateUpdate, labelGenerator);
        var labelOutput = ((IEnumerable<CodeInstruction>)labelPatch.Invoke(null, new object[] { labelNative, labelGenerator })).ToList();
        Assert(labelOutput.Count == labelNative.Count + 5 && labelOutput.Count(i => i.opcode == OpCodes.Or) > labelNative.Count(i => i.opcode == OpCodes.Or),
            "native starmap label patch inserts star-type visibility using real SetActive method operand");
        var generator = new DynamicMethod("test", typeof(void), Type.EmptyTypes).GetILGenerator();
        var method = AccessTools.Method(permanent, "SectorModel_CreateGalaxyAstroBuffer_Transpiler");
        var native = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(SectorModel), "CreateGalaxyAstroBuffer"), generator);
        var output = ((IEnumerable<CodeInstruction>)method.Invoke(null, new object[] {native, generator})).ToList();
        Assert(output.Count(i => i.LoadsConstant(102500)) == 4 && !output.Any(i => i.LoadsConstant(25600)), "native four buffer sites retain upstream expansion");
        var ui = AccessTools.Method(typeof(MoreSettings), "UIGalaxySelect__OnUpdate_Postfix");
        Assert(ui.GetCustomAttributes(typeof(HarmonyPriority), false).Cast<HarmonyPriority>().Single().info.priority == Priority.Last, "UI alignment executes after other ordinary UI patches");
        var open = AccessTools.Method(typeof(MoreSettings), "UIGalaxySelect__OnOpen_Postfix");
        Assert(open.GetCustomAttributes(typeof(HarmonyPriority), false).Cast<HarmonyPriority>().Single().info.priority == Priority.Last,
            "open layout collects GenesisBook and DSP_Battle rows after their creation patches");
        foreach (var entry in new[] {ui, open})
        {
            var calls = PatchProcessor.GetOriginalInstructions(entry);
            Assert(calls.Any(i => i.operand is MethodInfo m && (m.Name == "ApplySettingLayout" || m.Name == ui.Name)),
                entry.Name + " applies the complete settings layout");
        }
        return 0;
    }
}
