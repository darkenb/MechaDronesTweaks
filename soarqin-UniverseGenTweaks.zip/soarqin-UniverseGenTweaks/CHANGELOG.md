# soarqin-UniverseGenTweaks — detailed change report

Installed plugin version(s): **1.2.14**. Lay out UGT, Genesis, Battle and native new-game rows together without accumulating offsets or changing settings.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## New-game layout and compatibility — 1.2.12–1.2.14

Use the source corresponding to installed 1.2.11; do not mix a different development branch's lifecycle/API migration into that version. Preserve assembly identity 1.2.11.0, save behavior and extended difficulty features.

The initial layout repair retains the native Dark Fog details button's original local offset from its row. After UI updates, derive its position through the row transform. A sibling button follows the moved row; a button already parented to that row receives no second offset. Preserve TheyComeFromVoid's horizontal adjustment, Canvas scaling and reopening behavior without hard-coded screen coordinates or accumulated deltas.

Version 1.2.14 lays out the whole group after `_OnOpen`/`_OnUpdate`: four UGT rows, resource multiplier, free mode, GenesisBook/Battle quick-start rows, Dark Fog, Void Invasion, cluster code and metadata multiplier. The prior fix only moved the details button; Genesis child-index offsets and Battle fixed coordinates still overlapped the settings group.

Capture base positions once and derive every frame from them. Hidden options consume no space. Account for RectTransform heights/pivots and leave at least 10 Canvas units between visible rows. Rediscover optional-mod rows on repeated opening without revealing Battle's intentionally hidden quick-start row. Preserve values, listeners and save format.

Version 1.2.13 adds `/unsafe+` Mono-access metadata and fixes star-name visibility matching to use the actual `GameObject.SetActive(bool)` method instead of an invalid property-getter lookup; five expected added instructions were checked.

Evidence includes save byte equality/import round trip, preservation of four native buffer expansions, both GS/UGT transpiler orders and the native Dark Fog/new-game layout target scan. Unity transforms and real visual placement were not executed outside the game. Different scales, GS generator switching and reopening need live acceptance.

## Recorded source commits

- `77f5803a2480be9a141b1038953a32bc58a747cd`

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
