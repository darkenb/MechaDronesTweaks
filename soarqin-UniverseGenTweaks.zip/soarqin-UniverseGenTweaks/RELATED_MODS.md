# Related mod references - soarqin-UniverseGenTweaks

Full related-mod packages are intentionally omitted. Project URLs, versions, exact local assembly hashes and targeted source files are supplied under `References/`. Upstream HEAD may differ from the locally modified snapshot. Build/runtime dependencies remain external prerequisites.

The source links below point to files actually present in this ZIP. Original line numbers and short excerpts are retained. A shared native integration point does not imply a direct DLL dependency.

## CommonAPI-CommonAPI

[Project identity and versions](References/CommonAPI-CommonAPI/reference.json) | [Reference notes](References/CommonAPI-CommonAPI/README.md)

Upstream: https://github.com/kremnev8/CommonAPI

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/BaseSubmodule.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/BaseSubmodule.cs) - original line 18

```csharp
		{
			string name = GetType().Name;
			throw new InvalidOperationException(name + " is not loaded. Please use [CommonAPISubmoduleDependency(nameof(" + name + ")]");
		}
	}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 16

```csharp
namespace CommonAPI;

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPISubmoduleDependency.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPISubmoduleDependency.cs) - original line 6

```csharp

[AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
public class CommonAPISubmoduleDependency : Attribute
{
	public string?[]? SubmoduleNames { get; }
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ConfigFileExtension.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ConfigFileExtension.cs) - original line 33

```csharp
				entry.SetSerializedValue(item.Value);
				list.Add(item.Key);
				CommonAPIPlugin.logger.LogInfo("Migrating config from " + oldSection + ":" + key + " to " + newSection + ":" + key);
			}
		}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/HarmonyRegisterExtension.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/HarmonyRegisterExtension.cs) - original line 31

```csharp
			else
			{
				CommonAPIPlugin.logger.LogInfo("Failed to patch: " + item.FullName + ".");
			}
		}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ItemProtoExtenstion.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ItemProtoExtenstion.cs) - original line 17

```csharp
			{
				RecipeProto recipeProto = LDB.recipes.Select(proto.maincraft.ID);
				CommonAPIPlugin.logger.LogInfo($"Changing recipe icon: {recipeProto != null}");
				recipeProto.IconPath = "";
				recipeProto._iconSprite = iconSprite;
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/LoadSaveOnLoad.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/LoadSaveOnLoad.cs) - original line 42

```csharp
		{
			DSPGame.LoadFile = saveName;
			CommonAPIPlugin.logger.LogInfo("Loading save " + saveName + " by default!");
		}
	}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs) - original line 14

```csharp
[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
{
```

### Dependency reference code

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 24

```csharp
[BepInPlugin("org.LoShin.GenesisBook", "GenesisBook", "3.2.6")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/TextureResourcesPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/TextureResourcesPatches.cs) - original line 15

```csharp
		typeof(Type)
	})]
	[HarmonyBefore(new string[] { "dsp.common-api.CommonAPI" })]
	[HarmonyPrefix]
	public static bool GetAssemblyManifestResource(ref string path, Type systemTypeInstance, ref UnityEngine.Object __result)
```

[References/HiddenCirno-GenesisBook/Code/Evidence/InitialPhase/check.cs](References/HiddenCirno-GenesisBook/Code/Evidence/InitialPhase/check.cs) - original line 56

```csharp
            Assert(result == mapping.Item2, "Item/building/drop/custom-tab page mapping");
        }
        Console.WriteLine("PASS: native Item/Building/Drop and CommonAPI custom-tab pick pages.");
    }
    static void SaveFixtures(string directory) {
```

[References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/DspBattlePlugin.cs](References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/DspBattlePlugin.cs) - original line 21

```csharp
[BepInPlugin("com.ckcz123.DSP_Battle", "DSP_Battle", "3.4.28")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.soardev.universegentweaks", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/ckcz123-TheyComeFromVoid/Code/Source/EarlierWorkingSource/DspBattlePlugin.cs](References/ckcz123-TheyComeFromVoid/Code/Source/EarlierWorkingSource/DspBattlePlugin.cs) - original line 23

```csharp
    [BepInPlugin("com.ckcz123.DSP_Battle", "DSP_Battle", Configs.versionString)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [BepInDependency(CommonAPIPlugin.GUID)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(CompatManager.UniverseGenTweak_GUID, BepInDependency.DependencyFlags.SoftDependency)]
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs) - original line 19

```csharp

[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
```

[References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs) - original line 19

```csharp

[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
```

[References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/MoreMegaStructure.cs) - original line 24

```csharp
{
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(CommonAPIPlugin.GUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [CommonAPISubmoduleDependency(nameof(ProtoRegistry), nameof(TabSystem), nameof(LocalizationModule))]
```

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist/UXAssist.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist/UXAssist.cs) - original line 23

```csharp
namespace UXAssist;

[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "CustomKeyBindSystem" })]
```

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.ModsCompat/CommonAPIWrapper.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.ModsCompat/CommonAPIWrapper.cs) - original line 11

```csharp
	public static void Run(Harmony harmony)
	{
		if (ModCompatHelper.TryGetLoadedPluginInfo("dsp.common-api.CommonAPI", out var pluginInfo) && !(pluginInfo.Metadata.Version > new System.Version(1, 6, 7, 0)))
		{
			harmony.Patch(AccessTools.Method(typeof(GameOption), "InitKeys"), new HarmonyMethod(AccessTools.Method(typeof(CommonAPIWrapper), "PatchInitKeys"), 800));
```

[References/soarqin-UXAssist/Code/Source/EarlierWorkingSource/Common/ModFeatures/IModFeature.cs](References/soarqin-UXAssist/Code/Source/EarlierWorkingSource/Common/ModFeatures/IModFeature.cs) - original line 15

```csharp
/// <item><see cref="Init"/> runs <strong>eagerly</strong> at registration time — synchronously inside
/// <see cref="ModFeatureRegistry.Register{T}"/>, normally during the registering mod's BepInEx
/// <c>Awake</c> phase. It is the phase for early setup such as keybind registration via CommonAPI's
/// <c>CustomKeyBindSystem</c>, whose registered bindings are copied by the game's
/// <c>UIOptionWindow._OnCreate</c> only after all plugins finish loading. A late-discovered feature may
```

## CommonAPI-DSPModSave

[Project identity and versions](References/CommonAPI-DSPModSave/reference.json) | [Reference notes](References/CommonAPI-DSPModSave/README.md)

Upstream: https://github.com/kremnev8/DSP-Mods/tree/master/Mods/DSPModSave

- **declared_hard_dependency**: Plugin-level dependency declaration; this may belong to an optional compatibility plugin.
- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Code in this mod

[Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/UniverseGenTweaks.cs](Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/UniverseGenTweaks.cs) - original line 11

```csharp
[BepInPlugin("org.soardev.universegentweaks", "UniverseGenTweaks", "1.2.14")]
[BepInDependency("org.soardev.uxassist", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[ModSaveSettings(/*Could not decode attribute arguments.*/)]
public class UniverseGenTweaks : BaseUnityPlugin, IModCanSave
```

[Source/EarlierWorkingSource/UniverseGenTweaks.cs](Source/EarlierWorkingSource/UniverseGenTweaks.cs) - original line 10

```csharp
[BepInPlugin(PluginInfo.PLUGIN_GUID, PluginInfo.PLUGIN_NAME, PluginInfo.PLUGIN_VERSION)]
[BepInDependency(UXAssist.PluginInfo.PLUGIN_GUID)]
[BepInDependency(DSPModSavePlugin.MODGUID)]
[ModSaveSettings(LoadOrder = LoadOrder.Preload)]
public class UniverseGenTweaks : BaseUnityPlugin, IModCanSave
```

### Code in the related reference

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs) - original line 15

```csharp
namespace crecheng.DSPModSave;

[BepInPlugin("crecheng.DSPModSave", "DSP Mod Save", "1.2.3")]
public class DSPModSavePlugin : BaseUnityPlugin
{
```

[References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs](References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs) - original line 25

```csharp
        string path = Path.Combine(root, "sample.moddsv");
        var sample = new SaveSample();
        var settingsType = typeof(DSPModSavePlugin).Assembly.GetType("crecheng.DSPModSave.ModSaveSettings");
        var settings = Activator.CreateInstance(settingsType, true);
        AccessTools.Field(settingsType, "mod").SetValue(settings, sample);
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs) - original line 22

```csharp
    public class DSPModSavePlugin : BaseUnityPlugin
    {
        public const string MODGUID = "crecheng.DSPModSave";
        public const string MODNAME = "DSP Mod Save";
        public const string MODID = "DSPModSave";
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs) - original line 12

```csharp
	private static void EnterGame()
	{
		DSPModSavePlugin.logger.LogInfo("Enter New Game");
		foreach (ModSaveSettings value in DSPModSavePlugin.allModData.Values)
		{
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs) - original line 13

```csharp
		if (__result)
		{
			DSPModSavePlugin.OnSave(saveName);
		}
	}
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs) - original line 12

```csharp
        static void EnterGame()
        {
            DSPModSavePlugin.logger.LogInfo("Enter New Game");
            foreach (var d in DSPModSavePlugin.allModData.Values)
            {
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs) - original line 14

```csharp
            if (!__result) return;

            DSPModSavePlugin.OnSave(saveName);
        }

```

## Galactic_Scale-GalacticScale

[Project identity and versions](References/Galactic_Scale-GalacticScale/reference.json) | [Reference notes](References/Galactic_Scale-GalacticScale/README.md)

Upstream: https://github.com/Touhma/DSP_Plugins

- **fix_integration_context**: Astro-buffer transpiler order and repeated slider previews are coupled across the two mods.

### Code in this mod

[Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/MoreSettings.cs](Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/MoreSettings.cs) - original line 48

```csharp
			codeMatcher.Repeat(delegate(CodeMatcher m)
			{
				m.SetAndAdvance(OpCodes.Ldc_I4, 102500);
			});
			return codeMatcher.InstructionEnumeration();
```

[Evidence/InitialPhase/check.cs](Evidence/InitialPhase/check.cs) - original line 84

```csharp
        var native = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(SectorModel), "CreateGalaxyAstroBuffer"), generator);
        var output = ((IEnumerable<CodeInstruction>)method.Invoke(null, new object[] {native, generator})).ToList();
        Assert(output.Count(i => i.LoadsConstant(102500)) == 4 && !output.Any(i => i.LoadsConstant(25600)), "native four buffer sites retain upstream expansion");
        var ui = AccessTools.Method(typeof(MoreSettings), "UIGalaxySelect__OnUpdate_Postfix");
        Assert(ui.GetCustomAttributes(typeof(HarmonyPriority), false).Cast<HarmonyPriority>().Single().info.priority == Priority.Last, "UI alignment executes after other ordinary UI patches");
```

[Source/EarlierWorkingSource/MoreSettings.cs](Source/EarlierWorkingSource/MoreSettings.cs) - original line 355

```csharp
        private static IEnumerable<CodeInstruction> GalaxyData_Constructor_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
        {
            // 25700 -> 102500
            var matcher = new CodeMatcher(instructions, generator);
            matcher.MatchForward(false,
```

### Code in the related reference

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/Transpilers/SectorModel/CreateGalaxyAstroBuffer.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/Transpilers/SectorModel/CreateGalaxyAstroBuffer.cs) - original line 20

```csharp
                .MatchForward(
                    true,
                    new CodeMatch(i => i.LoadsConstant(25600) || i.LoadsConstant(102500)
                    ));
            if (matcher.IsInvalid)
```

[References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/GalacticScale/PatchOnSectorModel.cs](References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/GalacticScale/PatchOnSectorModel.cs) - original line 16

```csharp
	{
		MethodInfo calcMethod = AccessTools.Method(typeof(PatchOnSectorModel), "CalcAstroBufferSize");
		CodeMatcher codeMatcher = new CodeMatcher(instructions).MatchForward(true, new CodeMatch((CodeInstruction i) => i.LoadsConstant(25600L) || i.LoadsConstant(102500L)));
		if (codeMatcher.IsInvalid)
		{
```

[References/Galactic_Scale-GalacticScale/Code/Evidence/GalacticScale_20261006/check.cs](References/Galactic_Scale-GalacticScale/Code/Evidence/GalacticScale_20261006/check.cs) - original line 264

```csharp
        foreach (var result in new[] {gsFirst, ugtFirst})
        {
            Assert(result.Count(i => i.Calls(calc)) == 4 && !result.Any(i => i.LoadsConstant(25600) || i.LoadsConstant(102500)), "both patch orders use galaxy-sized buffers");
            Assert(result.Count == native.Count, "patch order preserves native instruction count");
        }
```

[References/Galactic_Scale-GalacticScale/Code/Evidence/GalacticScale_20261007/check.cs](References/Galactic_Scale-GalacticScale/Code/Evidence/GalacticScale_20261007/check.cs) - original line 372

```csharp
        foreach (var result in new[] {gsFirst, ugtFirst})
        {
            Assert(result.Count(i => i.Calls(calc)) == 4 && !result.Any(i => i.LoadsConstant(25600) || i.LoadsConstant(102500)), "both patch orders use galaxy-sized buffers");
            Assert(result.Count == native.Count, "patch order preserves native instruction count");
        }
```

[References/Galactic_Scale-GalacticScale/Code/Evidence/InitialPhase/check.cs](References/Galactic_Scale-GalacticScale/Code/Evidence/InitialPhase/check.cs) - original line 164

```csharp
        foreach (var result in new[] {gsFirst, ugtFirst})
        {
            Assert(result.Count(i => i.Calls(calc)) == 4 && !result.Any(i => i.LoadsConstant(25600) || i.LoadsConstant(102500)), "both patch orders use galaxy-sized buffers");
            Assert(result.Count == native.Count, "patch order preserves native instruction count");
        }
```

[References/Galactic_Scale-GalacticScale/Code/Source/EarlierWorkingSource/Scripts/Patches/Transpilers/SectorModel/CreateGalaxyAstroBuffer.cs](References/Galactic_Scale-GalacticScale/Code/Source/EarlierWorkingSource/Scripts/Patches/Transpilers/SectorModel/CreateGalaxyAstroBuffer.cs) - original line 20

```csharp
                .MatchForward(
                    true,
                    new CodeMatch(i => i.LoadsConstant(25600) || i.LoadsConstant(102500)
                    ));
            if (matcher.IsInvalid)
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Models/Packets/LobbyResponseUpdateSolarSystemsProcessor.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Models/Packets/LobbyResponseUpdateSolarSystemsProcessor.cs) - original line 34

```csharp
            GSSettings.lobbyReceivedUpdateValues = true;

            UIRoot.instance.galaxySelect.SetStarmapGalaxy();

            // Old galaxyData is free in SetStarmapGalaxy(), so we need to reassign again
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/UIGalaxySelect/_OnOpen.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/UIGalaxySelect/_OnOpen.cs) - original line 83

```csharp
            if (__instance.gameDesc == null) GS2.Warn("GameDesc Null 2");
            if (__instance.gameDesc?.starCount <= 0) __instance.gameDesc.starCount = 1;
            __instance.SetStarmapGalaxy();
            // PlanetModelingManager.PrepareWorks();
            __instance.darkFogToggle.isOn = __instance.gameDesc.isCombatMode;//0.10
```

## HiddenCirno-GenesisBook

[Project identity and versions](References/HiddenCirno-GenesisBook/reference.json) | [Reference notes](References/HiddenCirno-GenesisBook/README.md)

Upstream: https://github.com/Awbugl/ProjectGenesis

- **fix_integration_context**: The new-game layout fix places Genesis quick-start controls together with the UGT/native rows.

### Code in this mod

[Evidence/InitialPhase/check.cs](Evidence/InitialPhase/check.cs) - original line 89

```csharp
        var open = AccessTools.Method(typeof(MoreSettings), "UIGalaxySelect__OnOpen_Postfix");
        Assert(open.GetCustomAttributes(typeof(HarmonyPriority), false).Cast<HarmonyPriority>().Single().info.priority == Priority.Last,
            "open layout collects GenesisBook and DSP_Battle rows after their creation patches");
        foreach (var entry in new[] {ui, open})
        {
```

[Source/EarlierWorkingSource/MoreSettings.cs](Source/EarlierWorkingSource/MoreSettings.cs) - original line 119

```csharp
            ui.resourceMultiplierSlider.transform.parent, ui.sandboxToggle.transform.parent
        };
        // GenesisBook and DSP_Battle both use this name; retain each mod's visibility.
        foreach (Transform child in _settingsParent)
            if (child.name == "fast-start-mode") rows.Add(child);
```

[Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/MoreSettings.cs](Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/MoreSettings.cs) - original line 397

```csharp
	[HarmonyPostfix]
	[HarmonyPriority(0)]
	[HarmonyPatch(typeof(UIGalaxySelect), "_OnOpen")]
	private static void UIGalaxySelect__OnOpen_Postfix(UIGalaxySelect __instance)
	{
```

### Code in the related reference

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 22

```csharp
namespace ProjectGenesis;

[BepInPlugin("org.LoShin.GenesisBook", "GenesisBook", "3.2.6")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GalacticScale.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GalacticScale.cs) - original line 19

```csharp
	internal const string GUID = "dsp.galactic-scale.2";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.dsp.galactic-scale.2");

	internal static void Awake()
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GigaStationsUpdated.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GigaStationsUpdated.cs) - original line 15

```csharp
	internal const string GUID = "org.kremnev8.plugin.GigaStationsUpdated";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.org.kremnev8.plugin.GigaStationsUpdated");

	internal static void Awake()
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/InstallationCheckPlugin.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/InstallationCheckPlugin.cs) - original line 12

```csharp
namespace ProjectGenesis.Compatibility;

[BepInPlugin("org.LoShin.GenesisBook.InstallationCheck", "GenesisBook.InstallationCheck", "3.2.6")]
[BepInDependency("org.kremnev8.plugin.BlueprintTweaks", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("Gnimaerd.DSP.plugin.MoreMegaStructure", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/LazyOutposting.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/LazyOutposting.cs) - original line 14

```csharp
	internal const string GUID = "eirshy.dsp.LazyOutposting";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.eirshy.dsp.LazyOutposting");

	internal static void Awake()
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/MoreMegaStructure.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/MoreMegaStructure.cs) - original line 16

```csharp
	internal static readonly Dictionary<int, int> FastAssembleItems = new Dictionary<int, int>();

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.Gnimaerd.DSP.plugin.MoreMegaStructure");

	private static readonly int[] AddedRecipes = new int[57]
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/PlanetVeinUtilization.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/PlanetVeinUtilization.cs) - original line 13

```csharp
	internal const string GUID = "testpostpleaseignore.dsp.planet_vein_utilization";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.testpostpleaseignore.dsp.planet_vein_utilization");

	internal static void Awake()
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/WeaponPlus.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/WeaponPlus.cs) - original line 11

```csharp
	internal const string GUID = "org.weaponplus.plugins.Xiaokls";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.org.weaponplus.plugins.Xiaokls");

	internal static void Awake()
```

## ckcz123-TheyComeFromVoid

[Project identity and versions](References/ckcz123-TheyComeFromVoid/reference.json) | [Reference notes](References/ckcz123-TheyComeFromVoid/README.md)

Upstream: https://github.com/jinxOAO/DSP_Battle

- **fix_integration_context**: The new-game layout fix accounts for Battle quick-start/Void Invasion rows and preserves hidden controls.

### Code in this mod

[Evidence/InitialPhase/check.cs](Evidence/InitialPhase/check.cs) - original line 89

```csharp
        var open = AccessTools.Method(typeof(MoreSettings), "UIGalaxySelect__OnOpen_Postfix");
        Assert(open.GetCustomAttributes(typeof(HarmonyPriority), false).Cast<HarmonyPriority>().Single().info.priority == Priority.Last,
            "open layout collects GenesisBook and DSP_Battle rows after their creation patches");
        foreach (var entry in new[] {ui, open})
        {
```

[Source/EarlierWorkingSource/MoreSettings.cs](Source/EarlierWorkingSource/MoreSettings.cs) - original line 119

```csharp
            ui.resourceMultiplierSlider.transform.parent, ui.sandboxToggle.transform.parent
        };
        // GenesisBook and DSP_Battle both use this name; retain each mod's visibility.
        foreach (Transform child in _settingsParent)
            if (child.name == "fast-start-mode") rows.Add(child);
```

[Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/MoreSettings.cs](Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/MoreSettings.cs) - original line 397

```csharp
	[HarmonyPostfix]
	[HarmonyPriority(0)]
	[HarmonyPatch(typeof(UIGalaxySelect), "_OnOpen")]
	private static void UIGalaxySelect__OnOpen_Postfix(UIGalaxySelect __instance)
	{
```

### Code in the related reference

[References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/BattleBGMController.cs](References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/BattleBGMController.cs) - original line 65

```csharp
		Transform transform = GameObject.Find("Audios/BGM").transform;
		GameObject original = GameObject.Find("Audios/BGM/universe-1");
		bgmAB = AssetBundle.LoadFromStream(Assembly.GetExecutingAssembly().GetManifestResourceStream("DSP_Battle.battlebgm"));
		if (bgmAB == null)
		{
```

[References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/DspBattlePlugin.cs](References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/DspBattlePlugin.cs) - original line 19

```csharp
namespace DSP_Battle;

[BepInPlugin("com.ckcz123.DSP_Battle", "DSP_Battle", "3.4.28")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
```

[References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle.src.NebulaCompat/NebulaCompatPlugin.cs](References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle.src.NebulaCompat/NebulaCompatPlugin.cs) - original line 17

```csharp
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("com.ckcz123.DSP_Battle", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
{
```

[References/ckcz123-TheyComeFromVoid/Code/Evidence/InitialPhase/check.cs](References/ckcz123-TheyComeFromVoid/Code/Evidence/InitialPhase/check.cs) - original line 21

```csharp
                    "battle music bundle matches original SHA-256");
        }
        var renderer = typeof(DSP_Battle.Configs).Assembly.GetType("DSP_Battle.RendererSphere", true);
        var idle = AccessTools.Method(renderer, "RSphereRenderBulletPostfix");
        Assert(!idle.IsDefined(typeof(HarmonyPatch), false) && !idle.IsDefined(typeof(HarmonyPostfix), false),
```

[References/ckcz123-TheyComeFromVoid/Code/Source/EarlierWorkingSource/BattleBGMController.cs](References/ckcz123-TheyComeFromVoid/Code/Source/EarlierWorkingSource/BattleBGMController.cs) - original line 43

```csharp
            Transform BGMParent = GameObject.Find("Audios/BGM").transform;
            GameObject oriAudioSource = GameObject.Find("Audios/BGM/universe-1");
            bgmAB = AssetBundle.LoadFromStream(Assembly.GetExecutingAssembly().GetManifestResourceStream("DSP_Battle.battlebgm"));
            if (bgmAB == null)
            {
```

[References/ckcz123-TheyComeFromVoid/Code/Source/EarlierWorkingSource/DspBattlePlugin.cs](References/ckcz123-TheyComeFromVoid/Code/Source/EarlierWorkingSource/DspBattlePlugin.cs) - original line 21

```csharp
namespace DSP_Battle
{
    [BepInPlugin("com.ckcz123.DSP_Battle", "DSP_Battle", Configs.versionString)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [BepInDependency(CommonAPIPlugin.GUID)]
```

[References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/AssaultController.cs](References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/AssaultController.cs) - original line 30

```csharp
	}

	public static bool voidInvasionEnabled = false;

	public static int difficulty = 2;
```

[References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/Configs.cs](References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/Configs.cs) - original line 24

```csharp
	public static bool enableAlertTextGlowing = true;

	public static bool enableVoidInvasionUpdate = true;

	public static int versionWhenImporting = -1;
```

## jinxOAO-MoreMegaStructure

[Project identity and versions](References/jinxOAO-MoreMegaStructure/reference.json) | [Reference notes](References/jinxOAO-MoreMegaStructure/README.md)

Upstream: https://github.com/jinxOAO/DSPmod_MoreMegaStructures

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/ECpuWorkEntryExtended.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/ECpuWorkEntryExtended.cs) - original line 5

```csharp
public enum ECpuWorkEntryExtended
{
	MoreMegaStructure = 44,
	Receiver,
	StarAssembly,
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/GenesisCompatibilityPatch.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/GenesisCompatibilityPatch.cs) - original line 11

```csharp
	private void Awake()
	{
		if (!MoreMegaStructure.isBattleActive)
		{
			MoreMegaStructure.GenesisCompatibility = true;
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MegaButtonGroupBehaviour.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MegaButtonGroupBehaviour.cs) - original line 39

```csharp
	{
		bool flag = false;
		Transform transform = MoreMegaStructure.setMegaGroupObj.transform;
		Vector3 localPosition = transform.localPosition;
		if (MoreMegaStructure.NoUIAnimation.Value)
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MMSPF.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MMSPF.cs) - original line 9

```csharp
		MMSCPU.MarkMainThread();
		int index = MMSCPU.AddEntry("PF巨构总览", 0);
		MMSCPU.MapEnum(ECpuWorkEntryExtended.MoreMegaStructure, index);
		MMSCPU.MapEnum(ECpuWorkEntryExtended.Receiver, MMSCPU.AddEntry("PF接收器", 1));
		MMSCPU.MapEnum(ECpuWorkEntryExtended.StarAssembly, MMSCPU.AddEntry("PF星际组装厂", 1));
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MMSProtos.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MMSProtos.cs) - original line 45

```csharp
	internal static void AddNewItems()
	{
		int num = MoreMegaStructure.pagenum * 1000;
		int num2 = 0;
		bool flag = true;
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs) - original line 23

```csharp
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
[BepInDependency("starfi5h.plugin.ModFixerOne", BepInDependency.DependencyFlags.HardDependency)]
[BepInPlugin("Gnimaerd.DSP.plugin.MoreMegaStructure", "MoreMegaStructure", "2.0.2")]
public class MoreMegaStructure : BaseUnityPlugin, IModCanSave
{
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/ReceiverPatchers.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/ReceiverPatchers.cs) - original line 69

```csharp
		PowerSystem powerSystem = __instance;
		int index = powerSystem.factory.planet.star.index;
		if (index >= MoreMegaStructure.StarMegaStructureType.Length)
		{
			return true;
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/StarAssembly.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/StarAssembly.cs) - original line 684

```csharp
	public static void InitInGameData()
	{
		int num = (MoreMegaStructure.Support1000Stars.Value ? 1200 : 100);
		for (int i = 0; i < num; i++)
		{
```

### Dependency reference code

[References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/DspBattlePlugin.cs](References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/DspBattlePlugin.cs) - original line 25

```csharp
[BepInDependency("org.soardev.universegentweaks", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("org.LoShin.GenesisBook", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("Gnimaerd.DSP.plugin.MoreMegaStructure", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry" })]
[CommonAPISubmoduleDependency(new string[] { "TabSystem" })]
```

[References/ckcz123-TheyComeFromVoid/Code/Source/EarlierWorkingSource/DspBattlePlugin.cs](References/ckcz123-TheyComeFromVoid/Code/Source/EarlierWorkingSource/DspBattlePlugin.cs) - original line 27

```csharp
    [BepInDependency(CompatManager.UniverseGenTweak_GUID, BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency(CompatManager.GB_GUID, BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("Gnimaerd.DSP.plugin.MoreMegaStructure")]
    [CommonAPISubmoduleDependency(nameof(ProtoRegistry))]
    [CommonAPISubmoduleDependency(nameof(TabSystem))]
```

[References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/BattleProtos.cs](References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/BattleProtos.cs) - original line 33

```csharp
	public static void AddNormalProtos()
	{
		int num = (MoreMegaStructure.GenesisCompatibility ? (-200) : 0);
		int num2 = (MoreMegaStructure.GenesisCompatibility ? (-8) : 0);
		TechProto techProto = ProtoRegistry.RegisterTech(1999, "玻色子操控", "玻色子操控描述", "玻色子操控结论", "Assets/DSPBattle/bosontech", new int[0], new int[1] { 5201 }, new int[1] { 400 }, 72000L, new int[5]
```

## nebula-NebulaMultiplayerModApi

[Project identity and versions](References/nebula-NebulaMultiplayerModApi/reference.json) | [Reference notes](References/nebula-NebulaMultiplayerModApi/README.md)

Upstream: https://github.com/NebulaModTeam/nebula

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs) - original line 15

```csharp
[BepInPlugin("dsp.nebula-multiplayer-api", "NebulaMultiplayerModApi", "2.1.0.7")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class NebulaModAPI : BaseUnityPlugin
{
	public const string NEBULA_MODID = "dsp.nebula-multiplayer";
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/CollectionExtensions.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/CollectionExtensions.cs) - original line 5

```csharp
namespace NebulaAPI.DataStructures;

public static class CollectionExtensions
{
	public static Locker Lock(this ICollection collection)
```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs) - original line 13

```csharp

[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Bootstrap.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Bootstrap.cs) - original line 20

```csharp
    [BepInPlugin("dsp.galactic-scale.2", "Galactic Scale 2 Plug-In", "2.80.9")]
    [BepInDependency("space.customizing.console", BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("lltcggie.DSP.plugin.PlanetwidePlanetaryShieldGenerator", BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("un1eagle.planetwideshield", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/GalacticScale/Bootstrap.cs](References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/GalacticScale/Bootstrap.cs) - original line 14

```csharp
[BepInPlugin("dsp.galactic-scale.2", "Galactic Scale 2 Plug-In", "2.80.9")]
[BepInDependency("space.customizing.console", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("lltcggie.DSP.plugin.PlanetwidePlanetaryShieldGenerator", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("un1eagle.planetwideshield", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/NebulaCompatibility/Ignore_This_Warning_If_Not_Using_Nebula_Multiplayer_Mod.cs](References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/NebulaCompatibility/Ignore_This_Warning_If_Not_Using_Nebula_Multiplayer_Mod.cs) - original line 13

```csharp

[BepInPlugin("dsp.galactic-scale.2.nebula", "Galactic Scale 2 Nebula Compatibility Plug-In", "1.0.0.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
public class Ignore_This_Warning_If_Not_Using_Nebula_Multiplayer_Mod : BaseUnityPlugin, IMultiplayerModWithSettings, IMultiplayerMod
{
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 26

```csharp
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.LoShin.GenesisBook.InstallationCheck", BepInDependency.DependencyFlags.SoftDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
```

[References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle.src.NebulaCompat/NebulaCompatPlugin.cs](References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle.src.NebulaCompat/NebulaCompatPlugin.cs) - original line 15

```csharp
[BepInPlugin("Gnimaerd.DSP.plugin.TCMVNebulaCompat", "TCMVNebulaCompat", "0.0.1")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("com.ckcz123.DSP_Battle", BepInDependency.DependencyFlags.HardDependency)]
```

## soarqin-UXAssist

[Project identity and versions](References/soarqin-UXAssist/reference.json) | [Reference notes](References/soarqin-UXAssist/README.md)

Upstream: https://github.com/soarqin/DSP_Mods/tree/master/UXAssist

- **declared_hard_dependency**: Plugin-level dependency declaration; this may belong to an optional compatibility plugin.
- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Code in this mod

[Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/UniverseGenTweaks.cs](Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/UniverseGenTweaks.cs) - original line 10

```csharp

[BepInPlugin("org.soardev.universegentweaks", "UniverseGenTweaks", "1.2.14")]
[BepInDependency("org.soardev.uxassist", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[ModSaveSettings(/*Could not decode attribute arguments.*/)]
```

[Source/EarlierWorkingSource/UniverseGenTweaks.cs](Source/EarlierWorkingSource/UniverseGenTweaks.cs) - original line 9

```csharp

[BepInPlugin(PluginInfo.PLUGIN_GUID, PluginInfo.PLUGIN_NAME, PluginInfo.PLUGIN_VERSION)]
[BepInDependency(UXAssist.PluginInfo.PLUGIN_GUID)]
[BepInDependency(DSPModSavePlugin.MODGUID)]
[ModSaveSettings(LoadOrder = LoadOrder.Preload)]
```

[Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/BirthPlanetPatch.cs](Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/BirthPlanetPatch.cs) - original line 133

```csharp
			_patch = Harmony.CreateAndPatchAll(typeof(BirthPlanetPatch));
		}
		GameLogic.OnDataLoaded = (Action)Delegate.Combine(GameLogic.OnDataLoaded, new Action(VFPreload_InvokeOnLoadWorkEnded_Postfix));
	}

```

[Source/EarlierWorkingSource/BirthPlanetPatch.cs](Source/EarlierWorkingSource/BirthPlanetPatch.cs) - original line 77

```csharp
        PatchBirthThemeData();
        _patch ??= Harmony.CreateAndPatchAll(typeof(BirthPlanetPatch));
        GameLogicProc.OnDataLoaded += VFPreload_InvokeOnLoadWorkEnded_Postfix;
    }

```

[Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/EpicDifficulty.cs](Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/EpicDifficulty.cs) - original line 27

```csharp
	public static void Init()
	{
		I18N.Add("究极少", "Micro", "究极少");
		I18N.Add("史诗难度", "Epic Difficulty !!", "史诗难度 !!");
		I18N.Apply();
```

[Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/MoreSettings.cs](Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/MoreSettings.cs) - original line 209

```csharp
	public static void Init()
	{
		I18N.Add("恒星最小距离", "Star Distance Min", "恒星最小距离");
		I18N.Add("步进最小距离", "Step Distance Min", "步进最小距离");
		I18N.Add("步进最大距离", "Step Distance Max", "步进最大距离");
```

[Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/UIConfigWindow.cs](Source/Reconstructed/plugins/UniverseGenTweaks/UniverseGenTweaks/UIConfigWindow.cs) - original line 14

```csharp
	public static void Init()
	{
		I18N.Add("UniverseGen", "UniverseGen", "宇宙生成");
		I18N.Add("Birth Star", "Birth Star", "母星系");
		I18N.Add("Enable more settings on UniverseGen", "Enable more settings on UniverseGen", "启用更多宇宙生成设置");
```

[Source/EarlierWorkingSource/EpicDifficulty.cs](Source/EarlierWorkingSource/EpicDifficulty.cs) - original line 23

```csharp
    public static void Init()
    {
        I18N.Add("究极少", "Micro", "究极少");
        I18N.Add("史诗难度", "Epic Difficulty !!", "史诗难度 !!");
        I18N.Apply();
```

### Code in the related reference

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist/PluginInfo.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist/PluginInfo.cs) - original line 5

```csharp
public static class PluginInfo
{
	public const string PLUGIN_GUID = "org.soardev.uxassist";

	public const string PLUGIN_NAME = "UXAssist";
```

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist/UXAssist.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist/UXAssist.cs) - original line 26

```csharp
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "CustomKeyBindSystem" })]
[BepInPlugin("org.soardev.uxassist", "UXAssist", "1.6.3")]
[BepInDependency("testpostpleaseignore.dsp.planet_vein_utilization", BepInDependency.DependencyFlags.SoftDependency)]
public class UXAssist : BaseUnityPlugin, IModCanSave
```

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Patches/UIPatch.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Patches/UIPatch.cs) - original line 16

```csharp
namespace UXAssist.Patches;

[PatchGuid("org.soardev.uxassist")]
public class UIPatch : PatchImpl<UIPatch>
{
```

[References/soarqin-UXAssist/Code/Source/EarlierWorkingSource/PluginInfo.cs](References/soarqin-UXAssist/Code/Source/EarlierWorkingSource/PluginInfo.cs) - original line 6

```csharp
public static class PluginInfo
{
    public const string PLUGIN_GUID = "org.soardev.uxassist";
    public const string PLUGIN_NAME = "UXAssist";
    public const string PLUGIN_VERSION = "1.6.3";
```

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist/UIConfigWindow.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist/UIConfigWindow.cs) - original line 310

```csharp
	{
		_windowTrans = trans;
		wnd.AddTabGroup(trans, "UXAssist", "tab-group-uxassist");
		RectTransform parent = wnd.AddTab(trans, "General");
		float num = 0f;
```

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Common/GameLogic.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Common/GameLogic.cs) - original line 18

```csharp
	public static void VFPreload_InvokeOnLoadWorkEnded_Postfix()
	{
		OnDataLoaded.InvokeSafe(UXAssist.Logger, "OnDataLoaded");
	}

```

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Common/I18NKeys.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Common/I18NKeys.cs) - original line 23

```csharp
	public const string DisableAutoCruise = "Disable auto-cruise";

	public const string KEYOpenUXAssistConfigWindow = "KEYOpenUXAssistConfigWindow";

	public const string UXAssistConfig = "UXAssist Config";
```

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Common/PatchImpl.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Common/PatchImpl.cs) - original line 36

```csharp
			catch (Exception arg)
			{
				UXAssist.Logger.LogError($"Failed to apply Harmony patches for {typeof(T).FullName}: {arg}");
				try
				{
```

## starfi5h-ModFixerOne

[Project identity and versions](References/starfi5h-ModFixerOne/reference.json) | [Reference notes](References/starfi5h-ModFixerOne/README.md)

Upstream: https://github.com/starfi5h/DSP_Mod_Support

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/starfi5h-ModFixerOne/Code/Source/Reconstructed/patchers/ModFixerOnePreloader/ModFixerOne/Preloader.cs](References/starfi5h-ModFixerOne/Code/Source/Reconstructed/patchers/ModFixerOnePreloader/ModFixerOne/Preloader.cs) - original line 15

```csharp
public static class Preloader
{
	public static ManualLogSource logSource = Logger.CreateLogSource("ModFixerOne Preloader");

	public static IEnumerable<string> Guids;
```

[References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs](References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs) - original line 18

```csharp
			if (!IsVaild())
			{
				ErrorMessage = "Can't find injected fields or methods!\n Please make sure that ModFixerOnePreloader.dll is installed in BepInEx\\patchers.";
				Plugin.Log.LogWarning(ErrorMessage);
				harmony.PatchAll(typeof(Fixer_Patch));
```

[References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Plugin.cs](References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Plugin.cs) - original line 8

```csharp
namespace ModFixerOne;

[BepInPlugin("starfi5h.plugin.ModFixerOne", "ModFixerOne", "2.1.2")]
public class Plugin : BaseUnityPlugin
{
```

[References/starfi5h-ModFixerOne/Code/Evidence/InitialPhase/check.cs](References/starfi5h-ModFixerOne/Code/Evidence/InitialPhase/check.cs) - original line 19

```csharp
        try { resize.Invoke(null, unsafeShrink); } catch (TargetInvocationException e) { rejected = e.InnerException is System.IO.InvalidDataException; }
        if (!rejected || ((int[])unsafeShrink[0]).Length != 2 || ((int[])unsafeShrink[0])[1] != 9) throw new Exception("Occupied tail silently removed");
        ModFixerOne.Plugin.Log = new BepInEx.Logging.ManualLogSource("Import check");
        object[] removed = {new AssemblerComponent {recipeId = 9912, served = new[] {7}, incServed = new[] {21}}};
        rejected = false;
```

[References/starfi5h-ModFixerOne/Code/Source/EarlierWorkingSource/Fixer_Patch.cs](References/starfi5h-ModFixerOne/Code/Source/EarlierWorkingSource/Fixer_Patch.cs) - original line 28

```csharp
                if (!IsVaild())
                {
                    ErrorMessage = "Can't find injected fields or methods!\n Please make sure that ModFixerOnePreloader.dll is installed in BepInEx\\patchers.";
                    Plugin.Log.LogWarning(ErrorMessage);
                    harmony.PatchAll(typeof(Fixer_Patch));
```

[References/starfi5h-ModFixerOne/Code/Source/EarlierWorkingSource/Plugin.cs](References/starfi5h-ModFixerOne/Code/Source/EarlierWorkingSource/Plugin.cs) - original line 12

```csharp
    public class Plugin : BaseUnityPlugin
    {
        public const string GUID = "starfi5h.plugin.ModFixerOne";
        public const string NAME = "ModFixerOne";
        public const string VERSION = "2.1.2";
```

### Dependency reference code

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs) - original line 22

```csharp
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
[BepInDependency("starfi5h.plugin.ModFixerOne", BepInDependency.DependencyFlags.HardDependency)]
[BepInPlugin("Gnimaerd.DSP.plugin.MoreMegaStructure", "MoreMegaStructure", "2.0.2")]
public class MoreMegaStructure : BaseUnityPlugin, IModCanSave
```

[References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs) - original line 22

```csharp
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
[BepInDependency("starfi5h.plugin.ModFixerOne", BepInDependency.DependencyFlags.HardDependency)]
[BepInPlugin("Gnimaerd.DSP.plugin.MoreMegaStructure", "MoreMegaStructure", "2.0.2")]
public class MoreMegaStructure : BaseUnityPlugin, IModCanSave
```

[References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/MoreMegaStructure.cs) - original line 27

```csharp
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [CommonAPISubmoduleDependency(nameof(ProtoRegistry), nameof(TabSystem), nameof(LocalizationModule))]
    [BepInDependency("starfi5h.plugin.ModFixerOne")]
    [BepInPlugin("Gnimaerd.DSP.plugin.MoreMegaStructure", "MoreMegaStructure", "1.9.6")]
    public class MoreMegaStructure : BaseUnityPlugin, IModCanSave
```

## xiaoye97-LDBTool

[Project identity and versions](References/xiaoye97-LDBTool/reference.json) | [Reference notes](References/xiaoye97-LDBTool/README.md)

Upstream: https://github.com/xiaoye97/DSP_LDBTool

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs) - original line 11

```csharp
namespace xiaoye97;

public static class LDBTool
{
	public static Action PreAddDataAction;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs) - original line 11

```csharp
namespace xiaoye97;

[BepInPlugin("me.xiaoye97.plugin.Dyson.LDBTool", "LDBTool", "3.0.4")]
public class LDBToolPlugin : BaseUnityPlugin
{
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs) - original line 16

```csharp
	internal static void InitIndex()
	{
		LDBToolPlugin.logger.LogDebug("Generating Proto type list:");
		protoTypes = (from domainAssembly in AppDomain.CurrentDomain.GetAssemblies()
			from assemblyType in GetTypesSafe(domainAssembly)
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs) - original line 19

```csharp
		if (__instance.recipeExecuteData == null)
		{
			LDBToolPlugin.logger.LogWarning($"Importing assembler {__instance.recipeType}: Can't find recipeId {__instance.recipeId}");
			__instance.recipeId = 0;
			__instance.recipeType = ERecipeType.None;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs) - original line 12

```csharp
	private static void HistoryPatch(GameHistoryData __instance)
	{
		foreach (Proto item in LDBTool.TotalDict[ProtoIndex.GetIndex(typeof(RecipeProto))])
		{
			RecipeProto recipeProto = item as RecipeProto;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/UITip_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/UITip_Patch.cs) - original line 12

```csharp
	private static void ItemTipPatch(UIItemTip __instance, int itemId)
	{
		if (LDBToolPlugin.ShowProto.Value)
		{
			__instance.nameText.text += $" {itemId}";
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/VFPreload_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/VFPreload_Patch.cs) - original line 15

```csharp
	private static void VFPreloadPrePatch()
	{
		if (!LDBTool.Finshed)
		{
			LDBToolPlugin.logger.LogInfo("Pre Loading...");
```

[References/xiaoye97-LDBTool/Code/Evidence/InitialPhase/check.cs](References/xiaoye97-LDBTool/Code/Evidence/InitialPhase/check.cs) - original line 53

```csharp
            return null;
        };
        try { plugin = Assembly.LoadFrom(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "LDBTool.dll")); Run(); }
        catch (Exception error) { Console.Error.WriteLine(error); Environment.ExitCode = 1; }
    }
```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 17

```csharp

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/ProtoRegistry.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/ProtoRegistry.cs) - original line 81

```csharp
		spriteFileExtensions = new string[3] { ".jpg", ".png", ".tif" };
		audioClipFileExtensions = new string[4] { ".mp3", ".ogg", ".waw", ".aif" };
		LDBTool.PostAddDataAction = (Action)Delegate.Combine(LDBTool.PostAddDataAction, new Action(OnPostAdd));
		LDBTool.EditDataAction = (Action<Proto>)Delegate.Combine(LDBTool.EditDataAction, new Action<Proto>(EditProto));
	}
```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs) - original line 30

```csharp
    /// </summary>
    [BepInPlugin(GUID, DISPNAME, VERSION)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 25

```csharp
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.LoShin.GenesisBook.InstallationCheck", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/MoreMegaStructure.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/MoreMegaStructure.cs) - original line 37

```csharp
			HarmonyPatch.Patch(AccessTools.Method(typeof(VFPreload), "InvokeOnLoadWorkEnded"), null, new HarmonyMethod(typeof(MoreMegaStructure), "LDBToolOnPostAddDataAction")
			{
				after = new string[1] { "me.xiaoye97.plugin.Dyson.LDBTool" }
			});
		}
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/DisableLDBToolCachePatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/DisableLDBToolCachePatches.cs) - original line 21

```csharp

	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	[HarmonyAfter(new string[] { "me.xiaoye97.plugin.Dyson.LDBTool" })]
	[HarmonyPostfix]
	public static void DeleteFiles()
```

[References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/DspBattlePlugin.cs](References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/DspBattlePlugin.cs) - original line 22

```csharp
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.soardev.universegentweaks", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("org.LoShin.GenesisBook", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/Utils.cs](References/ckcz123-TheyComeFromVoid/Code/Source/Reconstructed/plugins/DSP_Battle/DSP_Battle/Utils.cs) - original line 247

```csharp
		modelProto2.sid = "";
		modelProto2.SID = "";
		LDBTool.PreAddProto((Proto)modelProto2);
	}

```

[References/ckcz123-TheyComeFromVoid/Code/Source/EarlierWorkingSource/BattleProtos.cs](References/ckcz123-TheyComeFromVoid/Code/Source/EarlierWorkingSource/BattleProtos.cs) - original line 167

```csharp
                elite8128._iconSprite = ori8128.iconSprite;

                LDBTool.PreAddProto(elite8128);

                Utils.CopyModelProto(300, 770);
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs) - original line 18

```csharp
namespace MoreMegaStructure;

[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
```

[References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs) - original line 18

```csharp
namespace MoreMegaStructure;

[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MMSProtos.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MMSProtos.cs) - original line 423

```csharp
		LDB.items.Select(2316).recipes.Add(recipeProto26);
		LDB.items.Select(2306).recipes.Add(recipeProto27);
		LDBTool.PostAddProto((Proto)recipeProto13);
		LDBTool.PostAddProto((Proto)recipeProto10);
		LDBTool.PostAddProto((Proto)recipeProto15);
```

[References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne.Mods/LDBTool_Patch.cs](References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne.Mods/LDBTool_Patch.cs) - original line 43

```csharp
	public const string NAME = "LDBTool";

	public const string GUID = "me.xiaoye97.plugin.Dyson.LDBTool";

	public const string VERSION = "3.0.1";
```

[References/starfi5h-ModFixerOne/Code/Source/EarlierWorkingSource/Mods/LDBTool_Patch.cs](References/starfi5h-ModFixerOne/Code/Source/EarlierWorkingSource/Mods/LDBTool_Patch.cs) - original line 11

```csharp
    {
        public const string NAME = "LDBTool";
        public const string GUID = "me.xiaoye97.plugin.Dyson.LDBTool";
        public const string VERSION = "3.0.1";
        private static bool IsGameLoaded = false;
```

[References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs](References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs) - original line 48

```csharp
			}
			harmony.PatchAll(typeof(Common_Patch));
			LDBTool_Patch.Init(harmony);
			if (ErrorMessage != "")
			{
```
