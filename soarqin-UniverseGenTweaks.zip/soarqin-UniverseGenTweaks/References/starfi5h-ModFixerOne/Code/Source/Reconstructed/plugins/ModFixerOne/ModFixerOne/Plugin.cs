using System.Diagnostics;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;

namespace ModFixerOne;

[BepInPlugin("starfi5h.plugin.ModFixerOne", "ModFixerOne", "2.1.2")]
public class Plugin : BaseUnityPlugin
{
	public const string GUID = "starfi5h.plugin.ModFixerOne";

	public const string NAME = "ModFixerOne";

	public const string VERSION = "2.1.2";

	public static ManualLogSource Log;

	public static Plugin Instance { get; private set; }

	public Harmony Harmony { get; private set; }

	public void Awake()
	{
		Instance = this;
		Log = base.Logger;
		Harmony = new Harmony("starfi5h.plugin.ModFixerOne");
		Fixer_Patch.OnAwake();
	}

	public void Start()
	{
		Fixer_Patch.OnStart();
	}

	[Conditional("DEBUG")]
	public void OnDestroy()
	{
		Harmony.UnpatchSelf();
		Harmony = null;
	}
}
