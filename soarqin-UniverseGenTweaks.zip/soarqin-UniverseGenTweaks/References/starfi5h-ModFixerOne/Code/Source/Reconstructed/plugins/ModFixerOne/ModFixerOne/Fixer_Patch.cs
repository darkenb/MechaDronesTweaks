using System;
using HarmonyLib;
using ModFixerOne.Mods;

namespace ModFixerOne;

public static class Fixer_Patch
{
	public static string ErrorMessage = "";

	public static void OnAwake()
	{
		try
		{
			Harmony harmony = Plugin.Instance.Harmony;
			if (!IsVaild())
			{
				ErrorMessage = "Can't find injected fields or methods!\n Please make sure that ModFixerOnePreloader.dll is installed in BepInEx\\patchers.";
				Plugin.Log.LogWarning(ErrorMessage);
				harmony.PatchAll(typeof(Fixer_Patch));
			}
			else if (ErrorMessage != "")
			{
				ErrorMessage = "Error occurred when patching following mods:" + ErrorMessage;
				Plugin.Log.LogWarning(ErrorMessage);
				harmony.PatchAll(typeof(Fixer_Patch));
			}
		}
		catch (Exception data)
		{
			Plugin.Log.LogError(data);
		}
	}

	public static void OnStart()
	{
		try
		{
			Harmony harmony = Plugin.Instance.Harmony;
			if (!IsVaild())
			{
				ErrorMessage = "Can't find injected fields or methods!\n Please make sure that ModFixerOnePreloader.dll is installed in BepInEx\\patchers.";
				Plugin.Log.LogWarning(ErrorMessage);
				harmony.PatchAll(typeof(Fixer_Patch));
				return;
			}
			harmony.PatchAll(typeof(Common_Patch));
			LDBTool_Patch.Init(harmony);
			if (ErrorMessage != "")
			{
				ErrorMessage = "Error occurred when patching following mods:" + ErrorMessage;
				harmony.PatchAll(typeof(Fixer_Patch));
			}
		}
		catch (Exception data)
		{
			Plugin.Log.LogError(data);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	internal static void InvokeOnLoadWorkEnded()
	{
		try
		{
			ShowMessageBox();
		}
		catch (Exception data)
		{
			Plugin.Log.LogError(data);
		}
	}

	private static void ShowMessageBox()
	{
		UIMessageBox.Show("Mod Fixer One Error", ErrorMessage, "确定".Translate(), 3);
	}

	private static bool IsVaild()
	{
		if (AccessTools.TypeByName("Language") == null)
		{
			return false;
		}
		if (AccessTools.TypeByName("StringTranslate") == null)
		{
			return false;
		}
		if (AccessTools.TypeByName("StringProto") == null)
		{
			return false;
		}
		return true;
	}
}
