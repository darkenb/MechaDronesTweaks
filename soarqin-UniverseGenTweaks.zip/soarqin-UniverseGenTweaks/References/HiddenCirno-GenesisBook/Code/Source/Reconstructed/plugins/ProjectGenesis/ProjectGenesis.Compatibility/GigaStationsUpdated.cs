using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using BepInEx.Bootstrap;
using HarmonyLib;
using xiaoye97;

namespace ProjectGenesis.Compatibility;

internal static class GigaStationsUpdated
{
	internal const string GUID = "org.kremnev8.plugin.GigaStationsUpdated";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.org.kremnev8.plugin.GigaStationsUpdated");

	internal static void Awake()
	{
		if (Chainloader.PluginInfos.TryGetValue("org.kremnev8.plugin.GigaStationsUpdated", out var value))
		{
			Type type = value.Instance.GetType().Assembly.GetType("GigaStations.GigaStationsPlugin");
			HarmonyPatch.Patch(AccessTools.Method(type, "AddGigaCollector"), null, null, new HarmonyMethod(typeof(GigaStationsUpdated), "AddGigaCollector_Transpiler"));
			ref List<List<Proto>> preToAdd = ref AccessTools.StaticFieldRefAccess<List<List<Proto>>>(typeof(LDBTool), "PreToAdd");
			MoveConflictRecipes(ref preToAdd);
			MoveBuildIndex(ref preToAdd);
		}
	}

	private static void MoveConflictRecipes(ref List<List<Proto>> preToAdd)
	{
		int index = ProtoIndex.GetIndex(typeof(RecipeProto));
		foreach (RecipeProto item in from RecipeProto proto in preToAdd[index]
			where proto != null
			select proto)
		{
			switch (item.ID)
			{
			case 410:
				item.ID = 430;
				item.Type = (ERecipeType)9;
				break;
			case 411:
				item.ID = 431;
				item.Type = (ERecipeType)9;
				break;
			case 412:
				item.ID = 432;
				item.Type = (ERecipeType)9;
				break;
			}
		}
	}

	private static void MoveBuildIndex(ref List<List<Proto>> preToAdd)
	{
		int index = ProtoIndex.GetIndex(typeof(ItemProto));
		foreach (ItemProto item in from ItemProto proto in preToAdd[index]
			where proto != null
			select proto)
		{
			switch (item.ID)
			{
			case 2110:
				item.BuildIndex = 1207;
				break;
			case 2111:
				item.BuildIndex = 1208;
				break;
			case 2112:
				item.BuildIndex = 1209;
				item.DescFields = new int[4] { 18, 32, 1, 40 };
				break;
			}
		}
	}

	public static IEnumerable<CodeInstruction> AddGigaCollector_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(PrefabDesc), "workEnergyPerTick")));
		codeMatcher.SetAndAdvance(OpCodes.Call, AccessTools.Method(typeof(GigaStationsUpdated), "SetWorkEnergyPerTick"));
		return codeMatcher.InstructionEnumeration();
	}

	public static void SetWorkEnergyPerTick(PrefabDesc desc, long workEnergyPerTick)
	{
		desc.workEnergyPerTick = 0L;
	}
}
