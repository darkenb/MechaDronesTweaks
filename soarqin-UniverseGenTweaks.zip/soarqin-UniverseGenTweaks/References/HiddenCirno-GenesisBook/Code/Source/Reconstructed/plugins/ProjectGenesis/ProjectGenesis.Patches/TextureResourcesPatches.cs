using System;
using HarmonyLib;
using ProjectGenesis.Utils;
using UnityEngine;

namespace ProjectGenesis.Patches;

public static class TextureResourcesPatches
{
	[HarmonyPatch(typeof(Resources), "Load", new Type[]
	{
		typeof(string),
		typeof(Type)
	})]
	[HarmonyBefore(new string[] { "dsp.common-api.CommonAPI" })]
	[HarmonyPrefix]
	public static bool GetAssemblyManifestResource(ref string path, Type systemTypeInstance, ref UnityEngine.Object __result)
	{
		if (!path.StartsWith("Assets/texpack/"))
		{
			return true;
		}
		string name = path.Substring("Assets/texpack/".Length);
		if (systemTypeInstance == typeof(Texture2D))
		{
			__result = TextureHelper.GetTexture(name);
			return __result == null;
		}
		if (systemTypeInstance == typeof(Sprite))
		{
			__result = TextureHelper.GetSprite(name);
			return __result == null;
		}
		return true;
	}
}
