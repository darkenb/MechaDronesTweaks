using System;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using CommonAPI;
using CommonAPI.Systems;
using HarmonyLib;
using NebulaAPI;
using NebulaAPI.Interfaces;
using ProjectGenesis.Compatibility;
using ProjectGenesis.Patches;
using ProjectGenesis.Utils;
using UnityEngine;
using crecheng.DSPModSave;
using xiaoye97;

namespace ProjectGenesis;

[BepInPlugin("org.LoShin.GenesisBook", "GenesisBook", "3.2.6")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.LoShin.GenesisBook.InstallationCheck", BepInDependency.DependencyFlags.SoftDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
[ModSaveSettings(/*Could not decode attribute arguments.*/)]
public class ProjectGenesis : BaseUnityPlugin, IModCanSave, IMultiplayerModWithSettings, IMultiplayerMod
{
	public const string MODGUID = "org.LoShin.GenesisBook";

	public const string MODNAME = "GenesisBook";

	public const string VERSION = "3.2.6";

	public const string DEBUGVERSION = "";

	public static bool LoadCompleted;

	internal static ManualLogSource logger;

	internal static ConfigFile configFile;

	internal static UIPlanetFocusWindow PlanetFocusWindow;

	internal static int[] TableID;

	internal static string ModPath;

	internal static ConfigEntry<bool> LDBToolCacheEntry;

	internal static ConfigEntry<bool> HideTechModeEntry;

	internal static ConfigEntry<bool> ShowMessageBoxEntry;

	internal static ConfigEntry<int> ProductOverflowEntry;

	private Harmony Harmony;

	public string Version => "3.2.6";

	public void Awake()
	{
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Expected O, but got Unknown
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Expected O, but got Unknown
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Expected O, but got Unknown
		//IL_027a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0284: Expected O, but got Unknown
		logger = base.Logger;
		if (!InstallationCheckPlugin.BepinExVersionMatch)
		{
			logger.Log(LogLevel.Error, "BepinEx Version is not 5.4.17!");
		}
		logger.Log(LogLevel.Info, "GenesisBook Awake");
		configFile = base.Config;
		LDBToolCacheEntry = base.Config.Bind("config", "UseLDBToolCache", defaultValue: false, "Enable LDBTool Cache, which allows you use config to fix some compatibility issues.\n启用LDBTool缓存，允许使用配置文件修复部分兼容性问题");
		HideTechModeEntry = base.Config.Bind("config", "HideTechMode", defaultValue: true, "Enable Tech Exploration Mode, which will hide locked techs in tech tree.\n启用科技探索模式，启用后将隐藏未解锁的科技");
		ShowMessageBoxEntry = base.Config.Bind("config", "ShowMessageBox", defaultValue: true, "Show message when GenesisBook is loaded.\n首次加载时的提示信息");
		ProductOverflowEntry = base.Config.Bind("config", "ProductOverflow", 0, "Changing the condition for stopping production of some recipes from single product pile up to all product pile up.\n将部分配方停止生产的条件由单产物堆积改为所有产物均堆积");
		base.Config.Save();
		Assembly executingAssembly = Assembly.GetExecutingAssembly();
		ModPath = Path.GetDirectoryName(executingAssembly.Location);
		ResourceData val = new ResourceData("org.LoShin.GenesisBook", "genesis-models", ModPath);
		val.LoadAssetBundle("genesis-models");
		ProtoRegistry.AddResource(val);
		ResourceData val2 = new ResourceData("org.LoShin.GenesisBook", "genesis-models-lab", ModPath);
		val2.LoadAssetBundle("genesis-models-lab");
		ProtoRegistry.AddResource(val2);
		Shader replacementShader = val.bundle.LoadAsset<Shader>("Assets/genesis-models/shaders/PBR Standard Vein Stone COLOR.shader");
		SwapShaderPatches.AddSwapShaderMapping("VF Shaders/Forward/PBR Standard Vein Stone", replacementShader);
		Shader replacementShader2 = val.bundle.LoadAsset<Shader>("Assets/genesis-models/shaders/PBR Standard Vein Metal COLOR.shader");
		SwapShaderPatches.AddSwapShaderMapping("VF Shaders/Forward/PBR Standard Vein Metal", replacementShader2);
		Shader replacementShader3 = val2.bundle.LoadAsset<Shader>("Assets/genesis-models/shaders/PBR Standard Vertex Toggle Lab REPLACE.shader");
		SwapShaderPatches.AddSwapShaderMapping("VF Shaders/Forward/PBR Standard Vertex Toggle Lab", replacementShader3);
		NebulaModAPI.RegisterPackets(executingAssembly);
		NebulaModAPI.OnPlanetLoadRequest = (Action<int>)Delegate.Combine(NebulaModAPI.OnPlanetLoadRequest, (Action<int>)delegate(int planetId)
		{
			NebulaModAPI.MultiplayerSession.Network.SendPacket<GenesisBookPlanetLoadRequest>(new GenesisBookPlanetLoadRequest(planetId));
		});
		NebulaModAPI.OnPlanetLoadFinished = (Action<int>)Delegate.Combine(NebulaModAPI.OnPlanetLoadFinished, new Action<int>(GenesisBookPlanetDataProcessor.ProcessBytesLater));
		Harmony = new Harmony("org.LoShin.GenesisBook");
		Type[] types = executingAssembly.GetTypes();
		foreach (Type type in types)
		{
			string text = type.Namespace;
			if (text != null && text.StartsWith("ProjectGenesis.Patches", StringComparison.Ordinal))
			{
				Harmony.PatchAll(type);
			}
		}
		TableID = new int[2]
		{
			TabSystem.RegisterTab("org.LoShin.GenesisBook:org.LoShin.GenesisBookTab2", new TabData("化工页面".TranslateFromJsonSpecial(), "Assets/texpack/T基础化工")),
			TabSystem.RegisterTab("org.LoShin.GenesisBook:org.LoShin.GenesisBookTab3", new TabData("防御页面".TranslateFromJsonSpecial(), "Assets/texpack/O防御"))
		};
		TranslateUtils.RegisterStrings();
		AddVeinPatches.ModifyVeinData();
		LDBTool.PreAddDataAction = (Action)Delegate.Combine(LDBTool.PreAddDataAction, new Action(PreAddDataAction));
		LDBTool.PostAddDataAction = (Action)Delegate.Combine(LDBTool.PostAddDataAction, new Action(PostAddDataAction));
		LoadCompleted = true;
	}

	public void Export(BinaryWriter w)
	{
		w.Write(VersionNumber());
		MegaAssemblerPatches.Export(w);
		PlanetFocusPatches.Export(w);
		QuantumStoragePatches.Export(w);
		AdvancedLaserPatches.Export(w);
		GlobalPowerSupplyPatches.Export(w);
	}

	public void Import(BinaryReader r)
	{
		r.ReadInt32();
		MegaAssemblerPatches.Import(r);
		PlanetFocusPatches.Import(r);
		QuantumStoragePatches.Import(r);
		AdvancedLaserPatches.Import(r);
		GlobalPowerSupplyPatches.Import(r);
	}

	public void IntoOtherSave()
	{
		MegaAssemblerPatches.IntoOtherSave();
		PlanetFocusPatches.IntoOtherSave();
		QuantumStoragePatches.IntoOtherSave();
		AdvancedLaserPatches.IntoOtherSave();
		GlobalPowerSupplyPatches.IntoOtherSave();
	}

	public bool CheckVersion(string hostVersion, string clientVersion)
	{
		return hostVersion.Equals(clientVersion);
	}

	private void PreAddDataAction()
	{
		LDB.items.OnAfterDeserialize();
		ModifyPlanetTheme.ModifyPlanetThemeDataVanilla();
		CopyModelUtils.AddCopiedModelProto();
		AddVeinPatches.AddEffectEmitterProto();
		JsonDataUtils.ImportJson(TableID);
		ModifyUpgradeTech.ModifyUpgradeTeches();
	}

	private void PostAddDataAction()
	{
		VegeProto vegeProto = LDB.veges.Select(9999);
		vegeProto.MiningItem = new int[4] { 6216, 1101, 1104, 6203 };
		vegeProto.MiningCount = new int[4] { 10, 100, 100, 100 };
		vegeProto.MiningChance = new float[4] { 1f, 1f, 1f, 1f };
		vegeProto.Preload();
		LabComponent.matrixPoints = new int[9];
		LabComponent.matrixIds = new int[9] { 6001, 6002, 6003, 6004, 6005, 6006, 6278, 6279, 6280 };
		LabComponent.matrixShaderStates = new float[10]
		{
			0f,
			11111.2f,
			22222.2f,
			33333.2f,
			44444.2f,
			55555.2f,
			66666.2f,
			77777.2f,
			88888.2f,
			271826f / MathF.E
		};
		LDB.items.OnAfterDeserialize();
		LDB.recipes.OnAfterDeserialize();
		LDB.techs.OnAfterDeserialize();
		LDB.models.OnAfterDeserialize();
		LDB.milestones.OnAfterDeserialize();
		LDB.journalPatterns.OnAfterDeserialize();
		LDB.themes.OnAfterDeserialize();
		LDB.veins.OnAfterDeserialize();
		if (GameMain.instance != null)
		{
			GameMain.instance.CreateGPUInstancing();
			GameMain.instance.CreateBPGPUInstancing();
			GameMain.instance.CreateStarmapGPUInstancing();
		}
		JsonDataUtils.PrefabDescPostFix();
		CopyModelUtils.ModelPostFix();
		ProtoPreload();
		JsonDataUtils.ApplyGoalsChild();
		CopyModelUtils.ModifyEnemyHpUpgrade();
		AddVeinPatches.SetMinerMk2Color();
		ChemicalRecipeFcolPatches.SetChemicalRecipeFcol();
		AddVeinPatches.SetEffectEmitterProto();
		VFEffectEmitter.Init();
		ItemProto.InitFuelNeeds();
		ItemProto.InitTurretNeeds();
		ItemProto.InitFluids();
		ItemProto.InitTurrets();
		ItemProto.InitEnemyDropTables();
		ItemProto.InitConstructableItems();
		ItemProto.InitItemIds();
		ItemProto.InitItemIndices();
		ItemProto.InitMechaMaterials();
		ItemProto.InitFighterIndices();
		ItemProto.InitPowerFacilityIndices();
		ItemProto.InitProductionMask();
		ModelProto.InitMaxModelIndex();
		ModelProto.InitModelIndices();
		ModelProto.InitModelOrders();
		RecipeProto.InitFractionatorNeeds();
		SignalProtoSet.InitSignalKeyIdPairs();
		RaycastLogic.LoadStatic();
		ref int[] reference = ref ItemProto.turretNeeds[1];
		reference[1] = 7607;
		reference[2] = 1603;
		ItemProto.stationCollectorId = 2105;
		ItemProto.kFuelAutoReplenishIds = FuelRodPatches.FuelRods;
		CopyModelUtils.ItemPostFix();
		StorageComponent.staticLoaded = false;
		StorageComponent.LoadStatic();
		UIBuildMenu.staticLoaded = false;
		UIBuildMenu.StaticLoad();
		SpaceSector.PrefabDescByModelIndex = null;
		SpaceSector.InitPrefabDescArray();
		PlanetFactory.PrefabDescByModelIndex = null;
		PlanetFactory.InitPrefabDescArray();
		ref MechaMaterialSetting reference2 = ref Configs.builtin.mechaArmorMaterials[21];
		reference2.itemId = 7705;
		reference2.density = 8.57f;
		reference2.durability = 4.35f;
		DevFunction();
	}

	private static void DevFunction()
	{
	}

	private static void ProtoPreload()
	{
		MilestoneProto[] dataArray = LDB.milestones.dataArray;
		for (int i = 0; i < dataArray.Length; i++)
		{
			dataArray[i].Preload();
		}
		JournalPatternProto[] dataArray2 = LDB.journalPatterns.dataArray;
		for (int i = 0; i < dataArray2.Length; i++)
		{
			dataArray2[i].Preload();
		}
		VeinProto[] dataArray3 = LDB.veins.dataArray;
		for (int i = 0; i < dataArray3.Length; i++)
		{
			dataArray3[i].Preload();
		}
		TechProto[] dataArray4 = LDB.techs.dataArray;
		for (int i = 0; i < dataArray4.Length; i++)
		{
			dataArray4[i].Preload();
		}
		for (int j = 0; j < LDB.items.dataArray.Length; j++)
		{
			ItemProto obj = LDB.items.dataArray[j];
			obj.recipes = null;
			obj.rawMats = null;
			obj.Preload(j);
		}
		for (int k = 0; k < LDB.recipes.dataArray.Length; k++)
		{
			LDB.recipes.dataArray[k].Preload(k);
		}
		dataArray4 = LDB.techs.dataArray;
		foreach (TechProto techProto in dataArray4)
		{
			techProto.PreTechsImplicit = techProto.PreTechsImplicit.Except(techProto.PreTechs).ToArray();
			techProto.UnlockRecipes = techProto.UnlockRecipes.Distinct().ToArray();
			techProto.Preload2();
		}
	}

	internal static void SetConfig(bool currentLDBToolCache, bool currentHideTechMode, bool currentShowMessageBox, int currentProductOverflow)
	{
		LDBToolCacheEntry.Value = currentLDBToolCache;
		HideTechModeEntry.Value = currentHideTechMode;
		ShowMessageBoxEntry.Value = currentShowMessageBox;
		ProductOverflowEntry.Value = currentProductOverflow;
		logger.LogInfo("SettingChanged");
		configFile.Save();
	}

	internal static void LogInfo(object data)
	{
		logger.LogInfo(data);
	}

	internal static int VersionNumber()
	{
		Version version = default(Version);
		version.FromFullString("3.2.6");
		return version.sig;
	}
}
