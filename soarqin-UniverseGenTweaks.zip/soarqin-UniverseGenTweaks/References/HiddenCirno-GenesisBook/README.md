# Reference: HiddenCirno-GenesisBook

Upstream: https://github.com/Awbugl/ProjectGenesis

The analysis and proposed fixes in this handoff were developed with assistance from the GPT 6.1 Sol model. English documentation accompanies the code to explain what changed, why it changed, and the available validation results.

Manifest version: 3.2.3. Exact local plugin versions, GUIDs, DLL SHA-256 values and MVIDs are in [reference.json](reference.json). The upstream URL identifies the project; it is not a claim that upstream HEAD contains these local changes.

`Code/` contains only the source files referenced by this package. These are review excerpts, not a complete related-mod project or runtime dependency. Context and code excerpts are in the receiving package's [RELATED_MODS.md](../../RELATED_MODS.md). No related-mod DLLs or assets are bundled.
