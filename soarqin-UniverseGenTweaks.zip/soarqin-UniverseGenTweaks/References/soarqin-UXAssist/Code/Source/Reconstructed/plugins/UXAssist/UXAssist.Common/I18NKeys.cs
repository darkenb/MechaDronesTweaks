namespace UXAssist.Common;

public static class I18NKeys
{
	public const string Unknown = "Unknown";

	public const string DoYouWantToUseMetadataToBuyoutTheFollowingTech = "Do you want to use metadata to buyout the following tech?";

	public const string TheFollowingIsTheRequiredMetadataForBuyout = "The following is the required metadata for buyout:";

	public const string BatchBuyoutTech = "Batch buyout tech";

	public const string EnableAutoConstruct = "Enable auto-construct";

	public const string DisableAutoConstruct = "Disable auto-construct";

	public const string BuildingsToConstruct0 = "Buildings to construct: {0}";

	public const string EnableAutoCruise = "Enable auto-cruise";

	public const string DisableAutoCruise = "Disable auto-cruise";

	public const string KEYOpenUXAssistConfigWindow = "KEYOpenUXAssistConfigWindow";

	public const string UXAssistConfig = "UXAssist Config";

	public const string NoRecentMilkywayUploadResults = "No recent milkyway upload results";

	public const string Success = "Success";

	public const string Failure = "Failure: ";

	public const string ShowTopPlayers = "Show top players";

	public const string HideTopPlayers = "Hide top players";

	public const string HighYield = "High yield";

	public const string Perfect = "Perfect";

	public const string UnionResults = "Union results";

	public const string All6BasicOres = "All 6 Basic Ores";

	public const string ShowOriginalName = "Show original name";

	public const string ShowDistance = "Show distance";

	public const string ShowPlanetCount = "Show planet count";

	public const string ShowAllInformation = "Show all information";

	public const string UXAssistNoNodeToFill = "[UXAssist] No node to fill";

	public const string KEYToggleDoNotRenderEntities = "KEYToggleDoNotRenderEntities";

	public const string KEYOffgridForPaths = "KEYOffgridForPaths";

	public const string KEYCutConveyorBelt = "KEYCutConveyorBelt";

	public const string KEYDismantleBlueprintSelection = "KEYDismantleBlueprintSelection";

	public const string KEYSelectAllBuildingsInBlueprintCopy = "KEYSelectAllBuildingsInBlueprintCopy";

	public const string KEYUPSSpeedDown = "KEYUPSSpeedDown";

	public const string KEYUPSSpeedUp = "KEYUPSSpeedUp";

	public const string LogicalFrameRate0X = "Logical frame rate: {0}x";

	public const string KEYShowAllStarsName = "KEYShowAllStarsName";

	public const string KEYToggleAllStarsName = "KEYToggleAllStarsName";

	public const string KEYToggleAutoCruise = "KEYToggleAutoCruise";

	public const string SorterCargoStackingPrefix = "Sorter cargo stacking prefix";

	public const string UXAssist = "UXAssist";

	public const string General = "General";

	public const string Factory = "Factory";

	public const string Logistics = "Logistics";

	public const string PlayerMecha = "Player/Mecha";

	public const string DysonSphere = "Dyson Sphere";

	public const string TechCombatUI = "Tech/Combat/UI";

	public const string EnableGameWindowResize = "Enable game window resize";

	public const string RemeberWindowPositionAndSizeOnLastExit = "Remeber window position and size on last exit";

	public const string BetterAutoSaveMechanism = "Better auto-save mechanism";

	public const string BetterAutoSaveMechanismTips = "Better auto-save mechanism tips";

	public const string ConvertOldSavesToCombatModeOnLoading = "Convert old saves to Combat Mode on loading";

	public const string ProfileBasedSaveFolder = "Profile-based save folder";

	public const string ProfileBasedSaveFolderTips = "Profile-based save folder tips";

	public const string ProfileBasedOption = "Profile-based option";

	public const string ProfileBasedOptionTips = "Profile-based option tips";

	public const string DefaultProfileName = "Default profile name";

	public const string LogicalFrameRate = "Logical Frame Rate";

	public const string Reset = "Reset";

	public const string ProcessPriority = "Process priority";

	public const string High = "High";

	public const string AboveNormal = "Above Normal";

	public const string Normal = "Normal";

	public const string BelowNormal = "Below Normal";

	public const string Idle = "Idle";

	public const string ShowRecentMilkywayUploadResults = "Show recent milkyway upload results";

	public const string UnlimitedInteractiveRange = "Unlimited interactive range";

	public const string NightLight = "Night Light";

	public const string AngleX = "Angle X:";

	public const string RemoveSomeBuildConditions = "Remove some build conditions";

	public const string RemoveBuildRangeLimit = "Remove build range limit";

	public const string LargerAreaForUpgradeAndDismantle = "Larger area for upgrade and dismantle";

	public const string LargerAreaForTerraform = "Larger area for terraform";

	public const string OffGridBuildingAndSteppedRotation = "Off-grid building and stepped rotation";

	public const string EnablePlayerActionsInGlobeView = "Enable player actions in globe view";

	public const string HideTipsForSoilPilesChanges = "Hide tips for soil piles changes";

	public const string EnhancedCountControlForHandMake = "Enhanced count control for hand-make";

	public const string EnhancedCountControlForHandMakeTips = "Enhanced count control for hand-make tips";

	public const string QuickBuildAndDismantleStackingLabs = "Quick build and dismantle stacking labs";

	public const string FastFillInToAndTakeOutFromTanks = "Fast fill in to and take out from tanks";

	public const string SpeedRatio = "Speed Ratio";

	public const string CutConveyorBeltWithShortcutKey = "Cut conveyor belt (with shortcut key)";

	public const string ProtectVeinsFromExhaustion = "Protect veins from exhaustion";

	public const string ProtectVeinsFromExhaustionTips = "Protect veins from exhaustion tips";

	public const string DoNotRenderFactoryEntities = "Do not render factory entities";

	public const string HideSortersToo = "Hide sorters too";

	public const string DragBuildingPowerPolesInMaximumConnectionRange = "Drag building power poles in maximum connection range";

	public const string BuildTeslaTowerAndWirelessPowerTowerAlternately = "Build Tesla Tower and Wireless Power Tower alternately";

	public const string AutoConstructButton = "Auto-construct button";

	public const string BeltSignalsForBuyOutDarkFogItemsAutomatically = "Belt signals for buy out dark fog items automatically";

	public const string MemoryUnit = "Memory Unit";

	public const string EnergyFragment = "Energy Fragment";

	public const string SiliconNeuron = "Silicon Neuron";

	public const string NegentropySingularity = "Negentropy Singularity";

	public const string MatterReassembler = "Matter Reassembler";

	public const string VirtualParticle = "Virtual Particle";

	public const string CtrlShiftClickToPickItemsFromWholeBelts = "Ctrl+Shift+Click to pick items from whole belts";

	public const string IncludeBranchesOfBelts = "Include branches of belts";

	public const string IncludeConnectedInserters = "Include connected inserters";

	public const string AutoConfigLogisticStations = "Auto-config logistic stations";

	public const string LimitAutoReplenishCountToValuesBelow = "Limit auto-replenish count to values below";

	public const string Dispenser = "Dispenser";

	public const string BattlefieldAnalysisBase = "Battlefield Analysis Base";

	public const string PLS = "PLS";

	public const string ILS = "ILS";

	public const string AdvancedMiningMachine = "Advanced Mining Machine";

	public const string OrbitalCollectorProductLimit = "Orbital Collector product limit";

	public const string ApplyToUniverse = "Apply to universe";

	public const string SetDefaultRemoteLogicToStorage = "Set default remote logic to storage";

	public const string MaxChargingPower = "Max. Charging Power";

	public const string CountOfBotsFilled = "Count of Bots filled";

	public const string DroneTransportRange = "Drone transport range";

	public const string MinLoadOfDrones = "Min. Load of Drones";

	public const string OutgoingIntegrationCount = "Outgoing integration count";

	public const string CountOfDronesFilled = "Count of Drones filled";

	public const string VesselTransportRange = "Vessel transport range";

	public const string WarpDistance = "Warp distance";

	public const string MinLoadOfVessels = "Min. Load of Vessels";

	public const string IncludeOrbitalCollector = "Include Orbital Collector";

	public const string WarpersRequired = "Warpers required";

	public const string CountOfVesselsFilled = "Count of Vessels filled";

	public const string CollectingSpeed = "Collecting Speed";

	public const string MinPilerValue = "Min. Piler Value";

	public const string UseTechMaxForPiler = "Use tech max for piler";

	public const string Cancel = "Cancel";

	public const string OK = "OK";

	public const string ApplyConfigToPlanet = "Apply config to planet";

	public const string ApplyAllConfigToPlanet = "Apply all config to planet";

	public const string ApplyConfigToPlanetTips = "Apply config to planet tips";

	public const string ApplyAllConfigToPlanetTips = "Apply all config to planet tips";

	public const string AllowOverflowForLogisticStationsAndAdvancedMiningMachines = "Allow overflow for Logistic Stations and Advanced Mining Machines";

	public const string IncreaseMaximumPowerUsageInLogisticStationsAndAdvancedMiningMachines = "Increase maximum power usage in Logistic Stations and Advanced Mining Machines";

	public const string EnhanceControlForLogisticStorageCapacities = "Enhance control for logistic storage capacities";

	public const string EnhanceControlForLogisticStorageCapacitiesTips = "Enhance control for logistic storage capacities tips";

	public const string LogisticsControlPanelImprovement = "Logistics Control Panel Improvement";

	public const string LogisticsControlPanelImprovementTips = "Logistics Control Panel Improvement tips";

	public const string RealTimeLogisticStationsInfoPanel = "Real-time logistic stations info panel";

	public const string ShowStatusBarsForStorageItems = "Show status bars for storage items";

	public const string TweakBuildingBuffers = "Tweak building buffers";

	public const string TweakBuildingBuffersTips = "Tweak building buffers tips";

	public const string AssemblerBufferTimeMultiplierInSeconds = "Assembler buffer time multiplier(in seconds)";

	public const string AssemblerBufferMinimumMultiplier = "Assembler buffer minimum multiplier";

	public const string BufferCountForAssemblingInLabs = "Buffer count for assembling in labs";

	public const string ExtraBufferCountForSelfEvolutionLabs = "Extra buffer count for Self-evolution Labs";

	public const string BufferCountForResearchingInLabs = "Buffer count for researching in labs";

	public const string RayReceiverGravitonLensBufferCount = "Ray Receiver Graviton Lens buffer count";

	public const string EjectorSolarSailsBufferCount = "Ejector Solar Sails buffer count";

	public const string SiloRocketsBufferCount = "Silo Rockets buffer count";

	public const string ShortcutKeysForBlueprintCopyMode = "Shortcut keys for Blueprint Copy mode";

	public const string ShortcutKeysForBlueprintCopyModeTips = "Shortcut keys for Blueprint Copy mode tips";

	public const string ShortcutKeysForShowingStarsName = "Shortcut keys for showing stars' name";

	public const string AutoBoost = "Auto boost";

	public const string DistanceToUseWarp = "Distance to use warp";

	public const string StopAutoCruiseOnManualInput = "Stop auto-cruise on manual input";

	public const string UseWarp = "Use warp";

	public const string UseWarpMinimalEnergy = "Use warp minimal energy";

	public const string AutoBoostMinimalEnergy = "Auto boost minimal energy";

	public const string DarkFogHiveFollowDistance = "Dark Fog Hive follow distance";

	public const string DarkFogCarrierFollowDistance = "Dark Fog Carrier follow distance";

	public const string AutoCruiseStarted = "Auto-cruise started";

	public const string AutoCruiseStopped = "Auto-cruise stopped";

	public const string AutoCruiseNoTarget = "Auto-cruise needs a navigation target";

	public const string TreatStackItemsAsSingleInMonitorComponents = "Treat stack items as single in monitor components";

	public const string InitializeThisPlanet = "Initialize This Planet";

	public const string InitializeThisPlanetConfirm = "Initialize This Planet Confirm";

	public const string ReturnBuildingsToPlayerWhenInitializingPlanet = "Return buildings to player when initializing planet";

	public const string ReturnLogisticStorageItemsToPlayerWhenInitializingPlanet = "Return logistic storage items to player when initializing planet";

	public const string ReturnBeltAndFactoryItemsToPlayerWhenInitializingPlanet = "Return belt and factory items to player when initializing planet";

	public const string DismantleAllBuildings = "Dismantle All Buildings";

	public const string DismantleAllBuildingsConfirm = "Dismantle All Buildings Confirm";

	public const string QuickBuildOrbitalCollectors = "Quick build Orbital Collectors";

	public const string MaximumCountToBuild = "Maximum count to build";

	public const string Max = "max";

	public const string StopEjectorsWhenAvailableNodesAreAllFilledUp = "Stop ejectors when available nodes are all filled up";

	public const string ConstructOnlyStructurePointsButFrames = "Construct only structure points but frames";

	public const string InitializeDysonSphere = "Initialize Dyson Sphere";

	public const string InitializeDysonSphereConfirm = "Initialize Dyson Sphere Confirm";

	public const string ClickToDismantleSelectedLayer = "Click to dismantle selected layer";

	public const string DismantleSelectedLayer = "Dismantle selected layer";

	public const string DismantleSelectedLayerConfirm = "Dismantle selected layer Confirm";

	public const string AutoFastBuildSpeedMultiplier = "Auto Fast Build Speed Multiplier";

	public const string RestoreUpgradesOfSorterCargoStackingOnPanel = "Restore upgrades of \"Sorter Cargo Stacking\" on panel";

	public const string DisableBattleRelatedTechsInPeaceMode = "Disable battle-related techs in Peace mode";

	public const string BuyOutTechsWithTheirPrerequisites = "Buy out techs with their prerequisites";

	public const string SetSorterCargoStackingToUnresearchedState = "Set \"Sorter Cargo Stacking\" to unresearched state";

	public const string UnlockAllTechsWithMetadata = "Unlock all techs with metadata";

	public const string OpenDarkFogCommunicator = "Open Dark Fog Communicator";

	public const string PlanetVeinUtilization = "Planet vein utilization";

	public const string Metadata = "Metadata";

	public const string InsufficientMetadata = "Insufficient metadata";

	public const string FirstTimeUsingMetadataDescription = "First time using metadata description";

	public const string FirstTimeUsingMetadataTitle = "First time using metadata";

	public const string TechLevelPrefix = "Tech level prefix";

	public const string AutoSaveEntry = "Auto-save entry";

	public static void Register()
	{
		I18N.Add("Unknown", "Unknown", "未知");
		I18N.Add("Do you want to use metadata to buyout the following tech?", "Do you want to use metadata to buyout the following tech?", "要使用元数据买断以下科技吗？");
		I18N.Add("The following is the required metadata for buyout:", "The following is the required metadata for buyout:", "以下是买断所需元数据：");
		I18N.Add("Batch buyout tech", "Batch buyout tech", "批量买断科技");
		I18N.Add("Enable auto-construct", "Enable auto-construct", "启用自动建造");
		I18N.Add("Disable auto-construct", "Disable auto-construct", "禁用自动建造");
		I18N.Add("Buildings to construct: {0}", "Buildings to construct: {0}", "待建造数量: {0}");
		I18N.Add("Enable auto-cruise", "Enable auto-cruise", "启用自动巡航");
		I18N.Add("Disable auto-cruise", "Disable auto-cruise", "禁用自动巡航");
		I18N.Add("KEYOpenUXAssistConfigWindow", "[UXA] Open UXAssist Config Window", "[UXA] 打开UX助手设置面板");
		I18N.Add("UXAssist Config", "UXAssist Config", "UX助手设置");
		I18N.Add("No recent milkyway upload results", "No recent milkyway upload results", "没有最近的银河系发电数据上传结果");
		I18N.Add("Success", "Success", "成功");
		I18N.Add("Failure: ", "Failure: ", "失败: ");
		I18N.Add("Show top players", "Show top players", "显示玩家排行榜");
		I18N.Add("Hide top players", "Hide top players", "隐藏玩家排行榜");
		I18N.Add("High yield", "High yield", "高产");
		I18N.Add("Perfect", "Perfect", "完美");
		I18N.Add("Union results", "Union results", "结果取并集");
		I18N.Add("All 6 Basic Ores", "All 6 Basic Ores", "六种基础矿物齐全");
		I18N.Add("Show original name", "Show original name", "显示原始名称");
		I18N.Add("Show distance", "Show distance", "显示距离");
		I18N.Add("Show planet count", "Show planet count", "显示行星数");
		I18N.Add("Show all information", "Show all information", "显示全部信息");
		I18N.Add("[UXAssist] No node to fill", "[UXAssist] No node to fill", "[UXAssist] 无可建造节点");
		I18N.Add("KEYToggleDoNotRenderEntities", "[UXA] Toggle Do Not Render Factory Entities", "[UXA] 切换不渲染工厂建筑实体");
		I18N.Add("KEYOffgridForPaths", "[UXA] Build belts offgrid", "[UXA] 脱离网格建造传送带");
		I18N.Add("KEYCutConveyorBelt", "[UXA] Cut conveyor belt", "[UXA] 切割传送带");
		I18N.Add("KEYDismantleBlueprintSelection", "[UXA] Dismantle blueprint selected buildings", "[UXA] 拆除蓝图选中的建筑");
		I18N.Add("KEYSelectAllBuildingsInBlueprintCopy", "[UXA] Select all buildings in Blueprint Copy Mode", "[UXA] 蓝图复制时选择所有建筑");
		I18N.Add("KEYUPSSpeedDown", "[UXA] Decrease logical frame rate", "[UXA] 降低逻辑帧率");
		I18N.Add("KEYUPSSpeedUp", "[UXA] Increase logical frame rate", "[UXA] 提升逻辑帧率");
		I18N.Add("Logical frame rate: {0}x", "[UXA] Logical frame rate: {0}x", "[UXA] 逻辑帧速率: {0}x");
		I18N.Add("KEYShowAllStarsName", "[UXA] Keep pressing to show all Stars' name", "[UXA] 按住显示所有星系名称");
		I18N.Add("KEYToggleAllStarsName", "[UXA] Toggle display of all Stars' name", "[UXA] 切换所有星系名称显示状态");
		I18N.Add("KEYToggleAutoCruise", "[UXA] Toggle auto-cruise", "[UXA] 切换自动巡航");
		I18N.Add("Sorter cargo stacking prefix", "Sorter Mk.III cargo stacking : ", "极速分拣器每次可运送 ");
		I18N.Add("UXAssist", "UXAssist", "UX助手");
		I18N.Add("General", "General", "常规");
		I18N.Add("Factory", "Factory", "工厂");
		I18N.Add("Logistics", "Logistics", "物流");
		I18N.Add("Player/Mecha", "Player/Mecha", "玩家/机甲");
		I18N.Add("Dyson Sphere", "Dyson Sphere", "戴森球");
		I18N.Add("Tech/Combat/UI", "Tech/Combat/UI", "科研/战斗/UI");
		I18N.Add("Enable game window resize", "Enable game window resize (maximum box and thick frame)", "可调整游戏窗口大小(可最大化和拖动边框)");
		I18N.Add("Remeber window position and size on last exit", "Remeber window position and size on last exit", "记住上次退出时的窗口位置和大小");
		I18N.Add("Better auto-save mechanism", "Better auto-save mechanism", "更好的自动存档机制");
		I18N.Add("Better auto-save mechanism tips", "Auto saves are stored in 'Save\\AutoSaves' folder, filenames are combined with cluster address and date-time", "自动存档会以星区地址和日期时间组合为文件名存储在'Save\\AutoSaves'文件夹中");
		I18N.Add("Convert old saves to Combat Mode on loading", "Convert old saves to Combat Mode on loading (Use settings in new game panel)", "读取旧档时转为战斗模式(使用新游戏面板的战斗难度设置)");
		I18N.Add("Profile-based save folder", "Mod manager profile based save folder", "基于mod管理器配置档案名的存档文件夹");
		I18N.Add("Profile-based save folder tips", "Save files are stored in 'Save\\<ProfileName>' folder.\nWill use original save location if matching default profile name", "存档文件会存储在'Save\\<ProfileName>'文件夹中\n如果匹配默认配置档案名则使用原始存档位置");
		I18N.Add("Profile-based option", "Mod manager profile based option", "基于mod管理器配置档案名的选项设置");
		I18N.Add("Profile-based option tips", "Options are stored in 'Option\\<ProfileName>.xml'.\nWill use original location if matching default profile name", "配置选项会存储在'Option\\<ProfileName>.xml'里\n如果匹配默认配置档案名则使用原始位置");
		I18N.Add("Default profile name", "Default profile name", "默认配置档案名");
		I18N.Add("Logical Frame Rate", "Logical Frame Rate", "逻辑帧倍率");
		I18N.Add("Reset", "Reset", "重置");
		I18N.Add("Process priority", "Process priority", "进程优先级");
		I18N.Add("High", "High", "高");
		I18N.Add("Above Normal", "Above Normal", "高于正常");
		I18N.Add("Normal", "Normal", "正常");
		I18N.Add("Below Normal", "Below Normal", "低于正常");
		I18N.Add("Idle", "Idle", "空闲");
		I18N.Add("Show recent milkyway upload results", "Show recent milkyway upload results", "显示最近的银河系发电数据上传结果");
		I18N.Add("Unlimited interactive range", "Unlimited interactive range", "无限交互距离");
		I18N.Add("Night Light", "Sunlight at night", "夜间日光灯");
		I18N.Add("Angle X:", "Angle X:", "入射角度X:");
		I18N.Add("Remove some build conditions", "Remove some build conditions", "移除部分不影响游戏逻辑的建造条件");
		I18N.Add("Remove build range limit", "Remove build count and range limit", "移除建造数量和距离限制");
		I18N.Add("Larger area for upgrade and dismantle", "Larger area for upgrade and dismantle", "范围升级和拆除的最大区域扩大");
		I18N.Add("Larger area for terraform", "Larger area for terraform", "范围铺设地基的最大区域扩大");
		I18N.Add("Off-grid building and stepped rotation", "Off-grid building and stepped rotation (Hold Shift)", "脱离网格建造以及小角度旋转(按住Shift)");
		I18N.Add("Enable player actions in globe view", "Enable player actions in globe view", "在行星视图中允许玩家操作");
		I18N.Add("Hide tips for soil piles changes", "Hide tips for soil piles changes", "隐藏沙土数量变动的提示");
		I18N.Add("Enhanced count control for hand-make", "Enhanced count control for hand-make", "手动制造物品的数量控制改进");
		I18N.Add("Enhanced count control for hand-make tips", "Maximum count is increased to 1000.\nHold Ctrl/Shift/Alt to change the count rapidly.", "最大数量提升至1000\n按住Ctrl/Shift/Alt可快速改变数量");
		I18N.Add("Quick build and dismantle stacking labs", "Quick build and dismantle stacking labs/storages/tanks(hold shift)", "快速建造和拆除堆叠研究站/储物仓/储液罐(按住shift)");
		I18N.Add("Fast fill in to and take out from tanks", "Fast fill in to and take out from tanks", "储液罐快速注入和抽取液体");
		I18N.Add("Speed Ratio", "Speed Ratio", "速度倍率");
		I18N.Add("Cut conveyor belt (with shortcut key)", "Cut conveyor belt (with shortcut key)", "切割传送带(使用快捷键)");
		I18N.Add("Protect veins from exhaustion", "Protect veins from exhaustion", "保护矿脉不会耗尽");
		I18N.Add("Protect veins from exhaustion tips", "By default, the vein amount is protected at 100, and oil speed is protected at 1.0/s, you can set them yourself in config file.\nWhen reach the protection value, veins/oils steeps will not be mined/extracted any longer.\nClose this function to resume mining and pumping, usually when you have enough level on `Veins Utilization`", "默认矿脉数量保护于剩余100，采油速保护于速度1.0/s，你可以在配置文件中自行设置。\n当达到保护值时，矿脉和油井将不再被开采。\n关闭此功能以恢复开采，一般是当你在`矿物利用`上有足够的等级时。\n");
		I18N.Add("Do not render factory entities", "Do not render factory entities (except belts and sorters)", "不渲染工厂建筑实体(除了传送带和分拣器)");
		I18N.Add("Hide sorters too", "Hide sorters too", "同时隐藏分拣器");
		I18N.Add("Drag building power poles in maximum connection range", "Drag building power poles in maximum connection range", "拖动建造电线杆时自动使用最大连接距离间隔");
		I18N.Add("Build Tesla Tower and Wireless Power Tower alternately", "Build Tesla Tower and Wireless Power Tower alternately", "交替建造电力感应塔和无线输电塔");
		I18N.Add("Auto-construct button", "Auto-construct button", "自动建造按钮");
		I18N.Add("Belt signals for buy out dark fog items automatically", "Belt signals for buy out dark fog items automatically", "用于自动购买黑雾物品的传送带信号");
		I18N.Add("Memory Unit", "Memory Unit", "存储单元");
		I18N.Add("Energy Fragment", "Energy Fragment", "能量碎片");
		I18N.Add("Silicon Neuron", "Silicon Neuron", "硅基神经元");
		I18N.Add("Negentropy Singularity", "Negentropy Singularity", "负熵奇点");
		I18N.Add("Matter Reassembler", "Matter Reassembler", "物质重组器");
		I18N.Add("Virtual Particle", "Virtual Particle", "虚粒子");
		I18N.Add("Ctrl+Shift+Click to pick items from whole belts", "Ctrl+Shift+Click to pick items from whole belts", "按住Ctrl+Shift点击从整条传送带抓取物品");
		I18N.Add("Include branches of belts", "Include branches of belts", "包含传送带分支");
		I18N.Add("Include connected inserters", "Include connected inserters (and their connected belts if above is checked)", "包含连接的分拣器(若勾选上面的选项则包含分拣器连接的传送带)");
		I18N.Add("Auto-config logistic stations", "Auto-config logistic stations", "自动配置物流设施");
		I18N.Add("Limit auto-replenish count to values below", "Limit auto-replenish count to values below", "限制自动补充数量为下面配置的值");
		I18N.Add("Dispenser", "Logistics Distributor", "物流配送器");
		I18N.Add("Battlefield Analysis Base", "Battlefield Analysis Base", "战场分析基站");
		I18N.Add("PLS", "PLS", "行星物流站");
		I18N.Add("ILS", "ILS", "星际物流站");
		I18N.Add("Advanced Mining Machine", "Advanced Mining Machine", "大型采矿机");
		I18N.Add("Orbital Collector product limit", "Orbital Collector product limit", "轨道采集器产物上限");
		I18N.Add("Apply to universe", "Apply to universe", "应用到全宇宙");
		I18N.Add("Set default remote logic to storage", "Set default remote logic to storage", "设置默认远程逻辑为仓储");
		I18N.Add("Max. Charging Power", "Max. Charging Power", "最大充能功率");
		I18N.Add("Count of Bots filled", "Count of Bots filled", "填充的配送机数量");
		I18N.Add("Drone transport range", "Drone transport range", "运输机最远路程");
		I18N.Add("Min. Load of Drones", "Min. Load of Drones", "运输机起送量");
		I18N.Add("Outgoing integration count", "Outgoing integration count", "输出货物集装数量");
		I18N.Add("Count of Drones filled", "Count of Drones filled", "填充的运输机数量");
		I18N.Add("Vessel transport range", "Vessel transport range", "运输船最远路程");
		I18N.Add("Warp distance", "Warp distance", "曲速启用路程");
		I18N.Add("Min. Load of Vessels", "Min. Load of Vessels", "运输船起送量");
		I18N.Add("Include Orbital Collector", "Include Orbital Collector", "包含轨道采集器");
		I18N.Add("Warpers required", "Warpers required", "翘曲器必备");
		I18N.Add("Count of Vessels filled", "Count of Vessels filled", "填充的运输船数量");
		I18N.Add("Collecting Speed", "Collecting Speed", "开采速度");
		I18N.Add("Min. Piler Value", "Outgoing integration count", "输出货物集装数量");
		I18N.Add("Use tech max for piler", "Use tech max for piler", "集装使用科技上限");
		I18N.Add("Cancel", "Cancel", "取消");
		I18N.Add("OK", "OK", "确定");
		I18N.Add("Apply config to planet", "Apply", "应用");
		I18N.Add("Apply all config to planet", "Apply All", "应用全部");
		I18N.Add("Apply config to planet tips", "Apply this value to all facilities of this type on the current planet", "将此项数值应用到当前行星上所有该类型物流设施");
		I18N.Add("Apply all config to planet tips", "Apply all settings of this category to all facilities of this type on the current planet", "将本分类的所有设置数值应用到当前行星上所有该类型物流设施");
		I18N.Add("Allow overflow for Logistic Stations and Advanced Mining Machines", "Allow overflow for Logistic Stations and Advanced Mining Machines", "允许物流站和大型采矿机物品溢出");
		I18N.Add("Increase maximum power usage in Logistic Stations and Advanced Mining Machines", "Increase maximum power usage in Logistic Stations and Advanced Mining Machines", "提升物流塔和大型采矿机的最大功耗");
		I18N.Add("Enhance control for logistic storage capacities", "Enhance control for logistic storage capacities", "物流塔存储容量控制改进");
		I18N.Add("Enhance control for logistic storage capacities tips", "Logistic storage capacity limits are not scaled on upgrading 'Logistics Carrier Capacity', if they are not set to maximum capacity or already greater than upgraded maximum capacity.\nUse arrow keys to adjust logistic storage capacities:\n  ←/→: -/+10  ↓↑: -/+100", "当升级'运输机舱扩容'时，不会对各种物流塔的存储容量按比例提升，除非设置为最大允许容量或者已经超过升级后的最大容量。\n你可以使用方向键微调物流塔存储容量：\n  ←→: -/+10  ↓↑: -/+100");
		I18N.Add("Logistics Control Panel Improvement", "Logistics Control Panel Improvement", "物流控制面板改进");
		I18N.Add("Logistics Control Panel Improvement tips", "Auto apply filter with item under mouse cursor while opening the panel\nQuick-set item filter while right-clicking item icons in storage list on the panel", "打开面板时自动将鼠标指向物品设为筛选条件\n在控制面板物流塔列表中右键点击物品图标快速设置为筛选条件");
		I18N.Add("Real-time logistic stations info panel", "Real-time logistic stations info panel", "物流运输站实时信息面板");
		I18N.Add("Show status bars for storage items", "Show status bars for storage items", "显示存储物品状态条");
		I18N.Add("Tweak building buffers", "Tweak building buffers", "调整建筑输入缓冲");
		I18N.Add("Tweak building buffers tips", "Original in-game values:\nAssembler buffer time multiplier (in seconds): 4\nAssembler buffer minimum multiplier: 2\nBuffer count for assembling in labs: 6\nExtra buffer count for Self-evolution Labs: 3\nBuffer count for researching in labs: 10\nRay Receiver Graviton Lens buffer count: 20\nEjector Solar Sails buffer count: 20\nSilo Rockets buffer count: 20", "游戏内原始值：\n工厂配方缓冲时间倍率（秒）：4\n工厂配方缓冲最小倍率：2\n研究站矩阵合成模式缓存数量：6\n自演化研究站矩阵额外缓冲数量：3\n研究站科研模式缓存数量：10\n射线接收器透镜缓冲数量：20\n弹射器太阳能帆缓冲数量：20\n发射井火箭缓冲数量：20");
		I18N.Add("Assembler buffer time multiplier(in seconds)", "Assembler buffer time multiplier(in seconds)", "工厂配方缓冲时间倍率(秒)");
		I18N.Add("Assembler buffer minimum multiplier", "Assembler buffer minimum multiplier", "工厂配方缓冲最小倍率");
		I18N.Add("Buffer count for assembling in labs", "Buffer count for assembling in labs", "研究站矩阵合成模式缓存数量");
		I18N.Add("Extra buffer count for Self-evolution Labs", "Extra buffer count for Self-evolution Labs", "自演化研究站矩阵额外缓冲数量");
		I18N.Add("Buffer count for researching in labs", "Buffer count for researching in labs", "研究站科研模式缓存数量");
		I18N.Add("Ray Receiver Graviton Lens buffer count", "Ray Receiver Graviton Lens buffer count", "射线接收器透镜缓冲数量");
		I18N.Add("Ejector Solar Sails buffer count", "Ejector Solar Sails buffer count", "弹射器太阳能帆缓冲数量");
		I18N.Add("Silo Rockets buffer count", "Silo Rockets buffer count", "发射井火箭缓冲数量");
		I18N.Add("Shortcut keys for Blueprint Copy mode", "Shortcut keys for Blueprint Copy mode", "蓝图复制模式快捷键");
		I18N.Add("Shortcut keys for Blueprint Copy mode tips", "You can set 2 shortcut keys in Settings panel:\n  1. Select all buildings\n  2. Dismantle selected buildings", "你可以在设置面板中设置2个快捷键：\n  1. 选择所有建筑\n  2. 拆除选中的建筑");
		I18N.Add("Shortcut keys for showing stars' name", "Shortcut keys for showing stars' name", "启用显示所有星系名称的快捷键");
		I18N.Add("Auto boost", "Auto boost", "自动加速");
		I18N.Add("Distance to use warp", "Distance to use warp (AU)", "使用曲速的距离(AU)");
		I18N.Add("Stop auto-cruise on manual input", "Stop auto-cruise on manual input", "手动输入时停止自动巡航");
		I18N.Add("Use warp", "Use warp", "启用曲速");
		I18N.Add("Use warp minimal energy", "Minimum energy to use warp (MJ)", "使用曲速最低能量(MJ)");
		I18N.Add("Auto boost minimal energy", "Minimum energy for auto boost (MJ)", "自动加速最低能量(MJ)");
		I18N.Add("Dark Fog Hive follow distance", "Dark Fog Hive follow distance (AU)", "黑雾巢穴跟踪距离(AU)");
		I18N.Add("Dark Fog Carrier follow distance", "Dark Fog Carrier follow distance (m)", "黑雾火种跟踪距离(m)");
		I18N.Add("Auto-cruise started", "Auto-cruise started", "自动巡航启动");
		I18N.Add("Auto-cruise stopped", "Auto-cruise stopped", "自动巡航关闭");
		I18N.Add("Auto-cruise needs a navigation target", "Auto-cruise needs a navigation target", "自动巡航需要先设置导航目标");
		I18N.Add("Treat stack items as single in monitor components", "Treat stack items as single in monitor components", "在流速计中将堆叠物品视为单个物品");
		I18N.Add("Initialize This Planet", "Initialize this planet", "初始化本行星");
		I18N.Add("Initialize This Planet Confirm", "This operation will destroy all buildings and revert terrains on this planet, are you sure?", "此操作将会摧毁本行星上的所有建筑并恢复地形，确定吗？");
		I18N.Add("Return buildings to player when initializing planet", "Return buildings to player when initializing planet", "初始化行星时将建筑归还给玩家");
		I18N.Add("Return logistic storage items to player when initializing planet", "Return logistic storage items to player when initializing planet", "初始化行星时将物流塔存储的物品归还给玩家");
		I18N.Add("Return belt and factory items to player when initializing planet", "Return belt and factory items to player when initializing planet", "初始化行星时将传送带和工厂里的物品归还给玩家");
		I18N.Add("Dismantle All Buildings", "Dismantle all buildings", "拆除所有建筑");
		I18N.Add("Dismantle All Buildings Confirm", "This operation will dismantle all buildings on this planet, are you sure?", "此操作将会拆除本行星上的所有建筑，确定吗？");
		I18N.Add("Quick build Orbital Collectors", "Quick build Orbital Collectors", "快速建造轨道采集器");
		I18N.Add("Maximum count to build", "Maximum count to build", "最大建造数量");
		I18N.Add("max", "max", "最大");
		I18N.Add("Stop ejectors when available nodes are all filled up", "Stop ejectors when available nodes are all filled up", "可用节点全部造完时停止弹射");
		I18N.Add("Construct only structure points but frames", "Construct only structure points but frames", "只造节点不造框架");
		I18N.Add("Initialize Dyson Sphere", "Initialize Dyson Sphere", "初始化戴森球");
		I18N.Add("Initialize Dyson Sphere Confirm", "This operation will destroy all layers on this dyson sphere, are you sure?", "此操作将会摧毁戴森球上的所有层级，确定吗？");
		I18N.Add("Click to dismantle selected layer", "Click to dismantle selected layer", "点击拆除对应的戴森壳");
		I18N.Add("Dismantle selected layer", "Dismantle selected layer", "拆除选中的戴森壳");
		I18N.Add("Dismantle selected layer Confirm", "This operation will dismantle selected layer, are you sure?", "此操作将会拆除选中的戴森壳，确定吗？");
		I18N.Add("Auto Fast Build Speed Multiplier", "Auto Fast Build Speed Multiplier", "自动快速建造速度倍率");
		I18N.Add("Restore upgrades of \"Sorter Cargo Stacking\" on panel", "Restore upgrades of \"Sorter Cargo Stacking\" on panel", "在升级面板上恢复\"分拣器货物叠加\"的升级");
		I18N.Add("Disable battle-related techs in Peace mode", "Disable battle-related techs in Peace mode", "在和平模式下隐藏战斗相关科技");
		I18N.Add("Buy out techs with their prerequisites", "Buy out techs with their prerequisites", "购买科技也同时购买所有前置科技");
		I18N.Add("Set \"Sorter Cargo Stacking\" to unresearched state", "Set \"Sorter Cargo Stacking\" to unresearched state", "将\"分拣器货物叠加\"设为未研究状态");
		I18N.Add("Unlock all techs with metadata", "Unlock all techs with metadata", "使用元数据解锁所有科技");
		I18N.Add("Open Dark Fog Communicator", "Open Dark Fog Communicator", "打开黑雾通讯器");
		I18N.Add("Planet vein utilization", "Planet vein utilization in star map", "宇宙视图行星/星系矿脉数量显示");
		I18N.Add("Metadata", "Metadata", "元数据");
		I18N.Add("Insufficient metadata", "Insufficient metadata", "元数据不足");
		I18N.Add("First time using metadata description", "Using metadata will disable achievements in this save. Are you sure?", "使用元数据会禁用本存档成就，确定吗？");
		I18N.Add("First time using metadata", "First time using metadata", "初次使用元数据");
		I18N.Add("Tech level prefix", " Lv.", "等级");
		I18N.Add("Auto-save entry", "Auto-save entry", "自动存档条目");
	}
}
