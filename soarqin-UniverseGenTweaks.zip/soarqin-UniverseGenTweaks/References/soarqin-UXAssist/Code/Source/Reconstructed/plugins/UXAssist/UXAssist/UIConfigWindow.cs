using System;
using System.Text;
using BepInEx.Configuration;
using UXAssist.Common.Config;
using UXAssist.Functions;
using UXAssist.ModsCompat;
using UXAssist.Patches;
using UXAssist.Patches.Logistics;
using UXAssist.UI;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace UXAssist;

public static class UIConfigWindow
{
	private class OcMapper : MyWindow.ValueMapper<int>
	{
		public override int Min => 0;

		public override int Max => 40;

		public override string FormatValue(string format, int value)
		{
			if (value != 0)
			{
				return base.FormatValue(format, value);
			}
			return "max".Translate();
		}
	}

	private class AngleMapper : MyWindow.ValueMapper<float>
	{
		public override int Min => 0;

		public override int Max => 20;

		public override float IndexToValue(int index)
		{
			return (float)index - 10f;
		}

		public override int ValueToIndex(float value)
		{
			return Mathf.RoundToInt(value + 10f);
		}
	}

	private class DistanceMapper : MyWindow.ValueMapper<double>
	{
		public override int Min => 1;

		public override int Max => 40;

		public override double IndexToValue(int index)
		{
			return (double)index * 0.5;
		}

		public override int ValueToIndex(double value)
		{
			return Mathf.RoundToInt((float)(value * 2.0));
		}
	}

	private class DistanceMapperHive : MyWindow.ValueMapper<double>
	{
		public override int Min => 1;

		public override int Max => 50;

		public override double IndexToValue(int index)
		{
			return (double)index * 0.1;
		}

		public override int ValueToIndex(double value)
		{
			return Mathf.RoundToInt((float)(value * 10.0));
		}
	}

	private class DistanceMapperCarrier : MyWindow.ValueMapper<double>
	{
		public override int Min => 100;

		public override int Max => 3000;

		public override double IndexToValue(int index)
		{
			return index;
		}

		public override int ValueToIndex(double value)
		{
			return Mathf.RoundToInt((float)value);
		}
	}

	private class EnergyMapper : MyWindow.ValueMapper<double>
	{
		public override int Min => 50;

		public override int Max => 1000;

		public override double IndexToValue(int index)
		{
			return index;
		}

		public override int ValueToIndex(double value)
		{
			return Mathf.RoundToInt((float)value);
		}
	}

	private class UpsMapper : MyWindow.ValueMapper<double>
	{
		public override int Min => 1;

		public override int Max => 100;

		public override double IndexToValue(int index)
		{
			return (double)index * 0.1;
		}

		public override int ValueToIndex(double value)
		{
			return Mathf.RoundToInt((float)(value * 10.0));
		}
	}

	private class AutoConfigDispenserChargePowerMapper : MyWindow.RangeValueMapper<int>
	{
		public AutoConfigDispenserChargePowerMapper()
			: base(3, 30)
		{
		}

		public override string FormatValue(string format, int value)
		{
			StringBuilder stringBuilder = new StringBuilder("         ");
			StringBuilderUtility.WriteKMG(stringBuilder, 8, (long)value * 300000L);
			stringBuilder.Append('W');
			return stringBuilder.ToString().Trim();
		}
	}

	private class AutoConfigBattleBaseChargePowerMapper : MyWindow.RangeValueMapper<int>
	{
		public AutoConfigBattleBaseChargePowerMapper()
			: base(4, 40)
		{
		}

		public override string FormatValue(string format, int value)
		{
			StringBuilder stringBuilder = new StringBuilder("         ");
			StringBuilderUtility.WriteKMG(stringBuilder, 8, (long)value * 300000L);
			stringBuilder.Append('W');
			return stringBuilder.ToString().Trim();
		}
	}

	private class AutoConfigPLSChargePowerMapper : MyWindow.RangeValueMapper<int>
	{
		public AutoConfigPLSChargePowerMapper()
			: base(2, 20)
		{
		}

		public override string FormatValue(string format, int value)
		{
			StringBuilder stringBuilder = new StringBuilder("         ");
			StringBuilderUtility.WriteKMG(stringBuilder, 8, (long)value * 3000000L);
			stringBuilder.Append('W');
			return stringBuilder.ToString().Trim();
		}
	}

	private class AutoConfigCarrierMinDeliverMapper : MyWindow.RangeValueMapper<int>
	{
		public AutoConfigCarrierMinDeliverMapper()
			: base(0, 10)
		{
		}

		public override string FormatValue(string format, int value)
		{
			return ((value == 0) ? 1 : (value * 10)).ToString("0\\%");
		}
	}

	private class AutoConfigMinPilerValueMapper : MyWindow.RangeValueMapper<int>
	{
		public AutoConfigMinPilerValueMapper()
			: base(0, 4)
		{
		}

		public override string FormatValue(string format, int value)
		{
			if (value != 0)
			{
				return value.ToString();
			}
			return "Use tech max for piler".Translate().Trim();
		}
	}

	private class AutoConfigILSChargePowerMapper : MyWindow.RangeValueMapper<int>
	{
		public AutoConfigILSChargePowerMapper()
			: base(2, 20)
		{
		}

		public override string FormatValue(string format, int value)
		{
			StringBuilder stringBuilder = new StringBuilder("         ");
			StringBuilderUtility.WriteKMG(stringBuilder, 8, (long)value * 15000000L);
			stringBuilder.Append('W');
			return stringBuilder.ToString().Trim();
		}
	}

	private class AutoConfigILSMaxTripShipMapper : MyWindow.RangeValueMapper<int>
	{
		public AutoConfigILSMaxTripShipMapper()
			: base(1, 41)
		{
		}

		public override string FormatValue(string format, int value)
		{
			if (value > 20)
			{
				if (value <= 40)
				{
					return (value * 2 - 20).ToString("0LY");
				}
				return "∞";
			}
			return value.ToString("0LY");
		}
	}

	private class AutoConfigILSWarperDistanceMapper : MyWindow.RangeValueMapper<int>
	{
		public AutoConfigILSWarperDistanceMapper()
			: base(2, 21)
		{
		}

		public override string FormatValue(string format, int value)
		{
			if (value <= 16)
			{
				if (value > 7)
				{
					if (value <= 13)
					{
						return ((double)value - 4.0).ToString("0.0AU");
					}
					return (value - 4).ToString("0AU");
				}
				return ((double)value * 0.5 - 0.5).ToString("0.0AU");
			}
			if (value <= 20)
			{
				return (value * 2 - 20).ToString("0AU");
			}
			return "60AU";
		}
	}

	private class AutoConfigVeinCollectorHarvestSpeedMapper : MyWindow.RangeValueMapper<int>
	{
		public AutoConfigVeinCollectorHarvestSpeedMapper()
			: base(0, 20)
		{
		}

		public override string FormatValue(string format, int value)
		{
			return (100 + value * 10).ToString("0\\%");
		}
	}

	private static RectTransform _windowTrans;

	private static RectTransform _dysonTab;

	private static UIButton _dysonInitBtn;

	private static readonly UIButton[] DysonLayerBtn = new UIButton[10];

	public static void Init()
	{
		MyConfigWindow.OnUICreated = (Action<MyConfigWindow, RectTransform>)Delegate.Combine(MyConfigWindow.OnUICreated, new Action<MyConfigWindow, RectTransform>(CreateUI));
		MyConfigWindow.OnUpdateUI = (Action)Delegate.Combine(MyConfigWindow.OnUpdateUI, new Action(UpdateUI));
	}

	private static void CreateUI(MyConfigWindow wnd, RectTransform trans)
	{
		_windowTrans = trans;
		wnd.AddTabGroup(trans, "UXAssist", "tab-group-uxassist");
		RectTransform parent = wnd.AddTab(trans, "General");
		float num = 0f;
		float num2 = 10f;
		wnd.AddCheckBox(num, num2, parent, GamePatch.EnableWindowResizeEnabled, "Enable game window resize");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent, GamePatch.LoadLastWindowRectEnabled, "Remeber window position and size on last exit");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent, GamePatch.ConvertSavesFromPeaceEnabled, "Convert old saves to Combat Mode on loading");
		MyCheckBox myCheckBox;
		if (WindowFunctions.ProfileName != null)
		{
			num2 += 36f;
			myCheckBox = wnd.AddCheckBox(num, num2, parent, GamePatch.ProfileBasedSaveFolderEnabled, "Profile-based save folder");
			wnd.AddTipsButton2(myCheckBox.Width + 5f, num2 + 6f, parent, "Profile-based save folder", "Profile-based save folder tips", "btn-profile-based-save-folder-tips");
			num2 += 36f;
			myCheckBox = wnd.AddCheckBox(num, num2, parent, GamePatch.ProfileBasedOptionEnabled, "Profile-based option");
			wnd.AddTipsButton2(myCheckBox.Width + 5f, num2 + 6f, parent, "Profile-based option", "Profile-based option tips", "btn-profile-based-option-tips");
			num2 += 36f;
			wnd.AddText2(num + 2f, num2, parent, "Default profile name", 15, "text-default-profile-name");
			num2 += 24f;
			wnd.AddInputField(num + 2f, num2, 200f, parent, GamePatch.DefaultProfileName, 15, "input-profile-save-folder");
			num2 += 18f;
		}
		num2 += 36f;
		wnd.AddButton(num, num2, 200f, parent, "Show recent milkyway upload results", 16, "button-show-recent-milkyway-upload-results", delegate
		{
			UIFunctions.ShowRecentMilkywayUploadResults();
		});
		Text text;
		if (!BulletTimeWrapper.HasBulletTime)
		{
			num2 += 36f;
			text = wnd.AddText2(num + 2f, num2, parent, "Logical Frame Rate", 15, "game-frame-rate");
			num += Util.GetPreferredWidth(text) + 7f;
			wnd.AddSlider(num, num2 + 6f, parent, GamePatch.GameUpsFactor, new UpsMapper(), "0.0x", 100f).WithSmallerHandle();
			((RectTransform)wnd.AddFlatButton(num + 104f, num2 + 6f, parent, "Reset", 13, "reset-game-frame-rate", delegate
			{
				GamePatch.GameUpsFactor.Value = 1.0;
			}).transform).sizeDelta = new Vector2(40f, 20f);
			num = 0f;
		}
		num2 += 36f;
		text = wnd.AddText2(num + 2f, num2, parent, "Process priority", 15, "process-priority");
		wnd.AddComboBox(num + 7f + Util.GetPreferredWidth(text), num2, parent).WithItems("High", "Above Normal", "Normal", "Below Normal", "Idle").WithSize(100f, 0f)
			.WithConfigEntry(WindowFunctions.ProcessPriority);
		RectTransform parent2 = wnd.AddTab(trans, "Factory");
		num = 0f;
		num2 = 10f;
		wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.RemoveSomeConditionEnabled, "Remove some build conditions");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.RemoveBuildRangeLimitEnabled, "Remove build range limit");
		num2 += 36f;
		myCheckBox = wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.NightLightEnabled, "Night Light");
		num += myCheckBox.Width + 5f + 10f;
		text = wnd.AddText2(num, num2 + 2f, parent2, "Angle X:", 13, "text-nightlight-angle-x");
		num += Util.GetPreferredWidth(text) + 5f;
		wnd.AddSlider(num, num2 + 7f, parent2, FactoryConfigProvider.NightLightAngleX, new AngleMapper(), "0", 60f).WithSmallerHandle();
		num += 70f;
		text = wnd.AddText2(num, num2 + 2f, parent2, "Y:", 13, "text-nightlight-angle-y");
		wnd.AddSlider(num + Util.GetPreferredWidth(text) + 5f, num2 + 7f, parent2, FactoryConfigProvider.NightLightAngleY, new AngleMapper(), "0", 60f).WithSmallerHandle();
		num = 0f;
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.LargerAreaForUpgradeAndDismantleEnabled, "Larger area for upgrade and dismantle");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.LargerAreaForTerraformEnabled, "Larger area for terraform");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.OffGridBuildingEnabled, "Off-grid building and stepped rotation");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.CutConveyorBeltEnabled, "Cut conveyor belt (with shortcut key)");
		num2 += 36f;
		myCheckBox = wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.TreatStackingAsSingleEnabled, "Treat stack items as single in monitor components");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.QuickBuildAndDismantleLabsEnabled, "Quick build and dismantle stacking labs");
		num2 += 36f;
		MyCheckBox myCheckBox2 = wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.TankFastFillInAndTakeOutEnabled, "Fast fill in to and take out from tanks");
		num += myCheckBox2.Width + 5f;
		text = wnd.AddText2(num, num2 + 2f, parent2, "Speed Ratio", 13, "text-tank-fast-fill-speed-ratio");
		MySlider tankSlider = wnd.AddSlider(num + Util.GetPreferredWidth(text) + 5f, num2 + 7f, parent2, FactoryConfigProvider.TankFastFillInAndTakeOutMultiplier, new int[8] { 2, 5, 10, 20, 50, 100, 500, 1000 }, "G", 100f).WithSmallerHandle();
		FactoryConfigProvider.TankFastFillInAndTakeOutEnabled.SettingChanged += TankSettingChanged;
		wnd.OnFree += delegate
		{
			FactoryConfigProvider.TankFastFillInAndTakeOutEnabled.SettingChanged -= TankSettingChanged;
		};
		TankSettingChanged(null, null);
		num = 0f;
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.DoNotRenderEntitiesEnabled, "Do not render factory entities");
		num2 += 27f;
		MyCheckBox hideSortersCheckBox = wnd.AddCheckBox(num + 20f, num2, parent2, FactoryConfigProvider.DoNotRenderEntitiesHideSortersEnabled, "Hide sorters too", 13);
		FactoryConfigProvider.DoNotRenderEntitiesEnabled.SettingChanged += DoNotRenderEntitiesEnabledChanged;
		wnd.OnFree += delegate
		{
			FactoryConfigProvider.DoNotRenderEntitiesEnabled.SettingChanged -= DoNotRenderEntitiesEnabledChanged;
		};
		DoNotRenderEntitiesEnabledChanged(null, null);
		num2 += 36f;
		myCheckBox = wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.ShortcutKeysForBlueprintCopyEnabled, "Shortcut keys for Blueprint Copy mode");
		wnd.AddTipsButton2(num + myCheckBox.Width + 5f, num2 + 6f, parent2, "Shortcut keys for Blueprint Copy mode", "Shortcut keys for Blueprint Copy mode tips", "shortcut-keys-for-blueprint-copy-mode-tips");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.BeltSignalsForBuyOutEnabled, "Belt signals for buy out dark fog items automatically");
		num2 += 36f;
		myCheckBox = wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.ProtectVeinsFromExhaustionEnabled, "Protect veins from exhaustion");
		wnd.AddTipsButton2(num + myCheckBox.Width + 5f, num2 + 6f, parent2, "Protect veins from exhaustion", "Protect veins from exhaustion tips", "protect-veins-tips");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.DragBuildPowerPolesEnabled, "Drag building power poles in maximum connection range");
		num2 += 27f;
		MyCheckBox alternatelyCheckBox = wnd.AddCheckBox(num + 20f, num2, parent2, FactoryConfigProvider.DragBuildPowerPolesAlternatelyEnabled, "Build Tesla Tower and Wireless Power Tower alternately", 13);
		FactoryConfigProvider.DragBuildPowerPolesEnabled.SettingChanged += AlternatelyCheckBoxChanged;
		wnd.OnFree += delegate
		{
			FactoryConfigProvider.DragBuildPowerPolesEnabled.SettingChanged -= AlternatelyCheckBoxChanged;
		};
		AlternatelyCheckBoxChanged(null, null);
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.AutoConstructButtonEnabled, "Auto-construct button");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.PressShiftToTakeWholeBeltItemsEnabled, "Ctrl+Shift+Click to pick items from whole belts");
		num2 += 27f;
		MyCheckBox includeBranches = wnd.AddCheckBox(num + 10f, num2, parent2, FactoryConfigProvider.PressShiftToTakeWholeBeltItemsIncludeBranches, "Include branches of belts", 13);
		num2 += 27f;
		MyCheckBox includeInserters = wnd.AddCheckBox(num + 10f, num2, parent2, FactoryConfigProvider.PressShiftToTakeWholeBeltItemsIncludeInserters, "Include connected inserters", 13);
		FactoryConfigProvider.PressShiftToTakeWholeBeltItemsEnabled.SettingChanged += PressShiftToTakeWholeBeltItemsEnabledChanged;
		wnd.OnFree += delegate
		{
			FactoryConfigProvider.PressShiftToTakeWholeBeltItemsEnabled.SettingChanged -= PressShiftToTakeWholeBeltItemsEnabledChanged;
		};
		PressShiftToTakeWholeBeltItemsEnabledChanged(null, null);
		num = 400f;
		num2 = 10f;
		wnd.AddButton(num, num2, parent2, "Initialize This Planet", 16, "button-init-planet", delegate
		{
			UIMessageBox.Show("Initialize This Planet".Translate(), "Initialize This Planet Confirm".Translate(), "Cancel".Translate(), "OK".Translate(), 2, null, delegate
			{
				PlanetFunctions.RecreatePlanet(revertReform: true);
			});
		});
		num2 += 24f;
		wnd.AddCheckBox(num + 10f, num2, parent2, PlanetFunctions.ReturnBuildingsOnInitializeEnabled, "Return buildings to player when initializing planet", 13);
		num2 += 24f;
		wnd.AddCheckBox(num + 10f, num2, parent2, PlanetFunctions.ReturnLogisticStorageItemsOnInitializeEnabled, "Return logistic storage items to player when initializing planet", 13);
		num2 += 24f;
		wnd.AddCheckBox(num + 10f, num2, parent2, PlanetFunctions.ReturnBeltAFactoryItemsOnInitializeEnabled, "Return belt and factory items to player when initializing planet", 13);
		num2 += 36f;
		wnd.AddButton(num, num2, parent2, "Dismantle All Buildings", 16, "button-dismantle-all", delegate
		{
			UIMessageBox.Show("Dismantle All Buildings".Translate(), "Dismantle All Buildings Confirm".Translate(), "Cancel".Translate(), "OK".Translate(), 2, null, delegate
			{
				PlanetFunctions.DismantleAll(toBag: false);
			});
		});
		num2 += 72f;
		wnd.AddButton(num, num2, 200f, parent2, "Quick build Orbital Collectors", 16, "button-init-planet", PlanetFunctions.BuildOrbitalCollectors);
		num2 += 30f;
		text = wnd.AddText2(num + 10f, num2, parent2, "Maximum count to build", 15, "text-oc-build-count");
		wnd.AddSlider(num + 10f + Util.GetPreferredWidth(text) + 5f, num2 + 6f, parent2, PlanetFunctions.OrbitalCollectorMaxBuildCount, new OcMapper(), "G", 160f);
		num2 += 18f;
		num2 += 36f;
		myCheckBox = wnd.AddCheckBox(num, num2, parent2, FactoryConfigProvider.TweakBuildingBufferEnabled, "Tweak building buffers");
		wnd.AddTipsButton2(num + myCheckBox.Width + 5f, num2 + 6f, parent2, "Tweak building buffers", "Tweak building buffers tips", "tweak-building-buffers-tips");
		num2 += 27f;
		text = wnd.AddText2(num + 20f, num2, parent2, "Assembler buffer time multiplier(in seconds)", 13);
		float num3 = Util.GetPreferredWidth(text) + 5f;
		num2 += 27f;
		text = wnd.AddText2(num + 20f, num2, parent2, "Assembler buffer minimum multiplier", 13);
		float num4 = Util.GetPreferredWidth(text) + 5f;
		num2 += 27f;
		text = wnd.AddText2(num + 20f, num2, parent2, "Buffer count for assembling in labs", 13);
		float num5 = Util.GetPreferredWidth(text) + 5f;
		num2 += 27f;
		text = wnd.AddText2(num + 20f, num2, parent2, "Extra buffer count for Self-evolution Labs", 13);
		float num6 = Util.GetPreferredWidth(text) + 5f;
		num2 += 27f;
		text = wnd.AddText2(num + 20f, num2, parent2, "Buffer count for researching in labs", 13);
		float num7 = Util.GetPreferredWidth(text) + 5f;
		num2 += 27f;
		text = wnd.AddText2(num + 20f, num2, parent2, "Ray Receiver Graviton Lens buffer count", 13);
		float num8 = Util.GetPreferredWidth(text) + 5f;
		num2 += 27f;
		text = wnd.AddText2(num + 20f, num2, parent2, "Ejector Solar Sails buffer count", 13);
		float num9 = Util.GetPreferredWidth(text) + 5f;
		num2 += 27f;
		text = wnd.AddText2(num + 20f, num2, parent2, "Silo Rockets buffer count", 13);
		float num10 = Util.GetPreferredWidth(text) + 5f;
		num2 -= 189f;
		float num11 = Mathf.Max(num3, num4, num5, num6, num7, num8, num9, num10) + 20f;
		MySlider assemblerBufferTimeMultiplierSlider = wnd.AddSlider(num + num11, num2 + 5f, parent2, FactoryConfigProvider.AssemblerBufferTimeMultiplier, new MyWindow.RangeValueMapper<int>(2, 10), "0", 120f).WithSmallerHandle();
		num2 += 27f;
		MySlider assemblerBufferMininumMultiplierSlider = wnd.AddSlider(num + num11, num2 + 5f, parent2, FactoryConfigProvider.AssemblerBufferMininumMultiplier, new MyWindow.RangeValueMapper<int>(2, 10), "0", 120f).WithSmallerHandle();
		num2 += 27f;
		MySlider labBufferMaxCountForAssembleSlider = wnd.AddSlider(num + num11, num2 + 5f, parent2, FactoryConfigProvider.LabBufferMaxCountForAssemble, new MyWindow.RangeValueMapper<int>(2, 20), "0", 120f).WithSmallerHandle();
		num2 += 27f;
		MySlider labBufferExtraCountForAdvancedAssembleSlider = wnd.AddSlider(num + num11, num2 + 5f, parent2, FactoryConfigProvider.LabBufferExtraCountForAdvancedAssemble, new MyWindow.RangeValueMapper<int>(1, 10), "0", 120f).WithSmallerHandle();
		num2 += 27f;
		MySlider labBufferMaxCountForResearchSlider = wnd.AddSlider(num + num11, num2 + 5f, parent2, FactoryConfigProvider.LabBufferMaxCountForResearch, new MyWindow.RangeValueMapper<int>(2, 20), "0", 120f).WithSmallerHandle();
		num2 += 27f;
		MySlider receiverBufferCountSlider = wnd.AddSlider(num + num11, num2 + 5f, parent2, FactoryConfigProvider.ReceiverBufferCount, new MyWindow.RangeValueMapper<int>(1, 20), "0", 120f).WithSmallerHandle();
		num2 += 27f;
		MySlider ejectorBufferCountSlider = wnd.AddSlider(num + num11, num2 + 5f, parent2, FactoryConfigProvider.EjectorBufferCount, new MyWindow.RangeValueWithMultiplierMapper<int>(1, 80, 5), "0", 120f).WithSmallerHandle();
		num2 += 27f;
		MySlider siloBufferCountSlider = wnd.AddSlider(num + num11, num2 + 5f, parent2, FactoryConfigProvider.SiloBufferCount, new MyWindow.RangeValueMapper<int>(1, 40), "0", 120f).WithSmallerHandle();
		FactoryConfigProvider.TweakBuildingBufferEnabled.SettingChanged += TweakBuildingBufferChanged;
		wnd.OnFree += delegate
		{
			FactoryConfigProvider.TweakBuildingBufferEnabled.SettingChanged -= TweakBuildingBufferChanged;
		};
		TweakBuildingBufferChanged(null, null);
		RectTransform tab3 = wnd.AddTab(trans, "Logistics");
		num = 0f;
		num2 = 10f;
		myCheckBox = wnd.AddCheckBox(num, num2, tab3, LogisticsConfigProvider.LogisticsCapacityTweaksEnabled, "Enhance control for logistic storage capacities");
		wnd.AddTipsButton2(num + myCheckBox.Width + 5f, num2 + 6f, tab3, "Enhance control for logistic storage capacities", "Enhance control for logistic storage capacities tips", "enhanced-logistic-capacities-tips");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, tab3, LogisticsConfigProvider.AllowOverflowInLogisticsEnabled, "Allow overflow for Logistic Stations and Advanced Mining Machines");
		num2 += 30f;
		wnd.AddCheckBox(num, num2, tab3, LogisticsConfigProvider.GreaterPowerUsageInLogisticsEnabled, "Increase maximum power usage in Logistic Stations and Advanced Mining Machines");
		num2 += 36f;
		myCheckBox = wnd.AddCheckBox(num, num2, tab3, LogisticsConfigProvider.LogisticsConstrolPanelImprovementEnabled, "Logistics Control Panel Improvement");
		wnd.AddTipsButton2(num + myCheckBox.Width + 5f, num2 + 6f, tab3, "Logistics Control Panel Improvement", "Logistics Control Panel Improvement tips", "lcp-improvement-tips");
		num2 += 36f;
		MyCheckBox realtimeLogisticsInfoPanelCheckBox = wnd.AddCheckBox(num, num2, tab3, LogisticsConfigProvider.RealtimeLogisticsInfoPanelEnabled, "Real-time logistic stations info panel");
		num2 += 27f;
		MyCheckBox realtimeLogisticsInfoPanelBarsCheckBox = wnd.AddCheckBox(num + 20f, num2, tab3, LogisticsConfigProvider.RealtimeLogisticsInfoPanelBarsEnabled, "Show status bars for storage items", 13);
		if (AuxilaryfunctionWrapper.ShowStationInfo != null)
		{
			AuxilaryfunctionWrapper.ShowStationInfo.SettingChanged += RealtimeLogisticsInfoPanelChanged;
			wnd.OnFree += delegate
			{
				AuxilaryfunctionWrapper.ShowStationInfo.SettingChanged -= RealtimeLogisticsInfoPanelChanged;
			};
		}
		LogisticsConfigProvider.RealtimeLogisticsInfoPanelEnabled.SettingChanged += RealtimeLogisticsInfoPanelChanged;
		wnd.OnFree += delegate
		{
			LogisticsConfigProvider.RealtimeLogisticsInfoPanelEnabled.SettingChanged -= RealtimeLogisticsInfoPanelChanged;
		};
		RealtimeLogisticsInfoPanelChanged(null, null);
		num2 += 36f;
		text = wnd.AddText2(num, num2 + 4f, tab3, "Orbital Collector product limit", 15, "text-orbital-collector-product-limit");
		ConfigEntry<int> productLimitConfig = LogisticsConfigProvider.OrbitalCollectorProductLimit;
		float preferredWidth = Util.GetPreferredWidth(text);
		InputField productLimitInput = wnd.AddInputField(num + preferredWidth + 10f, num2, tab3, productLimitConfig.Value.ToString(), 15, "input-orbital-collector-product-limit");
		productLimitInput.onEndEdit.AddListener(SetProductLimit);
		productLimitInput.contentType = InputField.ContentType.IntegerNumber;
		productLimitInput.characterValidation = InputField.CharacterValidation.Integer;
		(productLimitInput.transform as RectTransform).sizeDelta = new Vector2(100f, (productLimitInput.transform as RectTransform).sizeDelta.y);
		wnd.AddButton(num + preferredWidth + 120f, num2, 130f, tab3, "Apply to universe", 14, "button-apply-orbital-collector-product-limit", delegate
		{
			SetProductLimit(productLimitInput.text);
			LogisticsPatch.ApplyOrbitalCollectorProductLimitToUniverse();
		});
		productLimitConfig.SettingChanged += ProductLimitChanged;
		wnd.OnFree += delegate
		{
			productLimitConfig.SettingChanged -= ProductLimitChanged;
		};
		num2 += 36f;
		wnd.AddCheckBox(num, num2, tab3, LogisticsConfigProvider.AutoConfigLogisticsEnabled, "Auto-config logistic stations");
		num2 += 26f;
		wnd.AddCheckBox(num + 10f, num2, tab3, LogisticsConfigProvider.AutoConfigLimitAutoReplenishCount, "Limit auto-replenish count to values below", 13).WithSmallerBox();
		num2 += 18f;
		wnd.AddCheckBox(num + 10f, num2, tab3, LogisticsConfigProvider.SetDefaultRemoteLogicToStorage, "Set default remote logic to storage", 13).WithSmallerBox();
		num2 += 16f;
		float a = 0f;
		wnd.AddText2(10f, num2, tab3, "Dispenser", 14, "text-dispenser");
		float catY = num2;
		num2 += 18f;
		float num12 = num2;
		num = 20f;
		Text text2 = wnd.AddText2(num, num2, tab3, "Max. Charging Power", 13, "text-dispenser-max-charging-power");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Count of Bots filled", 13, "text-dispenser-count-of-bots-filled");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		wnd.AddText2(10f, num2, tab3, "Battlefield Analysis Base", 14, "text-battlefield-analysis-base");
		float catY2 = num2;
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Max. Charging Power", 13, "text-battlefield-analysis-base-max-charging-power");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		wnd.AddText2(10f, num2, tab3, "PLS", 14, "text-pls");
		float catY3 = num2;
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Max. Charging Power", 13, "text-pls-max-charging-power");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Drone transport range", 13, "text-pls-drone-transport-range");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Min. Load of Drones", 13, "text-pls-min-load-of-drones");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Outgoing integration count", 13, "text-pls-outgoing-integration-count");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Count of Drones filled", 13, "text-pls-count-of-drones-filled");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		wnd.AddText2(10f, num2, tab3, "ILS", 14, "text-ils");
		float catY4 = num2;
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Max. Charging Power", 13, "text-ils-max-charging-power");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Drone transport range", 13, "text-ils-drone-transport-range");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Vessel transport range", 13, "text-ils-vessel-transport-range");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Warp distance", 13, "text-ils-warp-distance");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Min. Load of Drones", 13, "text-ils-min-load-of-drones");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Min. Load of Vessels", 13, "text-ils-min-load-of-vessels");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Outgoing integration count", 13, "text-ils-outgoing-integration-count");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Count of Drones filled", 13, "text-ils-count-of-drones-filled");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Count of Vessels filled", 13, "text-ils-count-of-vessels-filled");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		wnd.AddText2(10f, num2, tab3, "Advanced Mining Machine", 14, "text-amm");
		float catY5 = num2;
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Collecting Speed", 13, "text-amm-collecting-speed");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 += 18f;
		text2 = wnd.AddText2(num, num2, tab3, "Min. Piler Value", 13, "text-amm-min-piler-value");
		a = Mathf.Max(a, Util.GetPreferredWidth(text2));
		num2 = num12 + 1f;
		float num13 = num + a + 5f + 10f;
		float applyBtnX = num13 + 265f;
		float applyAllBtnX = applyBtnX + 44f - 58f;
		float num14 = applyBtnX + 44f + 12f;
		AddCategoryApplyButton(catY, "btn-apply-all-dispenser", LogisticsPatch.ApplyAllDispenser);
		AddCategoryApplyButton(catY2, "btn-apply-all-battle-base", LogisticsPatch.ApplyAllBattleBase);
		AddCategoryApplyButton(catY3, "btn-apply-all-pls", LogisticsPatch.ApplyAllPLS);
		AddCategoryApplyButton(catY4, "btn-apply-all-ils", LogisticsPatch.ApplyAllILS);
		AddCategoryApplyButton(catY5, "btn-apply-all-amm", LogisticsPatch.ApplyAllVeinCollector);
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigDispenserChargePower, new AutoConfigDispenserChargePowerMapper(), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-dispenser-charge-power", LogisticsPatch.ApplyDispenserChargePower);
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigDispenserCourierCount, new MyWindow.RangeValueMapper<int>(0, 10), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-dispenser-courier-count", LogisticsPatch.ApplyDispenserCourierCount);
		num2 += 36f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigBattleBaseChargePower, new AutoConfigBattleBaseChargePowerMapper(), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-battle-base-charge-power", LogisticsPatch.ApplyBattleBaseChargePower);
		num2 += 36f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigPLSChargePower, new AutoConfigPLSChargePowerMapper(), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-pls-charge-power", LogisticsPatch.ApplyPLSChargePower);
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigPLSMaxTripDrone, new MyWindow.RangeValueMapper<int>(1, 180), "0°", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-pls-trip-range-drones", LogisticsPatch.ApplyPLSTripRangeDrones);
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigPLSDroneMinDeliver, new AutoConfigCarrierMinDeliverMapper(), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-pls-drone-min-deliver", LogisticsPatch.ApplyPLSDroneMinDeliver);
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigPLSMinPilerValue, new AutoConfigMinPilerValueMapper(), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-pls-min-piler-value", LogisticsPatch.ApplyPLSMinPilerValue);
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigPLSDroneCount, new MyWindow.RangeValueMapper<int>(0, 50), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-pls-drone-count", LogisticsPatch.ApplyPLSDroneCount);
		num2 += 36f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigILSChargePower, new AutoConfigILSChargePowerMapper(), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-ils-charge-power", LogisticsPatch.ApplyILSChargePower);
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigILSMaxTripDrone, new MyWindow.RangeValueMapper<int>(1, 180), "0°", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-ils-trip-range-drones", LogisticsPatch.ApplyILSTripRangeDrones);
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigILSMaxTripShip, new AutoConfigILSMaxTripShipMapper(), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-ils-trip-range-ships", LogisticsPatch.ApplyILSTripRangeShips);
		MyCheckBox myCheckBox3 = wnd.AddCheckBox(num14, num2 + 4f, tab3, LogisticsConfigProvider.AutoConfigILSIncludeOrbitCollector, "Include Orbital Collector", 13).WithSmallerBox();
		float rowY = num2;
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigILSWarperDistance, new AutoConfigILSWarperDistanceMapper(), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-ils-warp-distance", LogisticsPatch.ApplyILSWarpDistance);
		MyCheckBox myCheckBox4 = wnd.AddCheckBox(num14, num2 + 4f, tab3, LogisticsConfigProvider.AutoConfigILSWarperNecessary, "Warpers required", 13).WithSmallerBox();
		float bx = num14 + Mathf.Max(myCheckBox3.Width, myCheckBox4.Width) + 10f;
		AddApplyButtonAt(bx, rowY, "btn-apply-ils-include-orbit-collector", LogisticsPatch.ApplyILSIncludeOrbitCollector);
		AddApplyButtonAt(bx, num2, "btn-apply-ils-warper-necessary", LogisticsPatch.ApplyILSWarperNecessary);
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigILSDroneMinDeliver, new AutoConfigCarrierMinDeliverMapper(), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-ils-drone-min-deliver", LogisticsPatch.ApplyILSDroneMinDeliver);
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigILSShipMinDeliver, new AutoConfigCarrierMinDeliverMapper(), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-ils-ship-min-deliver", LogisticsPatch.ApplyILSShipMinDeliver);
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigILSMinPilerValue, new AutoConfigMinPilerValueMapper(), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-ils-min-piler-value", LogisticsPatch.ApplyILSMinPilerValue);
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigILSDroneCount, new MyWindow.RangeValueMapper<int>(0, 100), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-ils-drone-count", LogisticsPatch.ApplyILSDroneCount);
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigILSShipCount, new MyWindow.RangeValueMapper<int>(0, 10), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-ils-ship-count", LogisticsPatch.ApplyILSShipCount);
		num2 += 36f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigVeinCollectorHarvestSpeed, new AutoConfigVeinCollectorHarvestSpeedMapper(), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-amm-harvest-speed", LogisticsPatch.ApplyVeinCollectorHarvestSpeed);
		num2 += 18f;
		wnd.AddSideSlider(num13, num2, tab3, LogisticsConfigProvider.AutoConfigVeinCollectorMinPilerValue, new AutoConfigMinPilerValueMapper(), "G", 150f, -100f).WithFontSize(13);
		AddApplyButton(num2, "btn-apply-amm-min-piler-value", LogisticsPatch.ApplyVeinCollectorMinPilerValue);
		num = 0f;
		RectTransform parent3 = wnd.AddTab(trans, "Player/Mecha");
		num = 0f;
		num2 = 10f;
		wnd.AddCheckBox(num, num2, parent3, FactoryConfigProvider.UnlimitInteractiveEnabled, "Unlimited interactive range");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent3, PlanetPatch.PlayerActionsInGlobeViewEnabled, "Enable player actions in globe view");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent3, PlayerPatch.HideTipsForSandsChangesEnabled, "Hide tips for soil piles changes");
		num2 += 36f;
		myCheckBox = wnd.AddCheckBox(num, num2, parent3, PlayerPatch.EnhancedMechaForgeCountControlEnabled, "Enhanced count control for hand-make");
		wnd.AddTipsButton2(num + myCheckBox.Width + 5f, num2 + 6f, parent3, "Enhanced count control for hand-make", "Enhanced count control for hand-make tips", "enhanced-count-control-tips");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent3, PlayerPatch.ShortcutKeysForStarsNameEnabled, "Shortcut keys for showing stars' name");
		num2 += 36f;
		MyCheckBox autoCruiseCheckBox = wnd.AddCheckBox(num, num2, parent3, PlayerPatch.AutoCruiseEnabled, "Enable auto-cruise");
		num2 += 27f;
		MyCheckBox autoStopCheckBox = wnd.AddCheckBox(num + 20f, num2, parent3, PlayerPatch.StopOnArrivalAndInput, "Stop auto-cruise on manual input", 13);
		num2 += 27f;
		MyCheckBox useWarpCheckBox = wnd.AddCheckBox(num + 20f, num2, parent3, PlayerPatch.UseWarper, "Use warp", 13);
		float a2 = 0f;
		num2 += 27f;
		float y = num2;
		text = wnd.AddText2(num + 20f, num2, parent3, "Use warp minimal energy", 13, "use-warp-minimal-energy");
		a2 = Mathf.Max(a2, Util.GetPreferredWidth(text));
		num2 += 27f;
		float y2 = num2;
		text = wnd.AddText2(num + 20f, num2, parent3, "Distance to use warp", 13, "text-new-navigation-distance-to-warp");
		a2 = Mathf.Max(a2, Util.GetPreferredWidth(text));
		num2 += 27f;
		MyCheckBox speedUpCheckBox = wnd.AddCheckBox(num + 20f, num2, parent3, PlayerPatch.UseSpeedUp, "Auto boost", 13);
		num2 += 27f;
		float y3 = num2;
		text = wnd.AddText2(num + 20f, num2, parent3, "Auto boost minimal energy", 13, "auto-boost-minimal-energy");
		a2 = Mathf.Max(a2, Util.GetPreferredWidth(text));
		num2 += 27f;
		float y4 = num2;
		text = wnd.AddText2(num + 20f, num2, parent3, "Dark Fog Hive follow distance", 13, "dark-fog-hive-follow-distance");
		a2 = Mathf.Max(a2, Util.GetPreferredWidth(text));
		num2 += 27f;
		float y5 = num2;
		text = wnd.AddText2(num + 20f, num2, parent3, "Dark Fog Carrier follow distance", 13, "dark-fog-carrier-follow-distance");
		a2 = Mathf.Max(a2, Util.GetPreferredWidth(text));
		float x = num + 20f + a2 + 5f;
		MySideSlider warpEnergySlider = wnd.AddSideSlider(x, y, parent3, PlayerPatch.UseWarperMinimalEnergy, new EnergyMapper(), "0", 160f, -100f).WithFontSize(13);
		MySideSlider newNavDistanceSlider = wnd.AddSideSlider(x, y2, parent3, PlayerPatch.UseWarperDistance, new DistanceMapper(), "0.0", 160f, -100f).WithFontSize(13);
		MySideSlider speedUpEnergySlider = wnd.AddSideSlider(x, y3, parent3, PlayerPatch.UseSpeedUpMinimalEnergy, new EnergyMapper(), "0", 160f, -100f).WithFontSize(13);
		MySideSlider dfHiveSlider = wnd.AddSideSlider(x, y4, parent3, PlayerPatch.DFHiveFollowDistance, new DistanceMapperHive(), "0.0", 160f, -100f).WithFontSize(13);
		MySideSlider dfCarrierSlider = wnd.AddSideSlider(x, y5, parent3, PlayerPatch.DFCarrierFollowDistance, new DistanceMapperCarrier(), "0.0", 160f, -100f).WithFontSize(13);
		PlayerPatch.AutoCruiseEnabled.SettingChanged += NavSettingChanged;
		PlayerPatch.UseWarper.SettingChanged += NavSettingChanged;
		PlayerPatch.UseSpeedUp.SettingChanged += NavSettingChanged;
		wnd.OnFree += delegate
		{
			PlayerPatch.AutoCruiseEnabled.SettingChanged -= NavSettingChanged;
		};
		wnd.OnFree += delegate
		{
			PlayerPatch.UseWarper.SettingChanged -= NavSettingChanged;
		};
		wnd.OnFree += delegate
		{
			PlayerPatch.UseSpeedUp.SettingChanged -= NavSettingChanged;
		};
		NavSettingChanged(null, null);
		RectTransform rectTransform = wnd.AddTab(trans, "Dyson Sphere");
		num = 0f;
		num2 = 10f;
		wnd.AddCheckBox(num, num2, rectTransform, DysonSpherePatch.StopEjectOnNodeCompleteEnabled, "Stop ejectors when available nodes are all filled up");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, rectTransform, DysonSpherePatch.OnlyConstructNodesEnabled, "Construct only structure points but frames");
		num = 400f;
		num2 = 10f;
		_dysonInitBtn = wnd.AddButton(num, num2, rectTransform, "Initialize Dyson Sphere", 16, "init-dyson-sphere", delegate
		{
			UIMessageBox.Show("Initialize Dyson Sphere".Translate(), "Initialize Dyson Sphere Confirm".Translate(), "Cancel".Translate(), "OK".Translate(), 2, null, delegate
			{
				DysonSphereFunctions.InitCurrentDysonLayer(null, -1);
			});
		});
		num2 += 36f;
		wnd.AddText2(num, num2, rectTransform, "Click to dismantle selected layer", 16, "text-dismantle-layer");
		num2 += 27f;
		for (int num15 = 0; num15 < 10; num15++)
		{
			int id = num15 + 1;
			MyFlatButton myFlatButton = wnd.AddFlatButton(num, num2, rectTransform, id.ToString(), 12, "dismantle-layer-" + id, delegate
			{
				StarData star = DysonSphereFunctions.CurrentStarForDysonSystem();
				UIMessageBox.Show("Dismantle selected layer".Translate(), "Dismantle selected layer Confirm".Translate(), "Cancel".Translate(), "OK".Translate(), 2, null, delegate
				{
					DysonSphereFunctions.InitCurrentDysonLayer(star, id);
				});
			}).WithSize(40f, 20f);
			DysonLayerBtn[num15] = myFlatButton.uiButton;
			if (num15 == 4)
			{
				num -= 160f;
				num2 += 20f;
			}
			else
			{
				num += 40f;
			}
		}
		num = 400f;
		num2 += 36f;
		text = wnd.AddText2(num, num2, rectTransform, "Auto Fast Build Speed Multiplier", 15, "text-auto-fast-build-multiplier");
		wnd.AddSlider(num + Util.GetPreferredWidth(text) + 5f, num2 + 6f, rectTransform, DysonSpherePatch.AutoConstructMultiplier, new int[7] { 1, 2, 5, 10, 20, 50, 100 }, "0", 100f);
		_dysonTab = rectTransform;
		RectTransform parent4 = wnd.AddTab(trans, "Tech/Combat/UI");
		num = 10f;
		num2 = 10f;
		wnd.AddCheckBox(num, num2, parent4, UIPatch.PlanetVeinUtilizationEnabled, "Planet vein utilization");
		num2 += 72f;
		wnd.AddCheckBox(num, num2, parent4, TechPatch.BatchBuyoutTechEnabled, "Buy out techs with their prerequisites");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent4, TechPatch.SorterCargoStackingEnabled, "Restore upgrades of \"Sorter Cargo Stacking\" on panel");
		num2 += 36f;
		wnd.AddCheckBox(num, num2, parent4, TechPatch.DisableBattleRelatedTechsInPeaceModeEnabled, "Disable battle-related techs in Peace mode");
		num2 += 36f;
		wnd.AddButton(num, num2, 300f, parent4, "Set \"Sorter Cargo Stacking\" to unresearched state", 16, "button-remove-cargo-stacking", TechFunctions.RemoveCargoStackingTechs);
		num2 += 36f;
		wnd.AddButton(num, num2, 300f, parent4, "Unlock all techs with metadata", 16, "button-unlock-all-techs-with-metadata", TechFunctions.UnlockAllProtoWithMetadataAndPrompt);
		num2 += 72f;
		wnd.AddButton(num, num2, 300f, parent4, "Open Dark Fog Communicator", 16, "button-open-df-communicator", delegate
		{
			GameData data = GameMain.data;
			if (data != null && data.gameDesc.isCombatMode)
			{
				UIGame uiGame = UIRoot.instance.uiGame;
				uiGame.ShutPlayerInventory();
				uiGame.CloseEnemyBriefInfo();
				uiGame.OpenCommunicatorWindow(5);
			}
		});
		void AddApplyButton(float rowY2, string objName, UnityAction onClick)
		{
			AddApplyButtonAt(applyBtnX, rowY2, objName, onClick);
		}
		void AddApplyButtonAt(float x2, float num16, string objName, UnityAction onClick)
		{
			wnd.AddFlatButton(x2, num16 + 6f, tab3, "Apply config to planet", 11, objName, onClick).WithSize(44f, 15f).WithFontSize(11)
				.WithTip("Apply config to planet tips".Translate());
		}
		void AddCategoryApplyButton(float num16, string objName, UnityAction onClick)
		{
			wnd.AddFlatButton(applyAllBtnX, num16 + 7f, tab3, "Apply all config to planet", 11, objName, onClick).WithSize(58f, 15f).WithFontSize(11)
				.WithTip("Apply all config to planet tips".Translate());
		}
		void AlternatelyCheckBoxChanged(object o, EventArgs e)
		{
			alternatelyCheckBox.SetEnable(FactoryConfigProvider.DragBuildPowerPolesEnabled.Value);
		}
		void DoNotRenderEntitiesEnabledChanged(object o, EventArgs e)
		{
			hideSortersCheckBox.SetEnable(FactoryConfigProvider.DoNotRenderEntitiesEnabled.Value);
		}
		void NavSettingChanged(object o, EventArgs e)
		{
			autoCruiseCheckBox.SetEnable(on: true);
			autoStopCheckBox.SetEnable(PlayerPatch.AutoCruiseEnabled.Value);
			useWarpCheckBox.SetEnable(PlayerPatch.AutoCruiseEnabled.Value);
			warpEnergySlider.SetEnable(PlayerPatch.AutoCruiseEnabled.Value && PlayerPatch.UseWarper.Value);
			newNavDistanceSlider.SetEnable(PlayerPatch.AutoCruiseEnabled.Value && PlayerPatch.UseWarper.Value);
			speedUpCheckBox.SetEnable(PlayerPatch.AutoCruiseEnabled.Value);
			speedUpEnergySlider.SetEnable(PlayerPatch.AutoCruiseEnabled.Value && PlayerPatch.UseSpeedUp.Value);
			dfHiveSlider.SetEnable(PlayerPatch.AutoCruiseEnabled.Value);
			dfCarrierSlider.SetEnable(PlayerPatch.AutoCruiseEnabled.Value);
		}
		void PressShiftToTakeWholeBeltItemsEnabledChanged(object o, EventArgs e)
		{
			includeBranches.SetEnable(FactoryConfigProvider.PressShiftToTakeWholeBeltItemsEnabled.Value);
			includeInserters.SetEnable(FactoryConfigProvider.PressShiftToTakeWholeBeltItemsEnabled.Value);
		}
		void ProductLimitChanged(object sender, EventArgs args)
		{
			productLimitInput.text = productLimitConfig.Value.ToString();
		}
		void RealtimeLogisticsInfoPanelChanged(object o, EventArgs e)
		{
			if (AuxilaryfunctionWrapper.ShowStationInfo == null)
			{
				realtimeLogisticsInfoPanelCheckBox.SetEnable(on: true);
				realtimeLogisticsInfoPanelBarsCheckBox.SetEnable(LogisticsConfigProvider.RealtimeLogisticsInfoPanelEnabled.Value);
			}
			else
			{
				bool flag = !AuxilaryfunctionWrapper.ShowStationInfo.Value;
				realtimeLogisticsInfoPanelCheckBox.SetEnable(flag);
				realtimeLogisticsInfoPanelBarsCheckBox.SetEnable(flag & LogisticsConfigProvider.RealtimeLogisticsInfoPanelEnabled.Value);
				if (!flag)
				{
					LogisticsConfigProvider.RealtimeLogisticsInfoPanelEnabled.Value = false;
				}
			}
		}
		void SetProductLimit(string value)
		{
			if (int.TryParse(value, out var result))
			{
				productLimitConfig.Value = Mathf.Clamp(result, 1, 999999);
			}
			productLimitInput.text = productLimitConfig.Value.ToString();
		}
		void TankSettingChanged(object o, EventArgs e)
		{
			tankSlider.SetEnable(FactoryConfigProvider.TankFastFillInAndTakeOutEnabled.Value);
		}
		void TweakBuildingBufferChanged(object o, EventArgs e)
		{
			assemblerBufferTimeMultiplierSlider.SetEnable(FactoryConfigProvider.TweakBuildingBufferEnabled.Value);
			assemblerBufferMininumMultiplierSlider.SetEnable(FactoryConfigProvider.TweakBuildingBufferEnabled.Value);
			labBufferMaxCountForAssembleSlider.SetEnable(FactoryConfigProvider.TweakBuildingBufferEnabled.Value);
			labBufferExtraCountForAdvancedAssembleSlider.SetEnable(FactoryConfigProvider.TweakBuildingBufferEnabled.Value);
			labBufferMaxCountForResearchSlider.SetEnable(FactoryConfigProvider.TweakBuildingBufferEnabled.Value);
			receiverBufferCountSlider.SetEnable(FactoryConfigProvider.TweakBuildingBufferEnabled.Value);
			ejectorBufferCountSlider.SetEnable(FactoryConfigProvider.TweakBuildingBufferEnabled.Value);
			siloBufferCountSlider.SetEnable(FactoryConfigProvider.TweakBuildingBufferEnabled.Value);
		}
	}

	private static void UpdateUI()
	{
		UpdateDysonShells();
	}

	private static void UpdateDysonShells()
	{
		if (!_dysonTab.gameObject.activeSelf)
		{
			return;
		}
		StarData starData = DysonSphereFunctions.CurrentStarForDysonSystem();
		if (starData == null)
		{
			for (int i = 0; i < 10; i++)
			{
				DysonLayerBtn[i].button.interactable = false;
			}
			return;
		}
		DysonSphere[] array = GameMain.data?.dysonSpheres;
		if (((array != null) ? array[starData.index] : null) != null)
		{
			DysonSphere dysonSphere = array[starData.index];
			for (int j = 1; j <= 10; j++)
			{
				DysonSphereLayer dysonSphereLayer = dysonSphere.layersIdBased[j];
				DysonLayerBtn[j - 1].button.interactable = dysonSphereLayer != null && dysonSphereLayer.id == j;
			}
		}
	}
}
