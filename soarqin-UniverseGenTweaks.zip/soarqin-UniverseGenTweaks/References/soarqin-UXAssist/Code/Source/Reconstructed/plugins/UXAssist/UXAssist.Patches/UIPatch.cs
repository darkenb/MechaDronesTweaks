using System;
using System.Collections.Generic;
using System.Linq;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UXAssist.Common;
using UXAssist.Functions;
using UXAssist.Functions.UI;
using UXAssist.UI;
using UnityEngine;
using UnityEngine.UI;

namespace UXAssist.Patches;

[PatchGuid("org.soardev.uxassist")]
public class UIPatch : PatchImpl<UIPatch>
{
	private class PlanetVeinUtilization : PatchImpl<PlanetVeinUtilization>
	{
		private const float CountLabelGap = 4f;

		private const float MinCountWidth = 36f;

		private static VeinTypeInfo[] planetVeinCount = null;

		private static VeinTypeInfo[] starVeinCount = null;

		private static readonly Dictionary<int, bool> tmpGroups = new Dictionary<int, bool>();

		public static void OnGameBegin()
		{
			if (planetVeinCount != null)
			{
				VeinTypeInfo[] array = planetVeinCount;
				foreach (VeinTypeInfo veinTypeInfo in array)
				{
					veinTypeInfo.Reset();
					if (veinTypeInfo.textCtrl != null)
					{
						UnityEngine.Object.Destroy(veinTypeInfo.textCtrl.gameObject);
					}
				}
				planetVeinCount = null;
			}
			if (starVeinCount != null)
			{
				VeinTypeInfo[] array = starVeinCount;
				foreach (VeinTypeInfo veinTypeInfo2 in array)
				{
					veinTypeInfo2.Reset();
					if (veinTypeInfo2.textCtrl != null)
					{
						UnityEngine.Object.Destroy(veinTypeInfo2.textCtrl.gameObject);
					}
				}
				starVeinCount = null;
			}
			int num = LDB.veins.dataArray.Max((VeinProto vein) => vein.ID);
			planetVeinCount = new VeinTypeInfo[num + 1];
			starVeinCount = new VeinTypeInfo[num + 1];
			InitializeVeinCountArray(planetVeinCount);
			InitializeVeinCountArray(starVeinCount);
		}

		protected override void OnEnable()
		{
			if (planetVeinCount != null)
			{
				VeinTypeInfo[] array = planetVeinCount;
				foreach (VeinTypeInfo obj in array)
				{
					obj.Reset();
					obj.textCtrl?.gameObject.SetActive(value: true);
				}
				UIPlanetDetail_RefreshDynamicProperties_Postfix(UIRoot.instance.uiGame.planetDetail);
			}
			if (starVeinCount != null)
			{
				VeinTypeInfo[] array = starVeinCount;
				foreach (VeinTypeInfo obj2 in array)
				{
					obj2.Reset();
					obj2.textCtrl?.gameObject.SetActive(value: true);
				}
				UIStarDetail_RefreshDynamicProperties_Postfix(UIRoot.instance.uiGame.starDetail);
			}
		}

		private static Vector2 GetAdjustedSizeDelta(Vector2 origSizeDelta)
		{
			return new Vector2(origSizeDelta.x + 40f, origSizeDelta.y);
		}

		protected override void OnDisable()
		{
			if (planetVeinCount != null)
			{
				VeinTypeInfo[] array = planetVeinCount;
				foreach (VeinTypeInfo obj in array)
				{
					obj.Reset();
					obj.textCtrl?.gameObject.SetActive(value: false);
				}
			}
			if (starVeinCount != null)
			{
				VeinTypeInfo[] array = starVeinCount;
				foreach (VeinTypeInfo obj2 in array)
				{
					obj2.Reset();
					obj2.textCtrl?.gameObject.SetActive(value: false);
				}
			}
		}

		private static void ProcessVeinData(VeinTypeInfo[] veinCount, VeinData[] veinPool)
		{
			if (veinPool == null)
			{
				return;
			}
			lock (veinPool)
			{
				for (int i = 0; i < veinPool.Length; i++)
				{
					VeinData veinData = veinPool[i];
					if (veinData.groupIndex == 0 || veinData.amount == 0)
					{
						continue;
					}
					if (tmpGroups.TryGetValue(veinData.groupIndex, out var value))
					{
						if (!value)
						{
							value = veinData.minerCount > 0;
							if (value)
							{
								tmpGroups[veinData.groupIndex] = true;
								veinCount[(uint)veinData.type].numVeinGroupsWithCollector++;
							}
						}
					}
					else
					{
						value = veinData.minerCount > 0;
						tmpGroups.Add(veinData.groupIndex, value);
						VeinTypeInfo veinTypeInfo = veinCount[(uint)veinData.type];
						veinTypeInfo.numVeinGroups++;
						if (value)
						{
							veinTypeInfo.numVeinGroupsWithCollector++;
						}
					}
				}
			}
			tmpGroups.Clear();
		}

		private static void FormatResource(UIResAmountEntry uiresAmountEntry, VeinTypeInfo vt)
		{
			RectTransform rectTransform = uiresAmountEntry.labelText.rectTransform;
			if (vt.labelRect != rectTransform)
			{
				vt.RestoreLabel();
				vt.labelRect = rectTransform;
				vt.labelOffsetMinX = rectTransform.offsetMin.x;
			}
			if (vt.textCtrl == null)
			{
				vt.textCtrl = UnityEngine.Object.Instantiate(uiresAmountEntry.valueText, rectTransform.parent);
				vt.textCtrl.font = uiresAmountEntry.labelText.font;
				vt.textCtrl.text = "";
				vt.textCtrl.color = uiresAmountEntry.normalColor;
				vt.textCtrl.alignment = TextAnchor.MiddleRight;
				vt.textCtrl.fontStyle = FontStyle.Normal;
				vt.textCtrl.horizontalOverflow = HorizontalWrapMode.Overflow;
				vt.textCtrl.verticalOverflow = VerticalWrapMode.Overflow;
				vt.textCtrl.resizeTextForBestFit = false;
				vt.textCtrl.raycastTarget = false;
			}
			vt.textCtrl.text = $"{vt.numVeinGroupsWithCollector}/{vt.numVeinGroups}";
			float num = Mathf.Max(36f, Mathf.Ceil(global::UXAssist.UI.Util.GetPreferredWidth(vt.textCtrl)));
			RectTransform rectTransform2 = vt.textCtrl.rectTransform;
			if (rectTransform2.parent != rectTransform.parent)
			{
				rectTransform2.SetParent(rectTransform.parent, worldPositionStays: false);
			}
			rectTransform2.anchorMin = rectTransform.anchorMin;
			rectTransform2.anchorMax = new Vector2(rectTransform.anchorMin.x, rectTransform.anchorMax.y);
			rectTransform2.pivot = new Vector2(0f, rectTransform.pivot.y);
			rectTransform2.offsetMin = new Vector2(vt.labelOffsetMinX, rectTransform.offsetMin.y);
			rectTransform2.offsetMax = new Vector2(vt.labelOffsetMinX + num, rectTransform.offsetMax.y);
			rectTransform.offsetMin = new Vector2(vt.labelOffsetMinX + num + 4f, rectTransform.offsetMin.y);
		}

		private static void InitializeVeinCountArray(VeinTypeInfo[] veinCountArray)
		{
			for (int i = 0; i < veinCountArray.Length; i++)
			{
				veinCountArray[i] = new VeinTypeInfo();
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(UIPlanetDetail), "OnPlanetDataSet")]
		public static void UIPlanetDetail_OnPlanetDataSet_Prefix(UIPlanetDetail __instance)
		{
			VeinTypeInfo[] array = planetVeinCount;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].Reset();
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(UIPlanetDetail), "RefreshDynamicProperties")]
		public static void UIPlanetDetail_RefreshDynamicProperties_Postfix(UIPlanetDetail __instance)
		{
			PlanetData planet = __instance.planet;
			if (planet == null || planet.runtimeVeinGroups == null || __instance.tabIndex != 0)
			{
				return;
			}
			int num = ((__instance.planet == GameMain.localPlanet) ? 1 : 2);
			if (GameMain.history.universeObserveLevel < num)
			{
				return;
			}
			VeinTypeInfo[] array = planetVeinCount;
			foreach (VeinTypeInfo obj in array)
			{
				obj.numVeinGroups = 0;
				obj.numVeinGroupsWithCollector = 0;
			}
			PlanetFactory factory = planet.factory;
			if (factory != null)
			{
				ProcessVeinData(planetVeinCount, factory.veinPool);
			}
			else
			{
				VeinGroup[] runtimeVeinGroups = planet.runtimeVeinGroups;
				lock (planet.veinGroupsLock)
				{
					for (int j = 1; j < runtimeVeinGroups.Length; j++)
					{
						planetVeinCount[(uint)runtimeVeinGroups[j].type].numVeinGroups++;
					}
				}
			}
			foreach (UIResAmountEntry entry in __instance.entries)
			{
				int refId = entry.refId;
				if (refId > 0 && refId < 15)
				{
					VeinTypeInfo veinTypeInfo = planetVeinCount[refId];
					if (veinTypeInfo.numVeinGroups > 0)
					{
						FormatResource(entry, veinTypeInfo);
					}
					else
					{
						veinTypeInfo.Reset();
					}
				}
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(UIStarDetail), "OnStarDataSet")]
		public static void UIStaretail_OnStarDataSet_Prefix(UIStarDetail __instance)
		{
			VeinTypeInfo[] array = starVeinCount;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].Reset();
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(UIStarDetail), "RefreshDynamicProperties")]
		public static void UIStarDetail_RefreshDynamicProperties_Postfix(UIStarDetail __instance)
		{
			if (__instance.star == null || __instance.tabIndex != 0 || GameMain.history.universeObserveLevel < 2)
			{
				return;
			}
			VeinTypeInfo[] array = starVeinCount;
			foreach (VeinTypeInfo obj in array)
			{
				obj.numVeinGroups = 0;
				obj.numVeinGroupsWithCollector = 0;
			}
			PlanetData[] planets = __instance.star.planets;
			foreach (PlanetData planetData in planets)
			{
				PlanetFactory factory = planetData.factory;
				if (factory != null)
				{
					ProcessVeinData(starVeinCount, factory.veinPool);
					continue;
				}
				VeinGroup[] veinGroups = planetData.veinGroups;
				if (veinGroups == null)
				{
					continue;
				}
				lock (planetData.veinGroupsLock)
				{
					for (int j = 1; j < veinGroups.Length; j++)
					{
						starVeinCount[(uint)veinGroups[j].type].numVeinGroups++;
					}
				}
			}
			foreach (UIResAmountEntry entry in __instance.entries)
			{
				int refId = entry.refId;
				if (refId > 0 && refId < 15)
				{
					VeinTypeInfo veinTypeInfo = starVeinCount[refId];
					if (veinTypeInfo.numVeinGroups > 0)
					{
						FormatResource(entry, veinTypeInfo);
					}
					else
					{
						veinTypeInfo.Reset();
					}
				}
			}
		}
	}

	public class VeinTypeInfo
	{
		public int numVeinGroups;

		public int numVeinGroupsWithCollector;

		public Text textCtrl;

		public RectTransform labelRect;

		public float labelOffsetMinX;

		public void RestoreLabel()
		{
			if (labelRect != null)
			{
				labelRect.offsetMin = new Vector2(labelOffsetMinX, labelRect.offsetMin.y);
			}
			labelRect = null;
		}

		public void Reset()
		{
			numVeinGroups = 0;
			numVeinGroupsWithCollector = 0;
			RestoreLabel();
			if (textCtrl != null)
			{
				textCtrl.text = "";
			}
		}
	}

	public static ConfigEntry<bool> PlanetVeinUtilizationEnabled;

	public static void Init()
	{
		PlanetVeinUtilizationEnabled.SettingChanged += delegate
		{
			PatchImpl<PlanetVeinUtilization>.Enable(PlanetVeinUtilizationEnabled.Value);
		};
	}

	public static void Start()
	{
		global::UXAssist.Common.GameLogic.OnGameBegin = (Action)Delegate.Combine(global::UXAssist.Common.GameLogic.OnGameBegin, new Action(PlanetVeinUtilization.OnGameBegin));
		PatchImpl<UIPatch>.Enable(enable: true);
		UIFunctions.InitMenuButtons();
		UIFunctions.InitMilkyWayTopTenPlayers();
		PatchImpl<PlanetVeinUtilization>.Enable(PlanetVeinUtilizationEnabled.Value);
	}

	public static void Uninit()
	{
		PatchImpl<PlanetVeinUtilization>.Enable(enable: false);
		PatchImpl<UIPatch>.Enable(enable: false);
		global::UXAssist.Common.GameLogic.OnGameBegin = (Action)Delegate.Remove(global::UXAssist.Common.GameLogic.OnGameBegin, new Action(PlanetVeinUtilization.OnGameBegin));
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIRoot), "_OnOpen")]
	public static void UIRoot__OnOpen_Postfix()
	{
		UIFunctions.InitMenuButtons();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetData), "NotifyScanEnded")]
	private static void PlanetData_NotifyScanEnded_Postfix(PlanetData __instance)
	{
		if (PlanetModelingManager.scnPlanetReqList.Count <= 0)
		{
			ThreadingHelper.Instance.StartSyncInvoke(UIFunctions.OnPlanetScanEnded);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIPlanetGlobe), "DistributeButtons")]
	private static void UIPlanetGlobe_DistributeButtons_Postfix(UIPlanetGlobe __instance)
	{
		UIFunctions.UpdateGlobeButtonPosition(__instance);
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIStarmapStar), "OnStarDisplayNameChange")]
	private static bool UIStarmapStar_OnStarDisplayNameChange_Prefix()
	{
		return StarmapFilterUI.CornerComboBoxIndex == 0;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIStarmapStar), "_OnClose")]
	private static void UIStarmapStar__OnClose_Postfix(UIStarmapStar __instance)
	{
		StarmapFilterUI.StarmapFilterToggler?.SetCheckedWithEvent(check: false);
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIMechaLab), "DetermineVisible")]
	private static bool UIMechaLab_DetermineVisible_Prefix(UIMechaLab __instance, ref bool __result)
	{
		if (!UIRoot.instance.uiGame.starmap.active || !StarmapFilterUI.StarmapFilterToggler.Checked)
		{
			return true;
		}
		__instance._Close();
		__result = false;
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIGoalPanel), "DetermineVisiable")]
	private static bool UIGoalPanel_DetermineVisiable_Prefix(UIGoalPanel __instance)
	{
		if (!UIRoot.instance.uiGame.starmap.active || !StarmapFilterUI.StarmapFilterToggler.Checked)
		{
			return true;
		}
		__instance.isUseOverwrittenState = true;
		if (__instance.stateOverwritten == EUIGoalPanelState.None)
		{
			__instance.stateOverwritten = EUIGoalPanelState.Collapse;
		}
		return false;
	}
}
