using System;
using HarmonyLib;

namespace UXAssist.Common;

public class GameLogic : PatchImpl<GameLogic>
{
	public static Action OnDataLoaded;

	public static Action OnGameBegin;

	public static Action OnGameEnd;

	[HarmonyPostfix]
	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	public static void VFPreload_InvokeOnLoadWorkEnded_Postfix()
	{
		OnDataLoaded.InvokeSafe(UXAssist.Logger, "OnDataLoaded");
	}

	[HarmonyPostfix]
	[HarmonyPriority(0)]
	[HarmonyPatch(typeof(VFInput), "OnUpdate")]
	public static void VFInput_OnUpdate_Postfix()
	{
		UXAssist.OnInputUpdate();
	}

	[HarmonyPostfix]
	[HarmonyPriority(800)]
	[HarmonyPatch(typeof(GameMain), "Begin")]
	public static void GameMain_Begin_Postfix()
	{
		OnGameBegin.InvokeSafe(UXAssist.Logger, "OnGameBegin");
	}

	[HarmonyPostfix]
	[HarmonyPriority(0)]
	[HarmonyPatch(typeof(GameMain), "End")]
	public static void GameMain_End_Postfix()
	{
		OnGameEnd.InvokeSafe(UXAssist.Logger, "OnGameEnd");
	}
}
