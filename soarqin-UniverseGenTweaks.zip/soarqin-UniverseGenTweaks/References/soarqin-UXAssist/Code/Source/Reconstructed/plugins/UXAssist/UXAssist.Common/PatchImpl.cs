using System;
using System.Linq;
using System.Reflection;
using HarmonyLib;

namespace UXAssist.Common;

public class PatchImpl<T> where T : PatchImpl<T>, new()
{
	protected Harmony _patch;

	protected static T Instance { get; } = new T();

	public static void Enable(bool enable)
	{
		T instance = Instance;
		if (enable)
		{
			if (instance._patch != null)
			{
				return;
			}
			string id = typeof(T).GetCustomAttribute<PatchGuidAttribute>()?.Guid ?? ("PatchImpl." + (typeof(T).FullName ?? typeof(T).ToString()));
			bool flag = typeof(T).GetCustomAttributes<PatchSetCallbackFlagAttribute>().Any((PatchSetCallbackFlagAttribute n) => n.Flag == PatchCallbackFlag.CallOnEnableBeforePatch);
			if (flag)
			{
				instance.OnEnable();
			}
			Harmony harmony = new Harmony(id);
			try
			{
				harmony.PatchAll(typeof(T));
			}
			catch (Exception arg)
			{
				UXAssist.Logger.LogError($"Failed to apply Harmony patches for {typeof(T).FullName}: {arg}");
				try
				{
					harmony.UnpatchSelf();
					return;
				}
				catch (Exception arg2)
				{
					UXAssist.Logger.LogError($"Failed to roll back partially applied patches for {typeof(T).FullName}: {arg2}");
					return;
				}
			}
			instance._patch = harmony;
			if (!flag)
			{
				instance.OnEnable();
			}
		}
		else if (instance._patch != null)
		{
			bool num = typeof(T).GetCustomAttributes<PatchSetCallbackFlagAttribute>().Any((PatchSetCallbackFlagAttribute n) => n.Flag == PatchCallbackFlag.CallOnDisableAfterUnpatch);
			if (!num)
			{
				instance.OnDisable();
			}
			instance._patch.UnpatchSelf();
			instance._patch = null;
			if (num)
			{
				instance.OnDisable();
			}
		}
	}

	public static Harmony GetHarmony()
	{
		return Instance._patch;
	}

	protected virtual void OnEnable()
	{
	}

	protected virtual void OnDisable()
	{
	}
}
