using System;
using HarmonyLib;
using UXAssist.Common.ModCompat;

namespace UXAssist.ModsCompat;

public static class CommonAPIWrapper
{
	public static void Run(Harmony harmony)
	{
		if (ModCompatHelper.TryGetLoadedPluginInfo("dsp.common-api.CommonAPI", out var pluginInfo) && !(pluginInfo.Metadata.Version > new System.Version(1, 6, 7, 0)))
		{
			harmony.Patch(AccessTools.Method(typeof(GameOption), "InitKeys"), new HarmonyMethod(AccessTools.Method(typeof(CommonAPIWrapper), "PatchInitKeys"), 800));
		}
	}

	public static bool PatchInitKeys(GameOption __instance)
	{
		return __instance.overrideKeys == null;
	}
}
