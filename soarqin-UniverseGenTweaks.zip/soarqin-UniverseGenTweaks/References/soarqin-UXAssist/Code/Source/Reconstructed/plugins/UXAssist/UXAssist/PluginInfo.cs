namespace UXAssist;

public static class PluginInfo
{
	public const string PLUGIN_GUID = "org.soardev.uxassist";

	public const string PLUGIN_NAME = "UXAssist";

	public const string PLUGIN_VERSION = "1.6.3";
}
