using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;

namespace xiaoye97.Patches;

[HarmonyPatch]
public static class VFPreload_Patch
{
	[HarmonyPrefix]
	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	private static void VFPreloadPrePatch()
	{
		if (!LDBTool.Finshed)
		{
			LDBToolPlugin.logger.LogInfo("Pre Loading...");
			if (LDBTool.PreAddDataAction != null)
			{
				LDBTool.PreAddDataAction();
				LDBTool.PreAddDataAction = null;
			}
			LDBTool.AddProtos(LDBTool.PreToAdd);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	private static void VFPreloadPostPatch()
	{
		if (LDBTool.Finshed)
		{
			return;
		}
		LDBToolPlugin.logger.LogInfo("Post Loading...");
		if (LDBTool.PostAddDataAction != null)
		{
			LDBTool.PostAddDataAction();
			LDBTool.PostAddDataAction = null;
		}
		LDBTool.AddProtos(LDBTool.PostToAdd);
		if (LDBTool.EditDataAction != null)
		{
			PropertyInfo[] properties = typeof(LDB).GetProperties();
			foreach (PropertyInfo obj in properties)
			{
				Type type = obj.PropertyType;
				if (!type.IsConstructedGenericType)
				{
					type = type.BaseType;
				}
				Type type2 = type.GetGenericArguments()[0];
				object value = obj.GetValue(null);
				typeof(VFPreload_Patch).GetMethod("EditAllProtos", AccessTools.all).MakeGenericMethod(type2).Invoke(null, new object[1] { value });
			}
		}
		LDBToolPlugin.logger.LogInfo("Calling ItemProto init functions...");
		try
		{
			ItemProto.InitFuelNeeds();
			ItemProto.InitConstructableItems();
			ItemProto.InitItemIds();
			ItemProto.InitItemIndices();
			InitRecipeItems();
			SignalProtoSet.InitSignalKeyIdPairs();
		}
		catch (Exception arg)
		{
			LDBToolPlugin.logger.LogError($"Error calling ItemProto init functions\n{arg}");
		}
		GameMain.iconSet.loaded = false;
		GameMain.iconSet.Create();
		LDBTool.SetBuildBar();
		LDBTool.Finshed = true;
		LDBToolPlugin.logger.LogInfo("Done.");
	}

	private static void InitRecipeItems()
	{
		RecipeProto.recipeExecuteData = new Dictionary<int, RecipeExecuteData>();
		RecipeProto[] dataArray = LDB.recipes.dataArray;
		for (int i = 0; i < dataArray.Length; i++)
		{
			RecipeExecuteData value = new RecipeExecuteData(dataArray[i].Items, dataArray[i].ItemCounts, dataArray[i].Results, dataArray[i].ResultCounts, dataArray[i].TimeSpend * 10000, dataArray[i].TimeSpend * 100000, dataArray[i].productive);
			if (!RecipeProto.recipeExecuteData.ContainsKey(dataArray[i].ID))
			{
				RecipeProto.recipeExecuteData.Add(dataArray[i].ID, value);
			}
			else
			{
				LDBToolPlugin.logger.LogWarning($"Duplicate RecipeId:{dataArray[i].ID} Name:{dataArray[i].Name}");
			}
		}
	}

	private static void EditAllProtos<T>(ProtoSet<T> protoSet) where T : Proto
	{
		T[] dataArray = protoSet.dataArray;
		foreach (T val in dataArray)
		{
			if (val != null)
			{
				try
				{
					LDBTool.EditDataAction(val);
				}
				catch (Exception ex)
				{
					LDBToolPlugin.logger.LogWarning($"Edit Error: ID:{val.ID} Type:{val.GetType().Name} {ex.Message}");
				}
			}
		}
		ProtoLookup.Rebuild(protoSet, delegate(string message)
		{
			LDBToolPlugin.logger.LogWarning(message);
		});
	}
}
