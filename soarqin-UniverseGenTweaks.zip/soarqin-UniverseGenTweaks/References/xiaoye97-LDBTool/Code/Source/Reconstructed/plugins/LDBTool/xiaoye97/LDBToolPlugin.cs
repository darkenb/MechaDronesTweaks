using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;
using xiaoye97.UI;

namespace xiaoye97;

[BepInPlugin("me.xiaoye97.plugin.Dyson.LDBTool", "LDBTool", "3.0.4")]
public class LDBToolPlugin : BaseUnityPlugin
{
	public const string MODNAME = "LDBTool";

	public const string MODGUID = "me.xiaoye97.plugin.Dyson.LDBTool";

	public const string VERSION = "3.0.4";

	internal static ManualLogSource logger;

	internal static ConfigEntry<bool> ShowProto;

	internal static ConfigEntry<KeyCode> ShowProtoHotKey;

	internal static ConfigEntry<KeyCode> ShowItemProtoHotKey;

	internal static ConfigEntry<KeyCode> ShowRecipeProtoHotKey;

	internal static UIItemTip lastTip;

	private void Awake()
	{
		logger = base.Logger;
		ProtoIndex.InitIndex();
		LDBTool.Init();
		ShowProto = base.Config.Bind("config", "ShowProto", defaultValue: false, "是否开启数据显示");
		ShowProtoHotKey = base.Config.Bind("config", "ShowProtoHotKey", KeyCode.F5, "呼出界面的快捷键");
		ShowItemProtoHotKey = base.Config.Bind("config", "ShowItemProtoHotKey", KeyCode.I, "显示物品的Proto");
		ShowRecipeProtoHotKey = base.Config.Bind("config", "ShowRecipeProtoHotKey", KeyCode.R, "显示配方的Proto");
		new Harmony("me.xiaoye97.plugin.Dyson.LDBTool").PatchAll(Assembly.GetExecutingAssembly());
		logger.LogInfo("LDBTool is loaded successfully!");
	}

	private void Update()
	{
		if (!ShowProto.Value)
		{
			return;
		}
		if (Input.GetKeyDown(ShowProtoHotKey.Value))
		{
			ProtoDataUI.Show = !ProtoDataUI.Show;
		}
		if (SupportsHelper.UnityExplorerInstalled)
		{
			if (Input.GetKeyDown(ShowItemProtoHotKey.Value))
			{
				TryShowItemProto();
			}
			if (Input.GetKeyDown(ShowRecipeProtoHotKey.Value))
			{
				TryShowRecipeProto();
			}
		}
	}

	private void OnGUI()
	{
		if (ShowProto.Value && ProtoDataUI.Show)
		{
			ProtoDataUI.OnGUI();
		}
	}

	internal static void TryShowItemProto()
	{
		if (!ShowProto.Value || !(lastTip != null) || lastTip.showingItemId == 0)
		{
			return;
		}
		ItemProto itemProto = LDB.items.Select(lastTip.showingItemId);
		if (itemProto != null)
		{
			RUEHelper.ShowProto(itemProto);
			return;
		}
		RecipeProto recipeProto = LDB.recipes.Select(-lastTip.showingItemId);
		if (recipeProto != null)
		{
			int[] results = recipeProto.Results;
			foreach (int id in results)
			{
				RUEHelper.ShowProto(LDB.items.Select(id));
			}
		}
	}

	internal static void TryShowRecipeProto()
	{
		if (!ShowProto.Value || !(lastTip != null) || lastTip.showingItemId == 0)
		{
			return;
		}
		ItemProto itemProto = LDB.items.Select(lastTip.showingItemId);
		if (itemProto != null)
		{
			foreach (RecipeProto recipe in itemProto.recipes)
			{
				RUEHelper.ShowProto(recipe);
			}
			return;
		}
		RUEHelper.ShowProto(LDB.recipes.Select(-lastTip.showingItemId));
	}
}
