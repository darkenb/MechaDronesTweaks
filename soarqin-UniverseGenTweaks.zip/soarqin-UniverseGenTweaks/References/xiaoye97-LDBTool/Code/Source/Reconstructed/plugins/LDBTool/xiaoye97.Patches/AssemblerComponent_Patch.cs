using HarmonyLib;

namespace xiaoye97.Patches;

[HarmonyPatch]
public class AssemblerComponent_Patch
{
	[HarmonyPostfix]
	[HarmonyPriority(600)]
	[HarmonyPatch(typeof(AssemblerComponent), "Import")]
	private static void ValidateAndFixRecipeData(ref AssemblerComponent __instance)
	{
		if (__instance.recipeId <= 0)
		{
			return;
		}
		if (__instance.recipeExecuteData == null)
		{
			LDBToolPlugin.logger.LogWarning($"Importing assembler {__instance.recipeType}: Can't find recipeId {__instance.recipeId}");
			__instance.recipeId = 0;
			__instance.recipeType = ERecipeType.None;
			__instance.recipeExecuteData = null;
			__instance.served = null;
			__instance.incServed = null;
			__instance.needs = null;
			__instance.produced = null;
			return;
		}
		if (__instance.served.Length != __instance.recipeExecuteData.requireCounts.Length || __instance.incServed.Length != __instance.recipeExecuteData.requireCounts.Length)
		{
			LDBToolPlugin.logger.LogWarning($"Importing assembler {__instance.recipeType}: requireCounts mismatch");
			__instance.served = new int[__instance.recipeExecuteData.requireCounts.Length];
			__instance.incServed = new int[__instance.recipeExecuteData.requireCounts.Length];
		}
		if (__instance.produced.Length != __instance.recipeExecuteData.productCounts.Length)
		{
			LDBToolPlugin.logger.LogWarning($"Importing assembler {__instance.recipeType}: productCounts mismatch");
			__instance.produced = new int[__instance.recipeExecuteData.productCounts.Length];
		}
	}
}
