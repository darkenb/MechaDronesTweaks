using HarmonyLib;

namespace xiaoye97.Patches;

[HarmonyPatch]
public static class GameHistoryData_Patch
{
	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameHistoryData), "Import")]
	private static void HistoryPatch(GameHistoryData __instance)
	{
		foreach (Proto item in LDBTool.TotalDict[ProtoIndex.GetIndex(typeof(RecipeProto))])
		{
			RecipeProto recipeProto = item as RecipeProto;
			if (recipeProto.preTech != null && __instance.TechState(recipeProto.preTech.ID).unlocked && !__instance.RecipeUnlocked(recipeProto.ID))
			{
				__instance.UnlockRecipe(recipeProto.ID);
			}
		}
	}
}
