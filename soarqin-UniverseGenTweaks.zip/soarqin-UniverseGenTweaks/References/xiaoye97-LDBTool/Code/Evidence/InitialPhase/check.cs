using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;

class Check
{
    static Assembly plugin;
    static void Assert(bool ok, string message) { if (!ok) throw new Exception(message); }
    static void Rebuild<T>(ProtoSet<T> set, List<string> warnings) where T : Proto {
        plugin.GetType("xiaoye97.ProtoLookup", true).GetMethod("Rebuild", BindingFlags.Static | BindingFlags.NonPublic)
            .MakeGenericMethod(typeof(T)).Invoke(null, new object[] { set, new Action<string>(warnings.Add) });
    }
    static void Test<T>() where T : Proto, new() {
        var set = (ProtoSet<T>)FormatterServices.GetUninitializedObject(typeof(ProtoSet<T>));
        var native = new T { ID = 101, Name = "native" };
        var added = new T { ID = 202, Name = "added" };
        set.dataArray = new[] { native, added };
        var warnings = new List<string>();
        Rebuild(set, warnings);
        Assert(ReferenceEquals(set.Select(101), native) && ReferenceEquals(set.Select(202), added), "Native and mod lookups");
        Assert(warnings.Count == 0, "False duplicate warning");
        added.ID = 303;
        Rebuild(set, warnings);
        Assert(!set.Exist(202) && ReferenceEquals(set.Select(303), added), "EditDataAction ID change leaves stale lookup");
        var duplicate = new T { ID = 101, Name = "conflicting-mod-proto" };
        set.dataArray = new[] { native, added, duplicate };
        Rebuild(set, warnings);
        Assert(ReferenceEquals(set.Select(101), duplicate), "Installed last-entry lookup precedence changed");
        Assert(native.ID == 101 && duplicate.ID == 101 && added.ID == 303, "Automatic ID reassignment");
        Assert(warnings.Count == 1 && warnings[0].Contains("native") && warnings[0].Contains("conflicting-mod-proto") && warnings[0].Contains("101"), "Conflict diagnostic lacks context");
        var indicesField = typeof(ProtoSet<T>).GetField("dataIndices", BindingFlags.Instance | BindingFlags.NonPublic);
        var previous = indicesField.GetValue(set);
        set.dataArray = new T[] { native, null };
        bool failed = false;
        try { Rebuild(set, warnings); } catch (TargetInvocationException error) { failed = error.InnerException is InvalidOperationException; }
        Assert(failed && ReferenceEquals(previous, indicesField.GetValue(set)), "Invalid array published partial indices");
        set.dataArray = new T[0];
        Rebuild(set, warnings);
        Assert(!set.Exist(101), "Empty set kept stale index");
        Console.WriteLine("PASS: " + typeof(T).Name + " native/mod lookup, edited ID, duplicate precedence/diagnostic, no ID reassignment, invalid array and empty cache.");
    }
    [MethodImpl(MethodImplOptions.NoInlining)]
    static void Run() { Test<ItemProto>(); Test<RecipeProto>(); Test<TechProto>(); }
    static void Main(string[] args) {
        AppDomain.CurrentDomain.AssemblyResolve += (sender, ev) => {
            string name = new AssemblyName(ev.Name).Name + ".dll";
            foreach (string dir in args) { string p = Path.Combine(dir, name); if (File.Exists(p)) return Assembly.LoadFrom(p); }
            return null;
        };
        try { plugin = Assembly.LoadFrom(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "LDBTool.dll")); Run(); }
        catch (Exception error) { Console.Error.WriteLine(error); Environment.ExitCode = 1; }
    }
}
