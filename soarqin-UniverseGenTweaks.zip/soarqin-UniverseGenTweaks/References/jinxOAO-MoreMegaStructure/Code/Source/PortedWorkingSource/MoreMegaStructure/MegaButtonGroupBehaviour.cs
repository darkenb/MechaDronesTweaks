using System;
using UnityEngine;

namespace MoreMegaStructure;

public class MegaButtonGroupBehaviour
{
	private static bool cleared;

	private static float targetX;

	public static float currentX;

	public static void ShowSetMegaGroup()
	{
		targetX = 0f;
		if (UIRoot.instance?.uiGame?.dysonEditor?.selection != null && !cleared)
		{
			try
			{
				cleared = true;
				UIRoot.instance.uiGame.dysonEditor.selection.ClearAllSelection();
			}
			catch (Exception)
			{
			}
		}
	}

	public static void HideSetMegaGroup()
	{
		targetX = -270f;
		cleared = false;
	}

	public static void SetMegaGroupMove()
	{
		bool flag = false;
		Transform transform = MoreMegaStructure.setMegaGroupObj.transform;
		Vector3 localPosition = transform.localPosition;
		if (MoreMegaStructure.NoUIAnimation.Value)
		{
			if (localPosition.x != targetX)
			{
				currentX = targetX;
				transform.localPosition = new Vector3(currentX, localPosition.y, localPosition.z);
				flag = true;
			}
		}
		else if (targetX > localPosition.x + 0.5f)
		{
			float num = targetX - localPosition.x;
			float num2 = Math.Max(num * 0.2f, 0.5f);
			currentX = localPosition.x + num2;
			transform.localPosition = new Vector3(currentX, localPosition.y, localPosition.z);
			flag = true;
		}
		else if (targetX < localPosition.x - 0.5f)
		{
			float num3 = targetX - localPosition.x;
			float num4 = Math.Min(num3 * 0.2f, -0.5f);
			currentX = localPosition.x + num4;
			transform.localPosition = new Vector3(currentX, localPosition.y, localPosition.z);
			flag = true;
		}
		else if (targetX != localPosition.x)
		{
			currentX = targetX;
			transform.localPosition = new Vector3(currentX, localPosition.y, localPosition.z);
			flag = true;
		}
		if (flag)
		{
			MoreMegaStructure.SetMegaStructureWarningText.text = "鼠标触碰左侧黄条以规划巨构".Translate();
			float a = (-200f - currentX) * 1f / 70f;
			MoreMegaStructure.SetMegaStructureWarningText.color = new Color(1f, 1f, 0.57f, a);
			float num5 = (0f - currentX) * 1f / 270f;
			if (num5 > 1f)
			{
				num5 = 1f;
			}
			MoreMegaStructure.LeftMegaBuildWarning.transform.localScale = new Vector3(num5, 1f, 1f);
		}
	}
}
