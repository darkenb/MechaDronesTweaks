using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;
using xiaoye97;

namespace MoreMegaStructure;

public class StarAssembly
{
	public static List<List<int>> recipeIds = new List<List<int>>();

	public static List<List<double>> weights = new List<List<double>>();

	public static List<List<double>> progress = new List<List<double>>();

	public static List<List<double>> incProgress = new List<List<double>>();

	public static List<int> specProgress = new List<int>();

	public static List<int> curSpecType = new List<int>();

	public static List<int> inProgressSpecType = new List<int>();

	public static List<int> satisfiedSpecType = new List<int>();

	public static List<List<int>> productSpeedRequest = new List<List<int>>();

	public static Dictionary<int, Dictionary<int, int>> productStorage = new Dictionary<int, Dictionary<int, int>>();

	public static Dictionary<int, List<List<int>>> items = new Dictionary<int, List<List<int>>>();

	public static Dictionary<int, List<List<int>>> products = new Dictionary<int, List<List<int>>>();

	public static Dictionary<int, List<List<int>>> itemCounts = new Dictionary<int, List<List<int>>>();

	public static Dictionary<int, List<List<int>>> productCounts = new Dictionary<int, List<List<int>>>();

	public static Dictionary<int, List<int>> timeSpend = new Dictionary<int, List<int>>();

	public static Dictionary<int, Dictionary<int, int>> productStorageInc = new Dictionary<int, Dictionary<int, int>>();

	public static Dictionary<int, List<int>> specBuffLevel = new Dictionary<int, List<int>>();

	public static List<int> currentStarIncs = new List<int>();

	public static int blueBuffByTCFV = 0;

	public static int r002ByTCFV = 0;

	public static int r106ByTCFV = 0;

	public static int r208ByTCFV = 0;

	public static int currentRecipeSlot = 0;

	public static int slotCount = 16;

	public static GameObject GigaFactoryUIObj = null;

	public static GameObject specializeObj = null;

	public static GameObject showHideButtonObj = null;

	public static Text showHideBtnText;

	public static GameObject showHideLimitButtonObj = null;

	public static Text doubleAllBtnText;

	public static Text halveAllBtnText;

	public static List<Image> recipeIcons = new List<Image>();

	public static List<Image> incIcons = new List<Image>();

	public static List<GameObject> recipeSelectTips = new List<GameObject>();

	public static List<Text> produceSpeedTxts = new List<Text>();

	public static List<GameObject> sliderObjs = new List<GameObject>();

	public static List<GameObject> speedTextObjs = new List<GameObject>();

	public static List<GameObject> removeRecipeBtnObjs = new List<GameObject>();

	public static List<GameObject> setLimitObjs = new List<GameObject>();

	public static List<Slider> sliders = new List<Slider>();

	public static List<InputField> limitInputs = new List<InputField>();

	public static List<Text> weightTxts = new List<Text>();

	public static List<Text> storageTxts = new List<Text>();

	public static List<Text> recipePickerTxts = new List<Text>();

	public static List<Text> specializeTitleTxts = new List<Text>();

	public static List<Text> specializeStateTxts = new List<Text>();

	public static List<Text> tipButtonTxts = new List<Text>();

	public static List<UIButton> recipeCircleUIBtns = new List<UIButton>();

	public static Sprite noRecipeSelectedSprit = null;

	public static bool lowUIResolution = false;

	public static bool lockSliderListener = false;

	public static bool showingLimit = false;

	public static int tickEnergyForFullSpeed = 20000;

	public static int matrixTimeSpendRatio = 100;

	public static int recipeType1213TimeSpendRatio = 20;

	public static List<long> speedNeededToUnlockSlot = new List<long>
	{
		0L, 0L, 0L, 0L, 0L, 10L, 20L, 30L, 50L, 100L,
		200L, 500L, 1000L, 5000L, 10000L, 100000L
	};

	public static Color UITextOrange = new Color(1f, 0.705f, 0f, 0.745f);

	public static Color UITextBlue = new Color(0.382f, 0.845f, 1f, 0.784f);

	public static Color UITextGreen = new Color(0.225f, 1f, 0.179f, 0.744f);

	public static Color UITextRed = new Color(1f, 0.12f, 0.12f, 0.744f);

	public static Color UITextGray = new Color(0.5f, 0.5f, 0.5f, 0.5f);

	public static List<int> specializeRequirements = new List<int> { 0, 5, 3, 3, 5, 5 };

	public static int specializeTimeNeed = 36000;

	public static void InitAll()
	{
		InitUI();
		ResetAndInitArchiveData();
	}

	public static void InitUI()
	{
		if (!(GigaFactoryUIObj == null))
		{
			return;
		}
		Transform transform = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy").transform;
		GigaFactoryUIObj = new GameObject("GigaFactory");
		GigaFactoryUIObj.transform.SetParent(transform);
		GigaFactoryUIObj.transform.localScale = new Vector3(1f, 1f, 1f);
		GigaFactoryUIObj.transform.localPosition = new Vector3(300f, -Utils.UIActualHeight + 190, 0f);
		GigaFactoryUIObj.SetActive(value: false);
		GameObject original = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy/layers/buttons-group/buttons/add-button");
		showHideButtonObj = UnityEngine.Object.Instantiate(original, transform);
		showHideButtonObj.SetActive(value: true);
		showHideButtonObj.name = "show-hide";
		showHideButtonObj.transform.localPosition = new Vector3(320f, -Utils.UIActualHeight + 40, 0f);
		showHideButtonObj.GetComponent<RectTransform>().sizeDelta = new Vector2(200f, 24f);
		showHideBtnText = showHideButtonObj.transform.Find("Text").gameObject.GetComponent<Text>();
		showHideBtnText.text = "显示/隐藏星际组装厂配置".Translate();
		Button component = showHideButtonObj.GetComponent<Button>();
		component.interactable = true;
		component.onClick.RemoveAllListeners();
		component.onClick.AddListener(delegate
		{
			ShowHideUI();
		});
		GameObject gameObject = UnityEngine.Object.Instantiate(original, GigaFactoryUIObj.transform);
		gameObject.SetActive(value: true);
		gameObject.name = "double-all";
		gameObject.transform.localPosition = new Vector3(240f, -150f, 0f);
		gameObject.GetComponent<RectTransform>().sizeDelta = new Vector2(150f, 24f);
		doubleAllBtnText = gameObject.transform.Find("Text").gameObject.GetComponent<Text>();
		doubleAllBtnText.text = "加倍所有速度设置".Translate();
		Button component2 = gameObject.GetComponent<Button>();
		component2.interactable = true;
		component2.onClick.RemoveAllListeners();
		component2.onClick.AddListener(delegate
		{
			DoubleAllSpeedRequest();
		});
		GameObject gameObject2 = UnityEngine.Object.Instantiate(original, GigaFactoryUIObj.transform);
		gameObject2.SetActive(value: true);
		gameObject2.name = "halve-all";
		gameObject2.transform.localPosition = new Vector3(400f, -150f, 0f);
		gameObject2.GetComponent<RectTransform>().sizeDelta = new Vector2(150f, 24f);
		halveAllBtnText = gameObject2.transform.Find("Text").gameObject.GetComponent<Text>();
		halveAllBtnText.text = "减半所有速度设置".Translate();
		Button component3 = gameObject2.GetComponent<Button>();
		component3.interactable = true;
		component3.onClick.RemoveAllListeners();
		component3.onClick.AddListener(delegate
		{
			HalveAllSpeedRequest();
		});
		GameObject gameObject3 = new GameObject("back");
		gameObject3.transform.parent = GigaFactoryUIObj.transform;
		gameObject3.transform.localScale = new Vector3(1f, 1f, 1f);
		gameObject3.transform.localPosition = new Vector3(660f, 180f, 0f);
		gameObject3.AddComponent<Image>();
		gameObject3.GetComponent<Image>().color = new Color(0.106f, 0.18f, 0.228f, 0.88f);
		gameObject3.GetComponent<RectTransform>().sizeDelta = new Vector2(1280f, 650f);
		GameObject original2 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Assembler Window/offwork");
		GameObject original3 = GameObject.Find("UI Root/Overlay Canvas/In Game/FPS Stats/priority-bar/slider-2");
		GameObject gameObject4 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Station Window/storage-box-0(Clone)/storage-icon/inc-3");
		if (gameObject4 == null)
		{
			gameObject4 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Station Window/Station-scroll(Clone)/Viewport/pane/storage-box-0(Clone)/storage-icon/inc-3");
		}
		GameObject gameObject5 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Assembler Window/produce/circle-back/stop-btn");
		GameObject original4 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Assembler Window/produce/circle-back/stop-btn/x");
		GameObject gameObject6 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Belt Window/number-input");
		if (gameObject6 == null)
		{
			Utils.Log("Error when init oriInputField because some other mods has changed the Blueprint Browser UI. Please check if you've install the BluePrintTweaks and then contant jinxOAO.");
		}
		GameObject gameObject7 = UnityEngine.Object.Instantiate(gameObject6);
		gameObject7.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
		gameObject7.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
		if (gameObject7.GetComponent<UIButton>().transitions.Length != 0)
		{
			gameObject7.GetComponent<UIButton>().transitions[0].normalColor = new Color(0f, 0f, 0f, 0.4f);
		}
		gameObject7.GetComponent<Image>().sprite = Resources.Load<Sprite>("ui/textures/sprites/sci-fi/litter-panel-cc");
		gameObject7.GetComponent<InputField>().contentType = InputField.ContentType.Standard;
		gameObject7.GetComponent<InputField>().characterValidation = InputField.CharacterValidation.None;
		gameObject7.transform.Find("number-text").GetComponent<Text>().alignment = TextAnchor.MiddleLeft;
		gameObject7.transform.Find("number-text").GetComponent<Text>().color = new Color(1f, 1f, 1f, 0.5f);
		gameObject7.transform.Find("number-text").GetComponent<RectTransform>().anchorMax = new Vector2(0.92f, 1f);
		gameObject7.transform.Find("number-text").GetComponent<RectTransform>().anchorMin = new Vector2(0.08f, 0f);
		for (int num = 0; num < slotCount; num++)
		{
			GameObject gameObject8 = new GameObject("slot" + num);
			gameObject8.transform.SetParent(GigaFactoryUIObj.transform);
			gameObject8.transform.localScale = new Vector3(1f, 1f, 1f);
			gameObject8.transform.localPosition = new Vector3(num / 8 * 400, num % 8 * 80, 0f);
			GameObject gameObject9 = UnityEngine.Object.Instantiate(original2, gameObject8.transform);
			gameObject9.SetActive(value: true);
			gameObject9.transform.Find("tip-group/tip-text/paste-button").gameObject.SetActive(value: false);
			recipePickerTxts.Add(gameObject9.transform.Find("tip-group/tip-text").gameObject.GetComponent<Text>());
			GameObject gameObject10 = gameObject9.transform.Find("circle").gameObject;
			recipeIcons.Add(gameObject10.GetComponent<Image>());
			noRecipeSelectedSprit = gameObject10.GetComponent<Image>().sprite;
			recipeSelectTips.Add(gameObject9.transform.Find("tip-group").gameObject);
			Button component4 = gameObject10.GetComponent<Button>();
			component4.onClick.RemoveAllListeners();
			UIButton component5 = gameObject10.GetComponent<UIButton>();
			component5.tips.corner = 3;
			if (num == 0)
			{
				component5.tips.itemId = 9500;
			}
			recipeCircleUIBtns.Add(component5);
			GameObject gameObject11 = UnityEngine.Object.Instantiate(gameObject10, gameObject9.transform);
			gameObject11.name = "stop-btn";
			gameObject11.SetActive(value: true);
			gameObject11.transform.localPosition = new Vector3(78f, -28f, 0f);
			gameObject11.GetComponent<RectTransform>().sizeDelta = new Vector2(18f, 18f);
			gameObject11.GetComponent<Image>().sprite = gameObject5.GetComponent<Image>().sprite;
			gameObject11.GetComponent<Image>().material = gameObject5.GetComponent<Image>().material;
			gameObject11.GetComponent<Image>().color = new Color(0.988f, 0.588f, 0.368f, 0.141f);
			GameObject gameObject12 = UnityEngine.Object.Instantiate(original4, gameObject11.transform);
			Button component6 = gameObject11.GetComponent<Button>();
			component6.onClick.RemoveAllListeners();
			removeRecipeBtnObjs.Add(gameObject11);
			UIButton component7 = gameObject11.GetComponent<UIButton>();
			for (int num2 = 0; num2 < component7.transitions.Length; num2++)
			{
				component7.transitions[num2].normalColor = new Color(0.988f, 0.588f, 0.368f, 0.141f);
				component7.transitions[num2].pressedColor = new Color(0.988f, 0.588f, 0.368f, 0.041f);
				component7.transitions[num2].mouseoverColor = new Color(0.988f, 0.588f, 0.368f, 0.201f);
				component7.transitions[num2].mouseoverSize = 1.1f;
			}
			GameObject gameObject13 = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Assembler Window/produce/circle-back/cnt-text"), gameObject8.transform);
			gameObject13.transform.localPosition = new Vector3(110f, -136f);
			produceSpeedTxts.Add(gameObject13.GetComponent<Text>());
			gameObject13.GetComponent<Text>().text = "理论最大速度".Translate() + " --/min";
			gameObject13.GetComponent<Text>().alignment = TextAnchor.LowerLeft;
			gameObject13.GetComponent<Text>().supportRichText = true;
			gameObject13.GetComponent<Text>().color = new Color(0.992f, 0.588f, 0.3686f, 0.8384f);
			gameObject13.GetComponent<Text>().lineSpacing = 0.7f;
			speedTextObjs.Add(gameObject13);
			GameObject gameObject14 = UnityEngine.Object.Instantiate(gameObject4, gameObject8.transform);
			gameObject14.transform.localPosition = new Vector3(60f, -65f);
			gameObject14.transform.localScale = new Vector3(1f, 1f, 1f);
			gameObject14.SetActive(value: false);
			gameObject14.GetComponent<Image>().enabled = true;
			incIcons.Add(gameObject14.GetComponent<Image>());
			GameObject gameObject15 = UnityEngine.Object.Instantiate(original3, gameObject8.transform);
			gameObject15.GetComponent<RectTransform>().sizeDelta = new Vector2(100f, 20f);
			gameObject15.transform.localPosition = new Vector3(150f, -110f, 0f);
			gameObject15.SetActive(value: false);
			sliderObjs.Add(gameObject15);
			Slider component8 = gameObject15.GetComponent<Slider>();
			component8.minValue = 0f;
			component8.maxValue = 100f;
			component8.value = 0f;
			component8.onValueChanged.RemoveAllListeners();
			sliders.Add(component8);
			GameObject gameObject16 = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Assembler Window/produce/circle-back/cnt-text"), gameObject15.transform);
			gameObject16.transform.localPosition = new Vector3(30f, 12f, 0f);
			weightTxts.Add(gameObject16.GetComponent<Text>());
			gameObject16.GetComponent<Text>().fontSize = 16;
			gameObject16.GetComponent<Text>().text = "";
			gameObject16.GetComponent<Text>().alignment = TextAnchor.LowerLeft;
			GameObject gameObject17 = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Assembler Window/produce/circle-back/cnt-text"), gameObject8.transform);
			gameObject17.transform.localPosition = new Vector3(330f, -122f, 0f);
			storageTxts.Add(gameObject17.GetComponent<Text>());
			gameObject17.GetComponent<Text>().fontSize = 16;
			gameObject17.GetComponent<Text>().lineSpacing = 0.95f;
			gameObject17.GetComponent<Text>().text = "";
			gameObject17.GetComponent<Text>().alignment = TextAnchor.LowerLeft;
			GameObject gameObject18 = new GameObject();
			gameObject18.transform.SetParent(gameObject8.transform);
			gameObject18.name = "speed-limit";
			gameObject18.transform.localPosition = new Vector3(120f, -98f, 0f);
			gameObject18.transform.localScale = new Vector3(1f, 1f, 1f);
			setLimitObjs.Add(gameObject18);
			GameObject gameObject19 = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Assembler Window/produce/circle-back/cnt-text"), gameObject18.transform);
			gameObject19.name = "title";
			gameObject19.transform.localPosition = new Vector3(60f, 0f, 0f);
			gameObject19.GetComponent<Text>().text = "最大生产速度限制".Translate();
			gameObject19.GetComponent<Text>().fontSize = 16;
			gameObject19.GetComponent<Text>().alignment = TextAnchor.LowerLeft;
			GameObject gameObject20 = UnityEngine.Object.Instantiate(gameObject7, gameObject18.transform);
			gameObject20.name = "value-input";
			gameObject20.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
			gameObject20.transform.localPosition = new Vector3(30f, 0f, 0f);
			gameObject20.GetComponent<UIButton>().tips.tipTitle = "最大生产速度限制题目".Translate();
			gameObject20.GetComponent<UIButton>().tips.tipText = "最大生产速度限制描述".Translate();
			gameObject20.GetComponent<UIButton>().tips.width = 300;
			gameObject20.GetComponent<UIButton>().tips.offset = new Vector2(450f, 130f);
			gameObject20.GetComponent<RectTransform>().sizeDelta = new Vector2(70f, 20f);
			gameObject20.GetComponent<InputField>().contentType = InputField.ContentType.IntegerNumber;
			gameObject20.GetComponent<InputField>().textComponent.fontSize = 12;
			gameObject20.GetComponent<InputField>().characterLimit = 9;
			gameObject20.GetComponent<InputField>().onEndEdit.RemoveAllListeners();
			string istr = num.ToString();
			gameObject20.GetComponent<InputField>().onEndEdit.AddListener(delegate(string x)
			{
				SetProductSpeedRequest(Convert.ToInt32(istr), x);
			});
			limitInputs.Add(gameObject20.GetComponent<InputField>());
			gameObject18.SetActive(value: false);
			GameObject gameObject21 = UnityEngine.Object.Instantiate(gameObject10, gameObject18.transform);
			gameObject21.name = "normalizeSpeed1";
			gameObject21.transform.localPosition = new Vector3(119f, -10f, 0f);
			gameObject21.GetComponent<RectTransform>().sizeDelta = new Vector2(20f, 20f);
			gameObject21.GetComponent<Image>().sprite = Resources.Load<Sprite>("ui/textures/sprites/icons/speed-icon");
			gameObject21.GetComponent<Button>().onClick.RemoveAllListeners();
			int slotNum = num;
			gameObject21.GetComponent<Button>().onClick.AddListener(delegate
			{
				NormalizeSetValue(slotNum, forceFullInc: false);
			});
			gameObject21.GetComponent<UIButton>().transitions[0].mouseoverSize = 1f;
			gameObject21.GetComponent<UIButton>().tips.tipTitle = "组装厂速度规范化1标题".Translate();
			gameObject21.GetComponent<UIButton>().tips.tipText = "组装厂速度规范化1描述".Translate();
			gameObject21.GetComponent<UIButton>().tips.corner = 9;
			gameObject21.GetComponent<UIButton>().tips.width = 355;
			GameObject gameObject22 = UnityEngine.Object.Instantiate(gameObject10, gameObject18.transform);
			gameObject22.name = "normalizeSpeed2";
			gameObject22.transform.localPosition = new Vector3(145f, -10f, 0f);
			gameObject22.GetComponent<RectTransform>().sizeDelta = new Vector2(20f, 20f);
			gameObject22.GetComponent<Image>().sprite = Resources.Load<Sprite>("ui/textures/sprites/icons/speed-icon");
			gameObject22.GetComponent<Button>().onClick.RemoveAllListeners();
			gameObject22.GetComponent<Button>().onClick.AddListener(delegate
			{
				NormalizeSetValue(slotNum, forceFullInc: true);
			});
			gameObject22.GetComponent<UIButton>().transitions[0].mouseoverSize = 1f;
			gameObject22.GetComponent<UIButton>().tips.tipTitle = "组装厂速度规范化2标题".Translate();
			gameObject22.GetComponent<UIButton>().tips.tipText = "组装厂速度规范化2描述".Translate();
			gameObject22.GetComponent<UIButton>().tips.corner = 9;
			gameObject22.GetComponent<UIButton>().tips.width = 355;
			GameObject gameObject23 = new GameObject("inc-icon");
			gameObject23.transform.SetParent(gameObject22.transform, worldPositionStays: false);
			gameObject23.transform.localPosition = new Vector3(0f, -9f, 0f);
			gameObject23.transform.localScale = Vector3.one;
			Image image = gameObject23.AddComponent<Image>();
			image.sprite = Resources.Load<Sprite>("entities/models/cargo/inc-4");
			gameObject23.GetComponent<RectTransform>().sizeDelta = new Vector2(12f, 12f);
			gameObject22.GetComponent<UIButton>().transitions = gameObject22.GetComponent<UIButton>().transitions.AddItem(MethedEx.Copy<UIButton.Transition>(gameObject22.GetComponent<UIButton>().transitions[0])).ToArray();
			gameObject22.GetComponent<UIButton>().transitions[1].target = image;
			switch (num)
			{
			case 0:
				component8.interactable = false;
				break;
			case 1:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(1);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(1);
				});
				break;
			case 2:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(2);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(2);
				});
				break;
			case 3:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(3);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(3);
				});
				break;
			case 4:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(4);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(4);
				});
				break;
			case 5:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(5);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(5);
				});
				break;
			case 6:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(6);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(6);
				});
				break;
			case 7:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(7);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(7);
				});
				break;
			case 8:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(8);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(8);
				});
				break;
			case 9:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(9);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(9);
				});
				break;
			case 10:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(10);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(10);
				});
				break;
			case 11:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(11);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(11);
				});
				break;
			case 12:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(12);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(12);
				});
				break;
			case 13:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(13);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(13);
				});
				break;
			case 14:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(14);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(14);
				});
				break;
			case 15:
				component4.onClick.AddListener(delegate
				{
					OnRecipeSelectClick(15);
				});
				component6.onClick.AddListener(delegate
				{
					OnRecipeRemoveClick(15);
				});
				break;
			}
		}
		specializeObj = new GameObject("Specialize");
		specializeObj.transform.SetParent(transform);
		specializeObj.transform.localScale = new Vector3(1f, 1f, 1f);
		specializeObj.transform.localPosition = new Vector3(1200f, -Utils.UIActualHeight + 190, 0f);
		if (DSPGame.globalOption.resolution.width * Utils.UIActualHeight / DSPGame.globalOption.resolution.height < 1920)
		{
			lowUIResolution = true;
			specializeObj.transform.localPosition = new Vector3(400f, -Utils.UIActualHeight + 190, 0f);
		}
		specializeObj.SetActive(value: false);
		GameObject gameObject24 = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Assembler Window/produce/circle-back/cnt-text"), specializeObj.transform);
		gameObject24.name = "mainTitle";
		gameObject24.transform.localPosition = new Vector3(0f, 40f, 0f);
		gameObject24.GetComponent<Text>().fontSize = 20;
		gameObject24.GetComponent<Text>().lineSpacing = 0.95f;
		gameObject24.GetComponent<Text>().text = "星际组装厂特化".Translate();
		gameObject24.GetComponent<Text>().alignment = TextAnchor.LowerLeft;
		specializeTitleTxts.Add(gameObject24.GetComponent<Text>());
		specializeStateTxts.Add(gameObject24.GetComponent<Text>());
		for (int num3 = 0; num3 <= 5; num3++)
		{
			if (num3 > 0)
			{
				GameObject gameObject25 = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Assembler Window/produce/circle-back/cnt-text"), specializeObj.transform);
				gameObject25.name = $"specTitle{num3}";
				gameObject25.transform.localPosition = new Vector3(0f, 30 - 30 * num3, 0f);
				gameObject25.GetComponent<Text>().fontSize = 16;
				gameObject25.GetComponent<Text>().lineSpacing = 0.95f;
				gameObject25.GetComponent<Text>().text = $"星际组装厂特化名称{num3}".Translate();
				gameObject25.GetComponent<Text>().alignment = TextAnchor.MiddleLeft;
				gameObject25.GetComponent<Text>().color = new Color(1f, 0.705f, 0f, 0.765f);
				specializeTitleTxts.Add(gameObject25.GetComponent<Text>());
				GameObject gameObject26 = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Assembler Window/produce/circle-back/cnt-text"), specializeObj.transform);
				gameObject26.name = $"specState{num3}";
				gameObject26.transform.localPosition = new Vector3(260f, 30 - 30 * num3, 0f);
				gameObject26.GetComponent<Text>().fontSize = 16;
				gameObject26.GetComponent<Text>().lineSpacing = 0.95f;
				gameObject26.GetComponent<Text>().text = "";
				gameObject26.GetComponent<Text>().alignment = TextAnchor.MiddleCenter;
				specializeStateTxts.Add(gameObject26.GetComponent<Text>());
			}
			GameObject gameObject27 = UnityEngine.Object.Instantiate(original, specializeObj.transform);
			gameObject27.SetActive(value: true);
			gameObject27.name = $"tip{num3}";
			gameObject27.transform.localPosition = new Vector3(-60f, 50 - 30 * num3, 0f);
			if (num3 == 0)
			{
				gameObject27.transform.localPosition = new Vector3(-60f, 65f, 0f);
			}
			gameObject27.GetComponent<RectTransform>().sizeDelta = new Vector2(20f, 20f);
			tipButtonTxts.Add(gameObject27.transform.Find("Text").gameObject.GetComponent<Text>());
			gameObject27.transform.Find("Text").gameObject.GetComponent<Text>().text = "?";
			gameObject27.transform.Find("Text").gameObject.GetComponent<Text>().verticalOverflow = VerticalWrapMode.Overflow;
			Button component9 = gameObject27.GetComponent<Button>();
			component9.interactable = true;
			component9.onClick.RemoveAllListeners();
			gameObject27.GetComponent<UIButton>().tips.tipTitle = $"特化{num3}介绍标题".Translate();
			gameObject27.GetComponent<UIButton>().tips.tipText = $"特化{num3}介绍内容".Translate();
			gameObject27.GetComponent<UIButton>().tips.delay = 0.1f;
			gameObject27.GetComponent<UIButton>().tips.width = ((num3 == 0) ? 300 : 280);
			gameObject27.GetComponent<UIButton>().tips.corner = 7;
		}
	}

	public static void ResetAndInitArchiveData()
	{
		recipeIds = new List<List<int>>();
		weights = new List<List<double>>();
		progress = new List<List<double>>();
		incProgress = new List<List<double>>();
		productSpeedRequest = new List<List<int>>();
		specProgress = new List<int>();
		curSpecType = new List<int>();
		inProgressSpecType = new List<int>();
		satisfiedSpecType = new List<int>();
		for (int i = 0; i < 1200; i++)
		{
			recipeIds.Add(new List<int> { 0 });
			weights.Add(new List<double> { 1.0 });
			progress.Add(new List<double> { 0.0 });
			incProgress.Add(new List<double> { 0.0 });
			productSpeedRequest.Add(new List<int> { 0 });
			for (int j = 1; j < slotCount; j++)
			{
				recipeIds[i].Add(0);
				weights[i].Add(0.0);
				progress[i].Add(0.0);
				incProgress[i].Add(0.0);
				productSpeedRequest[i].Add(0);
			}
			specProgress.Add(0);
			curSpecType.Add(0);
			inProgressSpecType.Add(0);
			satisfiedSpecType.Add(0);
		}
	}

	public static void ResetDataAfterStarIndex100()
	{
		for (int i = 100; i < 1200; i++)
		{
			for (int j = 0; j < slotCount; j++)
			{
				recipeIds[i][j] = 0;
				weights[i][j] = ((j == 0) ? 1 : 0);
				progress[i][j] = 0.0;
				incProgress[i][j] = 0.0;
				productSpeedRequest[i][j] = 0;
			}
		}
	}

	public static void ResetArchiveDataByStarIndex(int starIndex)
	{
		recipeIds[starIndex] = new List<int> { 0 };
		weights[starIndex] = new List<double> { 1.0 };
		progress[starIndex] = new List<double> { 0.0 };
		incProgress[starIndex] = new List<double> { 0.0 };
		for (int i = 1; i < slotCount; i++)
		{
			recipeIds[starIndex].Add(0);
			weights[starIndex].Add(0.0);
			progress[starIndex].Add(0.0);
			incProgress[starIndex].Add(0.0);
		}
		specProgress[starIndex] = 0;
		curSpecType[starIndex] = 0;
		inProgressSpecType[starIndex] = 0;
		satisfiedSpecType[starIndex] = 0;
	}

	public static void InitInGameData()
	{
		int num = (MoreMegaStructure.Support1000Stars.Value ? 1200 : 100);
		for (int i = 0; i < num; i++)
		{
			if (MoreMegaStructure.StarMegaStructureType[i] == 4)
			{
				ResetInGameDataByStarIndex(i);
			}
		}
		currentRecipeSlot = 0;
		currentStarIncs = new List<int>();
		for (int j = 0; j < slotCount; j++)
		{
			currentStarIncs.Add(0);
		}
		lockSliderListener = false;
		blueBuffByTCFV = 0;
		r002ByTCFV = 0;
		r106ByTCFV = 0;
		r208ByTCFV = 0;
	}

	public static void CalcInGameData()
	{
		int num = (MoreMegaStructure.Support1000Stars.Value ? 1200 : 100);
		for (int i = 0; i < num; i++)
		{
			if (MoreMegaStructure.StarMegaStructureType[i] == 4)
			{
				CalcInGameDataByStarIndex(i);
			}
		}
		currentRecipeSlot = 0;
		currentStarIncs = new List<int>();
		for (int j = 0; j < slotCount; j++)
		{
			currentStarIncs.Add(0);
		}
		lockSliderListener = false;
		blueBuffByTCFV = 0;
		r002ByTCFV = 0;
		r106ByTCFV = 0;
		r208ByTCFV = 0;
	}

	public static void ForceResetIncDataCache()
	{
		currentStarIncs.Clear();
		for (int i = 0; i < slotCount; i++)
		{
			currentStarIncs.Add(0);
		}
	}

	public static void ResetInGameDataByStarIndex(int starIndex)
	{
		productStorage[starIndex] = new Dictionary<int, int>();
		productStorageInc[starIndex] = new Dictionary<int, int>();
		productStorage[starIndex][9500] = 0;
		CalcInGameDataByStarIndex(starIndex);
	}

	public static void CalcInGameDataByStarIndex(int starIndex)
	{
		items[starIndex] = new List<List<int>>();
		products[starIndex] = new List<List<int>>();
		itemCounts[starIndex] = new List<List<int>>();
		productCounts[starIndex] = new List<List<int>>();
		timeSpend[starIndex] = new List<int>();
		specBuffLevel[starIndex] = new List<int>();
		for (int i = 0; i < slotCount; i++)
		{
			items[starIndex].Add(new List<int>());
			itemCounts[starIndex].Add(new List<int>());
			products[starIndex].Add(new List<int>());
			productCounts[starIndex].Add(new List<int>());
			timeSpend[starIndex].Add(1);
			specBuffLevel[starIndex].Add(0);
		}
		for (int j = 0; j < slotCount; j++)
		{
			if (recipeIds[starIndex][j] <= 0)
			{
				continue;
			}
			RecipeProto recipeProto = LDB.recipes.Select(recipeIds[starIndex][j]);
			for (int k = 0; k < recipeProto.Items.Length; k++)
			{
				items[starIndex][j].Add(recipeProto.Items[k]);
				itemCounts[starIndex][j].Add(recipeProto.ItemCounts[k]);
			}
			for (int l = 0; l < recipeProto.Results.Length; l++)
			{
				products[starIndex][j].Add(recipeProto.Results[l]);
				productCounts[starIndex][j].Add(recipeProto.ResultCounts[l]);
				if (!productStorage[starIndex].ContainsKey(recipeProto.Results[l]))
				{
					productStorage[starIndex].Add(recipeProto.Results[l], 0);
				}
			}
			timeSpend[starIndex][j] = Math.Max(1, recipeProto.TimeSpend);
			if (recipeProto.Results[0] >= 6001 && recipeProto.Results[0] <= 6006)
			{
				timeSpend[starIndex][j] *= matrixTimeSpendRatio;
			}
		}
		if (starIndex < GameMain.galaxy.starCount)
		{
			GameData data = GameMain.data;
			if (((data != null) ? data.dysonSpheres[starIndex] : null) != null)
			{
				CheckSpecializeState(GameMain.data.dysonSpheres[starIndex], forceCheckAllSlot: true);
			}
		}
	}

	public static void InternalUpdate(DysonSphere __instance)
	{
		if (GameMain.instance.timei % 60 == 0)
		{
			CheckSpecializeState(__instance);
		}
		int index = __instance.starData.index;
		long num = __instance.energyGenCurrentTick - __instance.energyReqCurrentTick;
		int ori = (int)(Math.Log10(num / tickEnergyForFullSpeed / 100) * 4.0);
		ori = Utils.Limit(ori, 1, 12);
		UpdateSpecializeState(__instance, ori);
		int[] array = null;
		int[] consumeRegister = null;
		int num2 = CalcMaxSlotIndex(__instance) + 1;
		if (UIStatisticsPatcher.enabled)
		{
			FactoryProductionStat iAFactoryStat = UIStatisticsPatcher.GetIAFactoryStat(index);
			if (iAFactoryStat != null)
			{
				array = iAFactoryStat.productRegister;
				consumeRegister = iAFactoryStat.consumeRegister;
			}
		}
		else
		{
			for (int i = 0; i < GameMain.galaxy.stars[index].planetCount; i++)
			{
				PlanetData planetData = GameMain.galaxy.stars[index].planets[i];
				if (planetData == null)
				{
					continue;
				}
				PlanetFactory factory = planetData.factory;
				if (factory != null)
				{
					FactoryProductionStat factoryProductionStat = GameMain.statistics.production.factoryStatPool[factory.index];
					array = factoryProductionStat.productRegister;
					consumeRegister = factoryProductionStat.consumeRegister;
					if (array != null && consumeRegister != null)
					{
						break;
					}
				}
			}
		}
		AutoSprayInStation(index, ref consumeRegister);
		double num3 = 0.0;
		bool flag = true;
		long num4 = GameMain.data.dysonSpheres[index].energyGenCurrentTick - GameMain.data.dysonSpheres[index].energyReqCurrentTick;
		for (int j = 1; j < num2; j++)
		{
			if (recipeIds[index][j] <= 0)
			{
				continue;
			}
			if (flag && weights[index][j] > 0.0)
			{
				flag = false;
			}
			bool flag2 = false;
			bool flag3 = false;
			for (int k = 0; k < products[index][j].Count; k++)
			{
				int key = products[index][j][k];
				if (!productStorage[index].ContainsKey(key))
				{
					flag2 = true;
					break;
				}
				if (productStorage[index][key] < 10000 && productCounts[index][j][k] > 0)
				{
					flag2 = true;
					break;
				}
			}
			if (timeSpend[index][j] > 0)
			{
				if (flag2)
				{
					double redundantEnergy;
					double consumeProduceSpeedRatio = GetConsumeProduceSpeedRatio(index, j, out redundantEnergy);
					num3 += redundantEnergy;
					progress[index][j] += consumeProduceSpeedRatio;
				}
				else
				{
					double redundantEnergy2;
					double consumeProduceSpeedRatio2 = GetConsumeProduceSpeedRatio(index, j, out redundantEnergy2);
					num3 += redundantEnergy2;
				}
			}
		}
		if (flag)
		{
			weights[index][0] = 1.0;
		}
		else if (num4 > 0)
		{
			weights[index][0] = num3 / (double)num4;
		}
		else
		{
			weights[index][0] = 0.0;
		}
		progress[index][0] += GetConsumeProduceSpeedRatio(index, 0, out var _);
		for (int l = 1; l < num2; l++)
		{
			if (progress[index][l] >= 1.0)
			{
				if (recipeIds[index][l] > 0)
				{
					int num5 = recipeIds[index][l];
					int num6 = (int)progress[index][l];
					int num7 = 10;
					if (MoreMegaStructure.NoWasteResources.Value)
					{
						for (int m = 0; m < items[index][l].Count; m++)
						{
							if (itemCounts[index][l][m] > 0)
							{
								int inc = 0;
								int num8 = TakeItemForFactory(index, items[index][l][m], num6 * itemCounts[index][l][m], itemCounts[index][l][m], out inc, consume: false);
								if (num8 < itemCounts[index][l][m])
								{
									num6 = 0;
									num7 = 0;
									break;
								}
								num6 = Math.Min(num6, num8 / itemCounts[index][l][m]);
								num7 = Math.Min(num7, inc / num8);
							}
						}
					}
					for (int n = 0; n < items[index][l].Count; n++)
					{
						if (num6 <= 0)
						{
							break;
						}
						if (itemCounts[index][l][n] <= 0)
						{
							continue;
						}
						int inc2 = 0;
						int num9 = TakeItemForFactory(index, items[index][l][n], num6 * itemCounts[index][l][n], itemCounts[index][l][n], out inc2, consume: true);
						if (consumeRegister != null)
						{
							int[] array2 = consumeRegister;
							lock (array2)
							{
								consumeRegister[items[index][l][n]] += num9;
							}
						}
						if (num9 >= itemCounts[index][l][n])
						{
							num6 = Math.Min(num6, num9 / itemCounts[index][l][n]);
							num7 = Math.Min(num7, inc2 / num9);
							continue;
						}
						num6 = 0;
						num7 = 0;
						break;
					}
					if (num6 > 0)
					{
						for (int num10 = 0; num10 < products[index][l].Count; num10++)
						{
							float num11 = num6;
							if (r208ByTCFV > 0 && num5 == 74)
							{
								if (products[index][l][num10] == 1120)
								{
									num11 = 0f;
								}
								else if (products[index][l][num10] == 1122)
								{
									num11 = 1.5f * (float)num6;
								}
							}
							productStorage[index][products[index][l][num10]] += (int)(num11 * (float)productCounts[index][l][num10]);
							if (productStorage[index][products[index][l][num10]] > 99999)
							{
								productStorage[index][products[index][l][num10]] = 99999;
							}
							if ((curSpecType[index] == 2 && specBuffLevel[index][l] > 0) || r002ByTCFV > 0)
							{
								if (!productStorageInc.ContainsKey(index))
								{
									productStorageInc.Add(index, new Dictionary<int, int>());
								}
								if (!productStorageInc[index].ContainsKey(products[index][l][num10]))
								{
									productStorageInc[index].Add(products[index][l][num10], (int)(num11 * (float)productCounts[index][l][num10]) * 4);
								}
								else
								{
									productStorageInc[index][products[index][l][num10]] += (int)(num11 * (float)productCounts[index][l][num10]) * 4;
								}
								if (productStorageInc[index][products[index][l][num10]] > 4 * productStorage[index][products[index][l][num10]])
								{
									productStorageInc[index][products[index][l][num10]] = 4 * productStorage[index][products[index][l][num10]];
								}
							}
							if (array != null)
							{
								int[] array3 = array;
								lock (array3)
								{
									array[products[index][l][num10]] += (int)(num11 * (float)productCounts[index][l][num10]);
								}
							}
						}
						int num12 = num6;
						if (incProgress[index][l] >= 0.0 || specBuffLevel[index][l] > 0)
						{
							incProgress[index][l] += (float)num6 * GetFullIncMilli(index, l, num7);
							if (MoreMegaStructure.curStar != null && index == MoreMegaStructure.curStar.index)
							{
								currentStarIncs[l] = num7;
								if (curSpecType[index] == 2 && specBuffLevel[index][l] > 0)
								{
									currentStarIncs[l] = 4;
								}
							}
							if (incProgress[index][l] >= 1.0)
							{
								int num13 = (int)incProgress[index][l];
								for (int num14 = 0; num14 < products[index][l].Count; num14++)
								{
									float num15 = num13;
									if (r208ByTCFV > 0 && num5 == 74)
									{
										if (products[index][l][num14] == 1120)
										{
											num15 = 0f;
										}
										else if (products[index][l][num14] == 1122)
										{
											num15 = 1.5f * (float)num13;
										}
									}
									productStorage[index][products[index][l][num14]] += (int)(num15 * (float)productCounts[index][l][num14]);
									if (productStorage[index][products[index][l][num14]] > 99999)
									{
										productStorage[index][products[index][l][num14]] = 99999;
									}
									if ((curSpecType[index] == 2 && specBuffLevel[index][l] > 0) || r002ByTCFV > 0)
									{
										if (!productStorageInc.ContainsKey(index))
										{
											productStorageInc.Add(index, new Dictionary<int, int>());
										}
										if (!productStorageInc[index].ContainsKey(products[index][l][num14]))
										{
											productStorageInc[index].Add(products[index][l][num14], (int)(num15 * (float)productCounts[index][l][num14]) * 4);
										}
										else
										{
											productStorageInc[index][products[index][l][num14]] += (int)(num15 * (float)productCounts[index][l][num14]) * 4;
										}
										if (productStorageInc[index][products[index][l][num14]] > 4 * productStorage[index][products[index][l][num14]])
										{
											productStorageInc[index][products[index][l][num14]] = 4 * productStorage[index][products[index][l][num14]];
										}
									}
									if (array != null)
									{
										int[] array4 = array;
										lock (array4)
										{
											array[products[index][l][num14]] += num13 * productCounts[index][l][num14];
										}
									}
								}
								incProgress[index][l] -= (int)incProgress[index][l];
								if (incProgress[index][l] < 0.0)
								{
									incProgress[index][l] = 0.0;
								}
								num12 += num13;
							}
						}
						if (blueBuffByTCFV > 0 && itemCounts[index][l].Count > 1 && products[index][l][0] != 1803 && products[index][l][0] != 6006)
						{
							int num16 = num12 * productCounts[index][l][0];
							int num17 = num6 * itemCounts[index][l][0];
							int num18 = num16 - num17;
							int num19 = items[index][l][0];
							if (!productStorage[index].ContainsKey(num19))
							{
								productStorage[index].Add(num19, num16);
							}
							else
							{
								productStorage[index][num19] += num16;
							}
							if (productStorage[index][num19] > 99999)
							{
								productStorage[index][num19] = 99999;
							}
							if (num7 > 0)
							{
								if (!productStorageInc[index].ContainsKey(num19))
								{
									productStorageInc[index][num19] = num16 * num7;
								}
								else
								{
									productStorageInc[index][num19] += num16 * num7;
								}
								if (productStorageInc[index][num19] > 4 * productStorage[index][num19])
								{
									productStorageInc[index][num19] = 4 * productStorage[index][num19];
								}
							}
							if (num18 <= 0 && consumeRegister != null)
							{
								int[] array5 = consumeRegister;
								lock (array5)
								{
									consumeRegister[num19] -= num16;
								}
							}
							else if (consumeRegister != null && array != null)
							{
								int[] array6 = consumeRegister;
								lock (array6)
								{
									consumeRegister[num19] -= num17;
								}
								int[] array7 = array;
								lock (array7)
								{
									array[num19] += num18;
								}
							}
						}
						if (r106ByTCFV > 0)
						{
							int num20 = products[index][l][0];
							int num21 = -1;
							if (num20 >= 9488 && num20 <= 9490)
							{
								num21 = 2;
							}
							else if (num20 == 9491 || num20 == 9492 || num20 == 9510 || num20 == 1503)
							{
								num21 = 1;
							}
							if (num21 > 0)
							{
								int num22 = 1802;
								int num23 = num12 * 2;
								int num24 = 0;
								if (!productStorage[index].ContainsKey(num22))
								{
									productStorage[index].Add(num22, num23);
								}
								else
								{
									productStorage[index][num22] += num23;
								}
								if (productStorage[index][num22] > 99999)
								{
									productStorage[index][num22] = 99999;
								}
								if (num7 > 0)
								{
									if (!productStorageInc[index].ContainsKey(num22))
									{
										productStorageInc[index][num22] = num23 * num7;
									}
									else
									{
										productStorageInc[index][num22] += num23 * num7;
									}
									if (productStorageInc[index][num22] > 4 * productStorage[index][num22])
									{
										productStorageInc[index][num22] = 4 * productStorage[index][num22];
									}
								}
								if (num12 > num6)
								{
									num23 = num6 * 2;
									num24 = (num12 - num6) * 2;
									if (array != null)
									{
										int[] array8 = array;
										lock (array8)
										{
											array[num22] += num24;
										}
									}
								}
								if (consumeRegister != null)
								{
									int[] array9 = consumeRegister;
									lock (array9)
									{
										consumeRegister[num22] -= num23;
									}
								}
							}
						}
					}
					progress[index][l] -= (int)progress[index][l];
				}
				else
				{
					progress[index][l] = 0.0;
				}
			}
			else if (progress[index][l] < 0.0)
			{
				progress[index][l] = 0.0;
			}
		}
		if (progress[index][0] >= 1.0)
		{
			if (productStorage[index].ContainsKey(9500))
			{
				productStorage[index][9500] = Math.Min(productStorage[index][9500] + (int)progress[index][0], 10000);
			}
			else
			{
				productStorage[index][9500] = Math.Min((int)progress[index][0], 10000);
			}
			if (array != null)
			{
				int[] array10 = array;
				lock (array10)
				{
					array[9500] += (int)progress[index][0];
				}
			}
			progress[index][0] -= (int)progress[index][0];
		}
		else if (progress[index][0] < 0.0)
		{
			progress[index][0] = 0.0;
		}
		if (MoreMegaStructure.isRemoteReceiveingGear && productStorage[index][9500] > 0)
		{
			try
			{
				int num25 = productStorage[index][9500];
				productStorage[index][9500] = 0;
				GameMain.mainPlayer.TryAddItemToPackage(9500, num25, 0, throwTrash: true);
				if (!VFInput.inFullscreenGUI && MoreMegaStructure.maxAutoReceiveGear < 3000)
				{
					Utils.UIItemUp(9500, num25, 240f);
				}
			}
			catch (Exception)
			{
			}
		}
		SendProductToGround(index);
		AutoSprayInStation(index, ref consumeRegister);
	}

	public static void AutoSprayInStation(int starIndex, ref int[] consumeRegister)
	{
		int planetCount = GameMain.galaxy.stars[starIndex].planetCount;
		for (int i = 0; i < planetCount; i++)
		{
			PlanetFactory factory = GameMain.galaxy.stars[starIndex].planets[i].factory;
			if (factory == null)
			{
				continue;
			}
			PlanetTransport transport = factory.transport;
			if (transport == null)
			{
				continue;
			}
			for (int j = 1; j < transport.stationCursor; j++)
			{
				StationComponent stationComponent = transport.stationPool[j];
				if (stationComponent == null)
				{
					continue;
				}
				int protoId = factory.entityPool[stationComponent.entityId].protoId;
				if (protoId != 9512)
				{
					continue;
				}
				bool flag = false;
				int num = 0;
				int num2 = 1;
				float num3 = 1f;
				int itemId = stationComponent.storage[4].itemId;
				if (itemId == 1141 || itemId == 1142 || itemId == 1143)
				{
					flag = true;
					num2 = itemId switch
					{
						1142 => 24, 
						1143 => 60, 
						_ => 12, 
					};
					num = itemId switch
					{
						1142 => 2, 
						1143 => 4, 
						_ => 1, 
					};
					num2 = (int)((double)num2 * (Cargo.incTableMilli[4] + 1.0));
					num3 = 1f / (float)num2;
				}
				for (int k = 0; k < 5; k++)
				{
					StationStore[] storage = stationComponent.storage;
					lock (storage)
					{
						if (k == 4 || !flag || stationComponent.storage[4].count <= 0)
						{
							continue;
						}
						int count = stationComponent.storage[4].count;
						int count2 = stationComponent.storage[k].count;
						int inc = stationComponent.storage[k].inc;
						if (inc >= count2 * num)
						{
							continue;
						}
						int num4 = count2 * num - inc;
						int num5 = (int)(1f * (float)num4 / (float)num / (float)num2);
						int num6 = num4 - num5 * num * num2;
						if (Utils.RandF() < 1f * (float)num6 / (float)num * num3)
						{
							num5++;
						}
						if (count >= num5)
						{
							stationComponent.storage[4].inc = (int)(1f * (float)(count - num5) / (float)stationComponent.storage[4].count * (float)stationComponent.storage[4].inc);
							stationComponent.storage[4].count = count - num5;
							stationComponent.storage[k].inc = stationComponent.storage[k].inc + num4;
							if (consumeRegister != null)
							{
								int[] array = consumeRegister;
								lock (array)
								{
									consumeRegister[itemId] += num5;
								}
							}
							continue;
						}
						int count3 = stationComponent.storage[4].count;
						stationComponent.storage[k].inc = stationComponent.storage[k].inc + count3 * num2 * num;
						stationComponent.storage[4].inc = 0;
						stationComponent.storage[4].count = 0;
						if (consumeRegister != null)
						{
							int[] array2 = consumeRegister;
							lock (array2)
							{
								consumeRegister[itemId] += count3;
							}
						}
					}
				}
			}
		}
	}

	public static int TakeItemForFactory(int starIndex, int itemId, int itemCount, int minCount, out int inc, bool consume)
	{
		int num = 0;
		inc = 0;
		if (productStorage[starIndex].ContainsKey(itemId) && productStorage[starIndex][itemId] >= minCount)
		{
			num = Math.Min(itemCount, productStorage[starIndex][itemId]);
			if (consume)
			{
				productStorage[starIndex][itemId] -= num;
			}
			inc = 4 * num;
			if (productStorageInc.ContainsKey(starIndex) && productStorageInc[starIndex].ContainsKey(itemId))
			{
				productStorageInc[starIndex][itemId] -= ((inc < productStorageInc[starIndex][itemId]) ? inc : productStorageInc[starIndex][itemId]);
			}
		}
		CpuHandle handle = MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.CargoTransport);
		if (num < itemCount)
		{
			int planetCount = GameMain.galaxy.stars[starIndex].planetCount;
			for (int i = 0; i < planetCount; i++)
			{
				PlanetFactory factory = GameMain.galaxy.stars[starIndex].planets[i].factory;
				if (factory == null)
				{
					continue;
				}
				PlanetTransport transport = factory.transport;
				if (transport == null)
				{
					continue;
				}
				for (int j = 1; j < transport.stationCursor; j++)
				{
					StationComponent stationComponent = transport.stationPool[j];
					if (stationComponent == null)
					{
						continue;
					}
					int protoId = factory.entityPool[stationComponent.entityId].protoId;
					if (protoId != 9512)
					{
						continue;
					}
					for (int k = 0; k < 5; k++)
					{
						StationStore[] storage = stationComponent.storage;
						lock (storage)
						{
							if (stationComponent.storage[k].itemId != itemId || stationComponent.storage[k].count < minCount)
							{
								continue;
							}
							int num2 = stationComponent.storage[k].inc / stationComponent.storage[k].count;
							int num3 = itemCount - num;
							if (stationComponent.storage[k].count > num3)
							{
								num += num3;
								inc += num2 * num3;
								if (consume)
								{
									stationComponent.storage[k].count -= num3;
									stationComponent.storage[k].inc -= num2 * num3;
								}
								MMSCPU.EndSampleSafe(handle);
								return num;
							}
							num += stationComponent.storage[k].count;
							inc += stationComponent.storage[k].inc;
							if (consume)
							{
								stationComponent.storage[k].count = 0;
								stationComponent.storage[k].inc = 0;
							}
							break;
						}
					}
				}
			}
		}
		MMSCPU.EndSampleSafe(handle);
		return num;
	}

	public static void SendProductToGround(int starIndex)
	{
		MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.CargoTransport);
		int planetCount = GameMain.galaxy.stars[starIndex].planetCount;
		for (int i = 0; i < planetCount; i++)
		{
			PlanetFactory factory = GameMain.galaxy.stars[starIndex].planets[i].factory;
			if (factory == null)
			{
				continue;
			}
			PlanetTransport transport = factory.transport;
			if (transport == null)
			{
				continue;
			}
			for (int j = 1; j < transport.stationCursor; j++)
			{
				StationComponent stationComponent = transport.stationPool[j];
				if (stationComponent == null)
				{
					continue;
				}
				int protoId = factory.entityPool[stationComponent.entityId].protoId;
				if (protoId != 9512)
				{
					continue;
				}
				for (int k = 0; k < 5; k++)
				{
					StationStore[] storage = stationComponent.storage;
					lock (storage)
					{
						int itemId = stationComponent.storage[k].itemId;
						if (!productStorage[starIndex].ContainsKey(itemId) || productStorage[starIndex][itemId] <= 0)
						{
							continue;
						}
						int num = productStorage[starIndex][itemId];
						if (stationComponent.storage[k].max - stationComponent.storage[k].count >= num)
						{
							stationComponent.storage[k].count += num;
							productStorage[starIndex][itemId] = 0;
							if (productStorageInc.ContainsKey(starIndex) && productStorageInc[starIndex].ContainsKey(itemId))
							{
								stationComponent.storage[k].inc += productStorageInc[starIndex][itemId];
								productStorageInc[starIndex][itemId] = 0;
							}
						}
						else if (stationComponent.storage[k].max > stationComponent.storage[k].count)
						{
							int num2 = stationComponent.storage[k].max - stationComponent.storage[k].count;
							stationComponent.storage[k].count += num2;
							productStorage[starIndex][itemId] -= num2;
							if (productStorageInc.ContainsKey(starIndex) && productStorageInc[starIndex].ContainsKey(itemId))
							{
								int num3 = Math.Min(productStorageInc[starIndex][itemId], num2 * 4);
								stationComponent.storage[k].inc += num3;
								productStorageInc[starIndex][itemId] -= num3;
							}
						}
					}
				}
			}
		}
		MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.CargoTransport);
	}

	public static double GetConsumeProduceSpeedRatio(int starIndex, int slotNum, out double redundantEnergy)
	{
		long num = GameMain.data.dysonSpheres[starIndex].energyGenCurrentTick - GameMain.data.dysonSpheres[starIndex].energyReqCurrentTick;
		double num2 = (double)num * weights[starIndex][slotNum] / (double)tickEnergyForFullSpeed / (double)timeSpend[starIndex][slotNum];
		redundantEnergy = 0.0;
		if (slotNum != 0)
		{
			int num3 = productCounts[starIndex][slotNum][0];
			if (num3 == 0)
			{
				num3 = 1;
			}
			double num4 = 1.0 * (double)productSpeedRequest[starIndex][slotNum] / (double)num3 / 3600.0;
			if (num2 > num4)
			{
				redundantEnergy = (double)num * weights[starIndex][slotNum] * (num2 - num4) / num2;
				num2 = num4;
			}
		}
		if (specBuffLevel[starIndex][slotNum] > 0)
		{
			if (curSpecType[starIndex] == 1)
			{
				num2 *= 3.0;
			}
			else if (curSpecType[starIndex] == 2)
			{
				num2 *= 2.0;
			}
		}
		else if (slotNum == 0)
		{
			if (curSpecType[starIndex] == 1)
			{
				return 0.0;
			}
			return (double)num * weights[starIndex][0] / (double)MoreMegaStructure.multifunctionComponentHeat * (MoreMegaStructure.isRemoteReceiveingGear ? 0.1 : 1.0);
		}
		return num2;
	}

	public static double GetFirstProductFullySpeed(int starIndex, int slotNum, int forceIncLevel = -1)
	{
		if (slotNum <= 0)
		{
			return 0.0;
		}
		if (productCounts[starIndex][slotNum][0] == 0)
		{
			int num = 1;
		}
		double num2 = 1.0 * (double)productSpeedRequest[starIndex][slotNum];
		if (specBuffLevel[starIndex][slotNum] > 0)
		{
			if (curSpecType[starIndex] == 1)
			{
				num2 *= 3.0;
			}
			else if (curSpecType[starIndex] == 2)
			{
				num2 *= 2.0;
			}
		}
		if (forceIncLevel < 0)
		{
			forceIncLevel = currentStarIncs[slotNum];
		}
		float fullIncMilli = GetFullIncMilli(starIndex, slotNum, forceIncLevel);
		return num2 * (double)(1f + fullIncMilli);
	}

	public static double GetIncProduceSpeedRatio(double satisfiedRatio, int starIndex, int slotNum, int incLevel)
	{
		return satisfiedRatio * (double)GetFullIncMilli(starIndex, slotNum, incLevel);
	}

	public static float GetFullIncMilli(int starIndex, int slotNum, int incLevel)
	{
		incLevel = ((incLevel >= 10) ? 10 : incLevel);
		incLevel = ((incLevel >= 0) ? incLevel : 0);
		double num = Cargo.incTableMilli[incLevel];
		double num2 = 0.0;
		if (specBuffLevel[starIndex][slotNum] > 0)
		{
			if (curSpecType[starIndex] == 2)
			{
				num = Math.Max(num, (Cargo.incTableMilli.Length > 4) ? Cargo.incTableMilli[4] : 0.25);
			}
			else if (curSpecType[starIndex] == 3)
			{
				num2 = 0.25;
			}
			else if (curSpecType[starIndex] == 4)
			{
				num2 = 0.25 * (double)specBuffLevel[starIndex][slotNum];
			}
			else if (curSpecType[starIndex] == 5)
			{
				num2 = 0.25 * (double)specBuffLevel[starIndex][slotNum];
			}
		}
		else if (incProgress[starIndex][slotNum] < 0.0)
		{
			num = 0.0;
		}
		return (float)(num + num2);
	}

	public static void CheckSpecializeState(DysonSphere sphere, bool forceCheckAllSlot = false)
	{
		int index = sphere.starData.index;
		List<int> list = new List<int> { 0, 0, 0, 0, 0, 0 };
		int num = (forceCheckAllSlot ? (slotCount - 1) : CalcMaxSlotIndex(sphere));
		for (int i = 1; i <= num; i++)
		{
			if (recipeIds[index][i] == 0)
			{
				continue;
			}
			int num2 = 0;
			ERecipeType type = LDB.recipes.Select(recipeIds[index][i]).Type;
			if (type == ERecipeType.Smelt)
			{
				list[1]++;
				if (curSpecType[index] == 1)
				{
					num2 = 1;
				}
			}
			else
			{
				list[1] = -9999;
			}
			if (type == ERecipeType.Chemical || type == ERecipeType.Refine || type == (ERecipeType)16 || products[index][i].Contains(1141) || products[index][i].Contains(1142) || products[index][i].Contains(1143))
			{
				list[2]++;
				if (curSpecType[index] == 2)
				{
					num2 = 1;
				}
			}
			else
			{
				list[2] = -9999;
			}
			bool flag = false;
			for (int j = 0; j < items[index][i].Count; j++)
			{
				if (items[index][i][j] == 1121 || items[index][i][j] == 1122)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				for (int k = 0; k < products[index][i].Count; k++)
				{
					if (products[index][i][k] == 1121 || products[index][i][k] == 1122)
					{
						flag = true;
						break;
					}
				}
			}
			if (flag)
			{
				list[3]++;
				if (curSpecType[index] == 3)
				{
					num2 = 1;
				}
			}
			else
			{
				list[3] = -9999;
			}
			int num3 = 0;
			for (int l = 0; l < products[index][i].Count; l++)
			{
				if (products[index][i][l] == 1303 || products[index][i][l] == 1305 || products[index][i][l] == 9486)
				{
					num3 = 2;
					break;
				}
			}
			if (num3 <= 0)
			{
				for (int m = 0; m < items[index][i].Count; m++)
				{
					if (items[index][i][m] == 1303 || items[index][i][m] == 1305 || items[index][i][m] == 9486)
					{
						num3 = 1;
						break;
					}
				}
			}
			if (num3 > 0)
			{
				list[4]++;
				if (curSpecType[index] == 4)
				{
					num2 = num3;
				}
			}
			else
			{
				list[4] = -9999;
			}
			int num4 = 0;
			for (int n = 0; n < products[index][i].Count; n++)
			{
				int id = products[index][i][n];
				ItemProto itemProto = LDB.items.Select(id);
				if (itemProto.isAmmo)
				{
					num4 = 4;
					break;
				}
				if (itemProto.Type == EItemType.Defense || itemProto.Type == EItemType.Turret || itemProto.isCraft)
				{
					num4 = 2;
				}
			}
			if (num4 > 0)
			{
				list[5]++;
				if (curSpecType[index] == 5)
				{
					num2 = num4;
				}
			}
			else
			{
				list[5] = -9999;
			}
			specBuffLevel[index][i] = num2;
			if (num2 == 0)
			{
				RecipeProto recipeProto = LDB.recipes.Select(recipeIds[index][i]);
				if (recipeProto != null && !recipeProto.productive)
				{
					incProgress[index][i] = -1.0;
				}
			}
		}
		bool flag2 = true;
		for (int num5 = 5; num5 >= 1; num5--)
		{
			if (list[num5] >= specializeRequirements[num5])
			{
				satisfiedSpecType[index] = num5;
				flag2 = false;
				break;
			}
		}
		if (flag2)
		{
			satisfiedSpecType[index] = 0;
		}
	}

	public static void UpdateSpecializeState(DysonSphere sphere, int div)
	{
		int index = sphere.starData.index;
		if (index >= 1200)
		{
			return;
		}
		bool isSandboxMode = GameMain.data.gameDesc.isSandboxMode;
		if (isSandboxMode)
		{
			div = 1;
		}
		if (GameMain.instance.timei % div != 0)
		{
			return;
		}
		if (specProgress[index] <= 0)
		{
			if (satisfiedSpecType[index] > 0 && satisfiedSpecType[index] != curSpecType[index])
			{
				inProgressSpecType[index] = satisfiedSpecType[index];
				specProgress[index]++;
				if (isSandboxMode)
				{
					specProgress[index] += 300;
				}
			}
		}
		else if (satisfiedSpecType[index] == inProgressSpecType[index])
		{
			specProgress[index]++;
			if (isSandboxMode)
			{
				specProgress[index] += 300;
			}
		}
		else
		{
			specProgress[index]--;
			if (isSandboxMode)
			{
				specProgress[index] -= 300;
			}
		}
		if (specProgress[index] >= specializeTimeNeed)
		{
			specProgress[index] = 0;
			curSpecType[index] = inProgressSpecType[index];
		}
		else if (specProgress[index] <= 0)
		{
			inProgressSpecType[index] = 0;
			specProgress[index] = 0;
		}
	}

	public static void RefreshUI(bool forceShowUI = false)
	{
		if (MoreMegaStructure.curStar == null)
		{
			return;
		}
		showingLimit = true;
		int index = MoreMegaStructure.curStar.index;
		if (index < 1200 && MoreMegaStructure.StarMegaStructureType[index] == 4)
		{
			if (forceShowUI)
			{
				showingLimit = false;
				GigaFactoryUIObj.SetActive(value: true);
				if (lowUIResolution)
				{
					specializeObj.SetActive(value: false);
				}
				else
				{
					specializeObj.SetActive(value: true);
				}
			}
			showHideButtonObj.SetActive(value: true);
			showHideBtnText.text = "显示/隐藏星际组装厂配置".Translate();
			doubleAllBtnText.text = "加倍所有速度设置".Translate();
			halveAllBtnText.text = "减半所有速度设置".Translate();
			lockSliderListener = true;
			int num = CalcMaxSlotIndex(GameMain.data.dysonSpheres[MoreMegaStructure.curStar.index]);
			for (int i = 1; i < slotCount; i++)
			{
				if (recipeIds[index][i] > 0 && num >= i)
				{
					recipeIcons[i].sprite = LDB.recipes.Select(recipeIds[index][i]).iconSprite;
					recipeSelectTips[i].SetActive(value: false);
					sliderObjs[i].SetActive(!showingLimit);
					speedTextObjs[i].SetActive(value: true);
					setLimitObjs[i].SetActive(showingLimit);
					sliders[i].value = W2S(weights[index][i]);
					removeRecipeBtnObjs[i].SetActive(value: true);
					recipeCircleUIBtns[i].tips.itemId = products[index][i][0];
					if (LDB.recipes.Select(recipeIds[index][i]) != null && LDB.recipes.Select(recipeIds[index][i]).Explicit)
					{
						recipeCircleUIBtns[i].tips.itemId = -recipeIds[index][i];
					}
				}
				else
				{
					recipeIcons[i].sprite = noRecipeSelectedSprit;
					recipeSelectTips[i].SetActive(value: true);
					sliderObjs[i].SetActive(value: false);
					speedTextObjs[i].SetActive(value: false);
					setLimitObjs[i].SetActive(value: false);
					removeRecipeBtnObjs[i].SetActive(value: false);
					recipeCircleUIBtns[i].tips.itemId = 0;
					if (num < i)
					{
						recipePickerTxts[i].text = string.Format("组装厂槽位解锁于".Translate(), MoreMegaStructure.Capacity2Str(speedNeededToUnlockSlot[i]));
					}
					else
					{
						recipePickerTxts[i].text = "指定配方".Translate();
					}
				}
			}
			sliderObjs[0].SetActive(value: true);
			recipeSelectTips[0].SetActive(value: false);
			removeRecipeBtnObjs[0].SetActive(value: false);
			recipeIcons[0].sprite = MoreMegaStructure.iconInterCompo;
			sliders[0].value = (float)weights[index][0] * 100f;
			RefreshProduceSpeedContent();
			RefreshStorageText();
			RefreshSpecializeUI();
			RefreshLimitInputUI();
			lockSliderListener = false;
		}
		else
		{
			GigaFactoryUIObj.SetActive(value: false);
			specializeObj.SetActive(value: false);
			showHideButtonObj.SetActive(value: false);
		}
	}

	public static void UIFrameUpdate(long timei)
	{
		RefreshStorageText();
		if (timei % 10 == 0)
		{
			RefreshProduceSpeedContent();
			RefreshUI();
		}
	}

	public static void RefreshProduceSpeedContent()
	{
		if (UIRoot.instance.uiMainMenu.gameObject.activeSelf || MoreMegaStructure.curStar == null)
		{
			return;
		}
		int index = MoreMegaStructure.curStar.index;
		DysonSphere[] dysonSpheres = GameMain.data.dysonSpheres;
		if ((dysonSpheres != null && dysonSpheres.Length <= index) || !GigaFactoryUIObj.activeSelf)
		{
			return;
		}
		int num = CalcMaxSlotIndex(GameMain.data.dysonSpheres[index]);
		if (MoreMegaStructure.StarMegaStructureType[index] != 4)
		{
			return;
		}
		double redundantEnergy;
		for (int i = 1; i < slotCount; i++)
		{
			if (recipeIds[index][i] > 0 && i <= num)
			{
				double num2 = GetConsumeProduceSpeedRatio(index, i, out redundantEnergy) * 3600.0 * (double)productCounts[index][i][0];
				string text = "";
				double num3 = GetFullIncMilli(index, i, (currentStarIncs[i] > 10) ? 10 : currentStarIncs[i]);
				if (num3 > 0.0)
				{
					text = $"<color=#61D8FFC8>+{num3 * 100.0:N2} %</color>\n";
				}
				num2 *= 1.0 + num3;
				string text2 = ((num2 > 10.0) ? num2.ToString("N0") : ((num2 > 1.0) ? num2.ToString("N1") : ((num2 > 0.0) ? num2.ToString("N2") : "0.00")));
				double firstProductFullySpeed = GetFirstProductFullySpeed(index, i);
				if (firstProductFullySpeed > num2 + 0.0010000000474974513)
				{
					produceSpeedTxts[i].text = text + "可承载速度".Translate() + " " + text2 + "/min";
				}
				else
				{
					produceSpeedTxts[i].text = text + "理论最大速度".Translate() + " " + text2 + "/min";
				}
				Text text3 = weightTxts[i];
				string text4 = "能量分配".Translate();
				redundantEnergy = weights[index][i] * 100.0;
				text3.text = text4 + " " + redundantEnergy + "%";
			}
			else
			{
				produceSpeedTxts[i].text = "";
			}
		}
		double num4 = GetConsumeProduceSpeedRatio(index, 0, out redundantEnergy) * 3600.0;
		string text5 = ((num4 > 10.0) ? num4.ToString("N0") : ((num4 > 1.0) ? num4.ToString("N1") : ((num4 > 0.0) ? num4.ToString("N2") : "0.00")));
		string text6 = "";
		if (MoreMegaStructure.isRemoteReceiveingGear)
		{
			text6 = "已开启优先传输至机甲".Translate();
		}
		produceSpeedTxts[0].text = "理论最大速度".Translate() + " " + text5 + "/min   " + text6;
		weightTxts[0].text = "剩余能量".Translate() + " " + (weights[index][0] * 100.0).ToString("N0") + "%";
		for (int j = 1; j < slotCount; j++)
		{
			int num5 = currentStarIncs[j];
			if (num5 > 0 && j <= num)
			{
				int num6 = num5;
				if (num6 == 3)
				{
					num6 = 2;
				}
				else if (num6 > 4)
				{
					num6 = 4;
				}
				incIcons[j].sprite = Resources.Load<Sprite>($"entities/models/cargo/inc-{num6}");
				incIcons[j].gameObject.SetActive(value: true);
			}
			else
			{
				incIcons[j].gameObject.SetActive(value: false);
			}
		}
	}

	public static void RefreshStorageText()
	{
		if (MoreMegaStructure.curStar == null)
		{
			return;
		}
		int index = MoreMegaStructure.curStar.index;
		if (MoreMegaStructure.StarMegaStructureType[index] != 4)
		{
			return;
		}
		for (int i = 1; i < slotCount; i++)
		{
			if (recipeIds[index][i] > 0)
			{
				int key = products[index][i][0];
				int num = (productStorage[index].ContainsKey(key) ? productStorage[index][key] : 0);
				int num2 = recipeIds[index][i];
				if (productCounts[index][i].Count > 1)
				{
					storageTxts[i].text = "主产物巨构内部仓储".Translate() + "\n" + num + "/10000";
				}
				else
				{
					storageTxts[i].text = "巨构内部仓储".Translate() + "\n" + num + "/10000";
				}
			}
			else
			{
				storageTxts[i].text = "";
			}
		}
		int num3 = (productStorage[index].ContainsKey(9500) ? productStorage[index][9500] : 0);
		storageTxts[0].text = "巨构内部仓储".Translate() + "\n" + num3 + "/10000";
	}

	public static void RefreshSpecializeUI()
	{
		for (int i = 0; i < tipButtonTxts.Count; i++)
		{
			if (tipButtonTxts[i] != null)
			{
				tipButtonTxts[i].text = "?";
			}
		}
		for (int j = 0; j < specializeTitleTxts.Count; j++)
		{
			specializeTitleTxts[j].text = $"星际组装厂特化名称{j}".Translate();
		}
		for (int k = 1; k < specializeTitleTxts.Count; k++)
		{
			int index = MoreMegaStructure.curStar.index;
			if (curSpecType[index] == k)
			{
				specializeTitleTxts[k].color = UITextBlue;
				if (specProgress[index] > 0 && satisfiedSpecType[index] > 0 && satisfiedSpecType[index] != k)
				{
					specializeStateTxts[k].color = UITextOrange;
					specializeStateTxts[k].text = "特化即将被取代".Translate();
				}
				else
				{
					specializeStateTxts[k].color = UITextBlue;
					specializeStateTxts[k].text = "特化已激活".Translate();
				}
			}
			else if (inProgressSpecType[index] == k)
			{
				if (satisfiedSpecType[index] == k)
				{
					specializeTitleTxts[k].color = UITextGreen;
					specializeStateTxts[k].color = UITextGreen;
					specializeStateTxts[k].text = string.Format("特化进程".Translate(), (int)(100.0 * (double)specProgress[index] / (double)specializeTimeNeed));
				}
				else
				{
					specializeTitleTxts[k].color = UITextOrange;
					specializeStateTxts[k].color = UITextOrange;
					specializeStateTxts[k].text = string.Format("特化进程消退中".Translate(), (int)(100.0 * (double)specProgress[index] / (double)specializeTimeNeed));
				}
			}
			else if (satisfiedSpecType[index] == k)
			{
				specializeTitleTxts[k].color = UITextGreen;
				specializeStateTxts[k].color = UITextGreen;
				specializeStateTxts[k].text = "等待其他特化进程消退".Translate();
			}
			else
			{
				specializeTitleTxts[k].color = UITextGray;
				specializeStateTxts[k].color = UITextGray;
				specializeStateTxts[k].text = "特化条件未满足".Translate();
			}
		}
	}

	public static void OnRecipeSelectClick(int slotIndex)
	{
		if (MoreMegaStructure.curStar != null)
		{
			int num = CalcMaxSlotIndex(GameMain.data.dysonSpheres[MoreMegaStructure.curStar.index]);
			if (slotIndex > num)
			{
				UIRealtimeTip.Popup("星际组装厂槽位未解锁警告".Translate());
				return;
			}
			currentRecipeSlot = slotIndex;
			UIRecipePicker.Popup(new Vector2(0f, 0f), OnRecipePickerReturn);
		}
	}

	public static void OnRecipeRemoveClick(int slotIndex)
	{
		if (MoreMegaStructure.curStar != null)
		{
			int index = MoreMegaStructure.curStar.index;
			recipeIds[index][slotIndex] = 0;
			incProgress[index][slotIndex] = 0.0;
			progress[index][slotIndex] = 0.0;
			weights[index][slotIndex] = 0.0;
			productSpeedRequest[index][slotIndex] = 0;
			currentStarIncs[slotIndex] = 0;
			double num = 1.0;
			SetProductSpeedRequest(slotIndex, "0");
			RefreshUI();
		}
	}

	public static void OnRecipePickerReturn(RecipeProto recipe)
	{
		int index = MoreMegaStructure.curStar.index;
		if (MoreMegaStructure.Support1000Stars.Value)
		{
			if (index >= 1200)
			{
				UIRealtimeTip.Popup("警告巨构不支持恒星系数量大于1200个".Translate());
				return;
			}
		}
		else if (index > 99)
		{
			UIRealtimeTip.Popup("警告巨构不支持恒星系数量大于100个".Translate());
			return;
		}
		int iD = recipe.ID;
		for (int i = 1; i < slotCount; i++)
		{
			if (recipeIds[index][i] == iD)
			{
				if (i <= CalcMaxSlotIndex(GameMain.data.dysonSpheres[index]))
				{
					UIRealtimeTip.Popup("警告选择了重复的配方".Translate());
					return;
				}
				recipeIds[index][i] = 0;
			}
		}
		if (MoreMegaStructure.GenesisCompatibility && recipe.Type == (ERecipeType)14)
		{
			UIRealtimeTip.Popup("警告巨构不支持此类配方".Translate());
			return;
		}
		recipeIds[index][currentRecipeSlot] = recipe.ID;
		incProgress[index][currentRecipeSlot] = 0.0;
		progress[index][currentRecipeSlot] = 0.0;
		currentStarIncs[currentRecipeSlot] = 0;
		productSpeedRequest[index][currentRecipeSlot] = 0;
		if (!recipe.productive)
		{
			incProgress[index][currentRecipeSlot] = -1.0;
		}
		if (!items.ContainsKey(index))
		{
			items.Add(index, new List<List<int>>());
			products[index] = new List<List<int>>();
			itemCounts[index] = new List<List<int>>();
			productCounts[index] = new List<List<int>>();
			timeSpend[index] = new List<int>();
			productStorage[index] = new Dictionary<int, int>();
			productStorageInc[index] = new Dictionary<int, int>();
			productStorage[index][9500] = 0;
			for (int j = 0; j < slotCount; j++)
			{
				items[index].Add(new List<int>());
				itemCounts[index].Add(new List<int>());
				products[index].Add(new List<int>());
				productCounts[index].Add(new List<int>());
				timeSpend[index].Add(1);
			}
		}
		int index2 = currentRecipeSlot;
		items[index][index2].Clear();
		itemCounts[index][index2].Clear();
		products[index][index2].Clear();
		productCounts[index][index2].Clear();
		for (int k = 0; k < recipe.Items.Length; k++)
		{
			items[index][index2].Add(recipe.Items[k]);
			itemCounts[index][index2].Add(recipe.ItemCounts[k]);
		}
		for (int l = 0; l < recipe.Results.Length; l++)
		{
			products[index][index2].Add(recipe.Results[l]);
			productCounts[index][index2].Add(recipe.ResultCounts[l]);
			if (!productStorage[index].ContainsKey(recipe.Results[l]))
			{
				productStorage[index].Add(recipe.Results[l], 0);
			}
		}
		timeSpend[index][index2] = Math.Max(1, recipe.TimeSpend);
		if (recipe.Results[0] >= 6001 && recipe.Results[0] <= 6006)
		{
			timeSpend[index][index2] *= matrixTimeSpendRatio;
		}
		if (MoreMegaStructure.GenesisCompatibility && (recipe.Type == (ERecipeType)12 || recipe.Type == (ERecipeType)13))
		{
			timeSpend[index][index2] *= recipeType1213TimeSpendRatio;
		}
		SetProductSpeedRequest(currentRecipeSlot, "0");
		CheckSpecializeState(GameMain.data.dysonSpheres[index]);
		RefreshUI();
	}

	public static void OnSliderValueChange(int slotIndex, float sv)
	{
	}

	public static void NormalizeSetValue(int index, bool forceFullInc)
	{
		int index2 = MoreMegaStructure.curStar.index;
		int num = productSpeedRequest[index2][index];
		double firstProductFullySpeed = GetFirstProductFullySpeed(index2, index, forceFullInc ? 4 : (-1));
		SetProductSpeedRequest(index, ((int)Math.Ceiling((double)num * 1.0 / firstProductFullySpeed * (double)num)).ToString());
	}

	public static void TryUseRocketInStorageToBuildIA(DysonSphere __instance)
	{
		if (productStorage[__instance.starData.index].ContainsKey(9491) && productStorage[__instance.starData.index][9491] > 0)
		{
			productStorage[__instance.starData.index][9491] = AutoBuildInterstellarAssembly(__instance.starData.index, productStorage[__instance.starData.index][9491]);
		}
	}

	public static int AutoBuildInterstellarAssembly(int starIndex = -1, int amount = 1)
	{
		if (starIndex < 0)
		{
			return amount;
		}
		if (starIndex >= 0 && starIndex < GameMain.data.dysonSpheres.Length)
		{
			DysonSphere dysonSphere = GameMain.data.dysonSpheres[starIndex];
			if (dysonSphere != null)
			{
				for (int i = 0; i < dysonSphere.layersIdBased.Length; i++)
				{
					DysonSphereLayer dysonSphereLayer = dysonSphere.layersIdBased[i];
					if (dysonSphereLayer == null)
					{
						continue;
					}
					int num = dysonSphereLayer.nodePool.Length;
					for (int j = 0; j < num; j++)
					{
						DysonNode dysonNode = dysonSphereLayer.nodePool[j];
						if (dysonNode != null)
						{
							for (int k = 0; k < Math.Min(6, amount); k++)
							{
								if (dysonNode.spReqOrder > 0)
								{
									dysonSphere.OrderConstructSp(dysonNode);
									dysonSphere.ConstructSp(dysonNode);
									amount--;
								}
							}
						}
						if (amount <= 0)
						{
							return amount;
						}
					}
				}
			}
		}
		return amount;
	}

	public static void ShowHideUI()
	{
		if (GigaFactoryUIObj == null)
		{
			return;
		}
		showingLimit = false;
		if (GigaFactoryUIObj.activeSelf)
		{
			GigaFactoryUIObj.SetActive(value: false);
			if (lowUIResolution)
			{
				specializeObj.SetActive(value: true);
				RefreshSpecializeUI();
			}
			else
			{
				specializeObj.SetActive(value: false);
			}
			return;
		}
		GigaFactoryUIObj.SetActive(value: true);
		if (lowUIResolution)
		{
			specializeObj.SetActive(value: false);
		}
		else
		{
			specializeObj.SetActive(value: true);
			RefreshSpecializeUI();
		}
		RefreshUI();
	}

	public static void RefreshLimitInputUI()
	{
		if (GigaFactoryUIObj == null)
		{
			return;
		}
		int index = MoreMegaStructure.curStar.index;
		for (int i = 1; i < slotCount; i++)
		{
			if (!limitInputs[i].isFocused)
			{
				limitInputs[i].text = productSpeedRequest[index][i].ToString();
			}
		}
	}

	public static int CalcMaxSlotIndex(DysonSphere sphere)
	{
		if (sphere == null)
		{
			return 4;
		}
		long num = sphere.energyGenCurrentTick - sphere.energyReqCurrentTick;
		double num2 = 1.0 * (double)num / (double)tickEnergyForFullSpeed;
		for (int num3 = slotCount - 1; num3 > 4; num3--)
		{
			if ((double)speedNeededToUnlockSlot[num3] <= num2)
			{
				return num3;
			}
		}
		return 4;
	}

	public static void SetProductSpeedRequest(int index, string text)
	{
		if (MoreMegaStructure.curStar == null)
		{
			return;
		}
		int index2 = MoreMegaStructure.curStar.index;
		int num = 0;
		if (text.Length == 0 || text == "")
		{
			text = "0";
		}
		if (index > 0)
		{
			try
			{
				num = Convert.ToInt32(text);
			}
			catch (Exception)
			{
				num = 0;
			}
			if (num < 0)
			{
				num = 0;
			}
			productSpeedRequest[index2][index] = num;
			limitInputs[index].text = num.ToString();
		}
		double num2 = 0.0;
		for (int i = 1; i < slotCount; i++)
		{
			if (recipeIds[index2][i] > 0 && productCounts[index2][i][0] > 0)
			{
				num2 += 1.0 * (double)productSpeedRequest[index2][i] / (double)productCounts[index2][i][0] * (double)timeSpend[index2][i];
			}
		}
		for (int j = 1; j < slotCount; j++)
		{
			if (recipeIds[index2][j] > 0 && productCounts[index2][j][0] > 0 && num2 > 1E-09)
			{
				weights[index2][j] = 1.0 * (double)productSpeedRequest[index2][j] / (double)productCounts[index2][j][0] * (double)timeSpend[index2][j] / num2;
			}
			else
			{
				weights[index2][j] = 0.0;
			}
		}
		RefreshLimitInputUI();
		RefreshProduceSpeedContent();
	}

	public static void DoubleAllSpeedRequest()
	{
		int index = MoreMegaStructure.curStar.index;
		for (int i = 1; i < slotCount; i++)
		{
			if (recipeIds[index][i] > 0 && productSpeedRequest[index][i] >= 499999999)
			{
				UIRealtimeTip.Popup(string.Format("有过大数值警告".Translate(), LDB.recipes.Select(recipeIds[index][i]).Name.Translate()));
				return;
			}
		}
		for (int j = 1; j < slotCount; j++)
		{
			if (recipeIds[index][j] > 0)
			{
				productSpeedRequest[index][j] = ((productSpeedRequest[index][j] * 2 >= 0) ? (productSpeedRequest[index][j] * 2) : 0);
			}
		}
		SetProductSpeedRequest(0, "");
		RefreshUI();
	}

	public static void HalveAllSpeedRequest()
	{
		int index = MoreMegaStructure.curStar.index;
		for (int i = 1; i < slotCount; i++)
		{
			productSpeedRequest[index][i] = productSpeedRequest[index][i] / 2;
		}
		SetProductSpeedRequest(0, "");
		RefreshUI();
	}

	public static double S2W(double sliderValue)
	{
		if (MoreMegaStructure.NonlinearEnergy.Value)
		{
			return Math.Pow(sliderValue / 100.0, 2.0);
		}
		return sliderValue / 100.0;
	}

	public static float W2S(double weight)
	{
		if (MoreMegaStructure.NonlinearEnergy.Value)
		{
			return (float)(Math.Sqrt(weight) * 100.0);
		}
		return (float)(weight * 100.0);
	}

	public static void Import(BinaryReader r)
	{
		int num = 5;
		if (MoreMegaStructure.savedModVersion >= 119)
		{
			num = slotCount;
		}
		for (int i = 0; i < 100; i++)
		{
			for (int j = 0; j < num; j++)
			{
				recipeIds[i][j] = r.ReadInt32();
				weights[i][j] = r.ReadDouble();
				progress[i][j] = r.ReadDouble();
				incProgress[i][j] = r.ReadDouble();
			}
			for (int k = num; k < slotCount; k++)
			{
				recipeIds[i][k] = 0;
				weights[i][k] = 0.0;
				progress[i][k] = 0.0;
				incProgress[i][k] = 0.0;
			}
		}
		if (MoreMegaStructure.savedModVersion >= 116)
		{
			int num2 = r.ReadInt32();
			if (num2 > 0)
			{
				for (int l = 100; l < 1000; l++)
				{
					for (int m = 0; m < num; m++)
					{
						recipeIds[l][m] = r.ReadInt32();
						weights[l][m] = r.ReadDouble();
						progress[l][m] = r.ReadDouble();
						incProgress[l][m] = r.ReadDouble();
					}
					for (int n = num; n < slotCount; n++)
					{
						recipeIds[l][n] = 0;
						weights[l][n] = 0.0;
						progress[l][n] = 0.0;
						incProgress[l][n] = 0.0;
					}
				}
				if (MoreMegaStructure.savedModVersion >= 190)
				{
					for (int num3 = 1000; num3 < 1200; num3++)
					{
						for (int num4 = 0; num4 < slotCount; num4++)
						{
							recipeIds[num3][num4] = r.ReadInt32();
							weights[num3][num4] = r.ReadDouble();
							progress[num3][num4] = r.ReadDouble();
							incProgress[num3][num4] = r.ReadDouble();
						}
					}
				}
			}
			else
			{
				ResetDataAfterStarIndex100();
			}
		}
		else
		{
			ResetDataAfterStarIndex100();
		}
		int num5 = ((MoreMegaStructure.savedModVersion >= 190) ? 1200 : 1000);
		if (MoreMegaStructure.savedModVersion >= 120)
		{
			for (int num6 = 0; num6 < num5; num6++)
			{
				specProgress[num6] = r.ReadInt32();
				curSpecType[num6] = r.ReadInt32();
				inProgressSpecType[num6] = r.ReadInt32();
				satisfiedSpecType[num6] = r.ReadInt32();
			}
		}
		if (MoreMegaStructure.savedModVersion >= 130)
		{
			for (int num7 = 0; num7 < num5; num7++)
			{
				for (int num8 = 0; num8 < num; num8++)
				{
					productSpeedRequest[num7][num8] = r.ReadInt32();
				}
			}
		}
		tickEnergyForFullSpeed = (int)(20000.0 / MoreMegaStructure.IASpdFactor.Value);
		if (tickEnergyForFullSpeed <= 0)
		{
			tickEnergyForFullSpeed = 100000;
		}
		int num9 = (MoreMegaStructure.Support1000Stars.Value ? 1200 : 100);
		for (int num10 = 0; num10 < num9; num10++)
		{
			if (MoreMegaStructure.StarMegaStructureType[num10] == 4)
			{
				productStorage[num10] = new Dictionary<int, int>();
				productStorageInc[num10] = new Dictionary<int, int>();
				productStorage[num10][9500] = 0;
				productStorageInc[num10][9500] = 0;
			}
		}
		if (MoreMegaStructure.savedModVersion < 191)
		{
			return;
		}
		for (int num11 = 0; num11 < num9; num11++)
		{
			if (MoreMegaStructure.StarMegaStructureType[num11] != 4)
			{
				continue;
			}
			int num12 = r.ReadInt32();
			for (int num13 = 0; num13 < num12; num13++)
			{
				int key = r.ReadInt32();
				int num14 = r.ReadInt32();
				int value = r.ReadInt32();
				if (num14 > 0)
				{
					productStorage[num11][key] = num14;
					productStorageInc[num11][key] = value;
				}
			}
		}
	}

	public static void Export(BinaryWriter w)
	{
		for (int i = 0; i < 100; i++)
		{
			for (int j = 0; j < slotCount; j++)
			{
				w.Write(recipeIds[i][j]);
				w.Write(weights[i][j]);
				w.Write(progress[i][j]);
				w.Write(incProgress[i][j]);
			}
		}
		bool value = MoreMegaStructure.Support1000Stars.Value;
		w.Write(value ? 1 : 0);
		if (value)
		{
			for (int k = 100; k < 1200; k++)
			{
				for (int l = 0; l < slotCount; l++)
				{
					w.Write(recipeIds[k][l]);
					w.Write(weights[k][l]);
					w.Write(progress[k][l]);
					w.Write(incProgress[k][l]);
				}
			}
		}
		for (int m = 0; m < 1200; m++)
		{
			w.Write(specProgress[m]);
			w.Write(curSpecType[m]);
			w.Write(inProgressSpecType[m]);
			w.Write(satisfiedSpecType[m]);
		}
		for (int n = 0; n < 1200; n++)
		{
			for (int num = 0; num < slotCount; num++)
			{
				w.Write(productSpeedRequest[n][num]);
			}
		}
		int num2 = (MoreMegaStructure.Support1000Stars.Value ? 1200 : 100);
		for (int num3 = 0; num3 < num2; num3++)
		{
			if (MoreMegaStructure.StarMegaStructureType[num3] != 4)
			{
				continue;
			}
			w.Write(productStorage[num3].Count);
			Dictionary<int, int> dictionary = productStorageInc[num3];
			foreach (KeyValuePair<int, int> item in productStorage[num3])
			{
				w.Write(item.Key);
				w.Write(item.Value);
				if (dictionary.ContainsKey(item.Key))
				{
					w.Write(dictionary[item.Key]);
				}
				else
				{
					w.Write(0);
				}
			}
		}
	}

	public static void IntoOtherSave()
	{
		ResetAndInitArchiveData();
		InitInGameData();
		tickEnergyForFullSpeed = (int)(20000.0 / MoreMegaStructure.IASpdFactor.Value);
		if (tickEnergyForFullSpeed <= 0)
		{
			tickEnergyForFullSpeed = 100000;
		}
	}
}
