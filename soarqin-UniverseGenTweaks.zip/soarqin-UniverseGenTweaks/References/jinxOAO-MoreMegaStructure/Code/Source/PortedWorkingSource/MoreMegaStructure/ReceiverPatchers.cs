using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace MoreMegaStructure;

public static class ReceiverPatchers
{
	internal static readonly Dictionary<int, int> ProductId2MegaType = new Dictionary<int, int>();

	public static Dictionary<int, int> RRId2OreId = new Dictionary<int, int>();

	public static Dictionary<int, int> MDOreModeFactor = new Dictionary<int, int>();

	public static Dictionary<int, long> productHeat = new Dictionary<int, long>();

	internal static void InitRawData()
	{
		ProductId2MegaType.Add(0, 0);
		ProductId2MegaType.Add(1208, 0);
		ProductId2MegaType.Add(1101, 1);
		ProductId2MegaType.Add(1102, 1);
		ProductId2MegaType.Add(1104, 1);
		ProductId2MegaType.Add(1105, 1);
		ProductId2MegaType.Add(1106, 1);
		ProductId2MegaType.Add(1109, 1);
		ProductId2MegaType.Add(1016, 1);
		ProductId2MegaType.Add(1014, 5);
		ProductId2MegaType.Add(1126, 5);
		ProductId2MegaType.Add(1001, 1);
		ProductId2MegaType.Add(1002, 1);
		ProductId2MegaType.Add(1003, 1);
		ProductId2MegaType.Add(1004, 1);
		ProductId2MegaType.Add(1006, 1);
		RRId2OreId.Add(9493, 1001);
		RRId2OreId.Add(9494, 1002);
		RRId2OreId.Add(9495, 1003);
		RRId2OreId.Add(9496, 1004);
		RRId2OreId.Add(9497, 1016);
		RRId2OreId.Add(9501, 1006);
		RRId2OreId.Add(2208, 0);
		MDOreModeFactor.Add(1001, 1);
		MDOreModeFactor.Add(1002, 1);
		MDOreModeFactor.Add(1003, 2);
		MDOreModeFactor.Add(1004, 2);
		MDOreModeFactor.Add(1006, 2);
		productHeat.Add(1101, 6000000L);
		productHeat.Add(1102, 6000000L);
		productHeat.Add(1104, 6000000L);
		productHeat.Add(1105, 12000000L);
		productHeat.Add(1106, 12000000L);
		productHeat.Add(1109, 12000000L);
		productHeat.Add(1001, 5000000L);
		productHeat.Add(1002, 5000000L);
		productHeat.Add(1003, 5000000L);
		productHeat.Add(1004, 5000000L);
		productHeat.Add(1006, 5000000L);
		productHeat.Add(1016, 6000000L);
		productHeat.Add(1126, 120000000L);
		productHeat.Add(1014, 12000000L);
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PowerSystem), "RequestDysonSpherePower")]
	public static bool RequestDysonSpherePowerPrePatch(ref PowerSystem __instance)
	{
		PowerSystem powerSystem = __instance;
		int index = powerSystem.factory.planet.star.index;
		if (index >= MoreMegaStructure.StarMegaStructureType.Length)
		{
			return true;
		}
		DysonSphere dysonSphere = powerSystem.factory.dysonSphere;
		int num = MoreMegaStructure.StarMegaStructureType[index];
		float eta = 1f - GameMain.history.solarEnergyLossRate;
		float increase = ((dysonSphere != null) ? ((float)((double)dysonSphere.grossRadius / ((double)powerSystem.planet.sunDistance * 40000.0))) : 0f);
		Vector3 normalized = powerSystem.planet.runtimeLocalSunDirection.normalized;
		long num2 = 0L;
		for (int i = 1; i < powerSystem.genCursor; i++)
		{
			if (powerSystem.genPool[i].gamma)
			{
				int productId = powerSystem.genPool[i].productId;
				int protoId = powerSystem.factory.entityPool[powerSystem.genPool[i].entityId].protoId;
				if (productId <= 0 && MoreMegaStructure.StarMegaStructureType[index] != 0)
				{
					powerSystem.genPool[i].capacityCurrentTick = 0L;
				}
				else if (productId <= 0 && protoId != 2208)
				{
					powerSystem.genPool[i].capacityCurrentTick = 0L;
				}
				else if (!ProductId2MegaType.ContainsKey(productId) || ProductId2MegaType[productId] != num)
				{
					powerSystem.genPool[i].capacityCurrentTick = 0L;
				}
				else
				{
					num2 += powerSystem.genPool[i].EnergyCap_Gamma_Req(normalized.x, normalized.y, normalized.z, increase, eta);
				}
			}
		}
		if (dysonSphere != null)
		{
			dysonSphere.energyReqCurrentTick += num2;
		}
		return false;
	}

	[HarmonyPatch(typeof(BuildingParameters), "PasteToFactoryObject")]
	[HarmonyPostfix]
	public static void BuildingParametersPastePostPatch(ref BuildingParameters __instance, int objectId, PlanetFactory factory, ref bool __result)
	{
		int num = -objectId;
		Player mainPlayer = factory.gameData.mainPlayer;
		EntityData[] entityPool = factory.entityPool;
		PowerSystem powerSystem = factory.powerSystem;
		if (objectId <= 0 || entityPool[objectId].id != objectId)
		{
			return;
		}
		int powerGenId = entityPool[objectId].powerGenId;
		if (powerGenId != 0 && __instance.type == BuildingType.Gamma && powerSystem.genPool[powerGenId].gamma)
		{
			ItemProto itemProto = LDB.items.Select(entityPool[objectId].protoId);
			if (itemProto != null && __instance.mode0 > 0 && __instance.mode0 != powerSystem.genPool[powerGenId].productId && __instance.mode0 != itemProto.prefabDesc.powerProductId && productHeat.ContainsKey(__instance.mode0))
			{
				factory.TakeBackItemsInEntity(mainPlayer, objectId);
				powerSystem.genPool[powerGenId].productId = __instance.mode0;
				powerSystem.genPool[powerGenId].productHeat = productHeat[__instance.mode0];
				__result = true;
			}
		}
	}

	[HarmonyPatch(typeof(BuildingParameters), "ApplyPrebuildParametersToEntity")]
	[HarmonyPostfix]
	public static void ApplyPrebuildParametersToEntityPostPatch(int entityId, int[] parameters, PlanetFactory factory)
	{
		GameHistoryData history = factory.gameData.history;
		EntityData[] entityPool = factory.entityPool;
		PowerSystem powerSystem = factory.powerSystem;
		if (entityId <= 0 || entityPool[entityId].id != entityId)
		{
			return;
		}
		ItemProto itemProto = LDB.items.Select(entityPool[entityId].protoId);
		PrefabDesc prefabDesc = null;
		if (itemProto != null)
		{
			prefabDesc = itemProto.prefabDesc;
		}
		if (prefabDesc == null)
		{
			return;
		}
		int powerGenId = entityPool[entityId].powerGenId;
		if (powerGenId == 0)
		{
			return;
		}
		if (powerSystem.genPool[powerGenId].gamma && parameters != null && parameters.Length >= 1)
		{
			if (parameters[0] > 0 && parameters[0] != powerSystem.genPool[powerGenId].productId && history.ItemUnlocked(parameters[0]))
			{
				powerSystem.genPool[powerGenId].productId = parameters[0];
				powerSystem.genPool[powerGenId].productHeat = productHeat[parameters[0]];
			}
		}
		else if (powerSystem.genPool[powerGenId].gamma && parameters != null)
		{
		}
	}
}
