namespace MoreMegaStructure;

public enum ECpuWorkEntryExtended
{
	MoreMegaStructure = 44,
	Receiver,
	StarAssembly,
	CargoTransport,
	StarCannon,
	EnemySearch,
	AttackLogic,
	WarpField,
	Statistics,
	Patch,
	StarCannonRender
}
