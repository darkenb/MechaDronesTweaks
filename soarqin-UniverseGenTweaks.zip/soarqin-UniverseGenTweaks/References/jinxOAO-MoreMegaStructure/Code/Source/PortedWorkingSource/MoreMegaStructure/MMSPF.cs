namespace MoreMegaStructure;

public static class MMSPF
{
	public static void AddMMSSamples()
	{
		MMSCPU.MarkMainThread();
		int index = MMSCPU.AddEntry("PF巨构总览", 0);
		MMSCPU.MapEnum(ECpuWorkEntryExtended.MoreMegaStructure, index);
		MMSCPU.MapEnum(ECpuWorkEntryExtended.Receiver, MMSCPU.AddEntry("PF接收器", 1));
		MMSCPU.MapEnum(ECpuWorkEntryExtended.StarAssembly, MMSCPU.AddEntry("PF星际组装厂", 1));
		MMSCPU.MapEnum(ECpuWorkEntryExtended.CargoTransport, MMSCPU.AddEntry("PF货物输送", 2));
		MMSCPU.MapEnum(ECpuWorkEntryExtended.StarCannon, MMSCPU.AddEntry("PF恒星炮", 1));
		MMSCPU.MapEnum(ECpuWorkEntryExtended.AttackLogic, MMSCPU.AddEntry("PF攻击逻辑", 2));
		MMSCPU.MapEnum(ECpuWorkEntryExtended.EnemySearch, MMSCPU.AddEntry("PF寻敌逻辑", 2));
		MMSCPU.MapEnum(ECpuWorkEntryExtended.StarCannonRender, MMSCPU.AddEntry("PF绘制调用", 2));
		MMSCPU.MapEnum(ECpuWorkEntryExtended.WarpField, MMSCPU.AddEntry("PF折跃场", 1));
		MMSCPU.MapEnum(ECpuWorkEntryExtended.Statistics, MMSCPU.AddEntry("PF巨构数据统计", 1));
		MMSCPU.MapEnum(ECpuWorkEntryExtended.Patch, MMSCPU.AddEntry("PF其他补丁", 1));
	}
}
