using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using CommonAPI;
using CommonAPI.Systems;
using HarmonyLib;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using crecheng.DSPModSave;
using xiaoye97;

namespace MoreMegaStructure;

[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
[BepInDependency("starfi5h.plugin.ModFixerOne", BepInDependency.DependencyFlags.HardDependency)]
[BepInPlugin("Gnimaerd.DSP.plugin.MoreMegaStructure", "MoreMegaStructure", "2.0.2")]
public class MoreMegaStructure : BaseUnityPlugin, IModCanSave
{
	public static int modVersion = 200;

	public static int savedModVersion = 193;

	public static bool CompatibilityPatchUnlocked = false;

	public static bool GenesisCompatibility;

	public static bool isBattleActive;

	public static bool TCFVCompatibility = false;

	public static int megaNum = 7;

	public static bool developerMode = false;

	public static List<int> RelatedGammas;

	public static string GUID = "Gnimaerd.DSP.plugin.MoreMegaStructure";

	public static string MODID_tab = "MegaStructures";

	public static int pagenum = 3;

	public static int battlePagenum = 3;

	public static long HashGenDivisor = 40000000L;

	public static int HashBasicSpeedScale = 99;

	public static int HashBonusPerLevel = 1;

	public static long WarpAccDivisor = 10000000L;

	public static int WarpAccMax = 5000;

	public static long multifunctionComponentHeat = 4500000000L;

	public static Color normalTextColor = new Color(1f, 1f, 1f, 1f);

	public static Color currentTextColor = new Color(1f, 0.75f, 0.1f, 1f);

	public static Color disableTextColor = new Color(0.75f, 0.75f, 0.75f, 1f);

	public static bool isRemoteReceiveingGear;

	public static ConfigEntry<bool> NoUIAnimation;

	public static ConfigEntry<double> IASpdFactor;

	public static ConfigEntry<bool> NonlinearEnergy;

	public static ConfigEntry<bool> Support1000Stars;

	public static ConfigEntry<bool> NoWasteResources;

	public static ConfigEntry<bool> ReverseStarCannonShellAlignDirection;

	public static ConfigEntry<bool> ShowIAUIWhenOpenDE;

	public static ConfigEntry<bool> IAStatisticPanelEnabled;

	public static ConfigEntry<bool> StarCannonOnly;

	public static ConfigEntry<bool> EnableLandingProtection;

	public static bool resolutionLower1080 = false;

	public static ResourceData resources;

	public static ResourceData iconResources;

	public static Sprite iconRocketMattD;

	public static Sprite iconRocketScieN;

	public static Sprite iconRocketWarpG;

	public static Sprite iconRocketMegaA;

	public static Sprite iconRocketCrysM;

	public static Sprite iconGravityGen;

	public static Sprite iconConstrainRing;

	public static Sprite iconGravityDrill;

	public static Sprite iconIACompo;

	public static Sprite iconInterCompo;

	public static Sprite iconPhotonProbe;

	public static Sprite iconQuanComp;

	public static Sprite iconResDisc;

	public static Sprite iconTunnExciter;

	public static Sprite iconQuickAssembly;

	public static Sprite iconQuickBelt;

	public static Sprite iconQuickChemical;

	public static Sprite iconQuickCollider;

	public static Sprite iconQuickLab;

	public static Sprite iconQuickPLog;

	public static Sprite iconQuickILog;

	public static Sprite iconQuickPower;

	public static Sprite iconQuickReactor;

	public static Sprite iconQuickRefinery;

	public static Sprite iconQuickSmelter;

	public static Sprite iconQuickSorter;

	public static Sprite iconHashes;

	public static Sprite iconWarpBroadcast;

	public static Sprite iconReceiverIron;

	public static Sprite iconReceiverCopper;

	public static Sprite iconReceiverTitanium;

	public static Sprite iconReceiverSilicon;

	public static Sprite iconReceiverMagore;

	public static Sprite iconReceiverCasimir;

	public static Sprite iconReceiverIC;

	public static Sprite iconReceiverScience;

	public static Sprite iconReceiverWarp;

	public static Sprite iconReceiverCoal;

	public static Sprite iconReceiverGrating;

	public static Text LeftDysonCloudTitle;

	public static Text LeftDysonCloudBluePrintText;

	public static Text LeftDysonShellTitle;

	public static Text LeftDysonShellBluePrintText;

	public static Text LeftDysonShellOrbitTitleText;

	public static Text RightDysonTitle;

	public static Text RightStarPowRatioText;

	public static Text RightMaxPowGenText;

	public static Text RightMaxPowGenValueText;

	public static Text RightDysonBluePrintText;

	public static Text SpSailAmountText;

	public static Text SpNodeAmountText;

	public static Text SpSailLifeTimeText;

	public static Text SpSailLifeTimeBarText;

	public static Text SpConsumePowText;

	public static Text SpSwarmPowGenText;

	public static Text SpShellPowGenText;

	public static Text SpEnergySatisfiedLabelText;

	public static Text SoSailAmountText;

	public static Text SoSailPowGenText;

	public static Text SoSailLifeTimeText;

	public static Text SoSailLifeTimeBarText;

	public static Text LyPowGenText;

	public static Text NdPowGenText;

	public static Text FrPowGenText;

	public static Text ShPowGenText;

	public static Text ReceiverUIButton2Text;

	public static GameObject setMegaGroupObj;

	public static GameObject set2DysonButtonObj;

	public static GameObject set2MatDecomButtonObj;

	public static GameObject set2SciNexusButtonObj;

	public static GameObject set2WarpFieldGenButtonObj;

	public static GameObject set2MegaAssemButtonObj;

	public static GameObject set2CrystalMinerButtonObj;

	public static GameObject set2StarCannonButtonObj;

	public static GameObject rightBarObj;

	public static GameObject LeftMegaBuildWarning;

	public static GameObject DysonEditorPowerDescLabel4BarObj;

	public static GameObject selectAutoReceiveGearLimitObj;

	public static GameObject selectAutoReceiveGearLimitLabelObj;

	public static GameObject selectAutoReceiveGearLimitComboBoxObj;

	public static Button set2DysonButton;

	public static Button set2MatDecomButton;

	public static Button set2SciNexusButton;

	public static Button set2WarpFieldGenButton;

	public static Button set2MegaAssemButton;

	public static Button set2CrystalMinerButton;

	public static Button set2StarCannonButton;

	public static Transform set2DysonButtonTextTrans;

	public static Transform set2MatDecomButtonTextTrans;

	public static Transform set2SciNexusButtonTextTrans;

	public static Transform set2WarpFieldGenButtonTextTrans;

	public static Transform set2MegaAssemButtonTextTrans;

	public static Transform set2CrystalMinerButtonTextTrans;

	public static Transform set2StarCannonButtonTextTrans;

	public static UIComboBox selectAutoReceiveGearLimitComboBox;

	public static Material setButtonTextNormMat;

	public static Material setButtonTextAlphaMat;

	public static Text SetMegaStructureLabelText;

	public static Text SetMegaStructureWarningText;

	public static StarData curStar;

	public static DysonSphere curDysonSphere;

	public static int WarpBuiltStarIndex;

	public static int CannonBuiltStarIndex;

	public static long hashGenByAllSN;

	public static int resolutionY = 1080;

	public static System.Random randSeed = new System.Random();

	public const int MegaArrayOldLen = 1000;

	public const int MegaArrayLength = 1200;

	public static int[] StarMegaStructureType = new int[1200];

	public static int maxAutoReceiveGear = 1000;

	public static long autoReceiveGearProgress;

	public static int pilerLvl = 1;

	public static bool KeyNPressTime = false;

	public static int testHitIndex = 0;

	public void Awake()
	{
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Expected O, but got Unknown
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Expected O, but got Unknown
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Expected O, but got Unknown
		try
		{
			using (ProtoRegistry.StartModLoad(GUID))
			{
				string directoryName = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
				resources = new ResourceData(GUID, "MegaStructureTab", directoryName);
				resources.LoadAssetBundle("mmstabicon");
				ProtoRegistry.AddResource(resources);
				pagenum = TabSystem.RegisterTab(MODID_tab + ":" + MODID_tab + "Tab", new TabData("MegaStructures", "Assets/MegaStructureTab/megaStructureTabIcon"));
			}
		}
		catch (Exception)
		{
			pagenum = TabSystem.RegisterTab(MODID_tab + ":" + MODID_tab + "Tab", new TabData("MegaStructures", "Assets/MegaStructureTab/megaStructureTabIcon"));
		}
		battlePagenum = pagenum;
		NoUIAnimation = base.Config.Bind("config", "NoUIAnimation", defaultValue: false, "Turn this to true if your want to show and hide buttons without animations. 如果你想让按钮的出现和隐藏没有动画立即完成，将此项设置为true。");
		IASpdFactor = base.Config.Bind("config", "InterstellarAssemblySpeedFactor", 0.2, "Higher will make the interstellar assembly work faster with the same energy. 在同样的能量水平下，此项越高，星际组装厂的工作速度越快。可以是小数。");
		base.Config.Bind("config", "NonlinearEnergyAssignmentAdjust", defaultValue: true, "This config is no longer working. 此项已弃用。");
		NonlinearEnergy = base.Config.Bind("config", "NonlinearEnergyAssignmentAdjust2", defaultValue: true, "Turn this to true will let you adjust the energy allocation of the Interstellar Assembly more finely within the range of lower value. 将此项设置为true能够使你在调整星际组装厂配方的能量分配时，在较低分配比例的区间内更加精细地调整。");
		Support1000Stars = base.Config.Bind("config", "Support1000Stars", defaultValue: false, "Turn this to true will let the Interstellar Assemblies support upto 1024 stars (default is 100), but this might slow down your game or your save/load speed. 将此项设置为true能够使星际组装厂支持最多1024个星系（默认只支持100以下），但这可能使你的游戏速度或存读档速度被拖慢。");
		NoWasteResources = base.Config.Bind("config", "NoWasteResources", defaultValue: true, "Turn this to false might slightly increase the game speed. But this will cause: if one of the various materials required by a recipe in Interstellar Assembly is insufficient, (its supply cannot meet the speed of full-speed production). Although the actual output will slow down, other sufficient materials may still be consumed at full speed, which means that they may be wasted.  将此项设置为false可能会轻微提升游戏速度，但这会导致：当星际组装厂中的部分原材料不支持满速消耗时，虽然产出速度按照最低供应原材料的速度为准，但其他充足供应的原材料仍被满速消耗而产生浪费。");
		ReverseStarCannonShellAlignDirection = base.Config.Bind("config", "ReverseStarCannonShellAlignDirection", defaultValue: false, "Turn this to true will reverse the align direction of all the shell of star cannon when firing, which means the south pole (of the shells) will point to the target star rather than the north pole.  将此项设置为true会反转恒星炮开火时壳层的对齐方向，这意味着所有壳层的南极将指向目标恒星开火（而非默认的北极）。如果你的炮口造反了，可以尝试更改此项设置。");
		ShowIAUIWhenOpenDE = base.Config.Bind("config", "AutoShowDEUI", defaultValue: true, "Set this to true will force to show the Interstellar Assembly's UI when opening/switching its Megastructure Editor Panel. Set to false will maintain the IA UI's last state. 将此项设置为true将在每次打开星际组装厂的巨构编辑器面板时，强制显示UI。设置为false则会维持上次的状态。");
		IAStatisticPanelEnabled = base.Config.Bind("config", "InterstellarAssemblyStatisticPanelEnabled", defaultValue: true, "If the Interstellar Assembly's production statistics have a excluive page. 星际组装厂的生产数据是否会拥有一个独立的面板页。");
		StarCannonOnly = base.Config.Bind("config", "StarCannonOnly", defaultValue: false, "Set this to true will disable all mega structures except DysonSphere and StarCannon. 将此项设置为true将禁用除了戴森球和恒星炮以外的任何巨构。");
		EnableLandingProtection = base.Config.Bind("config", "EnableLandingProtection", defaultValue: true, "If you've installed the CustomCreateBirthStar or GalacticScale, enabling this option will prevent possible issues with logistics ships being unable to land, but it may cause non-warp speeds of logistics ships to be very fast in the early stages of the game. 若安装遗产mod或GalacticScale，开启此项将防止可能产生的物流船无法降落的问题，但会导致物流船非曲速的速度在游戏初期就很快。");
		UIStatisticsPatcher.enabled = IAStatisticPanelEnabled.Value;
		if (UIStatisticsPatcher.forceBanned)
		{
			UIStatisticsPatcher.enabled = false;
		}
		iconRocketMattD = Resources.Load<Sprite>("Assets/MegaStructureTab/rocketMatter");
		iconRocketScieN = Resources.Load<Sprite>("Assets/MegaStructureTab/rocketScience");
		iconRocketWarpG = Resources.Load<Sprite>("Assets/MegaStructureTab/rocketWarp");
		iconRocketMegaA = Resources.Load<Sprite>("Assets/MegaStructureTab/rocketAssembly");
		iconRocketCrysM = Resources.Load<Sprite>("Assets/MegaStructureTab/rocketCrystal");
		iconGravityGen = Resources.Load<Sprite>("Assets/MegaStructureTab/gravitygenerator");
		iconConstrainRing = Resources.Load<Sprite>("Assets/MegaStructureTab/constrainring");
		iconGravityDrill = Resources.Load<Sprite>("Assets/MegaStructureTab/gravitydrill2");
		iconIACompo = Resources.Load<Sprite>("Assets/MegaStructureTab/iacomponent");
		iconInterCompo = Resources.Load<Sprite>("Assets/MegaStructureTab/integratedcomponents");
		iconPhotonProbe = Resources.Load<Sprite>("Assets/MegaStructureTab/photonprobeflipsmall");
		iconQuanComp = Resources.Load<Sprite>("Assets/MegaStructureTab/quantumcomputer3");
		iconResDisc = Resources.Load<Sprite>("Assets/MegaStructureTab/resonancedisc");
		iconTunnExciter = Resources.Load<Sprite>("Assets/MegaStructureTab/tunnelingexciter2");
		iconQuickAssembly = Resources.Load<Sprite>("Assets/MegaStructureTab/Rassembly");
		iconQuickBelt = Resources.Load<Sprite>("Assets/MegaStructureTab/Rbelt");
		iconQuickChemical = Resources.Load<Sprite>("Assets/MegaStructureTab/Rchemical2");
		iconQuickCollider = Resources.Load<Sprite>("Assets/MegaStructureTab/Rcollider");
		iconQuickLab = Resources.Load<Sprite>("Assets/MegaStructureTab/Rlab");
		iconQuickPLog = Resources.Load<Sprite>("Assets/MegaStructureTab/Rlogistic");
		iconQuickILog = Resources.Load<Sprite>("Assets/MegaStructureTab/Rstellalogistic");
		iconQuickPower = Resources.Load<Sprite>("Assets/MegaStructureTab/Rpower");
		iconQuickReactor = Resources.Load<Sprite>("Assets/MegaStructureTab/Rreactor");
		iconQuickRefinery = Resources.Load<Sprite>("Assets/MegaStructureTab/Rrefinery");
		iconQuickSmelter = Resources.Load<Sprite>("Assets/MegaStructureTab/Rsmelter");
		iconQuickSorter = Resources.Load<Sprite>("Assets/MegaStructureTab/Rsorter");
		iconHashes = Resources.Load<Sprite>("Assets/MegaStructureTab/HashPoints");
		iconWarpBroadcast = Resources.Load<Sprite>("Assets/MegaStructureTab/WarpFieldBroadcast");
		iconReceiverIron = Resources.Load<Sprite>("Assets/MegaStructureTab/Ciron");
		iconReceiverCopper = Resources.Load<Sprite>("Assets/MegaStructureTab/Ccopper");
		iconReceiverTitanium = Resources.Load<Sprite>("Assets/MegaStructureTab/Ctitanium");
		iconReceiverSilicon = Resources.Load<Sprite>("Assets/MegaStructureTab/Csilicon");
		iconReceiverMagore = Resources.Load<Sprite>("Assets/MegaStructureTab/Cmagore");
		iconReceiverCasimir = Resources.Load<Sprite>("Assets/MegaStructureTab/Ccrystal");
		iconReceiverIC = Resources.Load<Sprite>("Assets/MegaStructureTab/Cic");
		iconReceiverScience = Resources.Load<Sprite>("Assets/MegaStructureTab/Cscience");
		iconReceiverWarp = Resources.Load<Sprite>("Assets/MegaStructureTab/Cwarp");
		iconReceiverCoal = Resources.Load<Sprite>("Assets/MegaStructureTab/Ccoal");
		iconReceiverGrating = Resources.Load<Sprite>("Assets/MegaStructureTab/Cgrating");
		Harmony.CreateAndPatchAll(typeof(MoreMegaStructure));
		Harmony.CreateAndPatchAll(typeof(StarCannon));
		Harmony.CreateAndPatchAll(typeof(ReceiverPatchers));
		Harmony.CreateAndPatchAll(typeof(StarAssembly));
		Harmony.CreateAndPatchAll(typeof(UIReceiverPatchers));
		if (UIStatisticsPatcher.enabled)
		{
			Harmony.CreateAndPatchAll(typeof(UIStatisticsPatcher));
		}
		if (UIBuildMenuPatcher.enabled)
		{
			Harmony.CreateAndPatchAll(typeof(UIBuildMenuPatcher));
		}
		Harmony.CreateAndPatchAll(typeof(UIStarCannon));
		Harmony.CreateAndPatchAll(typeof(UIMechaWindowPatcher));
		Harmony.CreateAndPatchAll(typeof(PerformanceMonitorPatcher));
		Harmony.CreateAndPatchAll(typeof(UIPerformancePanelPatcher));
		Harmony.CreateAndPatchAll(typeof(UIDialogPatch));
		Harmony.CreateAndPatchAll(typeof(UIStationWindowPatcher));
		Harmony.CreateAndPatchAll(typeof(WarpArray));
		Harmony.CreateAndPatchAll(typeof(UIWarpArray));
		MMSProtos.ChangeReceiverRelatedStringProto();
		MMSProtos.AddTranslateUILabel();
		MMSProtos.AddTranslateStructureName();
		MMSProtos.AddTranslateProtoNames1();
		MMSProtos.AddTranslateProtoNames2();
		MMSProtos.AddTranslateProtoNames3();
		MMSProtos.AddTranslateProtoNames4();
		LDBTool.PreAddDataAction = (Action)Delegate.Combine(LDBTool.PreAddDataAction, new Action(MMSProtos.AddNewItems));
		LDBTool.PreAddDataAction = (Action)Delegate.Combine(LDBTool.PreAddDataAction, new Action(MMSProtos.AddNewItems2));
		LDBTool.PostAddDataAction = (Action)Delegate.Combine(LDBTool.PostAddDataAction, new Action(MMSProtos.AddGenesisRecipes));
		LDBTool.PreAddDataAction = (Action)Delegate.Combine(LDBTool.PreAddDataAction, new Action(MMSProtos.AddReceivers));
		LDBTool.PostAddDataAction = (Action)Delegate.Combine(LDBTool.PostAddDataAction, new Action(MMSProtos.RefreshInitAll));
		LDBTool.EditDataAction = (Action<Proto>)Delegate.Combine(LDBTool.EditDataAction, new Action<Proto>(MMSProtos.EditOriRR));
		if (CompatibilityPatchUnlocked)
		{
			AccessTools.StaticFieldRefAccess<ConfigFile>(typeof(LDBTool), "CustomID").Clear();
			AccessTools.StaticFieldRefAccess<ConfigFile>(typeof(LDBTool), "CustomGridIndex").Clear();
			AccessTools.StaticFieldRefAccess<ConfigFile>(typeof(LDBTool), "CustomStringZHCN").Clear();
			AccessTools.StaticFieldRefAccess<ConfigFile>(typeof(LDBTool), "CustomStringENUS").Clear();
			AccessTools.StaticFieldRefAccess<ConfigFile>(typeof(LDBTool), "CustomStringFRFR").Clear();
		}
		MMSPF.AddMMSSamples();
	}

	public void Start()
	{
		InitWhenStart();
		GetVanillaUITexts();
		InitMegaSetUI();
		LateInitOtherUI();
		StarAssembly.InitAll();
		ReceiverPatchers.InitRawData();
		UIReceiverPatchers.InitAll();
		if (UIBuildMenuPatcher.enabled)
		{
			UIBuildMenuPatcher.InitAll();
		}
		UIStarCannon.InitAll();
		UIStationWindowPatcher.InitAll();
		if (isBattleActive)
		{
			Harmony.CreateAndPatchAll(typeof(StarCannon));
		}
	}

	public void Update()
	{
		Vector3 mousePosition = Input.mousePosition;
		int num = Math.Max(0, resolutionY - 1080);
		if (mousePosition.x <= MegaButtonGroupBehaviour.currentX + 280f && mousePosition.y <= (float)(270 + num))
		{
			MegaButtonGroupBehaviour.ShowSetMegaGroup();
		}
		else
		{
			MegaButtonGroupBehaviour.HideSetMegaGroup();
		}
		MegaButtonGroupBehaviour.SetMegaGroupMove();
		try
		{
			pilerLvl = GameMain.history.stationPilerLevel;
		}
		catch (Exception)
		{
			pilerLvl = 1;
		}
		if (Input.GetKeyDown(KeyCode.R) && UIRoot.instance.uiGame.starmap.active && !VFInput.inputing)
		{
			StarCannon.OnFireButtonClick();
		}
		if (developerMode && Input.GetKeyDown(KeyCode.N))
		{
			Utils.Log(DSPGame.globalOption.languageLCID.ToString());
		}
	}

	public static void InitWhenStart()
	{
		StarMegaStructureType = new int[1200];
		for (int i = 0; i < 1200; i++)
		{
			StarMegaStructureType[i] = 0;
		}
	}

	public static void GetVanillaUITexts()
	{
		try
		{
			GameObject obj = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy/swarm/title-text");
			GameObject gameObject = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy/swarm/blueprint/text");
			LeftDysonCloudTitle = obj.GetComponent<Text>();
			LeftDysonCloudBluePrintText = gameObject.GetComponent<Text>();
		}
		catch (Exception)
		{
		}
		try
		{
			GameObject obj2 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy/layers/title-text");
			GameObject gameObject2 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy/layers/blueprint-group/blueprint-text");
			GameObject gameObject3 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy/layers/buttons-group/orbit-title-text");
			LeftDysonShellTitle = obj2.GetComponent<Text>();
			LeftDysonShellBluePrintText = gameObject2.GetComponent<Text>();
			LeftDysonShellOrbitTitleText = gameObject3.GetComponent<Text>();
		}
		catch (Exception)
		{
		}
		try
		{
			RightDysonTitle = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/overview-group/name-text").GetComponent<Text>();
			RightStarPowRatioText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/overview-group/star-label").GetComponent<Text>();
			RightMaxPowGenText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/overview-group/gen-label").GetComponent<Text>();
			RightMaxPowGenValueText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/overview-group/gen-value").GetComponent<Text>();
			RightDysonBluePrintText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/overview-group/blueprint").GetComponent<Text>();
		}
		catch (Exception)
		{
		}
		try
		{
			SpSailAmountText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/sphere-group/prop-label-0").GetComponent<Text>();
			SpNodeAmountText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/sphere-group/prop-label-1").GetComponent<Text>();
			SpSailLifeTimeText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/sphere-group/sail-stat/sail-histogram/title").GetComponent<Text>();
			SpSailLifeTimeBarText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/sphere-group/sail-stat/bar-group/title").GetComponent<Text>();
			SpConsumePowText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/sphere-group/power-desc/label-2").GetComponent<Text>();
			SpSwarmPowGenText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/sphere-group/power-desc/label-3").GetComponent<Text>();
			SpShellPowGenText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/sphere-group/power-desc/label-4").GetComponent<Text>();
			SpEnergySatisfiedLabelText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/sphere-group/power-desc/Graph/cons-circle/label-c").GetComponent<Text>();
		}
		catch (Exception)
		{
		}
		try
		{
			SoSailAmountText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/swarm-orbit-group/self-info/prop-label-0").GetComponent<Text>();
			SoSailPowGenText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/swarm-orbit-group/self-info/prop-label-1").GetComponent<Text>();
			SoSailLifeTimeText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/swarm-orbit-group/sail-stat/sail-histogram/title").GetComponent<Text>();
			SoSailLifeTimeBarText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/swarm-orbit-group/sail-stat/bar-group/title").GetComponent<Text>();
			LyPowGenText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/layer-group/self-info/prop-label-4").GetComponent<Text>();
			NdPowGenText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/node-group/self-info/prop-label-5").GetComponent<Text>();
			DysonEditorPowerDescLabel4BarObj = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/sphere-group/power-desc/label-4/legend-4");
		}
		catch (Exception)
		{
		}
		try
		{
			FrPowGenText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/frame-group/self-info/prop-label-0").GetComponent<Text>();
			ShPowGenText = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/shell-group/self-info/prop-label-0").GetComponent<Text>();
		}
		catch (Exception)
		{
		}
		try
		{
			ReceiverUIButton2Text = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Power Generator Window/ray-receiver/switch-button-2/button-text").GetComponent<Text>();
			ReceiverUIButton2Text.text = "物质合成".Translate();
		}
		catch (Exception)
		{
		}
	}

	public static void InitMegaSetUI()
	{
		try
		{
			float height = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel").GetComponent<RectTransform>().rect.height;
			int num = (int)(270f - height);
			int num2 = Math.Min((int)(-940f * height / 1080f), -835);
			GameObject gameObject = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy");
			setMegaGroupObj = new GameObject("mega-buttons");
			setMegaGroupObj.transform.SetParent(gameObject.transform);
			setMegaGroupObj.transform.localPosition = new Vector3(0f, num, 0f);
			setMegaGroupObj.transform.localScale = new Vector3(1f, 1f, 1f);
			GameObject original = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy/layers/title-text");
			LeftMegaBuildWarning = UnityEngine.Object.Instantiate(original);
			LeftMegaBuildWarning.name = "settype-warning";
			LeftMegaBuildWarning.transform.SetParent(gameObject.transform, worldPositionStays: false);
			LeftMegaBuildWarning.transform.localPosition = new Vector3(280f, num2, 0f);
			LeftMegaBuildWarning.GetComponent<RectTransform>().pivot = new Vector2(1f, 1f);
			LeftMegaBuildWarning.GetComponent<RectTransform>().anchorMin = new Vector2(1f, 1f);
			LeftMegaBuildWarning.GetComponent<RectTransform>().anchorMax = new Vector2(1f, 1f);
			LeftMegaBuildWarning.SetActive(value: true);
			SetMegaStructureWarningText = LeftMegaBuildWarning.GetComponent<Text>();
			SetMegaStructureWarningText.GetComponent<RectTransform>().sizeDelta = new Vector2(270f, 100f);
			SetMegaStructureWarningText.text = "鼠标触碰左侧黄条以规划巨构".Translate();
			SetMegaStructureWarningText.alignment = TextAnchor.MiddleCenter;
			SetMegaStructureWarningText.fontSize = 16;
			SetMegaStructureWarningText.color = new Color(1f, 1f, 0.57f, 1f);
			rightBarObj = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/inspector/sphere-group/sail-stat/bar-group/bar-orange"), setMegaGroupObj.transform);
			rightBarObj.name = "right-bar";
			rightBarObj.transform.localPosition = new Vector3(270f, 0f, 0f);
			rightBarObj.transform.localScale = new Vector3(1f, 1f, 1f);
			rightBarObj.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
			rightBarObj.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 0f);
			rightBarObj.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 0f);
			rightBarObj.GetComponent<Image>().fillAmount = 1f;
			rightBarObj.GetComponent<RectTransform>().sizeDelta = new Vector2(8f, 243f);
			GameObject obj = UnityEngine.Object.Instantiate(original);
			obj.name = "title3";
			obj.transform.SetParent(setMegaGroupObj.transform, worldPositionStays: false);
			obj.transform.localPosition = new Vector3(22f, 0f, 0f);
			SetMegaStructureLabelText = obj.GetComponent<Text>();
			SetMegaStructureLabelText.text = "规划巨构建筑类型";
			GameObject original2 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy/layers/buttons-group/buttons/add-button");
			set2DysonButtonObj = UnityEngine.Object.Instantiate(original2);
			set2DysonButtonObj.SetActive(value: true);
			set2DysonButtonObj.name = "set-mega-0";
			set2DysonButtonObj.transform.SetParent(setMegaGroupObj.transform, worldPositionStays: false);
			set2DysonButtonObj.transform.localPosition = new Vector3(30f, -35f, 0f);
			set2DysonButtonObj.GetComponent<RectTransform>().sizeDelta = new Vector2(220f, 28f);
			set2DysonButtonTextTrans = set2DysonButtonObj.transform.Find("Text");
			set2DysonButton = set2DysonButtonObj.GetComponent<Button>();
			set2DysonButton.interactable = true;
			set2MatDecomButtonObj = UnityEngine.Object.Instantiate(original2);
			set2MatDecomButtonObj.SetActive(value: true);
			set2MatDecomButtonObj.name = "set-mega-1";
			set2MatDecomButtonObj.transform.SetParent(setMegaGroupObj.transform, worldPositionStays: false);
			set2MatDecomButtonObj.transform.localPosition = new Vector3(30f, -65f, 0f);
			set2MatDecomButtonObj.GetComponent<RectTransform>().sizeDelta = new Vector2(220f, 28f);
			set2MatDecomButtonTextTrans = set2MatDecomButtonObj.transform.Find("Text");
			set2MatDecomButton = set2MatDecomButtonObj.GetComponent<Button>();
			set2MatDecomButton.interactable = true;
			set2MatDecomButtonObj.GetComponent<UIButton>().tips.tipTitle = "功能说明题目".Translate();
			set2MatDecomButtonObj.GetComponent<UIButton>().tips.tipText = "物质解压器功能文本".Translate();
			set2MatDecomButtonObj.GetComponent<UIButton>().tips.delay = 0.3f;
			set2MatDecomButtonObj.GetComponent<UIButton>().tips.width = 280;
			set2MatDecomButtonObj.GetComponent<UIButton>().tips.corner = 9;
			set2SciNexusButtonObj = UnityEngine.Object.Instantiate(original2);
			set2SciNexusButtonObj.SetActive(value: true);
			set2SciNexusButtonObj.name = "set-mega-2";
			set2SciNexusButtonObj.transform.SetParent(setMegaGroupObj.transform, worldPositionStays: false);
			set2SciNexusButtonObj.transform.localPosition = new Vector3(30f, -95f, 0f);
			set2SciNexusButtonObj.GetComponent<RectTransform>().sizeDelta = new Vector2(220f, 28f);
			set2SciNexusButtonTextTrans = set2SciNexusButtonObj.transform.Find("Text");
			set2SciNexusButton = set2SciNexusButtonObj.GetComponent<Button>();
			set2SciNexusButton.interactable = true;
			set2SciNexusButtonObj.GetComponent<UIButton>().tips.tipTitle = "功能说明题目".Translate();
			set2SciNexusButtonObj.GetComponent<UIButton>().tips.tipText = "科学枢纽功能文本".Translate();
			set2SciNexusButtonObj.GetComponent<UIButton>().tips.delay = 0.3f;
			set2SciNexusButtonObj.GetComponent<UIButton>().tips.width = 260;
			set2SciNexusButtonObj.GetComponent<UIButton>().tips.corner = 9;
			set2WarpFieldGenButtonObj = UnityEngine.Object.Instantiate(original2);
			set2WarpFieldGenButtonObj.SetActive(value: true);
			set2WarpFieldGenButtonObj.name = "set-mega-3";
			set2WarpFieldGenButtonObj.transform.SetParent(setMegaGroupObj.transform, worldPositionStays: false);
			set2WarpFieldGenButtonObj.transform.localPosition = new Vector3(30f, -125f, 0f);
			set2WarpFieldGenButtonObj.GetComponent<RectTransform>().sizeDelta = new Vector2(220f, 28f);
			set2WarpFieldGenButtonTextTrans = set2WarpFieldGenButtonObj.transform.Find("Text");
			set2WarpFieldGenButton = set2WarpFieldGenButtonObj.GetComponent<Button>();
			set2WarpFieldGenButton.interactable = true;
			set2WarpFieldGenButtonObj.GetComponent<UIButton>().tips.tipTitle = "功能说明题目".Translate();
			set2WarpFieldGenButtonObj.GetComponent<UIButton>().tips.tipText = "折跃场广播阵列功能文本".Translate();
			set2WarpFieldGenButtonObj.GetComponent<UIButton>().tips.delay = 0.3f;
			set2WarpFieldGenButtonObj.GetComponent<UIButton>().tips.width = 260;
			set2WarpFieldGenButtonObj.GetComponent<UIButton>().tips.corner = 9;
			set2MegaAssemButtonObj = UnityEngine.Object.Instantiate(original2);
			set2MegaAssemButtonObj.SetActive(value: true);
			set2MegaAssemButtonObj.name = "set-mega-4";
			set2MegaAssemButtonObj.transform.SetParent(setMegaGroupObj.transform, worldPositionStays: false);
			set2MegaAssemButtonObj.transform.localPosition = new Vector3(30f, -155f, 0f);
			set2MegaAssemButtonObj.GetComponent<RectTransform>().sizeDelta = new Vector2(220f, 28f);
			set2MegaAssemButtonTextTrans = set2MegaAssemButtonObj.transform.Find("Text");
			set2MegaAssemButton = set2MegaAssemButtonObj.GetComponent<Button>();
			set2MegaAssemButton.interactable = true;
			set2MegaAssemButtonObj.GetComponent<UIButton>().tips.tipTitle = "功能说明题目".Translate();
			set2MegaAssemButtonObj.GetComponent<UIButton>().tips.tipText = "星际组装厂功能文本".Translate();
			set2MegaAssemButtonObj.GetComponent<UIButton>().tips.delay = 0.3f;
			set2MegaAssemButtonObj.GetComponent<UIButton>().tips.width = 260;
			set2MegaAssemButtonObj.GetComponent<UIButton>().tips.corner = 9;
			set2CrystalMinerButtonObj = UnityEngine.Object.Instantiate(original2);
			set2CrystalMinerButtonObj.SetActive(value: true);
			set2CrystalMinerButtonObj.name = "set-mega-5";
			set2CrystalMinerButtonObj.transform.SetParent(setMegaGroupObj.transform, worldPositionStays: false);
			set2CrystalMinerButtonObj.transform.localPosition = new Vector3(30f, -185f, 0f);
			set2CrystalMinerButtonObj.GetComponent<RectTransform>().sizeDelta = new Vector2(220f, 28f);
			set2CrystalMinerButtonTextTrans = set2CrystalMinerButtonObj.transform.Find("Text");
			set2CrystalMinerButton = set2CrystalMinerButtonObj.GetComponent<Button>();
			set2CrystalMinerButton.interactable = true;
			set2CrystalMinerButtonObj.GetComponent<UIButton>().tips.tipTitle = "功能说明题目".Translate();
			set2CrystalMinerButtonObj.GetComponent<UIButton>().tips.tipText = "晶体重构器功能文本".Translate();
			set2CrystalMinerButtonObj.GetComponent<UIButton>().tips.delay = 0.3f;
			set2CrystalMinerButtonObj.GetComponent<UIButton>().tips.width = 260;
			set2CrystalMinerButtonObj.GetComponent<UIButton>().tips.corner = 9;
			set2StarCannonButtonObj = UnityEngine.Object.Instantiate(original2);
			set2StarCannonButtonObj.SetActive(value: true);
			set2StarCannonButtonObj.name = "set-mega-6";
			set2StarCannonButtonObj.transform.SetParent(setMegaGroupObj.transform, worldPositionStays: false);
			set2StarCannonButtonObj.transform.localPosition = new Vector3(30f, -215f, 0f);
			set2StarCannonButtonObj.GetComponent<RectTransform>().sizeDelta = new Vector2(220f, 28f);
			set2StarCannonButtonTextTrans = set2StarCannonButtonObj.transform.Find("Text");
			set2StarCannonButton = set2StarCannonButtonObj.GetComponent<Button>();
			set2StarCannonButton.interactable = true;
			set2StarCannonButtonObj.GetComponent<UIButton>().tips.tipTitle = "恒星炮设计说明题目".Translate();
			set2StarCannonButtonObj.GetComponent<UIButton>().tips.tipText = "恒星炮设计说明文本".Translate();
			set2StarCannonButtonObj.GetComponent<UIButton>().tips.delay = 0.3f;
			set2StarCannonButtonObj.GetComponent<UIButton>().tips.width = 520;
			set2StarCannonButtonObj.GetComponent<UIButton>().tips.corner = 9;
			set2DysonButton.onClick.RemoveAllListeners();
			set2DysonButton.onClick.AddListener(delegate
			{
				SetMegaStructure(0);
			});
			set2MatDecomButton.onClick.RemoveAllListeners();
			set2MatDecomButton.onClick.AddListener(delegate
			{
				SetMegaStructure(1);
			});
			set2SciNexusButton.onClick.RemoveAllListeners();
			set2SciNexusButton.onClick.AddListener(delegate
			{
				SetMegaStructure(2);
			});
			set2WarpFieldGenButton.onClick.RemoveAllListeners();
			set2WarpFieldGenButton.onClick.AddListener(delegate
			{
				SetMegaStructure(3);
			});
			set2MegaAssemButton.onClick.RemoveAllListeners();
			set2MegaAssemButton.onClick.AddListener(delegate
			{
				SetMegaStructure(4);
			});
			set2CrystalMinerButton.onClick.RemoveAllListeners();
			set2CrystalMinerButton.onClick.AddListener(delegate
			{
				SetMegaStructure(5);
			});
			set2StarCannonButton.onClick.RemoveAllListeners();
			set2StarCannonButton.onClick.AddListener(delegate
			{
				SetMegaStructure(6);
			});
		}
		catch (Exception)
		{
		}
	}

	public static void LateInitOtherUI()
	{
		if (!(selectAutoReceiveGearLimitObj != null))
		{
			selectAutoReceiveGearLimitObj = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Mecha Window/information/movement-panel"));
			selectAutoReceiveGearLimitObj.name = "gear-max-num";
			selectAutoReceiveGearLimitObj.transform.SetParent(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Mecha Window/information").transform);
			selectAutoReceiveGearLimitObj.transform.localScale = new Vector3(1f, 1f, 1f);
			selectAutoReceiveGearLimitObj.transform.localPosition = new Vector3(-240f, -390f, 0f);
			selectAutoReceiveGearLimitObj.SetActive(value: true);
			UnityEngine.Object.Destroy(selectAutoReceiveGearLimitObj.transform.Find("title").gameObject);
			UnityEngine.Object.Destroy(selectAutoReceiveGearLimitObj.transform.Find("value-1").gameObject);
			UnityEngine.Object.Destroy(selectAutoReceiveGearLimitObj.transform.Find("label-2").gameObject);
			selectAutoReceiveGearLimitLabelObj = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Statistics Window/performance-bg/cpu-panel/Scroll View/Viewport/Content/label"), selectAutoReceiveGearLimitObj.transform);
			Text component = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Mecha Window/information/construction-panel/label-1").GetComponent<Text>();
			Text component2 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Mecha Window/information/construction-panel/title").GetComponent<Text>();
			selectAutoReceiveGearLimitObj.GetComponent<RectTransform>().sizeDelta = new Vector2(0f, 63f);
			UnityEngine.Object.DestroyImmediate(selectAutoReceiveGearLimitObj.GetComponent<EventTrigger>());
			selectAutoReceiveGearLimitLabelObj.name = "title";
			selectAutoReceiveGearLimitLabelObj.SetActive(value: true);
			selectAutoReceiveGearLimitLabelObj.transform.localPosition = new Vector3(10f, -6f, 0f);
			selectAutoReceiveGearLimitLabelObj.GetComponent<Text>().font = component.font;
			selectAutoReceiveGearLimitLabelObj.GetComponent<Text>().fontSize = 13;
			selectAutoReceiveGearLimitLabelObj.GetComponent<Text>().text = "远程折跃多功能组件限制".Translate();
			selectAutoReceiveGearLimitLabelObj.GetComponent<Text>().material = component2.material;
			selectAutoReceiveGearLimitLabelObj.GetComponent<Text>().color = component2.color;
			selectAutoReceiveGearLimitComboBoxObj = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Statistics Window/dyson-bg/top/TimeComboBox"), selectAutoReceiveGearLimitObj.transform);
			selectAutoReceiveGearLimitComboBoxObj.name = "combo-box";
			selectAutoReceiveGearLimitComboBoxObj.SetActive(value: true);
			selectAutoReceiveGearLimitComboBoxObj.transform.localPosition = new Vector3(130f, -30f, 0f);
			selectAutoReceiveGearLimitComboBoxObj.transform.localScale = new Vector3(0.8f, 0.8f, 0.8f);
			selectAutoReceiveGearLimitComboBox = selectAutoReceiveGearLimitComboBoxObj.GetComponent<UIComboBox>();
			selectAutoReceiveGearLimitComboBox.onItemIndexChange.RemoveAllListeners();
			selectAutoReceiveGearLimitComboBox.Items = new List<string>
			{
				"远程接收关闭gm".Translate(),
				"1000",
				"2000",
				"组件无限制".Translate()
			};
			selectAutoReceiveGearLimitComboBox.itemIndex = 1;
			selectAutoReceiveGearLimitComboBox.text = selectAutoReceiveGearLimitComboBox.Items[selectAutoReceiveGearLimitComboBox.itemIndex];
			selectAutoReceiveGearLimitComboBox.onItemIndexChange.AddListener(OnGearLimitChange);
			selectAutoReceiveGearLimitComboBox.enabled = true;
		}
	}

	public static void RefreshUIWhenLoad()
	{
		if (selectAutoReceiveGearLimitComboBox != null && selectAutoReceiveGearLimitLabelObj != null)
		{
			selectAutoReceiveGearLimitLabelObj.GetComponent<Text>().text = "远程折跃多功能组件限制".Translate();
			selectAutoReceiveGearLimitComboBox.Items = new List<string>
			{
				"远程接收关闭gm".Translate(),
				"1000",
				"2000",
				"组件无限制".Translate()
			};
			selectAutoReceiveGearLimitComboBox.text = selectAutoReceiveGearLimitComboBox.Items[selectAutoReceiveGearLimitComboBox.itemIndex];
		}
	}

	public static void InitResolutionWhenLoad()
	{
		resolutionY = DSPGame.globalOption.resolution.height;
	}

	public static void OnGearLimitChange()
	{
		maxAutoReceiveGear = selectAutoReceiveGearLimitComboBox.itemIndex * 1000;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(DysonSphere), "BeforeGameTick")]
	public static void BeforeGameTickPostPatch(ref DysonSphere __instance)
	{
		if (StarMegaStructureType[__instance.starData.id - 1] != 0)
		{
			__instance.energyGenCurrentTick = (long)((double)(__instance.energyGenOriginalCurrentTick - __instance.energyGenCurrentTick_Swarm) * __instance.energyDFHivesDebuffCoef);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIDEPowerDesc), "UpdateUI")]
	public static void UIDEPowerDescUpdateUIPostPatch(ref UIDEPowerDesc __instance)
	{
		int index = __instance.dysonSphere.starData.index;
		if (index >= 0 && index < 1200 && StarMegaStructureType[index] != 0)
		{
			UIDEPowerDesc uIDEPowerDesc = __instance;
			long num = (uIDEPowerDesc.dysonSphere.energyGenOriginalCurrentTick - uIDEPowerDesc.dysonSphere.energyGenCurrentTick_Swarm - uIDEPowerDesc.dysonSphere.energyGenCurrentTick) * 60;
			StringBuilderUtility.WriteKMG(uIDEPowerDesc.sb, 8, -num, blank: true);
			uIDEPowerDesc.valueText4.text = uIDEPowerDesc.sb.ToString();
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PowerGeneratorComponent), "GameTick_Gamma")]
	public static bool GameTick_GammaPatch(ref PowerGeneratorComponent __instance, bool useIon, bool useCata, bool keyFrame, PlanetFactory factory, int[] productRegister, int[] consumeRegister)
	{
		CpuHandle handle = MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
		CpuHandle handle2 = MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.Receiver);
		try
		{
			return GameTick_GammaBody(ref __instance, useIon, useCata, keyFrame, factory, productRegister, consumeRegister);
		}
		finally
		{
			MMSCPU.EndSampleSafe(handle2);
			MMSCPU.EndSampleSafe(handle);
		}
	}

	private static bool GameTick_GammaBody(ref PowerGeneratorComponent __instance, bool useIon, bool useCata, bool keyFrame, PlanetFactory factory, int[] productRegister, int[] consumeRegister)
	{
		int num = factory.planet.star.id - 1;
		bool flag = false;
		if (num < 0 || num >= 1200)
		{
			flag = true;
		}
		int num2 = StarMegaStructureType[num];
		int protoId = factory.entityPool[__instance.entityId].protoId;
		if (num2 == 0 && protoId == 2208)
		{
			flag = true;
		}
		else if (num2 == 1)
		{
			flag = true;
		}
		else if (num2 == 4 && protoId == 9499)
		{
			flag = false;
		}
		else if (num2 == 5)
		{
			flag = true;
		}
		int value = -1;
		if (ReceiverPatchers.ProductId2MegaType.TryGetValue(__instance.productId, out value))
		{
			if (value != num2)
			{
				flag = false;
			}
		}
		else
		{
			flag = false;
		}
		if (flag)
		{
			if (useCata)
			{
				if (__instance.catalystPoint > 0)
				{
					__instance.catalystPoint--;
				}
				else if (__instance.catalystCount > 0)
				{
					int num3 = __instance.catalystInc / __instance.catalystCount;
					num3 = ((num3 > 0) ? ((num3 > 10) ? 10 : num3) : 0);
					__instance.catalystInc -= (short)num3;
					__instance.catalystIncLevel = (byte)num3;
					__instance.curCatalystId = __instance.catalystId;
					__instance.catalystPoint = 3600;
					__instance.catalystPoint--;
					__instance.catalystCount--;
					lock (consumeRegister)
					{
						consumeRegister[__instance.catalystId]++;
					}
					if (!__instance.incUsed)
					{
						__instance.incUsed = __instance.catalystIncLevel > 0;
					}
					if (__instance.catalystCount == 0)
					{
						__instance.catalystId = 0;
						__instance.catalystInc = 0;
					}
				}
				else
				{
					__instance.curCatalystId = 0;
					__instance.catalystIncLevel = 0;
				}
			}
			if (__instance.productId > 0 && __instance.productCount < 20f)
			{
				int num4 = (int)__instance.productCount;
				__instance.productCount += (float)((double)__instance.capacityCurrentTick / (double)__instance.productHeat);
				int num5 = (int)__instance.productCount;
				lock (productRegister)
				{
					productRegister[__instance.productId] += num5 - num4;
				}
				if (__instance.productCount > 20f)
				{
					__instance.productCount = 20f;
				}
			}
			__instance.warmup += __instance.warmupSpeed;
			__instance.warmup = ((__instance.warmup > 1f) ? 1f : ((__instance.warmup < 0f) ? 0f : __instance.warmup));
			bool flag2 = __instance.productId > 0 && __instance.productCount >= (float)pilerLvl;
			bool flag3 = keyFrame && useIon && __instance.catalystCount < 10;
			if (flag2 || flag3)
			{
				factory.ReadObjectConn(__instance.entityId, 0, out var isOutput, out var otherObjId, out var otherSlot);
				factory.ReadObjectConn(__instance.entityId, 1, out var isOutput2, out var otherObjId2, out otherSlot);
				bool flag4;
				bool flag5;
				if (otherObjId <= 0)
				{
					flag4 = false;
					flag5 = false;
					otherObjId = 0;
				}
				else
				{
					flag4 = isOutput;
					flag5 = !isOutput;
				}
				bool flag6;
				bool flag7;
				if (otherObjId2 <= 0)
				{
					flag6 = false;
					flag7 = false;
					otherObjId2 = 0;
				}
				else
				{
					flag6 = isOutput2;
					flag7 = !isOutput2;
				}
				byte remainInc = 0;
				if (flag2)
				{
					if (flag4 && flag6)
					{
						if (__instance.fuelHeat == 0L)
						{
							if (factory.InsertInto(otherObjId, 0, __instance.productId, (byte)pilerLvl, 0, out remainInc) == pilerLvl)
							{
								__instance.productCount -= pilerLvl;
								__instance.fuelHeat = 1L;
							}
							else if (factory.InsertInto(otherObjId2, 0, __instance.productId, (byte)pilerLvl, 0, out remainInc) == pilerLvl)
							{
								__instance.productCount -= pilerLvl;
								__instance.fuelHeat = 0L;
							}
						}
						else if (factory.InsertInto(otherObjId2, 0, __instance.productId, (byte)pilerLvl, 0, out remainInc) == pilerLvl)
						{
							__instance.productCount -= pilerLvl;
							__instance.fuelHeat = 0L;
						}
						else if (factory.InsertInto(otherObjId, 0, __instance.productId, (byte)pilerLvl, 0, out remainInc) == pilerLvl)
						{
							__instance.productCount -= pilerLvl;
							__instance.fuelHeat = 1L;
						}
					}
					else if (flag4)
					{
						if (factory.InsertInto(otherObjId, 0, __instance.productId, (byte)pilerLvl, 0, out remainInc) == pilerLvl)
						{
							__instance.productCount -= pilerLvl;
							__instance.fuelHeat = 1L;
						}
					}
					else if (flag6 && factory.InsertInto(otherObjId2, 0, __instance.productId, (byte)pilerLvl, 0, out remainInc) == pilerLvl)
					{
						__instance.productCount -= pilerLvl;
						__instance.fuelHeat = 0L;
					}
				}
				if (flag3)
				{
					if (flag5)
					{
						if (__instance.catalystCount > 0)
						{
							if (factory.PickFrom(otherObjId, 0, __instance.catalystId, null, out var stack, out var inc) == __instance.catalystId)
							{
								ref short catalystCount = ref __instance.catalystCount;
								catalystCount += stack;
								ref short catalystInc = ref __instance.catalystInc;
								catalystInc += inc;
							}
						}
						else
						{
							int[] array = ItemProto.catalystNeeds[__instance.catalystMask];
							if (array != null && array.Length != 0)
							{
								byte stack2;
								byte inc2;
								int num6 = factory.PickFrom(otherObjId, 0, 0, array, out stack2, out inc2);
								if (num6 > 0)
								{
									__instance.catalystId = num6;
									ref short catalystCount2 = ref __instance.catalystCount;
									catalystCount2 += stack2;
									ref short catalystInc2 = ref __instance.catalystInc;
									catalystInc2 += inc2;
								}
							}
						}
					}
					if (flag7)
					{
						if (__instance.catalystCount > 0)
						{
							if (factory.PickFrom(otherObjId2, 0, __instance.catalystId, null, out var stack3, out var inc3) == __instance.catalystId)
							{
								ref short catalystCount3 = ref __instance.catalystCount;
								catalystCount3 += stack3;
								ref short catalystInc3 = ref __instance.catalystInc;
								catalystInc3 += inc3;
								return false;
							}
						}
						else
						{
							int[] array2 = ItemProto.catalystNeeds[__instance.catalystMask];
							if (array2 != null && array2.Length != 0)
							{
								byte stack4;
								byte inc4;
								int num7 = factory.PickFrom(otherObjId2, 0, 0, array2, out stack4, out inc4);
								if (num7 > 0)
								{
									__instance.catalystId = num7;
									ref short catalystCount4 = ref __instance.catalystCount;
									catalystCount4 += stack4;
									ref short catalystInc4 = ref __instance.catalystInc;
									catalystInc4 += inc4;
								}
							}
						}
					}
				}
			}
		}
		return false;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(ThreadManager), "ProcessFrame")]
	public static void GameTickPostPatch(long frameCounter)
	{
		CpuHandle handle = MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
		try
		{
			GameTickPostBody(frameCounter);
		}
		finally
		{
			MMSCPU.EndSampleSafe(handle);
		}
	}

	private static void GameTickPostBody(long frameCounter)
	{
		isRemoteReceiveingGear = false;
		if (GameMain.mainPlayer.package.GetItemCount(9500) < maxAutoReceiveGear || maxAutoReceiveGear >= 3000)
		{
			isRemoteReceiveingGear = true;
		}
		hashGenByAllSN *= 60L;
		int num = (int)(Math.Pow(hashGenByAllSN, 0.65) + 0.001 * (double)hashGenByAllSN * (double)GameMain.data.gameDesc.propertyMultiplier);
		if (num < 0)
		{
			num = 1932735232;
		}
		PropertyLogic propertyLogic = GameMain.gameScenario?.propertyLogic;
		if (propertyLogic != null)
		{
			long clusterSeedKey = propertyLogic.gameData.GetClusterSeedKey();
			ClusterPropertyData clusterData = propertyLogic.propertySystem.GetClusterData(clusterSeedKey);
			ClusterPropertyData propertyData = propertyLogic.gameData.history.propertyData;
			int[] productIds = PropertySystem.productIds;
			foreach (int itemId in productIds)
			{
				int itemProduction = propertyData.GetItemProduction(itemId);
				int itemProduction2 = clusterData.GetItemProduction(itemId);
				if (num > itemProduction)
				{
					propertyData.SetItemProduction(itemId, num);
				}
				if (num > itemProduction2)
				{
					clusterData.SetItemProduction(itemId, num);
				}
			}
		}
		hashGenByAllSN = 0L;
		MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.StarAssembly);
		StarAssembly.UIFrameUpdate(frameCounter);
		MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.StarAssembly);
		MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.StarCannon);
		StarCannon.RefreshStarCannonProperties();
		MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.StarCannon);
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(DysonSphere), "GameTick")]
	public static void DysonSphereGameTickPostPatch(ref DysonSphere __instance)
	{
		CpuHandle handle = MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
		try
		{
			DysonSphereGameTickBody(__instance);
		}
		finally
		{
			MMSCPU.EndSampleSafe(handle);
		}
	}

	private static void DysonSphereGameTickBody(DysonSphere __instance)
	{
		int num = __instance.starData.id - 1;
		if (num < 0 || num >= 1200)
		{
			return;
		}
		if (StarMegaStructureType[num] == 2)
		{
			GameHistoryData history = GameMain.history;
			GameStatData statistics = GameMain.statistics;
			int currentTech = history.currentTech;
			if (currentTech <= 0)
			{
				return;
			}
			TechProto techProto = LDB.techs.Select(currentTech);
			for (int i = 0; i < techProto.Items.Length; i++)
			{
				if (techProto.Items[i] == 5201)
				{
					return;
				}
			}
			FactoryProductionStat iAFactoryStat = UIStatisticsPatcher.GetIAFactoryStat(num);
			_ = statistics.techHashedThisFrame;
			_ = history.universeMatrixPointUploaded;
			if (currentTech > 0 && techProto != null && techProto.IsLabTech && GameMain.history.techStates.ContainsKey(currentTech))
			{
				_ = history.techStates[currentTech];
			}
			long num2 = (__instance.energyGenCurrentTick - __instance.energyReqCurrentTick) * (HashBasicSpeedScale + HashBonusPerLevel * history.techSpeed) / HashGenDivisor;
			history.AddTechHash(num2);
			hashGenByAllSN += num2;
			if (iAFactoryStat != null)
			{
				long hashRegister = iAFactoryStat.hashRegister;
				hashRegister += num2;
				iAFactoryStat.hashRegister = hashRegister;
			}
		}
		else if (StarMegaStructureType[num] != 3 && StarMegaStructureType[num] == 4)
		{
			MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.StarAssembly);
			StarAssembly.InternalUpdate(__instance);
			StarAssembly.TryUseRocketInStorageToBuildIA(__instance);
			MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.StarAssembly);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(SiloComponent), "InternalUpdate")]
	public static void SiloUpdatePatch(ref SiloComponent __instance)
	{
		int planetId = __instance.planetId;
		int num = planetId / 100 - 1;
		if (num < 0 || num >= 1200 || GameMain.galaxy.stars[num].planets[planetId % 100 - 1].factory.entityPool[__instance.entityId].protoId != 2312)
		{
			return;
		}
		CpuHandle handle = MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
		CpuHandle handle2 = MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.Patch);
		try
		{
			SiloUpdateBody(ref __instance, num);
		}
		finally
		{
			MMSCPU.EndSampleSafe(handle2);
			MMSCPU.EndSampleSafe(handle);
		}
	}

	private static void SiloUpdateBody(ref SiloComponent __instance, int starIndex)
	{
		int num = 1503;
		switch (StarMegaStructureType[starIndex])
		{
		case 0:
			num = 1503;
			break;
		case 1:
			num = 9488;
			break;
		case 2:
			num = 9489;
			break;
		case 3:
			num = 9490;
			break;
		case 4:
			num = 9491;
			break;
		case 5:
			num = 9492;
			break;
		case 6:
			num = 9510;
			break;
		}
		bool flag = false;
		int bulletId = __instance.bulletId;
		if (bulletId == 1503 || (uint)(bulletId - 9488) <= 4u || bulletId == 9510)
		{
			flag = true;
		}
		if (__instance.bulletId != num && flag)
		{
			__instance.bulletCount = 0;
			__instance.bulletInc = 0;
			__instance.bulletId = num;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(EjectorComponent), "InternalUpdate")]
	public static void EjectorUpdatePatch(ref EjectorComponent __instance)
	{
		int planetId = __instance.planetId;
		int num = planetId / 100 - 1;
		if (num < 0 || num >= 1200 || GameMain.galaxy.stars[num].planets[planetId % 100 - 1].factory.entityPool[__instance.entityId].protoId != 2311)
		{
			return;
		}
		CpuHandle handle = MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
		CpuHandle handle2 = MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.Patch);
		try
		{
			if (StarMegaStructureType[num] == 2)
			{
				if (__instance.bulletId == 1501)
				{
					__instance.bulletCount = 0;
					__instance.bulletInc = 0;
					__instance.bulletId = 6006;
				}
			}
			else if (__instance.bulletId == 6006)
			{
				__instance.bulletCount = 0;
				__instance.bulletInc = 0;
				__instance.bulletId = 1501;
			}
		}
		finally
		{
			MMSCPU.EndSampleSafe(handle2);
			MMSCPU.EndSampleSafe(handle);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIDysonEditor), "_OnOpen")]
	public static void SetTextOnOpen(UIDysonEditor __instance)
	{
		StarAssembly.ForceResetIncDataCache();
		if (__instance.selection.viewDysonSphere != null)
		{
			curDysonSphere = __instance.selection.viewDysonSphere;
		}
		if (__instance.selection.viewStar != null)
		{
			RefreshUILabels(__instance.selection.viewStar, ShowIAUIWhenOpenDE.Value);
		}
		else
		{
			RefreshUILabels(__instance.gameData.localStar, ShowIAUIWhenOpenDE.Value);
		}
		try
		{
			SetMegaStructureWarningText.text = "鼠标触碰左侧黄条以规划巨构".Translate();
		}
		catch (Exception)
		{
		}
		RefreshButtonPos();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIDysonEditor), "OnViewStarChange")]
	public static void SetTextOnViewStarChange(UIDysonEditor __instance)
	{
		StarAssembly.ForceResetIncDataCache();
		if (__instance.selection.viewDysonSphere != null)
		{
			curDysonSphere = __instance.selection.viewDysonSphere;
		}
		if (__instance.selection.viewStar != null)
		{
			RefreshUILabels(__instance.selection.viewStar, ShowIAUIWhenOpenDE.Value);
		}
		else
		{
			RefreshUILabels(__instance.gameData.localStar, ShowIAUIWhenOpenDE.Value);
		}
		try
		{
			SetMegaStructureWarningText.text = "鼠标触碰左侧黄条以规划巨构".Translate();
		}
		catch (Exception)
		{
		}
		RefreshButtonPos();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIDysonEditor), "OnSelectionChange")]
	public static void SetTextOnSelectionChange(UIDysonEditor __instance)
	{
		try
		{
			SetMegaStructureWarningText.text = "鼠标触碰左侧黄条以规划巨构".Translate();
		}
		catch (Exception)
		{
		}
		if (__instance.selection.viewDysonSphere != null)
		{
			curDysonSphere = __instance.selection.viewDysonSphere;
		}
		if (__instance.selection.viewStar != null)
		{
			RefreshUILabels(__instance.selection.viewStar);
		}
		else
		{
			RefreshUILabels(__instance.gameData.localStar);
		}
	}

	public static void RefreshButtonPos()
	{
		float height = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel").GetComponent<RectTransform>().rect.height;
		int num = (int)(270f - height);
		int num2 = Math.Min((int)(-940f * height / 1080f), -835);
		if (setMegaGroupObj != null)
		{
			setMegaGroupObj.transform.localPosition = new Vector3(MegaButtonGroupBehaviour.currentX, num, 0f);
		}
		if (LeftMegaBuildWarning != null)
		{
			LeftMegaBuildWarning.transform.localPosition = new Vector3(280f, num2, 0f);
		}
	}

	public static void RefreshUILabels(StarData star)
	{
		RefreshUILabels(star, forceShowUI: false);
	}

	public static void RefreshUILabels(StarData star, bool forceShowUI)
	{
		try
		{
			if (star == null)
			{
				return;
			}
			curStar = star;
			int num = star.id - 1;
			num = ((num >= 0) ? ((num >= 1200) ? 1199 : num) : 0);
			StarAssembly.RefreshUI(forceShowUI);
			SetMegaStructureLabelText.text = "规划巨构建筑类型".Translate();
			LeftDysonCloudTitle.text = "自由组件云".Translate();
			LeftDysonCloudBluePrintText.text = "组件云蓝图".Translate();
			LeftDysonShellTitle.text = "锚定结构".Translate();
			LeftDysonShellOrbitTitleText.text = "结构层级".Translate();
			LeftDysonShellBluePrintText.text = "锚定结构蓝图".Translate();
			RightStarPowRatioText.text = "恒星功效系数".Translate();
			RightMaxPowGenText.text = "最大工作效率".Translate();
			RightDysonBluePrintText.text = "巨构建筑蓝图".Translate();
			SpSailAmountText.text = "自由组件数量".Translate();
			SpSailLifeTimeText.text = "自由组件寿命分布".Translate();
			SpSailLifeTimeBarText.text = "自由组件状态统计".Translate();
			SpSwarmPowGenText.text = "自由组件工作效率".Translate();
			SpShellPowGenText.text = "锚定结构工作效率".Translate();
			SoSailAmountText.text = "自由组件数量".Translate();
			SoSailPowGenText.text = "工作效率".Translate();
			SoSailLifeTimeText.text = "自由组件寿命分布".Translate();
			SoSailLifeTimeBarText.text = "自由组件状态统计".Translate();
			LyPowGenText.text = "工作效率".Translate();
			NdPowGenText.text = "工作效率".Translate();
			FrPowGenText.text = "工作效率".Translate();
			ShPowGenText.text = "工作效率".Translate();
			if (curDysonSphere != null && StarMegaStructureType[curStar.index] == 6)
			{
				SpSailAmountText.text = "连续开火次数".Translate();
				SpNodeAmountText.text = "伤害削减".Translate();
				SpConsumePowText.text = "当前能量水平".Translate();
				SpSwarmPowGenText.text = "下一阶段所需能量水平".Translate();
				SpShellPowGenText.text = "冷却及充能时间".Translate();
				SpEnergySatisfiedLabelText.text = "修建进度".Translate();
				SpEnergySatisfiedLabelText.lineSpacing = 0.65f;
				if (StarCannon.GetStarCannonProperties(curDysonSphere)[0] >= 5)
				{
					SpEnergySatisfiedLabelText.text = "最终阶段".Translate();
				}
				DysonEditorPowerDescLabel4BarObj.SetActive(value: false);
			}
			else if (curDysonSphere != null && StarMegaStructureType[curStar.index] == 3)
			{
				SpSailAmountText.text = "折跃场内曲速速率".Translate();
				SpNodeAmountText.text = "折跃场内能量消耗".Translate();
			}
			else
			{
				SpEnergySatisfiedLabelText.text = "供电率".Translate();
				SpNodeAmountText.text = "节点总数（已规划）gm".Translate();
				SpConsumePowText.text = "请求功率gm".Translate();
				DysonEditorPowerDescLabel4BarObj.SetActive(value: true);
			}
			set2DysonButtonTextTrans.GetComponent<Text>().text = "规划".Translate() + "戴森球jinx".Translate();
			set2MatDecomButtonTextTrans.GetComponent<Text>().text = "规划".Translate() + "物质解压器".Translate();
			set2SciNexusButtonTextTrans.GetComponent<Text>().text = "规划".Translate() + "科学枢纽".Translate();
			set2WarpFieldGenButtonTextTrans.GetComponent<Text>().text = "规划".Translate() + "折跃场广播阵列".Translate();
			set2MegaAssemButtonTextTrans.GetComponent<Text>().text = "规划".Translate() + "星际组装厂".Translate();
			set2CrystalMinerButtonTextTrans.GetComponent<Text>().text = "规划".Translate() + "晶体重构器".Translate();
			set2StarCannonButtonTextTrans.GetComponent<Text>().text = "规划".Translate() + "恒星炮".Translate();
			set2StarCannonButtonObj.SetActive(GameMain.data.history.TechState(MMSProtos.StarCannonTechId).unlocked);
			rightBarObj.GetComponent<RectTransform>().sizeDelta = new Vector2(8f, GameMain.data.history.TechState(MMSProtos.StarCannonTechId).unlocked ? 243 : 213);
			set2DysonButtonTextTrans.GetComponent<Text>().color = normalTextColor;
			set2MatDecomButtonTextTrans.GetComponent<Text>().color = normalTextColor;
			set2SciNexusButtonTextTrans.GetComponent<Text>().color = normalTextColor;
			set2WarpFieldGenButtonTextTrans.GetComponent<Text>().color = normalTextColor;
			set2MegaAssemButtonTextTrans.GetComponent<Text>().color = normalTextColor;
			set2CrystalMinerButtonTextTrans.GetComponent<Text>().color = normalTextColor;
			set2StarCannonButtonTextTrans.GetComponent<Text>().color = normalTextColor;
			int num2 = StarMegaStructureType[num];
			RightDysonTitle.text = "巨构建筑".Translate() + " " + star.displayName;
			if (star.type != EStarType.BlackHole || (isBattleActive && !GameMain.history.TechUnlocked(1920)))
			{
				set2MatDecomButtonTextTrans.GetComponent<Text>().color = disableTextColor;
			}
			if ((star.type != EStarType.NeutronStar && star.type != EStarType.WhiteDwarf) || (isBattleActive && !GameMain.history.TechUnlocked(1923)))
			{
				set2CrystalMinerButtonTextTrans.GetComponent<Text>().color = disableTextColor;
			}
			if (isBattleActive && !GameMain.history.TechUnlocked(1924))
			{
				set2SciNexusButtonTextTrans.GetComponent<Text>().color = disableTextColor;
			}
			if (isBattleActive && !GameMain.history.TechUnlocked(1922))
			{
				set2MegaAssemButtonTextTrans.GetComponent<Text>().color = disableTextColor;
			}
			WarpBuiltStarIndex = CheckWarpArrayBuilt();
			CannonBuiltStarIndex = GetStarCannonBuiltIndex();
			if (WarpBuiltStarIndex >= 0 || (isBattleActive && !GameMain.history.TechUnlocked(1921)))
			{
				set2WarpFieldGenButtonTextTrans.GetComponent<Text>().color = disableTextColor;
			}
			if (CannonBuiltStarIndex >= 0 || (isBattleActive && !GameMain.history.TechUnlocked(1918)))
			{
				set2StarCannonButtonTextTrans.GetComponent<Text>().color = disableTextColor;
			}
			switch (num2)
			{
			case 0:
				RightDysonTitle.text = "戴森球jinx".Translate() + " " + star.displayName;
				set2DysonButtonTextTrans.GetComponent<Text>().color = currentTextColor;
				set2DysonButtonTextTrans.GetComponent<Text>().text = "当前".Translate() + " " + "戴森球jinx".Translate();
				break;
			case 1:
				RightDysonTitle.text = "物质解压器".Translate() + " " + star.displayName;
				set2MatDecomButtonTextTrans.GetComponent<Text>().color = currentTextColor;
				set2MatDecomButtonTextTrans.GetComponent<Text>().text = "当前".Translate() + " " + "物质解压器".Translate();
				break;
			case 2:
				RightDysonTitle.text = "科学枢纽".Translate() + " " + star.displayName;
				set2SciNexusButtonTextTrans.GetComponent<Text>().color = currentTextColor;
				set2SciNexusButtonTextTrans.GetComponent<Text>().text = "当前".Translate() + " " + "科学枢纽".Translate();
				RightMaxPowGenText.text = "研究效率".Translate();
				break;
			case 3:
				RightDysonTitle.text = "折跃场广播阵列".Translate() + " " + star.displayName;
				set2WarpFieldGenButtonTextTrans.GetComponent<Text>().color = currentTextColor;
				set2WarpFieldGenButtonTextTrans.GetComponent<Text>().text = "当前".Translate() + " " + "折跃场广播阵列".Translate();
				RightMaxPowGenText.text = "折跃场半径".Translate();
				break;
			case 4:
				RightDysonTitle.text = "星际组装厂".Translate() + " " + star.displayName;
				set2MegaAssemButtonTextTrans.GetComponent<Text>().color = currentTextColor;
				set2MegaAssemButtonTextTrans.GetComponent<Text>().text = "当前".Translate() + " " + "星际组装厂".Translate();
				RightMaxPowGenText.text = "最大生产速度gm".Translate();
				break;
			case 5:
				RightDysonTitle.text = "晶体重构器".Translate() + " " + star.displayName;
				set2CrystalMinerButtonTextTrans.GetComponent<Text>().color = currentTextColor;
				set2CrystalMinerButtonTextTrans.GetComponent<Text>().text = "当前".Translate() + " " + "晶体重构器".Translate();
				break;
			case 6:
				RightDysonTitle.text = "恒星炮".Translate() + " - 阶段" + StarCannon.GetStarCannonProperties(curDysonSphere)[0] + " " + star.displayName;
				set2StarCannonButtonTextTrans.GetComponent<Text>().color = currentTextColor;
				set2StarCannonButtonTextTrans.GetComponent<Text>().text = "当前".Translate() + " " + "恒星炮".Translate();
				RightMaxPowGenText.text = "每秒伤害gm".Translate();
				break;
			}
		}
		catch (Exception)
		{
		}
	}

	public static void SetMegaStructure(int type)
	{
		try
		{
			int num = curStar.id - 1;
			if (num >= 1200)
			{
				UIRealtimeTip.Popup("警告巨构不支持恒星系数量大于1200个".Translate());
			}
			else
			{
				if (type == StarMegaStructureType[num])
				{
					return;
				}
				if (StarCannonOnly.Value && type >= 1 && type <= 5)
				{
					UIRealtimeTip.Popup("玩家自行禁用了巨构警告".Translate());
					return;
				}
				if (isBattleActive && ((type == 1 && !GameMain.history.TechUnlocked(1920)) || (type == 2 && !GameMain.history.TechUnlocked(1924)) || (type == 3 && !GameMain.history.TechUnlocked(1921)) || (type == 4 && !GameMain.history.TechUnlocked(1922)) || (type == 5 && !GameMain.history.TechUnlocked(1923)) || (type == 6 && !GameMain.history.TechUnlocked(1918))))
				{
					UIRealtimeTip.Popup("警告巨构科技未解锁".Translate());
					return;
				}
				if (type == 1 && curStar.type != EStarType.BlackHole)
				{
					UIRealtimeTip.Popup("警告仅黑洞".Translate());
					return;
				}
				if (type == 2 && !GameMain.history.TechUnlocked(1508) && !GameMain.history.ItemUnlocked(9489))
				{
					UIRealtimeTip.Popup("警告巨构科技未解锁".Translate());
					return;
				}
				if (type == 5 && curStar.type != EStarType.NeutronStar && curStar.type != EStarType.WhiteDwarf)
				{
					UIRealtimeTip.Popup("警告仅中子星白矮星".Translate());
					return;
				}
				if (type == 6 && CannonBuiltStarIndex >= 0)
				{
					string displayName = GameMain.galaxy.stars[CannonBuiltStarIndex].displayName;
					UIRealtimeTip.Popup("警告最多一个恒星炮".Translate() + " " + displayName);
					return;
				}
				if (type == 6 && !GameMain.data.history.TechState(MMSProtos.StarCannonTechId).unlocked)
				{
					UIRealtimeTip.Popup("先解锁恒星炮科技警告".Translate());
					return;
				}
				if (curDysonSphere != null && curDysonSphere.totalNodeCount > 0 && !developerMode && !GameMain.data.gameDesc.isSandboxMode)
				{
					UIRealtimeTip.Popup("警告先拆除".Translate());
					return;
				}
				StarMegaStructureType[num] = type;
				OnMegaTypeChanged();
				if (type == 4)
				{
					StarAssembly.ResetArchiveDataByStarIndex(num);
					StarAssembly.ResetInGameDataByStarIndex(num);
					StarAssembly.ForceResetIncDataCache();
					RefreshUILabels(curStar, forceShowUI: true);
				}
				else
				{
					RefreshUILabels(curStar);
				}
				if (type == 2)
				{
					curDysonSphere.swarm.RemoveSailsByOrbit(-1);
				}
			}
		}
		catch (Exception)
		{
			UIRealtimeTip.Popup("警告未知错误".Translate());
		}
	}

	public static void OnMegaTypeChanged()
	{
		WarpArray.CheckSectorWarpArrays();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIDEOverview), "_OnUpdate")]
	public static void UIValueUpdate()
	{
		try
		{
			if (StarMegaStructureType[curDysonSphere.starData.id - 1] == 2)
			{
				long num = (curDysonSphere.energyGenCurrentTick - curDysonSphere.energyReqCurrentTick) * (HashBasicSpeedScale + HashBonusPerLevel * GameMain.history.techSpeed) / HashGenDivisor;
				RightMaxPowGenValueText.text = Capacity2Str(num * 60) + "H/s";
			}
			else if (StarMegaStructureType[curDysonSphere.starData.id - 1] == 3)
			{
				long energyPerFrame = curDysonSphere.energyGenCurrentTick - curDysonSphere.energyReqCurrentTick;
				RightMaxPowGenValueText.text = (WarpArray.GetRadiusByEnergyPerFrame(energyPerFrame) / 60.0 / 40000.0).ToString("N1") + " ly";
			}
			else if (StarMegaStructureType[curDysonSphere.starData.id - 1] == 4)
			{
				long num2 = (curDysonSphere.energyGenCurrentTick - curDysonSphere.energyReqCurrentTick) * 60;
				RightMaxPowGenValueText.text = Capacity2Str((double)num2 / 60.0 / (double)StarAssembly.tickEnergyForFullSpeed) + "x";
			}
			else if (StarMegaStructureType[curDysonSphere.starData.id - 1] == 6)
			{
				RightDysonTitle.text = "恒星炮".Translate() + " - 阶段" + StarCannon.GetStarCannonProperties(curDysonSphere)[0] + " " + curStar.displayName;
				RightMaxPowGenValueText.text = (StarCannon.GetStarCannonProperties(curDysonSphere)[1] * 60 / 100).ToString();
			}
		}
		catch (Exception)
		{
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIDESphereInfo), "_OnUpdate")]
	public static void UIValueUpdate2(ref UIDESphereInfo __instance)
	{
		if (curDysonSphere != null)
		{
			if (StarMegaStructureType[curDysonSphere.starData.index] == 3)
			{
				__instance.sailCntText.text = 250f + " ly/s";
				__instance.nodeCntText.text = "-" + ((1.0 - WarpArray.GetTripEnergyCostRatioByEnergyPerFrame(curDysonSphere.energyGenCurrentTick)) * 100.0).ToString("N0") + " %";
			}
			else if (StarMegaStructureType[curDysonSphere.starData.index] == 6)
			{
				int[] starCannonProperties = StarCannon.GetStarCannonProperties(curDysonSphere);
				__instance.sailCntText.text = ((starCannonProperties[2] < 9000) ? starCannonProperties[2].ToString() : "无限制gm".Translate());
				__instance.nodeCntText.text = "-" + starCannonProperties[5] + "% / ly";
			}
		}
	}

	public static int CheckWarpArrayBuilt()
	{
		return -1;
	}

	public static int GetStarCannonBuiltIndex()
	{
		for (int i = 0; i < 1200; i++)
		{
			if (StarMegaStructureType[i] == 6)
			{
				return i;
			}
		}
		return -1;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PlanetFactory), "AddEntityDataWithComponents")]
	public static bool AddEntityDataPrePatch(EntityData entity, ref PrefabDesc __state)
	{
		int protoId = entity.protoId;
		if ((protoId < 9493 || protoId > 9499) && protoId != 2208 && protoId != 9501 && protoId != 9502)
		{
			__state = null;
			return true;
		}
		ItemProto itemProto = LDB.items.Select(entity.protoId);
		if (itemProto == null || !itemProto.IsEntity)
		{
			__state = null;
			return true;
		}
		ModelProto modelProto = LDB.models.Select(entity.modelIndex);
		__state = modelProto.prefabDesc;
		modelProto.prefabDesc = MethedEx.Copy<PrefabDesc>(__state);
		modelProto.prefabDesc.powerProductId = itemProto.prefabDesc.powerProductId;
		modelProto.prefabDesc.powerProductHeat = itemProto.prefabDesc.powerProductHeat;
		return true;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetFactory), "AddEntityDataWithComponents")]
	public static void AddEntityDataPostPatch(EntityData entity, ref PrefabDesc __state)
	{
		if (__state != null)
		{
			int protoId = entity.protoId;
			if ((protoId >= 9493 && protoId <= 9499) || protoId == 2208 || protoId == 9501 || protoId == 9502)
			{
				LDB.models.Select(entity.modelIndex).prefabDesc = __state;
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UITechNode), "UpdateLayoutDynamic")]
	public static void UITechNode_UpdateLayoutDynamic(ref UITechNode __instance, bool forceUpdate = false, bool forceReset = false)
	{
		float num = Mathf.Max(__instance.unlockText.preferredWidth - 40f + __instance.unlockTextTrans.anchoredPosition.x, Math.Min(__instance.techProto.unlockRecipeArray.Length, 3) * 46) + (float)__instance.baseWidth;
		if (num < (float)__instance.minWidth)
		{
			num = __instance.minWidth;
		}
		if (num > (float)__instance.maxWidth)
		{
			num = __instance.maxWidth;
		}
		if (__instance.focusState < 1f)
		{
			__instance.panelRect.sizeDelta = new Vector2(Mathf.Lerp(__instance.minWidth, num, __instance.focusState), __instance.panelRect.sizeDelta.y);
		}
		else
		{
			__instance.panelRect.sizeDelta = new Vector2(Mathf.Lerp(num, __instance.maxWidth, __instance.focusState - 1f), __instance.panelRect.sizeDelta.y);
		}
		__instance.titleText.rectTransform.sizeDelta = new Vector2(__instance.panelRect.sizeDelta.x - (float)((GameMain.history.TechState(__instance.techProto.ID).curLevel > 0) ? 65 : 25), 24f);
	}

	public void Import(BinaryReader r)
	{
		curStar = null;
		curDysonSphere = null;
		savedModVersion = r.ReadInt32();
		for (int i = 0; i < 1000; i++)
		{
			StarMegaStructureType[i] = r.ReadInt32();
		}
		if (savedModVersion >= 190)
		{
			for (int j = 1000; j < 1200; j++)
			{
				StarMegaStructureType[j] = r.ReadInt32();
			}
		}
		if (savedModVersion >= 101)
		{
			maxAutoReceiveGear = r.ReadInt32();
			autoReceiveGearProgress = r.ReadInt64();
		}
		else
		{
			maxAutoReceiveGear = 1000;
			autoReceiveGearProgress = 0L;
		}
		selectAutoReceiveGearLimitComboBox.itemIndex = maxAutoReceiveGear / 1000;
		hashGenByAllSN = 0L;
		RefreshUIWhenLoad();
		InitResolutionWhenLoad();
		if (savedModVersion >= 110)
		{
			StarAssembly.Import(r);
			StarAssembly.CalcInGameData();
		}
		else
		{
			StarAssembly.ResetAndInitArchiveData();
			StarAssembly.CalcInGameData();
		}
		UIBuildMenuPatcher.InitDataWhenLoad();
		if (savedModVersion >= 130)
		{
			StarCannon.Import(r);
		}
		else
		{
			StarCannon.IntoOtherSave();
		}
		WarpArray.Import(r);
		UIWarpArray.Import(r);
		UIStatisticsPatcher.Import(r);
		if (GameMain.galaxy.starCount >= 100 && !Support1000Stars.Value)
		{
			UIMessageBox.Show("警告mms".Translate(), "警告未开启大于1000星系支持".Translate(), "我明白".Translate(), 1);
		}
		if (savedModVersion < 160)
		{
			UIMessageBox.Show("警告mms".Translate(), "星际组装厂逻辑更新警告".Translate(), "我明白".Translate(), 1);
		}
	}

	public void Export(BinaryWriter w)
	{
		w.Write(modVersion);
		for (int i = 0; i < 1200; i++)
		{
			w.Write(StarMegaStructureType[i]);
		}
		w.Write(maxAutoReceiveGear);
		w.Write(autoReceiveGearProgress);
		StarAssembly.Export(w);
		StarCannon.Export(w);
		WarpArray.Export(w);
		UIWarpArray.Export(w);
		UIStatisticsPatcher.Export(w);
	}

	public void IntoOtherSave()
	{
		for (int i = 0; i < 1200; i++)
		{
			StarMegaStructureType[i] = 0;
		}
		maxAutoReceiveGear = 1000;
		autoReceiveGearProgress = 0L;
		selectAutoReceiveGearLimitComboBox.itemIndex = maxAutoReceiveGear / 1000;
		_ = isBattleActive;
		hashGenByAllSN = 0L;
		RefreshUIWhenLoad();
		InitResolutionWhenLoad();
		UIBuildMenuPatcher.InitDataWhenLoad();
		StarAssembly.IntoOtherSave();
		StarCannon.IntoOtherSave();
		WarpArray.IntoOtherSave();
		UIWarpArray.IntoOtherSave();
		UIStatisticsPatcher.IntoOtherSave();
	}

	private static string Capacity2Str(double capacityPerSecond)
	{
		if (capacityPerSecond >= 100.0 || capacityPerSecond == 0.0)
		{
			return Capacity2Str((long)capacityPerSecond);
		}
		if (capacityPerSecond >= 10.0)
		{
			return capacityPerSecond.ToString("F1") + " ";
		}
		if (capacityPerSecond >= 1.0)
		{
			return capacityPerSecond.ToString("F2") + " ";
		}
		return capacityPerSecond.ToString("F3") + " ";
	}

	internal static string Capacity2Str(long capacityPerSecond)
	{
		string text = "";
		long num;
		if (capacityPerSecond >= 1000000000000000000L)
		{
			num = capacityPerSecond / 1000000000000000L;
			text = " E";
		}
		else if (capacityPerSecond >= 1000000000000000L)
		{
			num = capacityPerSecond / 1000000000000L;
			text = " P";
		}
		else if (capacityPerSecond >= 1000000000000L)
		{
			num = capacityPerSecond / 1000000000;
			text = " T";
		}
		else if (capacityPerSecond >= 1000000000)
		{
			num = capacityPerSecond / 1000000;
			text = " G";
		}
		else if (capacityPerSecond >= 1000000)
		{
			num = capacityPerSecond / 1000;
			text = " M";
		}
		else
		{
			if (capacityPerSecond < 1000)
			{
				return capacityPerSecond + " ";
			}
			num = capacityPerSecond;
			text = " k";
		}
		if (num >= 100000)
		{
			return num / 1000 + text;
		}
		if (num >= 10000)
		{
			return (double)(num / 100) / 10.0 + text;
		}
		return (double)(num / 10) / 100.0 + text;
	}

	public static string Capacity2SpeedAcc(int ratio)
	{
		return ((double)ratio * 0.05).ToString("G3") + " ";
	}
}
