using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using static System.Reflection.Emit.OpCodes;

namespace GalacticScale
{
    public partial class PatchOnSectorModel
    {
        [HarmonyTranspiler, HarmonyPatch(typeof(SectorModel), nameof(SectorModel.CreateGalaxyAstroBuffer))]
        public static IEnumerable<CodeInstruction> TranspilerSectorModelCreateGalaxyAstroBuffer(
            IEnumerable<CodeInstruction> instructions)
        {
            var calcMethod = AccessTools.Method(typeof(PatchOnSectorModel), nameof(CalcAstroBufferSize));
            var matcher = new CodeMatcher(instructions)
                // UniverseGenTweaks may have already expanded the native constant.
                .MatchForward(
                    true,
                    new CodeMatch(i => i.LoadsConstant(25600) || i.LoadsConstant(102500)
                    ));
            if (matcher.IsInvalid)
            {
                GS2.Error("SectorModel.CreateGalaxyAstroBuffer transpiler: native or UniverseGenTweaks astro buffer constant not found. Returning original code.");
                return instructions;
            }

            return matcher
                .Repeat(m => { m.SetInstructionAndAdvance(new CodeInstruction(Call, calcMethod)); }).InstructionEnumeration();
        }

        public static int CalcAstroBufferSize()
        {
            return GameMain.spaceSector.galaxy.starCount * 400;
        }


        [HarmonyPrefix, HarmonyPatch(typeof(SectorModel), nameof(SectorModel.OnCameraPostRender))]
        public static bool PatchOnCameraPostRender(ref SectorModel __instance, Camera cam)
        {
            if (GameMain.mainPlayer == null)
            {
                return false;
            }

            return true;
        }
    }
}
