using System;
using System.IO;
using System.Reflection;
using BepInEx;
using BepInEx.Logging;
using GalacticScale;
using NebulaAPI;
using NebulaAPI.Interfaces;

namespace NebulaCompatibility;

[BepInPlugin("dsp.galactic-scale.2.nebula", "Galactic Scale 2 Nebula Compatibility Plug-In", "1.0.0.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
public class Ignore_This_Warning_If_Not_Using_Nebula_Multiplayer_Mod : BaseUnityPlugin, IMultiplayerModWithSettings, IMultiplayerMod
{
	public new static ManualLogSource Logger;

	public string Version => GS2.Version;

	public void Awake()
	{
		NebulaModAPI.RegisterPackets(Assembly.GetExecutingAssembly());
		BCE.Console.Init();
		if (NebulaModAPI.NebulaIsInstalled)
		{
			NebulaModAPI.OnMultiplayerGameStarted = (Action)Delegate.Combine(NebulaModAPI.OnMultiplayerGameStarted, new Action(NebulaCompat.NebulaStart));
			NebulaModAPI.OnMultiplayerGameEnded = (Action)Delegate.Combine(NebulaModAPI.OnMultiplayerGameEnded, new Action(NebulaCompat.NebulaEnd));
		}
		Logger = new ManualLogSource("GS2DepCheck");
		BepInEx.Logging.Logger.Sources.Add(Logger);
		Logger.Log(LogLevel.Message, "Loaded");
	}

	bool IMultiplayerMod.CheckVersion(string hostVersion, string clientVersion)
	{
		if (GS2.ActiveGenerator.GUID == "space.customizing.generators.vanilla")
		{
			GS2.ShowMessage("Cannot Play Multiplayer using the Vanilla Generator", "Warning", "OK".Translate());
			GS2.ShowMessage(GS2.ActiveGenerator.GUID, "Warning", "OK".Translate());
			return false;
		}
		return hostVersion.Equals(clientVersion);
	}

	public void Export(BinaryWriter w)
	{
		string value = GSSettings.Serialize();
		w.Write(value);
	}

	public void Import(BinaryReader r)
	{
		GSSettings.DeSerialize(r.ReadString());
		GS2.ActiveGenerator = GS2.GetGeneratorByID(GSSettings.Instance.generatorGUID);
	}
}
