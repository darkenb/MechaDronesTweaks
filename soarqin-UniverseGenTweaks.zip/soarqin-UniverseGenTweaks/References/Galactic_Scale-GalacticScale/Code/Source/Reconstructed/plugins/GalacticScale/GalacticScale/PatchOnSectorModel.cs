using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;

namespace GalacticScale;

public class PatchOnSectorModel
{
	[HarmonyTranspiler]
	[HarmonyPatch(typeof(SectorModel), "CreateGalaxyAstroBuffer")]
	public static IEnumerable<CodeInstruction> TranspilerSectorModelCreateGalaxyAstroBuffer(IEnumerable<CodeInstruction> instructions)
	{
		MethodInfo calcMethod = AccessTools.Method(typeof(PatchOnSectorModel), "CalcAstroBufferSize");
		CodeMatcher codeMatcher = new CodeMatcher(instructions).MatchForward(true, new CodeMatch((CodeInstruction i) => i.LoadsConstant(25600L) || i.LoadsConstant(102500L)));
		if (codeMatcher.IsInvalid)
		{
			GS2.Error("SectorModel.CreateGalaxyAstroBuffer transpiler: native or UniverseGenTweaks astro buffer constant not found. Returning original code.", 24);
			return instructions;
		}
		return codeMatcher.Repeat(delegate(CodeMatcher m)
		{
			m.SetInstructionAndAdvance(new CodeInstruction(OpCodes.Call, calcMethod));
		}).InstructionEnumeration();
	}

	public static int CalcAstroBufferSize()
	{
		return GameMain.spaceSector.galaxy.starCount * 400;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(SectorModel), "OnCameraPostRender")]
	public static bool PatchOnCameraPostRender(ref SectorModel __instance, Camera cam)
	{
		if (GameMain.mainPlayer == null)
		{
			return false;
		}
		return true;
	}
}
