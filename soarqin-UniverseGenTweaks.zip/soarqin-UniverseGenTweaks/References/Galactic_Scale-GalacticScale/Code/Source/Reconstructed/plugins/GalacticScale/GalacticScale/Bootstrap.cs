using System;
using System.Collections;
using System.IO;
using System.Reflection;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;

namespace GalacticScale;

[BepInPlugin("dsp.galactic-scale.2", "Galactic Scale 2 Plug-In", "2.80.9")]
[BepInDependency("space.customizing.console", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("lltcggie.DSP.plugin.PlanetwidePlanetaryShieldGenerator", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("un1eagle.planetwideshield", BepInDependency.DependencyFlags.SoftDependency)]
public class Bootstrap : BaseUnityPlugin
{
	public static Bootstrap instance;

	public new static ManualLogSource Logger;

	public static Queue buffer = new Queue();

	internal void Awake()
	{
		instance = this;
		InitializeLogger();
		InitializeComponents();
		ApplyHarmonyPatches();
	}

	private void InitializeLogger()
	{
		AppDomain.CurrentDomain.UnhandledException += delegate(object o, UnhandledExceptionEventArgs e)
		{
			GS2.LogError(o, e, 39);
		};
		System.Version version = Assembly.GetExecutingAssembly().GetName().Version;
		Assembly.GetAssembly(typeof(GSStar));
		GS2.Version = $"{version.Major}.{version.Minor}.{version.Build}";
		BCE.Console.Init();
		Logger = new ManualLogSource("GS2");
		BepInEx.Logging.Logger.Sources.Add(Logger);
		GS2.ConsoleSplash();
	}

	private void InitializeComponents()
	{
		if (GS2.TP == null)
		{
			GS2.TP = base.gameObject.AddComponent<TeleportComponent>();
		}
		if (GS2.InputComponent == null)
		{
			GS2.InputComponent = base.gameObject.AddComponent<InputComponent>();
		}
	}

	private void ApplyHarmonyPatches()
	{
		Directory.CreateDirectory("./mmdump");
		FileInfo[] files = new DirectoryInfo("./mmdump").GetFiles();
		for (int i = 0; i < files.Length; i++)
		{
			files[i].Delete();
		}
		try
		{
			Harmony harmony = new Harmony("dsp.galactic-scale.2");
			harmony.PatchAll(typeof(EnemyUnitComponentTranspiler));
			harmony.PatchAll(typeof(PlanetCountTransipler));
			harmony.PatchAll(typeof(PlanetSizeTranspiler));
			harmony.PatchAll(typeof(TurretComponentTranspiler));
			harmony.PatchAll(typeof(UnitComponentTranspiler));
			harmony.PatchAll(typeof(CombatShipPathingTranspiler));
			harmony.PatchAll(typeof(DetermineCraftAstroIdTranspiler));
			harmony.PatchAll(typeof(LagFixTranspiler));
			harmony.PatchAll(typeof(PatchOnUnspecified_Debug));
			harmony.PatchAll(typeof(PatchOnBlueprintUtils));
			harmony.PatchAll(typeof(PatchOnBomb));
			harmony.PatchAll(typeof(PatchOnBuildingGizmo));
			harmony.PatchAll(typeof(PatchOnBuildTool_BlueprintCopy));
			harmony.PatchAll(typeof(PatchOnBuildTool_BlueprintPaste));
			harmony.PatchAll(typeof(PatchOnBuildTool_Click));
			harmony.PatchAll(typeof(PatchOnBuildTool_Inserter));
			harmony.PatchAll(typeof(PatchOnBuildTool_Reform));
			harmony.PatchAll(typeof(PatchOnBuildTool_Path));
			harmony.PatchAll(typeof(PatchOnBuildTool_PathAddon));
			harmony.PatchAll(typeof(PatchOnCloudSimulator));
			harmony.PatchAll(typeof(PatchOnCosmicMessageManager));
			harmony.PatchAll(typeof(PatchOnDFGTurretComponent));
			harmony.PatchAll(typeof(PatchOnDFRelayComponent));
			harmony.PatchAll(typeof(PatchOnDFTinderComponent));
			harmony.PatchAll(typeof(PatchOnDigitalSystem));
			harmony.PatchAll(typeof(PatchOnDysonSphere));
			harmony.PatchAll(typeof(PatchOnDysonSwarm));
			harmony.PatchAll(typeof(PatchOnDysonSphereRocket));
			harmony.PatchAll(typeof(PatchOnDysonStatistics));
			harmony.PatchAll(typeof(PatchOnUIDEDialogues));
			harmony.PatchAll(typeof(PatchOnEnemyDFGroundSystem));
			harmony.PatchAll(typeof(PatchOnEnemyDFHiveSystem));
			harmony.PatchAll(typeof(PatchOnFactoryModel));
			harmony.PatchAll(typeof(PatchOnGalaxyData));
			harmony.PatchAll(typeof(PatchOnGameAbnormalityData));
			harmony.PatchAll(typeof(PatchOnGameAchievementData));
			harmony.PatchAll(typeof(PatchOnGameData));
			harmony.PatchAll(typeof(PatchOnGameDesc));
			harmony.PatchAll(typeof(PatchOnGameHistoryData));
			harmony.PatchAll(typeof(PatchOnGameLoader));
			harmony.PatchAll(typeof(PatchOnGameMain));
			harmony.PatchAll(typeof(PatchOnGameOption));
			harmony.PatchAll(typeof(PatchOnGameSave));
			harmony.PatchAll(typeof(PatchOnGameScenarioLogic));
			harmony.PatchAll(typeof(PatchOnGraticulePoser));
			harmony.PatchAll(typeof(PatchOnGuideMissionStandardMode));
			harmony.PatchAll(typeof(PatchOnKillStatistics));
			harmony.PatchAll(typeof(PatchOnLocalGeneralProjectile));
			harmony.PatchAll(typeof(PatchOnLocalLaserContinuous));
			harmony.PatchAll(typeof(PatchOnLocalLaserOneShot));
			harmony.PatchAll(typeof(PatchOnNearColliderLogic));
			harmony.PatchAll(typeof(PatchOnPlanetAlgorithm));
			harmony.PatchAll(typeof(PatchOnPlanetAtmoBlur));
			harmony.PatchAll(typeof(PatchOnPlanetAuxData));
			harmony.PatchAll(typeof(PatchOnPlanetData));
			harmony.PatchAll(typeof(PatchOnPlanetDataDirtyMesh));
			harmony.PatchAll(typeof(PatchOnPlanetFactory));
			harmony.PatchAll(typeof(PatchOnPlanetGrid));
			harmony.PatchAll(typeof(PatchOnPlanetModelingManager));
			harmony.PatchAll(typeof(PatchOnPlanetRawData));
			harmony.PatchAll(typeof(PatchOnPlanetSimulator));
			harmony.PatchAll(typeof(PatchOnPlatformSystem));
			harmony.PatchAll(typeof(PatchOnPlayerFootsteps));
			harmony.PatchAll(typeof(PatchOnPlayerMove_Fly));
			harmony.PatchAll(typeof(PatchOnPlayerMove_Sail));
			harmony.PatchAll(typeof(PatchOnPowerSystem));
			harmony.PatchAll(typeof(PatchOnSectorModel));
			harmony.PatchAll(typeof(PatchOnSpaceSector));
			harmony.PatchAll(typeof(PatchOnSprayCoaterComponent));
			harmony.PatchAll(typeof(PatchOnStarGen));
			harmony.PatchAll(typeof(PatchOnStationComponent));
			harmony.PatchAll(typeof(RemoteShipStuckRecovery));
			harmony.PatchAll(typeof(MoreMegaStructuresCompatibility));
			MoreMegaStructuresCompatibility.TryInstall(harmony);
			harmony.PatchAll(typeof(PatchOnThemeProto));
			harmony.PatchAll(typeof(PatchOnTrashSystem));
			harmony.PatchAll(typeof(PatchOnUIAchievementPanel));
			harmony.PatchAll(typeof(PatchOnUIAdvisorTip));
			harmony.PatchAll(typeof(PatchOnUIBuildingGrid));
			harmony.PatchAll(typeof(PatchOnUIBuildMenu));
			harmony.PatchAll(typeof(PatchOnUICommunicatorIndicator));
			harmony.PatchAll(typeof(PatchOnUIEnemyBriefInfo));
			harmony.PatchAll(typeof(PatchOnUIEscMenu));
			harmony.PatchAll(typeof(PatchOnUIGalaxySelect));
			harmony.PatchAll(typeof(PatchOnUIGame));
			harmony.PatchAll(typeof(PatchOnUIGameLoadingSplash));
			harmony.PatchAll(typeof(PatchOnUILoadGameWindow));
			harmony.PatchAll(typeof(PatchOnUIMainMenu));
			harmony.PatchAll(typeof(PatchOnUIOptionWindow));
			harmony.PatchAll(typeof(PatchOnUIPlanetDetail));
			harmony.PatchAll(typeof(PatchOnUIResearchResultsWindow));
			harmony.PatchAll(typeof(PatchOnUIRoot));
			harmony.PatchAll(typeof(PatchOnUISaveGameWindow));
			harmony.PatchAll(typeof(PatchOnUISpaceGuide));
			harmony.PatchAll(typeof(PatchOnUISpaceGuideEntry));
			harmony.PatchAll(typeof(PatchOnUIStarDetail));
			harmony.PatchAll(typeof(PatchOnUIStarmap));
			harmony.PatchAll(typeof(PatchOnUIStarmapPlanet));
			harmony.PatchAll(typeof(PatchOnUIStarmapStar));
			harmony.PatchAll(typeof(PatchOnUITutorialTip));
			harmony.PatchAll(typeof(PatchOnUIVeinDetail));
			harmony.PatchAll(typeof(PatchOnUIVersionText));
			harmony.PatchAll(typeof(PatchOnUIVirtualStarmap));
			harmony.PatchAll(typeof(PatchOnUniverseGen));
			harmony.PatchAll(typeof(PatchOnUniverseSimulator));
			harmony.PatchAll(typeof(PatchOnVFPreload));
			harmony.PatchAll(typeof(PatchOnWarningSystem));
		}
		catch (Exception ex)
		{
			GS2.Error(ex.ToString(), 184);
		}
	}

	public static void Debug(object data, LogLevel logLevel, bool isActive)
	{
		if (isActive && Logger != null)
		{
			while (buffer.Count > 0)
			{
				(object, LogLevel, bool) tuple = ((object, LogLevel, bool))buffer.Dequeue();
				if (tuple.Item3)
				{
					Logger.Log(tuple.Item2, "Q:" + tuple.Item1);
				}
			}
			Logger.Log(logLevel, data);
		}
		else
		{
			buffer.Enqueue((data, logLevel, true));
		}
	}

	public static void Debug(object data)
	{
		Debug(data, LogLevel.Message, isActive: true);
	}

	public static void WaitUntil(TestFunction t, TestThen u)
	{
		instance.StartCoroutine(WaitUntilRoutine(t, u));
	}

	public static IEnumerator WaitUntilRoutine(TestFunction t, TestThen u)
	{
		yield return new WaitUntil(() => t());
		u();
	}
}
