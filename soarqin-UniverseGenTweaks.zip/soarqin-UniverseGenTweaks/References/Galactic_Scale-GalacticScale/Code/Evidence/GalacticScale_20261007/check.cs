using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using GalacticScale;

static class Check
{
    static void Assert(bool ok, string label) { if (!ok) throw new Exception(label); Console.WriteLine("PASS " + label); }
    static string loadedSettingsPath;
    static int loadedStarCount;
    static bool ThemeLibraryStub(ref ThemeLibrary __result) { __result = new ThemeLibrary(); return false; }
    static bool SidecarLoaderStub(string path, ref bool __result)
    {
        // Read actual sidecar bytes; native Unity theme allocation belongs to game acceptance.
        var settings = GSSerializer.fsJsonParser.Parse(File.ReadAllText(path)).AsDictionary;
        GSSettings.Seed = (int)settings["Seed"].AsInt64;
        loadedStarCount = settings["Stars"].AsList.Count;
        loadedSettingsPath = path;
        __result = true;
        return false;
    }
    static void CheckSaveImport()
    {
        var harmony = new Harmony("gs2.save.import.check");
        harmony.Patch(AccessTools.Method(typeof(ThemeLibrary), "Vanilla"), prefix: new HarmonyMethod(typeof(Check), nameof(ThemeLibraryStub)));
        harmony.Patch(AccessTools.Method(typeof(GS2), "LoadSettingsFromJson"), prefix: new HarmonyMethod(typeof(Check), nameof(SidecarLoaderStub)));
        try
        {
        var saveFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Dyson Sphere Program", "Save");
        GS2.ActiveGenerator = GS2.GetGeneratorByID("space.customizing.generators.gs2dev");
        foreach (var name in new[] { "_lastexit_", "bug" })
        {
            var sidecar = Path.Combine(saveFolder, name + ".gs2");
            Console.WriteLine("CHECK parse real sidecar " + name);
            var settings = GSSerializer.fsJsonParser.Parse(File.ReadAllText(sidecar)).AsDictionary;
            var nativeSave = Path.Combine(saveFolder, name + ".dsv");
            bool realNativeSave = File.Exists(nativeSave);
            Console.WriteLine(realNativeSave ? "CHECK real native save" : "CHECK synthetic native marker: current .dsv is absent");
            using (var r = new BinaryReader(realNativeSave ? (Stream)File.OpenRead(nativeSave) : new MemoryStream(new byte[248093])))
            {
                r.BaseStream.Position = 248092;
                GS2.SaveOrLoadWindowOpen = false;
                Console.WriteLine("CHECK import real sidecar " + name);
                loadedSettingsPath = null;
                Assert(GS2.Import(r, sidecar) && loadedSettingsPath == sidecar, name + " real sidecar reaches existing loader without legacy-read exception");
                Assert(r.BaseStream.Position == 248092, name + " native save position is unchanged");
                Assert(GSSettings.Seed == settings["Seed"].AsInt64 && loadedStarCount == settings["Stars"].AsList.Count && GSSettings.Instance.imported,
                    name + " real JSON reaches loader fixture and imported state is set");
                var imported = GSSettings.Instance;
                GS2.SaveOrLoadWindowOpen = true;
                loadedSettingsPath = null;
                Assert(GS2.Import(r, sidecar) && loadedSettingsPath == null && r.BaseStream.Position == 248092 && ReferenceEquals(imported, GSSettings.Instance),
                    name + " thumbnail probe preserves native data and active settings");
            }
        }
        foreach (var bytes in new[] {
            new byte[0], new byte[] { 0 }, new byte[] { 3, 50 },
            new byte[] { 3, 50, 46, 48, 255, 255, 255, 127 },
            new byte[] { 3, 50, 46, 48, 255, 255, 255, 255, 255 },
            new byte[] { 3, 50, 46, 48, 2, 123, 125 } })
        {
            using (var r = new BinaryReader(new MemoryStream(bytes)))
            {
                var settings = GSSettings.Instance;
                Assert(GS2.Import(r) && r.BaseStream.Position == 0 && ReferenceEquals(settings, GSSettings.Instance),
                    "absent/truncated/oversized/invalid optional legacy payload restores stream and preview state");
            }
        }
        using (var stream = new MemoryStream())
        {
            var w = new BinaryWriter(stream);
            w.Write("2.0"); w.Write("{\"Seed\":1367,\"Stars\":[],\"ThemeLibrary\":{}}");
            var end = stream.Position;
            w.Write(0x12345678); w.Flush(); stream.Position = 0;
            var r = new BinaryReader(stream);
            GS2.SaveOrLoadWindowOpen = false;
            Assert(GS2.Import(r) && stream.Position == end && GSSettings.Seed == 1367 && r.ReadInt32() == 0x12345678,
                "valid embedded legacy settings consume only their own bytes");
            stream.Position = 0;
            var sidecar = Path.Combine(saveFolder, "bug.gs2");
            var seed = GSSerializer.fsJsonParser.Parse(File.ReadAllText(sidecar)).AsDictionary["Seed"].AsInt64;
            Assert(GS2.Import(r, sidecar) && stream.Position == end && GSSettings.Seed == seed,
                "mixed legacy plus sidecar preserves byte alignment and sidecar precedence");
        }
        GS2.SaveOrLoadWindowOpen = false;
        }
        finally { harmony.UnpatchSelf(); GS2.SaveOrLoadWindowOpen = false; }
    }
    [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
    static void CheckGenerationDiagnostics(string diagnosticsDir)
    {
        AccessTools.Field(typeof(GS2), "AssemblyPath").SetValue(null, diagnosticsDir);
        Bootstrap.Logger = new BepInEx.Logging.ManualLogSource("GS2 check");
        var errors = new List<string>();
        Bootstrap.Logger.LogEvent += (_, e) => { if (e.Level == BepInEx.Logging.LogLevel.Error) errors.Add(e.Data.ToString()); };
        Assert(!GS2.Config.DebugMode, "diagnostic regression runs with debug logging disabled");
        Exception generationError;
        try { throw new InvalidOperationException("generation-diagnostic-marker", new ArgumentException("inner-diagnostic-marker")); }
        catch (Exception e) { generationError = e; }
        GS2.DumpException(generationError);
        Assert(errors.Any(e => e.Contains("System.InvalidOperationException") && e.Contains("inner-diagnostic-marker") && e.Contains(nameof(CheckGenerationDiagnostics))),
            "full exception, inner cause and original stack are emitted at Error level with debug disabled");
        var report = System.IO.Directory.GetFiles(System.IO.Path.Combine(diagnosticsDir, "ErrorLog"), "*.exceptionlog.json").Single();
        Assert(System.IO.File.ReadAllText(report).Contains("generation-diagnostic-marker"), "exception report is actually written to ErrorLog");
        var processInstructions = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(GS2), "ProcessGalaxyLocked"));
        Assert(processInstructions.Any(i => i.Calls(AccessTools.Method(typeof(GS2), "DumpException"))),
            "galaxy generation catch records the exception before displaying the generic error");
    }
    static object ProcessingLock => AccessTools.Field(typeof(PlanetModelingManager), "planetProcessingLock").GetValue(null);
    static GalaxyData regenerated;
    static bool GenerationStub(GameDesc desc, ref GalaxyData __result)
    {
        Assert(System.Threading.Monitor.IsEntered(ProcessingLock), "settings remain protected by the worker lock throughout regeneration");
        Assert(!SystemDisplay.inSystemDisplay && SystemDisplay.viewStar == null, "old system selection is cleared before generation");
        regenerated = new GalaxyData { starCount = desc.starCount };
        __result = regenerated;
        return false;
    }
    static PlanetAlgorithm fixtureAlgorithm;
    static bool AlgorithmStub(ref PlanetAlgorithm __result) { __result = fixtureAlgorithm; return false; }
    static bool LocalPlanetStub(ref PlanetData __result) { __result = null; return false; }
    static bool CalcVertsStub() { return false; }
    class FailingAlgorithm : PlanetAlgorithm
    {
        public PlanetRawData seenData;
        public override void GenerateVegetables() { }
        public override void GenerateVeins() { }
        public override void GenerateTerrain(double x, double y)
        {
            seenData = planet.data;
            throw new InvalidOperationException("scan-fixture-failure");
        }
    }
    [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
    static void CheckRegeneration()
    {
        var planet = new PlanetData { id = 101 };
        var queued = new List<object>();
        foreach (string name in new[] { "scnPlanetReqList", "genPlanetReqList", "modPlanetReqList", "fctPlanetReqList" })
        {
            var field = AccessTools.Field(typeof(PlanetModelingManager), name);
            var queue = (Queue<PlanetData>)field.GetValue(null) ?? new Queue<PlanetData>();
            field.SetValue(null, queue);
            queue.Enqueue(planet); queued.Add(queue);
        }
        var held = new System.Threading.ManualResetEvent(false);
        var release = new System.Threading.ManualResetEvent(false);
        var resetStarted = new System.Threading.ManualResetEvent(false);
        var resetFinished = new System.Threading.ManualResetEvent(false);
        var worker = new System.Threading.Thread(() => { lock (ProcessingLock) { held.Set(); release.WaitOne(); } });
        worker.Start(); Assert(held.WaitOne(5000), "worker acquired its processing lock");
        var reset = new System.Threading.Thread(() => { resetStarted.Set(); Modeler.Reset(); resetFinished.Set(); });
        reset.Start(); resetStarted.WaitOne();
        try { Assert(!resetFinished.WaitOne(100), "reset waits for an active worker instead of changing queues underneath it"); }
        finally { release.Set(); worker.Join(5000); reset.Join(5000); }
        Assert(resetFinished.WaitOne(0), "reset completes after the old worker finishes");
        int q = 0;
        foreach (string name in new[] { "scnPlanetReqList", "genPlanetReqList", "modPlanetReqList", "fctPlanetReqList" })
        {
            var queue = (Queue<PlanetData>)AccessTools.Field(typeof(PlanetModelingManager), name).GetValue(null);
            Assert(ReferenceEquals(queue, queued[q++]) && queue.Count == 0, "cancelled " + name + " keeps its original lock object");
        }
        var getter = AccessTools.Method(typeof(SystemDisplay), "GetDisplayedPlanet");
        var resetView = AccessTools.Method(typeof(SystemDisplay), "ResetGalaxyView");
        foreach (StarData star in new[] { null, new StarData(), new StarData { planets = new[] { planet } } })
        {
            SystemDisplay.viewStar = star;
            foreach (int index in new[] { -1, 0, 1, 2, int.MaxValue })
            {
                var result = getter.Invoke(null, new object[] { index });
                Assert(ReferenceEquals(result, star?.planets != null && index == 1 ? planet : null), "display click safely resolves null/stale/out-of-range planet selection");
                if (result == null)
                {
                    AccessTools.Method(typeof(SystemDisplay), "OnSolarSystemPlanetClick").Invoke(null, new object[] { index });
                    AccessTools.Method(typeof(SystemDisplay), "OnSolarSystemPlanetRightClick").Invoke(null, new object[] { null, index });
                }
            }
        }
        SystemDisplay.inSystemDisplay = true;
        resetView.Invoke(null, null);
        Assert(SystemDisplay.viewStar == null && !SystemDisplay.inSystemDisplay, "regenerated galaxy drops the previous system view");
        var harmony = new Harmony("gs2.regeneration.check");
        try
        {
            harmony.Patch(AccessTools.Method(typeof(GS2), "ProcessGalaxyLocked"), prefix: new HarmonyMethod(typeof(Check), nameof(GenerationStub)));
            foreach (int count in new[] { 250, 512 })
            {
                SystemDisplay.inSystemDisplay = true; SystemDisplay.viewStar = new StarData();
                var result = GS2.ProcessGalaxy(new GameDesc { starCount = count }, true);
                Assert(ReferenceEquals(result, regenerated) && result.starCount == count, "regeneration wrapper preserves requested galaxy size " + count);
            }
            harmony.Patch(AccessTools.Method(typeof(PlanetModelingManager), "Algorithm"), prefix: new HarmonyMethod(typeof(Check), nameof(AlgorithmStub)));
            harmony.Patch(AccessTools.PropertyGetter(typeof(GameMain), "localPlanet"), prefix: new HarmonyMethod(typeof(Check), nameof(LocalPlanetStub)));
            harmony.Patch(AccessTools.Method(typeof(PlanetRawData), "CalcVerts"), prefix: new HarmonyMethod(typeof(Check), nameof(CalcVertsStub)));
            foreach (bool hadData in new[] { false, true })
            {
                var scanPlanet = new PlanetData { precision = 20 };
                var original = hadData ? new PlanetRawData(20) : null;
                scanPlanet.data = original;
                var algorithm = new FailingAlgorithm(); algorithm.Reset(1, scanPlanet); fixtureAlgorithm = algorithm;
                bool failed = false;
                try { Modeler.ScanPlanetGS(scanPlanet); }
                catch (InvalidOperationException e) { failed = e.Message == "scan-fixture-failure"; }
                Assert(failed && algorithm.seenData != null, "failure fixture executes the real scan allocation path");
                Assert(hadData ? ReferenceEquals(original, algorithm.seenData) && ReferenceEquals(original, scanPlanet.data)
                    : scanPlanet.data == null && scanPlanet.aux == null, "failed scan releases temporary data and preserves existing data");
                if (original != null) original.Free();
            }
        }
        finally { harmony.UnpatchSelf(); }
        var copy = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(GSTheme), "CopyFrom"));
        Assert(!copy.Any(i => i.operand is MethodInfo m && m.Name == "Instantiate" && m.IsGenericMethod && m.GetGenericArguments().Contains(typeof(UnityEngine.AudioClip))),
            "theme copies no longer allocate a new native audio clip per variant/regeneration");
    }
    static void CheckUpstreamFeatures()
    {
        Assert(PatchOnBuildTool_Reform.MaxBrushSize == 20, "upstream 20x20 foundation brush is retained");
        Assert(PatchOnPlanetATField.GetShieldReachFactor(200f, 0.25f, 0.5f) == 1f,
            "upstream shield scaling preserves the reference planet radius");
        Assert(PatchOnPlanetATField.GetShieldReachFactor(50f, 0.25f, 0f) > 1f &&
            PatchOnPlanetATField.GetShieldReachFactor(400f, 0f, 0.5f) < 1f &&
            PatchOnPlanetATField.GetShieldReachFactor(50f, 0f, 0f) == 1f,
            "upstream small/large shield controls and disabled scaling are retained");
        var click = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(SystemDisplay), "OnSolarSystemPlanetRightClick"));
        Assert(click.Any(i => i.LoadsConstant(5)) && click.Any(i => i.operand is MethodInfo m && m.Name == "Popup"),
            "upstream gas giant birth selection guard is retained alongside safe click lookup");
        var layout = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(SystemDisplay), "InitHelpText"));
        Assert(layout.Any(i => i.Calls(AccessTools.Method(typeof(SystemDisplay), "MoveMetadataPanelToTopLeft"))),
            "upstream top-left metadata panel layout is retained");
        Assert(AccessTools.Method(typeof(GalacticScale.Generators.GS2Generator2), "GetSelectedBirthPlanetTheme") != null &&
            AccessTools.Method(typeof(PatchOnPlanetModelingManager), "LoadingPlanetFactoryMain_Finalizer") != null &&
            AccessTools.Method(typeof(PatchOnDysonStatistics), "RefreshDetailData_Transpiler") != null,
            "upstream birth theme, factory loading context and Dyson statistics patches are retained");
    }
    static readonly List<UnityEngine.Object> destroyedResources = new List<UnityEngine.Object>();
    static bool DestroyResourceStub(UnityEngine.Object resource) { destroyedResources.Add(resource); return false; }
    static UnityEngine.Object FakeResource(int id)
    {
        var resource = (UnityEngine.Material)System.Runtime.Serialization.FormatterServices.GetUninitializedObject(typeof(UnityEngine.Material));
        AccessTools.Field(typeof(UnityEngine.Object), "m_CachedPtr").SetValue(resource, new IntPtr(id));
        return resource;
    }
    static GSTheme EmptyTheme()
    {
        var theme = (GSTheme)System.Runtime.Serialization.FormatterServices.GetUninitializedObject(typeof(GSTheme));
        AccessTools.Field(typeof(GSTheme), "ownedResources").SetValue(theme, new List<UnityEngine.Object>());
        return theme;
    }
    static void CheckOwnedResources()
    {
        var harmony = new Harmony("gs2.resource.check");
        var external = GS2.externalThemes;
        var own = AccessTools.Method(typeof(GSTheme), "OwnResource").MakeGenericMethod(typeof(UnityEngine.Object));
        var release = AccessTools.Method(typeof(GSTheme), "ReleaseGenerationResources");
        try
        {
            harmony.Patch(AccessTools.Method(typeof(ThemeLibrary), "Vanilla"), prefix: new HarmonyMethod(typeof(Check), nameof(ThemeLibraryStub)));
            harmony.Patch(AccessTools.Method(typeof(GSTheme), "DestroyOwnedResource"), prefix: new HarmonyMethod(typeof(Check), nameof(DestroyResourceStub)));
            var persistent = EmptyTheme(); var protectedResource = FakeResource(1);
            own.Invoke(persistent, new object[] { protectedResource });
            GS2.externalThemes = new ThemeLibrary(); GS2.externalThemes.Add("persistent-fixture", persistent);
            destroyedResources.Clear();
            for (int i = 0; i < 65; i++)
            {
                var abandoned = EmptyTheme(); var current = EmptyTheme();
                own.Invoke(abandoned, new object[] { FakeResource(2 + i * 2) });
                own.Invoke(current, new object[] { FakeResource(3 + i * 2) });
                // A generated theme borrowing a persistent resource must not destroy it.
                own.Invoke(current, new object[] { protectedResource });
                release.Invoke(null, null);
                Assert(destroyedResources.Count == (i + 1) * 2, "generation " + i + " releases both current and overwritten theme allocations");
            }
            Assert(!destroyedResources.Any(x => ReferenceEquals(x, protectedResource)), "persistent external resources survive all 65 resets");
            release.Invoke(null, null);
            Assert(destroyedResources.Count == 130, "resource reset is idempotent");
            GS2.externalThemes = new ThemeLibrary(); release.Invoke(null, null);
            Assert(destroyedResources.Count == 131, "resources are released when their persistent owner is removed");
            var clone = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(GSAmbientSettings), "Clone"));
            Assert(!clone.Any(i => i.operand is MethodInfo m && m.Name == "Instantiate"), "ambient clone shares read-only cubemaps instead of allocating a new native texture");
            var reset = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(GSSettings), "Reset"));
            Assert(reset.Any(i => i.Calls(release)), "every GSSettings.Reset reaches resource cleanup");
            var copy = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(GSTheme), "CopyFrom"));
            Assert(copy.Count(i => i.operand is MethodInfo m && m.Name == "OwnResource") == 8,
                "all seven copied materials and copied ambient component are registered for native cleanup");
            var destroy = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(GSTheme), "DestroyOwnedResource"));
            Assert(destroy.Any(i => i.operand is MethodInfo m && m.Name == "get_gameObject"), "owned ambient component destroys its entire cloned GameObject");
            var tint = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(GSAmbientSettings), "ToTheme"));
            Assert(tint.Any(i => i.operand is FieldInfo f && f.Name == "tintedReflectionMap") &&
                tint.Any(i => i.operand is MethodInfo m && m.Name == "OwnResource"), "reflection tint is cached and its native texture is owned");
            var wait = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(PatchOnUIGalaxySelect.Delayer), "Wait"));
            Assert(!wait.Any(i => i.Calls(AccessTools.Method(typeof(PatchOnUIGalaxySelect.Delayer), "WaitAWhile"))), "drag has no one-second timer racing pointer release");
        }
        finally { GS2.externalThemes = external; harmony.UnpatchSelf(); }
    }
    class MemoryFailingAlgorithm : PlanetAlgorithm
    {
        public int attempts;
        public override void GenerateVegetables() { }
        public override void GenerateVeins() { }
        public override void GenerateTerrain(double x, double y) { attempts++; throw new OutOfMemoryException("safe injected memory failure"); }
    }
    static void CheckMemoryFailure()
    {
        var harmony = new Harmony("gs2.memory.failure.check");
        var scanThreadField = AccessTools.Field(typeof(PlanetModelingManager), "planetScanThread");
        var scanFlag = AccessTools.Field(typeof(PlanetModelingManager), "planetScanThreadFlag");
        var oldThread = scanThreadField.GetValue(null); var oldFlag = scanFlag.GetValue(null);
        var exhausted = AccessTools.Field(typeof(Modeler), "scanMemoryExhausted");
        var queue = (Queue<PlanetData>)AccessTools.Field(typeof(PlanetModelingManager), "scnPlanetReqList").GetValue(null);
        var first = new PlanetData { precision = 8, scanning = true }; var pending = new PlanetData { precision = 8, scanning = true };
        var algorithm = new MemoryFailingAlgorithm(); algorithm.Reset(1, first); fixtureAlgorithm = algorithm;
        Exception threadError = null;
        var thread = new System.Threading.Thread(() => { try { Modeler.Scan(); } catch (Exception e) { threadError = e; } });
        try
        {
            harmony.Patch(AccessTools.Method(typeof(PlanetModelingManager), "Algorithm"), prefix: new HarmonyMethod(typeof(Check), nameof(AlgorithmStub)));
            harmony.Patch(AccessTools.PropertyGetter(typeof(GameMain), "localPlanet"), prefix: new HarmonyMethod(typeof(Check), nameof(LocalPlanetStub)));
            harmony.Patch(AccessTools.Method(typeof(PlanetRawData), "CalcVerts"), prefix: new HarmonyMethod(typeof(Check), nameof(CalcVertsStub)));
            Modeler.Reset(); lock(queue) { queue.Enqueue(first); queue.Enqueue(pending); }
            scanThreadField.SetValue(null, thread); scanFlag.SetValue(null, Enum.Parse(scanFlag.FieldType, "Running")); thread.Start();
            bool stopped = System.Threading.SpinWait.SpinUntil(() => { lock(ProcessingLock) return (bool)exhausted.GetValue(null) && !first.scanning; }, 5000);
            Assert(stopped && threadError == null && algorithm.attempts == 1 && queue.Count == 0 && !pending.scanning,
                "real scan loop stops after one injected OOM and cancels queued scans");
            var late = new PlanetData { precision = 8, scanning = true }; lock(queue) queue.Enqueue(late);
            Assert(System.Threading.SpinWait.SpinUntil(() => { lock(ProcessingLock) return !late.scanning; }, 5000) && algorithm.attempts == 1,
                "late scan requests are cancelled without further allocation retries");
            Assert(first.data == null && first.aux == null && !first.scanned && !Modeler.processing.Contains(first), "OOM frees temporary scan data and clears in-flight flags");
            scanFlag.SetValue(null, Enum.Parse(scanFlag.FieldType, "Ending")); Assert(thread.Join(5000), "scan worker exits cleanly");
            Modeler.Reset(); Assert(!(bool)exhausted.GetValue(null), "fresh generation clears OOM latch");
        }
        finally
        {
            scanFlag.SetValue(null, Enum.Parse(scanFlag.FieldType, "Ending")); if(thread.IsAlive) thread.Join(5000);
            scanThreadField.SetValue(null, oldThread); scanFlag.SetValue(null, oldFlag); harmony.UnpatchSelf();
        }
    }
    static int Main()
    {
        var diagnosticsDir = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "gs2-error-check-" + Guid.NewGuid());
        AccessTools.Method(typeof(BepInEx.Paths), "SetExecutablePath").Invoke(null, new object[] {
            System.IO.Path.Combine(diagnosticsDir, "DSPGAME.exe"), System.IO.Path.Combine(diagnosticsDir, "BepInEx"),
            "D:/Games/Dyson Sphere Program/DSPGAME_Data/Managed", new string[0]});
        CheckGenerationDiagnostics(diagnosticsDir);
        if (Type.GetType("Mono.Runtime") != null) CheckSaveImport();
        CheckUpstreamFeatures();
        // The game's Queue fields use netstandard 2.1; lifecycle checks run in its actual Mono runtime.
        if (Type.GetType("Mono.Runtime") != null)
        {
            CheckRegeneration(); CheckOwnedResources(); CheckMemoryFailure();
        }
        var platform = AccessTools.Method(typeof(PatchOnPlatformSystem), "DetermineLongitudeSegmentCount");
        var grid = AccessTools.Method(typeof(PatchOnPlanetGrid), "DetermineLongitudeSegmentCount");
        var platformInstructions = PatchProcessor.GetOriginalInstructions(platform);
        Assert(platformInstructions.Any(i => i.Calls(grid)) &&
            !platformInstructions.Any(i => i.opcode == OpCodes.Ldarg_0),
            "static platform patch uses shared grid calculation without dereferencing null instance");
        var generator = new DynamicMethod("buffer", typeof(void), Type.EmptyTypes).GetILGenerator();
        var native = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(SectorModel), "CreateGalaxyAstroBuffer"), generator);
        Assert(native.Count(i => i.LoadsConstant(25600)) == 4, "current native game has four buffer constants");
        var originalUgt = Assembly.LoadFile(System.IO.Path.Combine(Environment.CurrentDirectory, "soarqin-UniverseGenTweaks", "UniverseGenTweaks.dll"));
        var ugt = originalUgt.GetType("UniverseGenTweaks.MoreSettings+PermanentPatch").GetMethod("SectorModel_CreateGalaxyAstroBuffer_Transpiler", BindingFlags.Static | BindingFlags.NonPublic);
        Func<IEnumerable<CodeInstruction>, List<CodeInstruction>> applyUgt = input => ((IEnumerable<CodeInstruction>)ugt.Invoke(null, new object[] {input, generator})).ToList();
        var gsFirst = applyUgt(PatchOnSectorModel.TranspilerSectorModelCreateGalaxyAstroBuffer(native.Select(i => new CodeInstruction(i))).ToList());
        var ugtFirst = PatchOnSectorModel.TranspilerSectorModelCreateGalaxyAstroBuffer(applyUgt(native.Select(i => new CodeInstruction(i)))).ToList();
        var calc = AccessTools.Method(typeof(PatchOnSectorModel), "CalcAstroBufferSize");
        foreach (var result in new[] {gsFirst, ugtFirst})
        {
            Assert(result.Count(i => i.Calls(calc)) == 4 && !result.Any(i => i.LoadsConstant(25600) || i.LoadsConstant(102500)), "both patch orders use galaxy-sized buffers");
            Assert(result.Count == native.Count, "patch order preserves native instruction count");
        }
        return 0;
    }
}
