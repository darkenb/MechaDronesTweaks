using System;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using GalacticScale;

static class Check
{
    static void Assert(bool ok, string label) { if (!ok) throw new Exception(label); Console.WriteLine("PASS " + label); }
    [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
    static void CheckGenerationDiagnostics(string diagnosticsDir)
    {
        AccessTools.Field(typeof(GS2), "AssemblyPath").SetValue(null, diagnosticsDir);
        Bootstrap.Logger = new BepInEx.Logging.ManualLogSource("GS2 check");
        var errors = new List<string>();
        Bootstrap.Logger.LogEvent += (_, e) => { if (e.Level == BepInEx.Logging.LogLevel.Error) errors.Add(e.Data.ToString()); };
        Assert(!GS2.Config.DebugMode, "diagnostic regression runs with debug logging disabled");
        Exception generationError;
        try { throw new InvalidOperationException("generation-diagnostic-marker", new ArgumentException("inner-diagnostic-marker")); }
        catch (Exception e) { generationError = e; }
        GS2.DumpException(generationError);
        Assert(errors.Any(e => e.Contains("System.InvalidOperationException") && e.Contains("inner-diagnostic-marker") && e.Contains(nameof(CheckGenerationDiagnostics))),
            "full exception, inner cause and original stack are emitted at Error level with debug disabled");
        var report = System.IO.Directory.GetFiles(System.IO.Path.Combine(diagnosticsDir, "ErrorLog"), "*.exceptionlog.json").Single();
        Assert(System.IO.File.ReadAllText(report).Contains("generation-diagnostic-marker"), "exception report is actually written to ErrorLog");
        var processInstructions = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(GS2), "ProcessGalaxyLocked"));
        Assert(processInstructions.Any(i => i.Calls(AccessTools.Method(typeof(GS2), "DumpException"))),
            "galaxy generation catch records the exception before displaying the generic error");
    }
    static object ProcessingLock => AccessTools.Field(typeof(PlanetModelingManager), "planetProcessingLock").GetValue(null);
    static GalaxyData regenerated;
    static bool GenerationStub(GameDesc desc, ref GalaxyData __result)
    {
        Assert(System.Threading.Monitor.IsEntered(ProcessingLock), "settings remain protected by the worker lock throughout regeneration");
        Assert(!SystemDisplay.inSystemDisplay && SystemDisplay.viewStar == null, "old system selection is cleared before generation");
        regenerated = new GalaxyData { starCount = desc.starCount };
        __result = regenerated;
        return false;
    }
    static PlanetAlgorithm fixtureAlgorithm;
    static bool AlgorithmStub(ref PlanetAlgorithm __result) { __result = fixtureAlgorithm; return false; }
    static bool LocalPlanetStub(ref PlanetData __result) { __result = null; return false; }
    static bool CalcVertsStub() { return false; }
    class FailingAlgorithm : PlanetAlgorithm
    {
        public PlanetRawData seenData;
        public override void GenerateVegetables() { }
        public override void GenerateVeins() { }
        public override void GenerateTerrain(double x, double y)
        {
            seenData = planet.data;
            throw new InvalidOperationException("scan-fixture-failure");
        }
    }
    [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
    static void CheckRegeneration()
    {
        var planet = new PlanetData { id = 101 };
        var queued = new List<object>();
        foreach (string name in new[] { "scnPlanetReqList", "genPlanetReqList", "modPlanetReqList", "fctPlanetReqList" })
        {
            var field = AccessTools.Field(typeof(PlanetModelingManager), name);
            var queue = (Queue<PlanetData>)field.GetValue(null) ?? new Queue<PlanetData>();
            field.SetValue(null, queue);
            queue.Enqueue(planet); queued.Add(queue);
        }
        var held = new System.Threading.ManualResetEvent(false);
        var release = new System.Threading.ManualResetEvent(false);
        var resetStarted = new System.Threading.ManualResetEvent(false);
        var resetFinished = new System.Threading.ManualResetEvent(false);
        var worker = new System.Threading.Thread(() => { lock (ProcessingLock) { held.Set(); release.WaitOne(); } });
        worker.Start(); Assert(held.WaitOne(5000), "worker acquired its processing lock");
        var reset = new System.Threading.Thread(() => { resetStarted.Set(); Modeler.Reset(); resetFinished.Set(); });
        reset.Start(); resetStarted.WaitOne();
        try { Assert(!resetFinished.WaitOne(100), "reset waits for an active worker instead of changing queues underneath it"); }
        finally { release.Set(); worker.Join(5000); reset.Join(5000); }
        Assert(resetFinished.WaitOne(0), "reset completes after the old worker finishes");
        int q = 0;
        foreach (string name in new[] { "scnPlanetReqList", "genPlanetReqList", "modPlanetReqList", "fctPlanetReqList" })
        {
            var queue = (Queue<PlanetData>)AccessTools.Field(typeof(PlanetModelingManager), name).GetValue(null);
            Assert(ReferenceEquals(queue, queued[q++]) && queue.Count == 0, "cancelled " + name + " keeps its original lock object");
        }
        var getter = AccessTools.Method(typeof(SystemDisplay), "GetDisplayedPlanet");
        var resetView = AccessTools.Method(typeof(SystemDisplay), "ResetGalaxyView");
        foreach (StarData star in new[] { null, new StarData(), new StarData { planets = new[] { planet } } })
        {
            SystemDisplay.viewStar = star;
            foreach (int index in new[] { -1, 0, 1, 2, int.MaxValue })
            {
                var result = getter.Invoke(null, new object[] { index });
                Assert(ReferenceEquals(result, star?.planets != null && index == 1 ? planet : null), "display click safely resolves null/stale/out-of-range planet selection");
                if (result == null)
                {
                    AccessTools.Method(typeof(SystemDisplay), "OnSolarSystemPlanetClick").Invoke(null, new object[] { index });
                    AccessTools.Method(typeof(SystemDisplay), "OnSolarSystemPlanetRightClick").Invoke(null, new object[] { null, index });
                }
            }
        }
        SystemDisplay.inSystemDisplay = true;
        resetView.Invoke(null, null);
        Assert(SystemDisplay.viewStar == null && !SystemDisplay.inSystemDisplay, "regenerated galaxy drops the previous system view");
        var harmony = new Harmony("gs2.regeneration.check");
        try
        {
            harmony.Patch(AccessTools.Method(typeof(GS2), "ProcessGalaxyLocked"), prefix: new HarmonyMethod(typeof(Check), nameof(GenerationStub)));
            foreach (int count in new[] { 250, 512 })
            {
                SystemDisplay.inSystemDisplay = true; SystemDisplay.viewStar = new StarData();
                var result = GS2.ProcessGalaxy(new GameDesc { starCount = count }, true);
                Assert(ReferenceEquals(result, regenerated) && result.starCount == count, "regeneration wrapper preserves requested galaxy size " + count);
            }
            harmony.Patch(AccessTools.Method(typeof(PlanetModelingManager), "Algorithm"), prefix: new HarmonyMethod(typeof(Check), nameof(AlgorithmStub)));
            harmony.Patch(AccessTools.PropertyGetter(typeof(GameMain), "localPlanet"), prefix: new HarmonyMethod(typeof(Check), nameof(LocalPlanetStub)));
            harmony.Patch(AccessTools.Method(typeof(PlanetRawData), "CalcVerts"), prefix: new HarmonyMethod(typeof(Check), nameof(CalcVertsStub)));
            foreach (bool hadData in new[] { false, true })
            {
                var scanPlanet = new PlanetData { precision = 20 };
                var original = hadData ? new PlanetRawData(20) : null;
                scanPlanet.data = original;
                var algorithm = new FailingAlgorithm(); algorithm.Reset(1, scanPlanet); fixtureAlgorithm = algorithm;
                bool failed = false;
                try { Modeler.ScanPlanetGS(scanPlanet); }
                catch (InvalidOperationException e) { failed = e.Message == "scan-fixture-failure"; }
                Assert(failed && algorithm.seenData != null, "failure fixture executes the real scan allocation path");
                Assert(hadData ? ReferenceEquals(original, algorithm.seenData) && ReferenceEquals(original, scanPlanet.data)
                    : scanPlanet.data == null && scanPlanet.aux == null, "failed scan releases temporary data and preserves existing data");
                if (original != null) original.Free();
            }
        }
        finally { harmony.UnpatchSelf(); }
        var copy = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(GSTheme), "CopyFrom"));
        Assert(!copy.Any(i => i.operand is MethodInfo m && m.Name == "Instantiate" && m.IsGenericMethod && m.GetGenericArguments().Contains(typeof(UnityEngine.AudioClip))),
            "theme copies no longer allocate a new native audio clip per variant/regeneration");
    }
    static int Main()
    {
        var diagnosticsDir = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "gs2-error-check-" + Guid.NewGuid());
        AccessTools.Method(typeof(BepInEx.Paths), "SetExecutablePath").Invoke(null, new object[] {
            System.IO.Path.Combine(diagnosticsDir, "DSPGAME.exe"), System.IO.Path.Combine(diagnosticsDir, "BepInEx"),
            "D:/Games/Dyson Sphere Program/DSPGAME_Data/Managed", new string[0]});
        CheckGenerationDiagnostics(diagnosticsDir);
        // The game's Queue fields use netstandard 2.1; lifecycle checks run in its actual Mono runtime.
        if (Type.GetType("Mono.Runtime") != null) CheckRegeneration();
        var platform = AccessTools.Method(typeof(PatchOnPlatformSystem), "DetermineLongitudeSegmentCount");
        var grid = AccessTools.Method(typeof(PatchOnPlanetGrid), "DetermineLongitudeSegmentCount");
        var platformInstructions = PatchProcessor.GetOriginalInstructions(platform);
        Assert(platformInstructions.Any(i => i.Calls(grid)) &&
            !platformInstructions.Any(i => i.opcode == OpCodes.Ldarg_0),
            "static platform patch uses shared grid calculation without dereferencing null instance");
        var generator = new DynamicMethod("buffer", typeof(void), Type.EmptyTypes).GetILGenerator();
        var native = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(SectorModel), "CreateGalaxyAstroBuffer"), generator);
        Assert(native.Count(i => i.LoadsConstant(25600)) == 4, "current native game has four buffer constants");
        var originalUgt = Assembly.LoadFile(System.IO.Path.Combine(Environment.CurrentDirectory, "soarqin-UniverseGenTweaks", "UniverseGenTweaks.dll"));
        var ugt = originalUgt.GetType("UniverseGenTweaks.MoreSettings+PermanentPatch").GetMethod("SectorModel_CreateGalaxyAstroBuffer_Transpiler", BindingFlags.Static | BindingFlags.NonPublic);
        Func<IEnumerable<CodeInstruction>, List<CodeInstruction>> applyUgt = input => ((IEnumerable<CodeInstruction>)ugt.Invoke(null, new object[] {input, generator})).ToList();
        var gsFirst = applyUgt(PatchOnSectorModel.TranspilerSectorModelCreateGalaxyAstroBuffer(native.Select(i => new CodeInstruction(i))).ToList());
        var ugtFirst = PatchOnSectorModel.TranspilerSectorModelCreateGalaxyAstroBuffer(applyUgt(native.Select(i => new CodeInstruction(i)))).ToList();
        var calc = AccessTools.Method(typeof(PatchOnSectorModel), "CalcAstroBufferSize");
        foreach (var result in new[] {gsFirst, ugtFirst})
        {
            Assert(result.Count(i => i.Calls(calc)) == 4 && !result.Any(i => i.LoadsConstant(25600) || i.LoadsConstant(102500)), "both patch orders use galaxy-sized buffers");
            Assert(result.Count == native.Count, "patch order preserves native instruction count");
        }
        return 0;
    }
}
