using System.Collections;

namespace NebulaAPI.DataStructures;

public static class CollectionExtensions
{
	public static Locker Lock(this ICollection collection)
	{
		return new Locker(collection.SyncRoot);
	}

	public static Locker GetLocked<T>(this T collection, out T result) where T : ICollection
	{
		result = collection;
		return new Locker(collection.SyncRoot);
	}
}
