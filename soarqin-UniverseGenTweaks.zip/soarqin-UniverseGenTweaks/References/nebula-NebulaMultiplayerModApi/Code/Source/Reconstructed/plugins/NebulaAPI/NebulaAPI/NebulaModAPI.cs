using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BepInEx;
using BepInEx.Bootstrap;
using HarmonyLib;
using NebulaAPI.GameState;
using NebulaAPI.Interfaces;

namespace NebulaAPI;

[BepInPlugin("dsp.nebula-multiplayer-api", "NebulaMultiplayerModApi", "2.1.0.7")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class NebulaModAPI : BaseUnityPlugin
{
	public const string NEBULA_MODID = "dsp.nebula-multiplayer";

	public const string API_GUID = "dsp.nebula-multiplayer-api";

	public const string API_NAME = "NebulaMultiplayerModApi";

	public const int PLANET_NONE = -2;

	public const int AUTHOR_NONE = -1;

	public const int STAR_NONE = -1;

	private static PropertyInfo multiplayerSessionGetter;

	private static ConstructorInfo binaryWriterConstructor;

	private static ConstructorInfo binaryReaderConstructor;

	public static readonly List<Assembly> TargetAssemblies = new List<Assembly>();

	public static Action OnMultiplayerGameStarted;

	public static Action OnMultiplayerGameEnded;

	public static Action<int> OnStarLoadRequest;

	public static Action<int> OnDysonSphereLoadFinished;

	public static Action<int> OnPlanetLoadRequest;

	public static Action<int> OnPlanetLoadFinished;

	public static Action<IPlayerData> OnPlayerJoinedGame;

	public static Action<IPlayerData> OnPlayerLeftGame;

	public static bool NebulaIsInstalled { get; set; }

	public static bool IsMultiplayerActive { get; private set; }

	public static IMultiplayerSession MultiplayerSession { get; private set; }

	public static void OnMultiplayerSessionChange(bool isActive)
	{
		IsMultiplayerActive = isActive;
		MultiplayerSession = (isActive ? ((IMultiplayerSession)(multiplayerSessionGetter?.GetValue(null))) : null);
	}

	private void Awake()
	{
		NebulaIsInstalled = false;
		using (IEnumerator<KeyValuePair<string, PluginInfo>> enumerator = Chainloader.PluginInfos.Where((KeyValuePair<string, PluginInfo> pluginInfo) => pluginInfo.Value.Metadata.GUID == "dsp.nebula-multiplayer").GetEnumerator())
		{
			if (enumerator.MoveNext())
			{
				KeyValuePair<string, PluginInfo> current = enumerator.Current;
				NebulaIsInstalled = true;
			}
		}
		if (NebulaIsInstalled)
		{
			multiplayerSessionGetter = AccessTools.TypeByName("NebulaWorld.Multiplayer").GetProperty("Session");
			Type type = AccessTools.TypeByName("NebulaModel.Networking.BinaryUtils");
			binaryWriterConstructor = type.GetNestedType("Writer").GetConstructor(Type.EmptyTypes);
			binaryReaderConstructor = type.GetNestedType("Reader").GetConstructor(new Type[1] { typeof(byte[]) });
			base.Logger.LogInfo("Nebula API is ready!");
		}
	}

	public static void RegisterPackets(Assembly assembly)
	{
		TargetAssemblies.Add(assembly);
	}

	public static IWriterProvider GetBinaryWriter()
	{
		if (!NebulaIsInstalled)
		{
			return null;
		}
		return (IWriterProvider)binaryWriterConstructor.Invoke(Array.Empty<object>());
	}

	public static IReaderProvider GetBinaryReader(byte[] bytes)
	{
		if (!NebulaIsInstalled)
		{
			return null;
		}
		return (IReaderProvider)binaryReaderConstructor.Invoke(new object[1] { bytes });
	}
}
