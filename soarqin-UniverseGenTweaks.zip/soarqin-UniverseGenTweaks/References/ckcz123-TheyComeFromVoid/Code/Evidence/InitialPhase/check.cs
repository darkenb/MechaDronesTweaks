using System;
using System.Reflection;
using System.Runtime.Serialization;
using HarmonyLib;
using DSP_Battle;

static class Check
{
    static void Assert(bool value, string name) { if (!value) throw new Exception(name); Console.WriteLine("PASS " + name); }
    static int Main()
    {
        using (var music = typeof(BattleBGMController).Assembly.GetManifestResourceStream("DSP_Battle.battlebgm"))
        {
            Assert(music != null, "battle music resource stream exists");
            Assert(music.Length == 27743236, "complete original battle music bundle embedded");
            using (var sha = System.Security.Cryptography.SHA256.Create())
                Assert(BitConverter.ToString(sha.ComputeHash(music)).Replace("-", "") ==
                    "7E7B16E17C92CFA9967DB918FA58AC14B75A924FFEF7CCD1AFF67971B482ECB1",
                    "battle music bundle matches original SHA-256");
        }
        var renderer = typeof(DSP_Battle.Configs).Assembly.GetType("DSP_Battle.RendererSphere", true);
        var idle = AccessTools.Method(renderer, "RSphereRenderBulletPostfix");
        Assert(!idle.IsDefined(typeof(HarmonyPatch), false) && !idle.IsDefined(typeof(HarmonyPostfix), false),
            "unused Update profiler callback is not registered");
        idle.Invoke(null, null);
        Assert(true, "idle render callback is safe without game or profiler initialization");
        var draw = AccessTools.Method(renderer, "DrawPostPostfix");
        var drawHarmony = new Harmony("test.tcfv.drawpost");
        drawHarmony.Patch(AccessTools.Method(typeof(GameLogic), "DrawPost"), postfix: new HarmonyMethod(draw));
        try {
            Assert(draw.GetParameters().Length == 0, "DrawPost uses no incompatible GameData instance injection");
            draw.Invoke(null, null);
        } finally { drawHarmony.UnpatchSelf(); }
        AccessTools.Field(typeof(ItemProto), "catalystAbilityById").SetValue(null, new float[12000]);
        ItemProto.catalystAbilityById[1211] = 2;
        ItemProto.catalystAbilityById[6522] = 4;
        ItemProto.catalystAbilityById[6523] = 8;
        var receiver = new PowerGeneratorComponent { genEnergyPerTick = 54000, warmup = 0.5f, entityId = 1,
            catalystId = 1211, catalystCount = 2, catalystInc = 8 };
        LensRelicSupport.Prepare(ref receiver);
        long baseline = LensRelicSupport.Request(ref receiver, 0.8f);
        Assert(receiver.curCatalystId == 1211 && receiver.catalystIncLevel == 4 && receiver.catalystPoint == 3500,
            "legacy free lens and minimum proliferator preserved");
        receiver.catalystId = 6522;
        LensRelicSupport.Prepare(ref receiver);
        long stronger = LensRelicSupport.Request(ref receiver, 0.8f);
        Assert(receiver.curCatalystId == 6522 && Math.Abs(stronger - baseline * 2) <= 1,
            "new supplied lens ability uses native capacity and request methods");
        receiver.curCatalystId = 6523; receiver.catalystId = 1211;
        LensRelicSupport.Prepare(ref receiver);
        Assert(receiver.curCatalystId == 6523, "stronger active lens is not downgraded");
        receiver.catalystIncLevel = 9; LensRelicSupport.Prepare(ref receiver);
        Assert(receiver.catalystIncLevel == 9, "higher proliferator level preserved");
        var harmony = new Harmony("test.tcfv.lens");
        harmony.Patch(AccessTools.Method(typeof(PowerGeneratorComponent), "GameTick_Gamma"),
            prefix: new HarmonyMethod(typeof(RelicFunctionPatcher), "GammaReceiverPatch"));
        harmony.Patch(AccessTools.Method(typeof(PowerGeneratorComponent), "EnergyCap_Gamma_Req"),
            prefix: new HarmonyMethod(typeof(RelicFunctionPatcher), "EnergyCapGammaReqPatch"));
        try
        {
            var factory = (PlanetFactory)FormatterServices.GetUninitializedObject(typeof(PlanetFactory));
            var signs = typeof(PlanetFactory).GetField("entitySignPool");
            signs.SetValue(factory, Array.CreateInstance(signs.FieldType.GetElementType(), 2));
            var products = new int[12000]; var consumption = new int[12000];
            Relic.relics = new[] {1 << 4, 0, 0, 0, 0};
            receiver.curCatalystId = 0; receiver.catalystPoint = 0; receiver.catalystIncLevel = 0;
            for (int i = 0; i < 500; i++) receiver.GameTick_Gamma(false, true, false, factory, products, consumption);
            Assert(receiver.catalystCount == 2 && receiver.catalystInc == 8 && consumption[1211] == 0,
                "free relic avoids first-tick and repeated physical lens consumption in native gamma tick");
            long relicRequest = receiver.EnergyCap_Gamma_Req(0, 0, -1, 0, 0.8f);
            Assert(relicRequest > 0 && receiver.currentStrength == 1, "relic retains night-side full reception");
            Relic.relics[0] = 0; receiver.catalystPoint = 0;
            receiver.GameTick_Gamma(false, true, false, factory, products, consumption);
            Assert(receiver.catalystCount == 1 && consumption[1211] == 1, "no relic follows native real lens consumption");
            receiver.x = 0; receiver.y = 0; receiver.z = 1;
            Assert(receiver.EnergyCap_Gamma_Req(0, 0, -1, 0, 0.8f) == 0, "no relic follows native night-side reception");
        }
        finally { harmony.UnpatchSelf(); }
        Assert(DSP_Battle.Configs.versionCode == 30251114, "save format version unchanged");
        return 0;
    }
}
