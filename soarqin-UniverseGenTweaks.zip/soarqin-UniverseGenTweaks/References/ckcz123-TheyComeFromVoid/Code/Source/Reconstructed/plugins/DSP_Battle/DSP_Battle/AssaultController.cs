using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using HarmonyLib;
using MoreMegaStructure;

namespace DSP_Battle;

public static class AssaultController
{
	public enum EAssaultModifier
	{
		DamageResist,
		Evade,
		AdditionalArmor,
		ShieldDamageBuff,
		DropletKiller,
		NoExp,
		KineticDamageSuppressor,
		EnergyDamageSuppressor,
		BlastDamageSuppressor,
		MagneticDamageSuppressor,
		SpaceJammer,
		DamageBuffSteal,
		QuickHeal,
		SuperSpeed
	}

	public static bool voidInvasionEnabled = false;

	public static int difficulty = 2;

	public static List<AssaultHive> assaultHives = new List<AssaultHive>();

	public static bool modifierEnabled;

	public static List<int> modifier;

	public static bool timeChangedByRelic = false;

	public static int nextRollVoidEcho = 1;

	public static int[] expandingHives;

	public static int[] invincibleHives;

	public static int[] modifierHives;

	public static int[] alertHives;

	public static bool assaultActive;

	public static int quickTickHive = -1;

	public static int quickTickFactor = 1;

	public static int testLvlSet = -1;

	public static List<int> oriAstroId = new List<int>();

	public static List<int> time = new List<int>();

	public static List<int> state = new List<int>();

	public static List<int> level = new List<int>();

	public static int count = 0;

	public const int DamageReduction = 0;

	public const int Dodge = 1;

	public const int DamageToShield = 2;

	public const int DropletInvincible = 3;

	public const int AddtionalArmor = 4;

	public const int SpeedUp = 5;

	public const int HardenedStructure = 6;

	public static int lancerModelIndex = 285;

	public static int oriLancerMarchMovementSpeed = 400;

	public static int oriLancerMaxMovementAcceleration = 500;

	public static int oriLancerMaxMovementSpeed = 1500;

	public static int basicInhibitPoint = 1000;

	public static List<int> modifierPoolEarly = new List<int> { 0, 1, 2, 3, 5, 11 };

	public static List<int> modifierPoolMid = new List<int> { 0, 1, 2, 3, 5, 8, 10, 11, 13 };

	public static List<int> modifierPoolLate = new List<int>
	{
		0, 1, 2, 3, 4, 5, 7, 8, 10, 11,
		12, 13
	};

	public static List<int> modifierValueMinEarly = new List<int>
	{
		10, 10, 3, 50, 1, 1, 30, 30, 30, 30,
		1, 10, 60, 50
	};

	public static List<int> modifierValueMinMid = new List<int>
	{
		20, 15, 30, 75, 2, 1, 100, 100, 100, 100,
		1, 30, 180, 100
	};

	public static List<int> modifierValueMinLate = new List<int>
	{
		30, 20, 120, 100, 5, 1, 300, 300, 300, 300,
		1, 40, 600, 200
	};

	public static List<int> modifierMaxActiveCount = new List<int>
	{
		1, 1, 2, 2, 2, 3, 3, 3, 3, 3,
		4, 4, 4, 5, 5, 5
	};

	public static int modifierTypeCount = 14;

	public static void InitWhenLoad()
	{
		voidInvasionEnabled = false;
		difficulty = 2;
		assaultHives = new List<AssaultHive>();
		expandingHives = new int[GameMain.spaceSector.maxHiveCount];
		invincibleHives = new int[GameMain.spaceSector.maxHiveCount];
		modifierHives = new int[GameMain.spaceSector.maxHiveCount];
		alertHives = new int[GameMain.spaceSector.maxHiveCount];
		modifier = new List<int>
		{
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0
		};
		timeChangedByRelic = false;
		nextRollVoidEcho = 1;
		ClearDataArrays();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(ThreadManager), "ProcessFrame")]
	public static void LogicTick(long frameCounter)
	{
		MMSCPU.BeginSample(TCFVPerformanceMonitor.MainLogic);
		MMSCPU.BeginSample(TCFVPerformanceMonitor.Assault);
		if (voidInvasionEnabled && assaultHives.Count == 0 && frameCounter % 3600 == 0L)
		{
			bool flag = false;
			if (GameMain.data.dysonSpheres != null)
			{
				for (int i = 0; i < GameMain.data.dysonSpheres.Length; i++)
				{
					if (GameMain.data.dysonSpheres[i] != null && (GameMain.data.dysonSpheres[i].energyGenCurrentTick_Swarm > 0 || GameMain.data.dysonSpheres[i].energyGenCurrentTick > 0))
					{
						flag = true;
						_ = GameMain.data.dysonSpheres[i].starData.index;
						break;
					}
				}
			}
			if (flag)
			{
				InitNewAssault();
			}
		}
		for (int j = 0; j < assaultHives.Count; j++)
		{
			assaultHives[j].LogicTick();
		}
		CalcCombatState();
		if (modifierEnabled && Configs.combatState == 3)
		{
			if (modifier[10] != 0)
			{
				CombatModuleComponent combatModuleComponent = GameMain.mainPlayer?.mecha?.spaceCombatModule;
				if (combatModuleComponent != null)
				{
					ModuleFleet[] moduleFleets = combatModuleComponent.moduleFleets;
					for (int k = 0; k < moduleFleets.Length; k++)
					{
						if (moduleFleets[k].protoId != DropletFleetPatchers.fleetConfigId1 && moduleFleets[k].protoId != DropletFleetPatchers.fleetConfigId2)
						{
							moduleFleets[k].fleetEnabled = false;
						}
					}
				}
			}
			if (modifier[13] > 0)
			{
				SpaceSector.PrefabDescByModelIndex[lancerModelIndex].unitMarchMovementSpeed = (float)oriLancerMarchMovementSpeed * ((float)modifier[13] * 1f / 100f);
				SpaceSector.PrefabDescByModelIndex[lancerModelIndex].unitMaxMovementAcceleration = (float)oriLancerMaxMovementAcceleration * ((float)modifier[13] * 1f / 100f);
			}
		}
		PostLogicTick(frameCounter);
		MMSCPU.EndSample(TCFVPerformanceMonitor.Assault);
		MMSCPU.EndSample(TCFVPerformanceMonitor.MainLogic);
	}

	public static void PostLogicTick(long time)
	{
		bool flag = assaultHives != null && assaultHives.Count > 0;
		for (int i = 0; i < assaultHives.Count; i++)
		{
			if (assaultHives[i].state == EAssaultHiveState.Remove)
			{
				expandingHives[assaultHives[i].byAstroIndex] = -1;
				invincibleHives[assaultHives[i].byAstroIndex] = -1;
				modifierHives[assaultHives[i].byAstroIndex] = -1;
				alertHives[assaultHives[i].byAstroIndex] = -1;
			}
			else
			{
				flag = false;
			}
		}
		if (flag && !MP.clientBlocker)
		{
			OnAssaultEnd();
		}
	}

	public static void CalcCombatState()
	{
		if (assaultHives == null || assaultHives.Count == 0)
		{
			Configs.combatState = 0;
			return;
		}
		bool flag = false;
		bool flag2 = false;
		bool flag3 = false;
		for (int i = 0; i < assaultHives.Count; i++)
		{
			if (assaultHives[i].state == EAssaultHiveState.Assault)
			{
				flag3 = true;
				break;
			}
			if (assaultHives[i].timeTillAssault <= 18000)
			{
				flag2 = true;
			}
			else if (assaultHives[i].state != EAssaultHiveState.End && assaultHives[i].state != EAssaultHiveState.Remove)
			{
				flag = true;
			}
		}
		if (flag3)
		{
			Configs.combatState = 3;
		}
		else if (flag2)
		{
			Configs.combatState = 2;
		}
		else if (flag)
		{
			Configs.combatState = 1;
		}
	}

	public static void ClearDataArrays()
	{
		if (expandingHives == null)
		{
			expandingHives = new int[GameMain.spaceSector.maxHiveCount];
		}
		else
		{
			for (int i = 0; i < expandingHives.Length; i++)
			{
				expandingHives[i] = -1;
			}
		}
		if (invincibleHives == null)
		{
			invincibleHives = new int[GameMain.spaceSector.maxHiveCount];
		}
		else
		{
			for (int j = 0; j < invincibleHives.Length; j++)
			{
				invincibleHives[j] = -1;
			}
		}
		if (modifierHives == null)
		{
			modifierHives = new int[GameMain.spaceSector.maxHiveCount];
		}
		else
		{
			for (int k = 0; k < modifierHives.Length; k++)
			{
				modifierHives[k] = -1;
			}
		}
		if (alertHives == null)
		{
			alertHives = new int[GameMain.spaceSector.maxHiveCount];
		}
		else
		{
			for (int l = 0; l < alertHives.Length; l++)
			{
				alertHives[l] = -1;
			}
		}
		if (modifier == null)
		{
			modifier = new List<int>
			{
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0
			};
		}
		else
		{
			for (int m = 0; m < modifier.Count; m++)
			{
				modifier[m] = 0;
			}
		}
		SpaceSector.PrefabDescByModelIndex[lancerModelIndex].unitMarchMovementSpeed = oriLancerMarchMovementSpeed;
		SpaceSector.PrefabDescByModelIndex[lancerModelIndex].unitMaxMovementAcceleration = oriLancerMaxMovementAcceleration;
		modifierEnabled = false;
		assaultHives.Clear();
	}

	public static void InitNewAssault(int starIndex = -1)
	{
		if (MP.clientBlocker)
		{
			return;
		}
		if (starIndex < 0)
		{
			long num = (long)((float)((long)SkillPoints.skillLevelR[8] * 1000000L) * SkillPoints.skillValuesR[8]);
			List<long> list = new List<long>();
			for (int i = 0; i < GameMain.galaxy.starCount; i++)
			{
				list.Add(0L);
				if (GameMain.galaxy.stars[i] == null)
				{
					continue;
				}
				PlanetData[] planets = GameMain.galaxy.stars[i].planets;
				for (int j = 0; j < GameMain.galaxy.stars[i].planetCount; j++)
				{
					if (planets[j] == null || planets[j].factory == null)
					{
						continue;
					}
					PowerSystem powerSystem = planets[j].factory.powerSystem;
					if (powerSystem == null)
					{
						continue;
					}
					for (int k = 1; k < powerSystem.netCursor; k++)
					{
						PowerNetwork powerNetwork = powerSystem.netPool[k];
						if (powerNetwork != null)
						{
							list[i] += powerNetwork.energyServed;
						}
					}
				}
				if (list[i] * 60 <= num)
				{
					list[i] = 0L;
				}
			}
			long num2 = list.Sum();
			if (num2 <= 0)
			{
				num2 = 1L;
			}
			List<double> list2 = new List<double>();
			if (list.Count > 1)
			{
				list2.Add((double)list[0] * 1.0 / (double)num2);
			}
			for (int l = 1; l < list.Count; l++)
			{
				list2.Add(list2[l - 1] + (double)list[l] * 1.0 / (double)num2);
			}
			double num3 = Utils.RandDouble();
			for (int m = 0; m < list2.Count; m++)
			{
				if (list2[m] >= num3)
				{
					starIndex = m;
					break;
				}
			}
		}
		ClearDataArrays();
		if (starIndex < 0)
		{
			return;
		}
		int num4 = Configs.wavePerStar[starIndex];
		int totalWave = Configs.totalWave;
		bool flag = totalWave % 5 == 4;
		int assaultTotalNum = GetAssaultTotalNum(num4);
		int val = assaultTotalNum / 1440 + 1;
		int val2 = Math.Min(assaultTotalNum / 1440 + 4, assaultTotalNum / 10 + 1) + 1;
		int num5 = Utils.RandInt(max: Math.Min(val2, 9), min: Math.Min(val, 8));
		int num6 = assaultTotalNum / num5;
		int hiveLevel = GetHiveLevel(num4);
		for (int n = 0; n < num5; n++)
		{
			int num7 = (int)(((Utils.RandDouble() - 0.5) / 2.5 + 1.0) * (double)num6) + 1;
			if (num7 > 1440)
			{
				num7 = 1440;
			}
			AssaultHive assaultHive = new AssaultHive(starIndex, n, assaultHives.Count);
			assaultHive.assaultNumTotal = num7;
			assaultHive.level = Math.Min(100, hiveLevel + (flag ? 20 : 0));
			assaultHive.hive.evolve.level = Math.Max(assaultHive.hive.evolve.level, assaultHive.level);
			float num8 = (float)Math.Max(assaultHive.level, 1) * 1f / 20f;
			if (num8 > 1f)
			{
				num8 = 1f + (num8 - 1f) / 4f;
			}
			assaultHive.inhibitPointsTotalInit = (int)(num8 * (float)basicInhibitPoint);
			assaultHive.inhibitPointsLimit = assaultHive.inhibitPointsTotalInit;
			if (n == num5 - 1)
			{
				assaultHive.inhibitPointsLimit = (int)((double)assaultHive.inhibitPointsLimit * 0.8) + 1;
			}
			assaultHive.time = n * 5;
			assaultHive.timeTillAssault = GetAssembleTime(num4) + 5 * n;
			assaultHive.timeTotalInit = assaultHive.timeTillAssault;
			if (flag)
			{
				assaultHive.isSuper = flag;
				assaultHive.timeTillAssault += 18000;
				assaultHive.timeTotalInit += 18000;
			}
			assaultHives.Add(assaultHive);
		}
		if (flag)
		{
			InitModifiers(totalWave, num4);
		}
		assaultActive = true;
		timeChangedByRelic = false;
		Configs.wavePerStar[starIndex]++;
		UIAssaultAlert.tipRefreshCounter = UIAssaultAlert.tipRefreshCounterResetValue;
		MP.Sync(EDataType.CallOnAssaultInited);
	}

	public static void InitModifiers(int waveCountTotal, int waveCountCur)
	{
		int num = waveCountTotal / 5;
		List<int> list = new List<int>();
		List<int> list2 = modifierPoolEarly;
		List<int> list3 = modifierValueMinEarly;
		if (num >= 10)
		{
			list2 = modifierPoolLate;
			list3 = modifierValueMinLate;
		}
		else if (num >= 5)
		{
			list2 = modifierPoolMid;
			list3 = modifierValueMinMid;
		}
		for (int i = 0; i < list2.Count; i++)
		{
			list.Add(list2[i]);
		}
		int modifierCount = GetModifierCount(num);
		for (int j = 0; j < modifierCount; j++)
		{
			if (list.Count <= 0)
			{
				break;
			}
			int index = Utils.RandInt(0, list.Count);
			int index2 = list[index];
			int value = Utils.RandInt(list3[index2], 2 * list3[index2] + 1);
			modifier[index2] = value;
			list.RemoveAt(index);
		}
	}

	public static void NotifyAssaultDetected()
	{
		if (assaultHives != null && assaultHives.Count != 0 && assaultHives[0] != null)
		{
			bool isSuper = assaultHives[0].isSuper;
			int starIndex = assaultHives[0].starIndex;
			string text = "";
			if (!isSuper)
			{
				text += string.Format("侦测到虚空入侵提示".Translate(), GameMain.galaxy.StarById(starIndex + 1)?.displayName);
			}
			else
			{
				text += string.Format("侦测到虚空入侵提示".Translate(), GameMain.galaxy.StarById(starIndex + 1)?.displayName);
				text += "虚空入侵额外特性提示".Translate();
				text += GetModifierDesc();
			}
			UIDialogPatch.ShowUIDialog("虚空入侵".Translate(), text);
		}
	}

	public static string GetModifierDesc()
	{
		string text = "";
		for (int i = 0; i < modifier.Count; i++)
		{
			if (modifier[i] > 0 || (i >= 6 && i <= 9 && modifier[i] < 0))
			{
				int value = modifier[i];
				text += "\n<color=#ffa800dd>";
				text += string.Format($"额外特性描述{i}".Translate(), Math.Abs(value));
				text += "</color>";
			}
		}
		return text;
	}

	public static void OnAssaultEnd()
	{
		MP.Sync(EDataType.CallOnAssaultEndSettleStart);
		assaultActive = false;
		modifierEnabled = false;
		if (modifier[6] < 0)
		{
			GameMain.data.history.kineticDamageScale -= (float)modifier[6] * 1f / 100f;
		}
		if (modifier[7] < 0)
		{
			GameMain.data.history.energyDamageScale -= (float)modifier[7] * 1f / 100f;
		}
		if (modifier[8] < 0)
		{
			GameMain.data.history.blastDamageScale -= (float)modifier[8] * 1f / 100f;
		}
		if (modifier[9] < 0)
		{
			GameMain.data.history.magneticDamageScale -= (float)modifier[9] * 1f / 100f;
		}
		if (modifier[10] != 0)
		{
			CombatModuleComponent combatModuleComponent = GameMain.mainPlayer?.mecha?.spaceCombatModule;
			if (combatModuleComponent != null)
			{
				ModuleFleet[] moduleFleets = combatModuleComponent.moduleFleets;
				for (int i = 0; i < moduleFleets.Length; i++)
				{
					if (moduleFleets[i].protoId != DropletFleetPatchers.fleetConfigId1 && moduleFleets[i].protoId != DropletFleetPatchers.fleetConfigId2)
					{
						moduleFleets[i].fleetEnabled = true;
					}
				}
			}
		}
		int num = 0;
		int num2 = 0;
		bool flag = false;
		for (int j = 0; j < assaultHives.Count; j++)
		{
			num += assaultHives[j].enemyKilled;
			num2 += assaultHives[j].assaultNum;
			if (!flag)
			{
				flag = assaultHives[j].isSuper;
			}
		}
		if (num2 <= 0)
		{
			num2 = 1;
		}
		float num3 = (float)num * 1f / (float)num2;
		if (num3 > 1f)
		{
			num3 = 1f;
		}
		int num4 = GiveReward(num3);
		string text = "";
		text += string.Format("虚空入侵结束提示".Translate(), num, num2, num4);
		if (flag)
		{
			if (EventSystem.recorder != null && EventSystem.recorder.protoId > 0 && Relic.GetRelicCount() < Relic.relicHoldMax)
			{
				if (EventSystem.recorder.modifier != null)
				{
					EventSystem.recorder.modifier[4] += 50;
				}
				text = text + "\n\n" + "虚空入侵结束提示元驱动解译".Translate();
			}
			else if (EventSystem.recorder == null || EventSystem.recorder.protoId == 0)
			{
				if (Relic.GetRelicCount() <= 0)
				{
					if (EventSystem.neverStartTheFirstEvent > 0)
					{
						EventSystem.InitNewEvent();
					}
					else
					{
						EventSystem.TransferTo(9997);
						EventSystem.recorder.decodeType = 24;
						EventSystem.recorder.decodeTimeNeed = 3600;
						EventSystem.recorder.decodeTimeSpend = 0;
					}
				}
				else
				{
					EventSystem.TransferTo(9998);
				}
				text = text + "\n\n" + "虚空入侵结束提示元驱动发现".Translate();
			}
		}
		UIDialogPatch.ShowUIDialog("虚空入侵结束".Translate(), text);
		assaultHives.Clear();
		ClearDataArrays();
		Configs.combatState = 0;
		BattleBGMController.SetWaveFinished();
	}

	public static int GiveReward(float factor)
	{
		int totalWave = Configs.totalWave;
		int num = 0;
		num = ((totalWave < Configs.rewardSPMap.Count && totalWave >= 0) ? Configs.rewardSPMap[totalWave] : Configs.rewardSPMap.Last());
		if (num > 2 && timeChangedByRelic)
		{
			num = 2;
		}
		int num2 = (int)(factor * (float)num);
		SkillPoints.totalPoints += num2;
		return num2;
	}

	public static int GetAssaultTotalNum(int waveCount)
	{
		float num = GameMain.data.history.combatSettings.difficulty;
		float num2 = 4f;
		if (num < 0.05f)
		{
			num = 0.05f;
		}
		else if (num > num2)
		{
			num = num2;
		}
		int num3 = Configs.totalAssaultNumMap.Count - 1;
		int num4 = num3 - 36;
		int num5 = 36;
		if (num > 1f)
		{
			num5 += (int)(((double)num - 1.0) / ((double)num2 - 1.0) * (double)num4);
		}
		if (num5 > num3)
		{
			num5 = num3;
		}
		int num6 = ((waveCount < num5 && waveCount >= 0) ? Configs.totalAssaultNumMap[waveCount] : Configs.totalAssaultNumMap[num5]);
		if (num < 1f)
		{
			num6 = Math.Max((int)((float)num6 * num), 1);
		}
		if (Configs.developerMode)
		{
			Utils.Log($"dif{num}, realMaxlen{num5}, got result {num6}");
		}
		return num6;
	}

	public static int GetHiveLevel(int waveCount)
	{
		float num = GameMain.data.history.combatSettings.difficulty;
		if (num < 0.125f)
		{
			num = 0.125f;
		}
		int num2 = ((waveCount < Configs.levelMap.Count && waveCount >= 0) ? Configs.levelMap[waveCount] : Configs.levelMap.Last());
		if (num < 1f)
		{
			num2 = (int)((float)num2 * num);
		}
		return num2;
	}

	public static int GetAssembleTime(int waveCount)
	{
		if (Configs.totalWave > 20)
		{
			int num = Configs.totalWave / 10;
			if (num > 10)
			{
				num = 10;
			}
			waveCount += num;
		}
		float num2 = GameMain.data.history.combatSettings.difficulty;
		int num3 = 8 - (int)num2;
		if (num3 < 0)
		{
			num3 = 0;
		}
		if (num3 > 6)
		{
			num3 = 6;
		}
		int num4 = Configs.assembleTimeMap.Count - 1 - num3;
		if (num4 < 0)
		{
			num4 = 0;
		}
		if (num4 >= Configs.assembleTimeMap.Count)
		{
			num4 = Configs.assembleTimeMap.Count - 1;
		}
		if (DspBattlePlugin.voidInvasionMaxFrequency.Value >= 2)
		{
			num4 = Configs.assembleTimeMap.Count - 1;
		}
		if (waveCount >= num4 || waveCount < 0)
		{
			waveCount = num4;
		}
		if (DspBattlePlugin.voidInvasionMaxFrequency.Value >= 3 || waveCount == num4)
		{
			return 18000;
		}
		return Configs.assembleTimeMap[waveCount];
	}

	public static int GetModifierCount(int superWaveCount)
	{
		int num = 0;
		if (superWaveCount >= modifierMaxActiveCount.Count())
		{
			num = modifierMaxActiveCount.Last();
		}
		else if (superWaveCount >= 0)
		{
			num = modifierMaxActiveCount[superWaveCount];
		}
		int min = num;
		if (num >= 4)
		{
			min = num - 2;
		}
		else if (num >= 2)
		{
			min = num - 1;
		}
		return Utils.RandInt(min, num + 1);
	}

	public static void CheckHiveStatus(int starIndex)
	{
		for (int i = 1; i < 9; i++)
		{
			EnemyDFHiveSystem enemyDFHiveSystem = GameMain.spaceSector.dfHivesByAstro[starIndex * 8 + i];
			if (enemyDFHiveSystem != null)
			{
				int instId = enemyDFHiveSystem.pbuilders[1].instId;
				Utils.Log($"instId is {instId}");
			}
			else
			{
				Utils.Log($"null hive at{i}");
			}
		}
	}

	public static void BuildHiveAlreadyInited(int starIndex)
	{
		for (int i = 1; i < 9; i++)
		{
			EnemyDFHiveSystem enemyDFHiveSystem = GameMain.spaceSector.dfHivesByAstro[starIndex * 8 + i];
			if (enemyDFHiveSystem == null)
			{
				continue;
			}
			ref GrowthPattern_DFSpace.Builder reference = ref enemyDFHiveSystem.pbuilders[1];
			if (reference.instId <= 0)
			{
				int protoId = reference.protoId;
				EnemyProto enemyProto = LDB.enemies.Select(protoId);
				if (enemyProto != null)
				{
					EnemyData enemy = new EnemyData
					{
						protoId = (short)protoId,
						modelIndex = (short)enemyProto.ModelIndex,
						astroId = enemyDFHiveSystem.hiveAstroId,
						originAstroId = enemyDFHiveSystem.hiveAstroId,
						owner = 0,
						port = 0,
						dynamic = !enemyProto.IsBuilding,
						isSpace = true,
						localized = true,
						stateFlags = 0,
						pos = reference.pos,
						rot = reference.rot
					};
					GameMain.spaceSector.AddEnemyDataWithComponents(ref enemy, enemyDFHiveSystem, 1, isPreview: false);
				}
				enemyDFHiveSystem.isEmpty = false;
			}
		}
	}

	public static bool hasCore(this EnemyDFHiveSystem hive)
	{
		if (hive == null)
		{
			return false;
		}
		return hive.pbuilders[1].instId > 0;
	}

	public static void BuildCore(this EnemyDFHiveSystem hive)
	{
		if (hive == null)
		{
			return;
		}
		ref GrowthPattern_DFSpace.Builder reference = ref hive.pbuilders[1];
		if (reference.instId <= 0)
		{
			int protoId = reference.protoId;
			EnemyProto enemyProto = LDB.enemies.Select(protoId);
			if (enemyProto != null)
			{
				EnemyData enemy = new EnemyData
				{
					protoId = (short)protoId,
					modelIndex = (short)enemyProto.ModelIndex,
					astroId = hive.hiveAstroId,
					originAstroId = hive.hiveAstroId,
					owner = 0,
					port = 0,
					dynamic = !enemyProto.IsBuilding,
					isSpace = true,
					localized = true,
					stateFlags = 0,
					pos = reference.pos,
					rot = reference.rot
				};
				GameMain.spaceSector.AddEnemyDataWithComponents(ref enemy, hive, 1, isPreview: false);
			}
			hive.isEmpty = false;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(EnemyDFHiveSystem), "InitFormations")]
	public static bool InitDFSHivePrePatch(ref EnemyDFHiveSystem __instance)
	{
		__instance.forms = new EnemyFormation[3];
		__instance.forms[0] = new EnemyFormation();
		__instance.forms[1] = new EnemyFormation();
		__instance.forms[2] = new EnemyFormation();
		__instance.forms[0].SetPortCount(1440);
		__instance.forms[1].SetPortCount(120);
		__instance.forms[2].SetPortCount(6);
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(EvolveData), "AddExp")]
	public static bool EvolveDataAddExpPrefix(ref EvolveData __instance, int _addexp)
	{
		if (__instance.level >= 100)
		{
			if (__instance.expf != 0 || __instance.expp != 0 || __instance.level != 100)
			{
				__instance.level = 100;
				__instance.expf = 0;
				__instance.expp = 0;
				__instance.expl = EvolveData.LevelCummulativeExp(100);
			}
			return false;
		}
		__instance.expf += _addexp;
		bool flag = __instance.level < 30;
		while (__instance.expf >= EvolveData.levelExps[__instance.level] && flag)
		{
			int num = EvolveData.levelExps.Length - 1;
			__instance.expf -= EvolveData.levelExps[__instance.level];
			__instance.expl += EvolveData.levelExps[__instance.level];
			__instance.level++;
			if (__instance.level >= num)
			{
				__instance.level = num;
				__instance.expf = 0;
				return false;
			}
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(EvolveData), "AddExpPoint")]
	public static bool EvolveDataAddExpPointPrefix(ref EvolveData __instance, int _addexpp)
	{
		if (__instance.level >= 100)
		{
			if (__instance.expf != 0 || __instance.expp != 0 || __instance.level != 100)
			{
				__instance.level = 30;
				__instance.expf = 0;
				__instance.expp = 0;
				__instance.expl = EvolveData.LevelCummulativeExp(100);
			}
			return false;
		}
		if (_addexpp > 0)
		{
			__instance.expp += _addexpp;
			if (__instance.expp >= 10000)
			{
				__instance.expf += __instance.expp / 10000;
				__instance.expp %= 10000;
				bool flag = __instance.level < 30;
				while (__instance.expf >= EvolveData.levelExps[__instance.level] && flag)
				{
					int num = EvolveData.levelExps.Length - 1;
					__instance.expf -= EvolveData.levelExps[__instance.level];
					__instance.expl += EvolveData.levelExps[__instance.level];
					__instance.level++;
					if (__instance.level >= num)
					{
						__instance.level = num;
						__instance.expf = 0;
						__instance.expp = 0;
						return false;
					}
				}
			}
		}
		return false;
	}

	public static void TryEnableVoidInvasion()
	{
		UIMessageBox.Show("开启虚空入侵".Translate(), "虚空入侵提示".Translate(), "否".Translate(), "是".Translate(), 1, RegretEnable, delegate
		{
			voidInvasionEnabled = true;
		});
	}

	public static void RegretEnable()
	{
	}

	public static void AskEnableVoidInvasion()
	{
		if (Configs.enableVoidInvasionUpdate)
		{
			UIMessageBox.Show("开启虚空入侵".Translate(), "虚空入侵版本更新提示".Translate(), "否".Translate(), "是".Translate(), 1, RegretEnable, delegate
			{
				voidInvasionEnabled = true;
			});
		}
	}

	public static bool CheckCasterOrTargetHasModifier(ref SkillTarget caster)
	{
		if (modifierEnabled && caster.astroId > 1000000 && caster.type == ETargetType.Enemy)
		{
			int num = caster.astroId - 1000000;
			if (num < modifierHives.Length && modifierHives[num] >= 0)
			{
				return true;
			}
		}
		return false;
	}

	public static bool CheckHiveHasModifier(ref EnemyDFHiveSystem hive)
	{
		return CheckHiveHasModifier(hive.hiveAstroId);
	}

	public static bool CheckHiveHasModifier(int oriAstroId)
	{
		if (modifierEnabled && oriAstroId > 1000000)
		{
			int num = oriAstroId - 1000000;
			if (num < modifierHives.Length && modifierHives[num] >= 0)
			{
				return true;
			}
		}
		return false;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(CombatStat), "TickSkillLogic")]
	public static void HpRecoverBuff(ref CombatStat __instance)
	{
		if (CheckHiveHasModifier(__instance.originAstroId) && modifierEnabled && modifier[12] > 0)
		{
			__instance.hp += modifier[12] * 100 / 60;
			if (__instance.hp > __instance.hpMax)
			{
				__instance.hp = __instance.hpMax;
			}
		}
	}

	public static void Import(BinaryReader r)
	{
		InitWhenLoad();
		if (Configs.versionWhenImporting >= 30240716)
		{
			voidInvasionEnabled = r.ReadBoolean();
			difficulty = r.ReadInt32();
			int num = r.ReadInt32();
			for (int i = 0; i < num; i++)
			{
				AssaultHive assaultHive = new AssaultHive(0, i, i);
				assaultHive.Import(r);
				assaultHives.Add(assaultHive);
			}
			modifierEnabled = r.ReadBoolean();
			int num2 = r.ReadInt32();
			for (int j = 0; j < num2; j++)
			{
				int value = r.ReadInt32();
				if (j < modifier.Count)
				{
					modifier[j] = value;
				}
			}
			timeChangedByRelic = r.ReadBoolean();
		}
		UIEscMenuPatch.Init();
		if (Configs.versionWhenImporting < 30240703)
		{
			AskEnableVoidInvasion();
		}
		if (Configs.versionWhenImporting >= 30240716 && Configs.versionWhenImporting < 30240825)
		{
			voidInvasionEnabled = false;
		}
		if (Configs.versionWhenImporting >= 30240830)
		{
			nextRollVoidEcho = r.ReadInt32();
		}
	}

	public static void Export(BinaryWriter w)
	{
		w.Write(voidInvasionEnabled);
		w.Write(difficulty);
		w.Write(assaultHives.Count);
		for (int i = 0; i < assaultHives.Count; i++)
		{
			assaultHives[i].Export(w);
		}
		w.Write(modifierEnabled);
		w.Write(modifier.Count);
		for (int j = 0; j < modifier.Count; j++)
		{
			w.Write(modifier[j]);
		}
		w.Write(timeChangedByRelic);
		w.Write(nextRollVoidEcho);
	}

	public static void IntoOtherSave()
	{
		InitWhenLoad();
	}

	public static EnemyDFHiveSystem TryCreateNewHiveAndCore(int starIndex)
	{
		EnemyDFHiveSystem enemyDFHiveSystem = GameMain.spaceSector.TryCreateNewHive(GameMain.galaxy.StarById(starIndex + 1));
		if (enemyDFHiveSystem != null)
		{
			ref GrowthPattern_DFSpace.Builder reference = ref enemyDFHiveSystem.pbuilders[1];
			if (reference.instId > 0)
			{
				return enemyDFHiveSystem;
			}
			int protoId = reference.protoId;
			EnemyProto enemyProto = LDB.enemies.Select(protoId);
			if (enemyProto != null)
			{
				EnemyData enemy = new EnemyData
				{
					protoId = (short)protoId,
					modelIndex = (short)enemyProto.ModelIndex,
					astroId = enemyDFHiveSystem.hiveAstroId,
					originAstroId = enemyDFHiveSystem.hiveAstroId,
					owner = 0,
					port = 0,
					dynamic = !enemyProto.IsBuilding,
					isSpace = true,
					localized = true,
					stateFlags = 0,
					pos = reference.pos,
					rot = reference.rot
				};
				GameMain.spaceSector.AddEnemyDataWithComponents(ref enemy, enemyDFHiveSystem, 1, isPreview: false);
			}
			enemyDFHiveSystem.isEmpty = false;
		}
		return enemyDFHiveSystem;
	}
}
