using System;
using System.IO;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using CommonAPI;
using CommonAPI.Systems;
using DSP_Battle.src.Compat;
using HarmonyLib;
using MoreMegaStructure;
using UnityEngine;
using UnityEngine.UI;
using crecheng.DSPModSave;
using xiaoye97;

namespace DSP_Battle;

[BepInPlugin("com.ckcz123.DSP_Battle", "DSP_Battle", "3.4.28")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.soardev.universegentweaks", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("org.LoShin.GenesisBook", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("Gnimaerd.DSP.plugin.MoreMegaStructure", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry" })]
[CommonAPISubmoduleDependency(new string[] { "TabSystem" })]
[CommonAPISubmoduleDependency(new string[] { "LocalizationModule" })]
public class DspBattlePlugin : BaseUnityPlugin, IModCanSave
{
	public const string GUID = "com.ckcz123.DSP_Battle";

	public static string MODID_tab = "DSPBattle";

	public static System.Random randSeed = new System.Random();

	public static int pagenum;

	public static ManualLogSource logger;

	private static ConfigFile config;

	public static ConfigEntry<int> starCannonRenderLevel;

	public static ConfigEntry<bool> starCannonDirectionReverse;

	public static ConfigEntry<bool> enableBattleBGM;

	public static ConfigEntry<float> battleBGMVolume;

	public static ConfigEntry<int> voidInvasionMaxFrequency;

	public static ConfigEntry<bool> newYearFirework;

	public static ConfigEntry<bool> fastStart;

	public static ConfigEntry<bool> invasionActiveByDefault;

	public static bool isControlDown = false;

	public static bool isShiftDown = false;

	public static bool playerInvincible = false;

	public static GameObject mainLogo = null;

	public static GameObject escLogo = null;

	public static Texture2D logoTexture = null;

	public static Texture2D escLogoTexture = null;

	public void Awake()
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		logger = base.Logger;
		config = base.Config;
		Configs.Init(base.Config);
		string directoryName = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
		ResourceData val = new ResourceData("com.ckcz123.DSP_Battle", "DSPBattle", directoryName);
		val.LoadAssetBundle("dspbattletex");
		ProtoRegistry.AddResource(val);
		try
		{
			using (ProtoRegistry.StartModLoad("com.ckcz123.DSP_Battle"))
			{
				pagenum = MoreMegaStructure.pagenum;
				BattleProtos.pageBias = (pagenum - 2) * 1000;
				MoreMegaStructure.battlePagenum = pagenum;
			}
		}
		catch (Exception)
		{
			pagenum = 0;
		}
		starCannonRenderLevel = base.Config.Bind("config", "StarCannonRenderLevel", 2, "[0-3] Higher Level will provide more star cannon effect and particles but might decrease the UPS and FPS when star cannon is firing. 更高的设置会提供更多的恒星炮特效，但可能会在恒星炮开火时降低帧率，反之则可能提高开火时的帧率。");
		starCannonDirectionReverse = base.Config.Bind("config", "starCannonDirectionReverse", defaultValue: false, "Deprecated. 已弃用。");
		enableBattleBGM = base.Config.Bind("config", "EnableBattleBGM", defaultValue: true, "Set to false to disable the BGM switching when Icarus is in combat. 设置为false来关闭战斗时的BGM切换。");
		battleBGMVolume = base.Config.Bind("config", "BattleBGMVolume", 1f, "( 0.0 - 2.0 )Control the Battle BGM's volume, will not affect the vanilla game BGM.  控制战斗音乐的音量大小，不会影响游戏默认BGM的音量。最小为0，最大为2.");
		voidInvasionMaxFrequency = base.Config.Bind("config", "voidInvasionMaxFrequency", 1, "(1,2 or 3) Setting to 2 will ignore the dark fog difficulty, and the minimum interval for void invasion at the end of the game is 10 minutes (as before v3.2.4). Setting to 3 will make it to 5min.    将此项设置为2会无视黑雾难度系数，让游戏末期的进攻间隔最小为10min（如同v3.2.4之前的版本），设置为3则会将最小间隔设置为5min.");
		newYearFirework = config.Bind("config", "NewYearFirework", defaultValue: true, "");
		fastStart = config.Bind("config", "FastStart", defaultValue: true, "Whether fast start option is enabled by default. 快速开局选项是否默认启用。");
		invasionActiveByDefault = config.Bind("config", "InvasionActiveByDefault", defaultValue: false, "Whether void invasion option is enabled by default. 虚空入侵选项是否默认启用。");
		StarCannon.renderLevel = starCannonRenderLevel.Value;
		StarCannon.renderLevel = ((StarCannon.renderLevel > 3) ? 3 : StarCannon.renderLevel);
		StarCannon.renderLevel = ((StarCannon.renderLevel >= 0) ? StarCannon.renderLevel : 0);
		Configs.enableBattleBGM = enableBattleBGM.Value;
		BattleBGMController.volumeFactor = BattleBGMController.volumeBasic * (float)Maths.Clamp(battleBGMVolume.Value, 0.0, 2.0);
		Harmony.CreateAndPatchAll(typeof(DspBattlePlugin));
		Harmony.CreateAndPatchAll(typeof(BattleProtos));
		Harmony.CreateAndPatchAll(typeof(NewGameOption));
		Harmony.CreateAndPatchAll(typeof(UIDialogPatch));
		Harmony.CreateAndPatchAll(typeof(Droplets));
		Harmony.CreateAndPatchAll(typeof(RendererSphere));
		Harmony.CreateAndPatchAll(typeof(PlanetEngine));
		Harmony.CreateAndPatchAll(typeof(UIRank));
		Harmony.CreateAndPatchAll(typeof(Rank));
		Harmony.CreateAndPatchAll(typeof(BattleBGMController));
		Harmony.CreateAndPatchAll(typeof(Relic));
		Harmony.CreateAndPatchAll(typeof(RelicFunctionPatcher));
		Harmony.CreateAndPatchAll(typeof(StarFortress));
		Harmony.CreateAndPatchAll(typeof(UIStarFortress));
		Harmony.CreateAndPatchAll(typeof(StationOrderFixPatch));
		Harmony.CreateAndPatchAll(typeof(DropletFleetPatchers));
		Harmony.CreateAndPatchAll(typeof(EventSystem));
		Harmony.CreateAndPatchAll(typeof(AssaultController));
		Harmony.CreateAndPatchAll(typeof(UIAssaultAlert));
		Harmony.CreateAndPatchAll(typeof(UIEscMenuPatch));
		Harmony.CreateAndPatchAll(typeof(UIHiveNamePatcher));
		Harmony.CreateAndPatchAll(typeof(WormholeRenderer));
		Harmony.CreateAndPatchAll(typeof(UIEnemyBriefInfoPatcher));
		Harmony.CreateAndPatchAll(typeof(PlanetBombing));
		Harmony.CreateAndPatchAll(typeof(UIPlanetBombing));
		Harmony.CreateAndPatchAll(typeof(UIMechaEnergyPatcher));
		Harmony.CreateAndPatchAll(typeof(StarCannonAutoFire));
		Harmony.CreateAndPatchAll(typeof(UITechPatch));
		LDBTool.PreAddDataAction = (Action)Delegate.Combine(LDBTool.PreAddDataAction, new Action(BattleProtos.AddProtos));
		LDBTool.PostAddDataAction = (Action)Delegate.Combine(LDBTool.PostAddDataAction, new Action(BattleProtos.PostEditModelProto));
		BattleProtos.AddTranslate();
		BattleProtos.InitEventProtos();
		TCFVPerformanceMonitor.Awake();
		EvolveData.levelExps[100] = int.MaxValue;
		CompatManager.Init();
	}

	public void Start()
	{
		BattleBGMController.InitAudioSources();
	}

	public void Update()
	{
		if (Configs.developerMode && Input.GetKeyDown(KeyCode.Z) && MoreMegaStructure.curStar != null)
		{
			_ = MoreMegaStructure.curStar.index;
			_ = isControlDown;
		}
		if (Input.GetKeyDown(KeyCode.LeftControl) || Input.GetKeyDown(KeyCode.RightControl))
		{
			isControlDown = true;
			UIStarFortress.RefreshSetBtnText();
		}
		if (Input.GetKeyUp(KeyCode.LeftControl) || Input.GetKeyUp(KeyCode.RightControl))
		{
			isControlDown = false;
			UIStarFortress.RefreshSetBtnText();
		}
		if (Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift))
		{
			isShiftDown = true;
			UIStarFortress.RefreshSetBtnText();
		}
		if (Input.GetKeyUp(KeyCode.LeftShift) || Input.GetKeyUp(KeyCode.RightShift))
		{
			isShiftDown = false;
			UIStarFortress.RefreshSetBtnText();
		}
		if (Input.GetKeyDown(KeyCode.UpArrow) && UIDevConsole.consoleObj != null && UIDevConsole.consoleObj.activeSelf)
		{
			DevConsole.PrevCommand();
		}
		if (Input.GetKeyDown(KeyCode.DownArrow) && UIDevConsole.consoleObj != null && UIDevConsole.consoleObj.activeSelf)
		{
			DevConsole.NextCommand();
		}
		if (Input.GetKeyDown(KeyCode.BackQuote))
		{
			if (MoreMegaStructure.GenesisCompatibility && isControlDown)
			{
				UIEventSystem.OnEventButtonClick();
			}
			else if (!MoreMegaStructure.GenesisCompatibility)
			{
				UIEventSystem.OnEventButtonClick();
			}
		}
		if (Input.GetKeyDown(KeyCode.L) && !VFInput.inputing)
		{
			UISkillPointsWindow.Switch();
		}
		if (UIRelic.leftSlotsShowing && Input.mouseScrollDelta.y != 0f)
		{
			UIRelic.ChangePage(Input.mouseScrollDelta.y);
		}
		if (Configs.developerMode && isControlDown && Input.GetKeyDown(KeyCode.Z))
		{
			Relic.PrepareNewRelic();
			if (GameMain.localPlanet != null)
			{
				_ = GameMain.localPlanet.id;
			}
		}
		if (Configs.developerMode && isControlDown)
		{
			Input.GetKeyDown(KeyCode.B);
		}
		if (Configs.developerMode && isControlDown && Input.GetKeyDown(KeyCode.F))
		{
			PlanetBombing.LaserSweepTest();
		}
		if (Configs.developerMode && isControlDown && Input.GetKeyDown(KeyCode.G))
		{
			new TestSkillCasts().SweepLaser(ETestSkillType.SpaceLaserSweep, GameMain.spaceSector, GameMain.spaceSector.skillSystem, GameMain.localPlanet?.factory, GameMain.localStar, GameMain.mainPlayer);
		}
		if (Configs.developerMode && isControlDown && Input.GetKeyDown(KeyCode.K))
		{
			GameMain.mainPlayer.Kill();
		}
		if (Configs.developerMode && isControlDown && Input.GetKeyDown(KeyCode.H))
		{
			for (int i = 0; i < AssaultController.assaultHives.Count; i++)
			{
				AssaultController.assaultHives[i].time -= 3600;
				AssaultController.assaultHives[i].timeTillAssault -= 3600;
			}
		}
		if (Configs.developerMode && isShiftDown && Input.GetKeyDown(KeyCode.H))
		{
			for (int j = 0; j < AssaultController.assaultHives.Count; j++)
			{
				AssaultController.assaultHives[j].time -= 18000;
				AssaultController.assaultHives[j].timeTillAssault -= 18000;
			}
		}
		if (Configs.developerMode && isControlDown && Input.GetKeyDown(KeyCode.J))
		{
			AssaultController.InitNewAssault();
		}
		if (Configs.developerMode && isShiftDown && Input.GetKeyDown(KeyCode.J))
		{
			for (int k = 0; k < AssaultController.assaultHives.Count; k++)
			{
				AssaultController.assaultHives[k].state = EAssaultHiveState.Remove;
			}
		}
		if (playerInvincible && GameMain.mainPlayer != null)
		{
			GameMain.mainPlayer.invincibleTicks = 60;
		}
		UIRelic.SelectionWindowAnimationUpdate();
		UIRelic.CheckRelicSlotsWindowShowByMouse();
		UIRelic.SlotWindowAnimationUpdate();
		UIEventSystem.OnUpdate();
		BattleBGMController.BGMLogicUpdate();
		UISkillPointsWindow.Update();
		DevConsole.Update();
		UIPlanetBombing.OnUpdate();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameMain), "OnDestroy")]
	public static void GameMain_onDestroy()
	{
		if (config == null)
		{
			return;
		}
		try
		{
			string path = Path.Combine(Path.GetDirectoryName(config.ConfigFilePath), "LDBTool");
			if (Directory.Exists(path))
			{
				Directory.Delete(path, recursive: true);
			}
		}
		catch (Exception)
		{
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIMainMenu), "_OnOpen")]
	public static void UIMainMenu_OnOpen()
	{
		UpdateLogo();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIMainMenu), "_OnUpdate")]
	public static void UIMainMenu_OnUpdate()
	{
		UpdateLogo();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIEscMenu), "_OnOpen")]
	public static void UIEscMenu_OnOpen()
	{
		UpdateLogo();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIEscMenu), "_OnUpdate")]
	public static void UIEscMenu_OnUpdate()
	{
		UpdateLogo();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameOption), "Apply")]
	public static void UpdateGameOption_Apply()
	{
		UpdateLogo();
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(GameMain), "LateUpdate")]
	public static bool EscLogicBlocker()
	{
		UIDevConsole.EscLogic();
		UIEventSystem.EscLogic();
		UISkillPointsWindow.EscLogic();
		return true;
	}

	public static void UpdateLogo()
	{
		if (mainLogo == null)
		{
			mainLogo = GameObject.Find("UI Root/Overlay Canvas/Main Menu/dsp-logo");
		}
		if (escLogo == null)
		{
			escLogo = GameObject.Find("UI Root/Overlay Canvas/In Game/Esc Menu/logo");
		}
		if (logoTexture == null || escLogoTexture == null)
		{
			string text = ((DSPGame.globalOption.languageLCID == 2052) ? "Assets/DSPBattle/LOGO-cn" : "Assets/DSPBattle/LOGO-en");
			string path = ((DSPGame.globalOption.languageLCID == 2052) ? "Assets/DSPBattle/LOGO-cn-c" : "Assets/DSPBattle/LOGO-en");
			if (MoreMegaStructure.GenesisCompatibility)
			{
				text = ((DSPGame.globalOption.languageLCID == 2052) ? "Assets/DSPBattle/LOGOGB-cn" : "Assets/DSPBattle/LOGOGB-en");
				path = text;
				mainLogo.GetComponent<RectTransform>().sizeDelta = new Vector2(600f, 250f);
				escLogo.GetComponent<RectTransform>().sizeDelta = new Vector2(600f, 250f);
			}
			logoTexture = Resources.Load<Sprite>(text).texture;
			escLogoTexture = Resources.Load<Sprite>(path).texture;
		}
		if (mainLogo.GetComponent<RawImage>().texture != logoTexture)
		{
			mainLogo.GetComponent<RawImage>().texture = logoTexture;
		}
		if (escLogo.GetComponent<RawImage>().texture != escLogoTexture)
		{
			escLogo.GetComponent<RawImage>().texture = escLogoTexture;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIAbnormalityTip), "_OnInit")]
	public static void UIAbnormalityTip_OnInit(ref UIAbnormalityTip __instance)
	{
		__instance.isWarned = true;
		__instance.willClose = true;
		__instance.mainTweener.Play1To0Continuing();
		__instance.closeDelayTime = 3f;
	}

	public static void InitStaticDataWhenLoad()
	{
		BattleProtos.EditProtossWhenLoad();
		MP.InitBlocker();
	}

	public void Export(BinaryWriter w)
	{
		Configs.Export(w);
		Droplets.Export(w);
		Rank.Export(w);
		Relic.Export(w);
		EventSystem.Exprot(w);
		StarFortress.Export(w);
		SkillPoints.Export(w);
		AssaultController.Export(w);
		DevConsole.Export(w);
		PlanetBombing.Export(w);
		StarCannonAutoFire.Export(w);
	}

	public void Import(BinaryReader r)
	{
		Configs.Import(r);
		Droplets.Import(r);
		Rank.Import(r);
		Relic.Import(r);
		EventSystem.Import(r);
		StarFortress.Import(r);
		SkillPoints.Import(r);
		AssaultController.Import(r);
		DevConsole.Import(r);
		PlanetBombing.Import(r);
		StarCannonAutoFire.Import(r);
		BattleProtos.ReCheckTechUnlockRecipes();
		BattleProtos.UnlockTutorials();
		BattleBGMController.InitWhenLoad();
		InitStaticDataWhenLoad();
		if (RendererSphere.dropletSpheres.Count != GameMain.galaxy.starCount)
		{
			RendererSphere.InitAll();
		}
	}

	public void IntoOtherSave()
	{
		Configs.IntoOtherSave();
		Droplets.IntoOtherSave();
		Rank.IntoOtherSave();
		Relic.IntoOtherSave();
		EventSystem.IntoOtherSave();
		StarFortress.IntoOtherSave();
		DevConsole.IntoOtherSave();
		SkillPoints.IntoOtherSave();
		AssaultController.IntoOtherSave();
		PlanetBombing.IntoOtherSave();
		StarCannonAutoFire.IntoOtherSave();
		BattleProtos.ReCheckTechUnlockRecipes();
		BattleProtos.UnlockTutorials();
		BattleBGMController.InitWhenLoad();
		InitStaticDataWhenLoad();
		if (RendererSphere.dropletSpheres.Count != GameMain.galaxy.starCount)
		{
			RendererSphere.InitAll();
		}
	}
}
