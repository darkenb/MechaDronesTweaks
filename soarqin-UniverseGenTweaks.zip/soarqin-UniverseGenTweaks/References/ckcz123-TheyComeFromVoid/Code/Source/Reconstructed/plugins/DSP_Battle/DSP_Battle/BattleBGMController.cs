using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using HarmonyLib;
using UnityEngine;

namespace DSP_Battle;

public class BattleBGMController
{
	public static int musicState = 0;

	public static int musicCnt = 0;

	public static bool isOverriding = false;

	public static int currentGroup = -1;

	public static int lastMusic = -1;

	public static int currentMusic = -1;

	public static int nextMusic = -1;

	public static float fadeOutTime = 0f;

	public static float fadeInTime = 0f;

	public static string[] index2NameMap = new string[25]
	{
		"pre_1", "loop_1", "fin_1", "pre_2", "loop_2", "pre_3", "loop_3", "fin_3", "pre_4", "loop_4",
		"fin_4", "pre_5", "loop_5", "fin_5", "pre_6", "loop_6", "fin_6", "Track7", "Track9", "Track10",
		"Track39", "TrackA1", "TrackE1", "TrackU1", "TrackU2"
	};

	public static Dictionary<string, int> name2IndexMap = new Dictionary<string, int>();

	public static List<int> finMusics = new List<int> { 2, 7, 10, 13, 16 };

	public static AssetBundle bgmAB;

	public static List<AudioSource> battleMusics = new List<AudioSource>();

	public static List<float> musicBPM = new List<float> { 100f, 176f, 180f, 180f, 180f, 200f, 200f };

	public static int beforeBattleBgmBeginNum = 17;

	public static bool nextPlayFinishMusic = false;

	public static int takeDamageCountdown = 0;

	public static float volumeBasic = 0.4f;

	public static float volumeFactor = 0.4f;

	public static void InitAudioSources()
	{
		if (!Configs.enableBattleBGM)
		{
			return;
		}
		Transform transform = GameObject.Find("Audios/BGM").transform;
		GameObject original = GameObject.Find("Audios/BGM/universe-1");
		bgmAB = AssetBundle.LoadFromStream(Assembly.GetExecutingAssembly().GetManifestResourceStream("DSP_Battle.battlebgm"));
		if (bgmAB == null)
		{
			Configs.enableBattleBGM = false;
			return;
		}
		musicCnt = index2NameMap.Length;
		for (int i = 0; i < index2NameMap.Length; i++)
		{
			GameObject gameObject = UnityEngine.Object.Instantiate(original, transform);
			gameObject.name = index2NameMap[i];
			AudioSource component = gameObject.GetComponent<AudioSource>();
			component.clip = bgmAB.LoadAsset<AudioClip>(index2NameMap[i]);
			name2IndexMap.Add(index2NameMap[i], i);
			if (index2NameMap[i] == "fin_1")
			{
				name2IndexMap.Add("fin_2", i);
			}
			battleMusics.Add(component);
		}
	}

	public static void InitWhenLoad()
	{
		if (Configs.enableBattleBGM)
		{
			if (currentMusic >= 0 && currentMusic < musicCnt)
			{
				battleMusics[currentMusic].Stop();
			}
			if (lastMusic >= 0 && lastMusic < musicCnt)
			{
				battleMusics[lastMusic].Stop();
			}
			currentGroup = -1;
			lastMusic = -1;
			currentMusic = -1;
			nextMusic = -1;
			fadeOutTime = 0f;
			fadeInTime = 0f;
			isOverriding = false;
			nextPlayFinishMusic = false;
			takeDamageCountdown = 0;
		}
	}

	public static void BGMLogicUpdate()
	{
		if (!Configs.enableBattleBGM)
		{
			return;
		}
		if (Configs.combatState <= 1 || (Configs.combatState != 3 && nextPlayFinishMusic))
		{
			if (nextPlayFinishMusic)
			{
				if (currentGroup < 0 || currentMusic < 0)
				{
					nextPlayFinishMusic = false;
					lastMusic = -1;
					currentMusic = -1;
					nextMusic = -1;
					fadeOutTime = 0f;
					fadeInTime = 0f;
					isOverriding = false;
					BGMController.Playback(0, 1f, 1f);
				}
				else if (atBarEnd(battleMusics[currentMusic].time, musicBPM[currentGroup]) && name2IndexMap.ContainsKey("fin_" + currentGroup))
				{
					nextPlayFinishMusic = false;
					nextMusic = name2IndexMap["fin_" + currentGroup];
				}
			}
			else if (currentMusic >= 0 && battleMusics[currentMusic].time >= battleMusics[currentMusic].clip.length - 0.05f)
			{
				lastMusic = -1;
				currentMusic = -1;
				nextMusic = -1;
				fadeOutTime = 0f;
				fadeInTime = 0f;
				isOverriding = false;
				currentGroup = Utils.RandInt(1, 7);
				BGMController.Playback(0, 1f, 1f);
			}
		}
		else if (Configs.combatState == 2)
		{
			if (!isOverriding)
			{
				currentGroup = Utils.RandInt(1, 7);
			}
			if (currentMusic < 0)
			{
				nextMusic = Utils.RandInt(beforeBattleBgmBeginNum, battleMusics.Count);
			}
			else if (battleMusics[currentMusic].time >= battleMusics[currentMusic].clip.length - 0.05f)
			{
				nextMusic = Utils.RandInt(beforeBattleBgmBeginNum, battleMusics.Count);
				if (nextMusic == currentMusic)
				{
					nextMusic = ((currentMusic + 1 < musicCnt) ? (currentMusic + 1) : (currentMusic - 1));
				}
			}
		}
		else if (Configs.combatState == 3)
		{
			if (currentGroup < 0)
			{
				currentGroup = new System.Random().Next(1, 7);
			}
			if (currentMusic >= beforeBattleBgmBeginNum || currentMusic < 0)
			{
				nextMusic = name2IndexMap["pre_" + currentGroup];
			}
			else if (finMusics.Contains(currentMusic) && atBarEnd(battleMusics[currentMusic].time, musicBPM[currentGroup]))
			{
				nextMusic = name2IndexMap["loop_" + currentGroup];
			}
			else if (index2NameMap[currentMusic][0] == 'p' && battleMusics[currentMusic].time >= battleMusics[currentMusic].clip.length - 0.05f)
			{
				nextMusic = name2IndexMap["loop_" + currentGroup];
			}
		}
		if (currentMusic != nextMusic)
		{
			PlayNext();
		}
		if (isOverriding)
		{
			if (fadeOutTime > 0f && lastMusic >= 0 && lastMusic < musicCnt)
			{
				battleMusics[lastMusic].volume -= 0.01666667f / fadeOutTime;
				if (battleMusics[lastMusic].volume <= 0f)
				{
					fadeOutTime = 0f;
					battleMusics[lastMusic].volume = 0f;
					battleMusics[lastMusic].loop = false;
				}
			}
			else if (fadeOutTime <= 0f && lastMusic >= 0 && lastMusic < musicCnt)
			{
				battleMusics[lastMusic].volume = 0f;
				battleMusics[lastMusic].loop = false;
				battleMusics[lastMusic].Stop();
			}
			if (fadeInTime > 0f && currentMusic >= 0 && currentMusic < musicCnt)
			{
				battleMusics[currentMusic].volume += 0.01666667f / fadeInTime;
				if (battleMusics[currentMusic].volume >= VFAudio.audioVolume * VFAudio.musicVolume * volumeFactor)
				{
					fadeOutTime = 0f;
					battleMusics[currentMusic].volume = VFAudio.audioVolume * VFAudio.musicVolume * volumeFactor;
				}
			}
			else if (fadeInTime <= 0f && currentMusic >= 0 && currentMusic < musicCnt)
			{
				battleMusics[currentMusic].volume = VFAudio.audioVolume * VFAudio.musicVolume * volumeFactor;
			}
		}
		if (takeDamageCountdown > 0)
		{
			Interlocked.Add(ref takeDamageCountdown, -1);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(ThreadManager), "ProcessFrame")]
	public static void GameData_GameTick(long frameCounter)
	{
		if (frameCounter % 5 == 0L && isOverriding)
		{
			MuteGameOriBgm();
		}
	}

	public static void PlayerTakeDamage()
	{
		Interlocked.Exchange(ref takeDamageCountdown, 2700);
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(SkillSystem), "DeterminePlanetATFieldRaytestInStar", new Type[]
	{
		typeof(int),
		typeof(ERayTestSkillType),
		typeof(int),
		typeof(VectorLF3),
		typeof(VectorLF3),
		typeof(int)
	}, new ArgumentType[]
	{
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Ref,
		ArgumentType.Ref,
		ArgumentType.Normal
	})]
	[HarmonyPatch(typeof(SkillSystem), "DeterminePlanetATFieldRaytestInStar", new Type[]
	{
		typeof(int),
		typeof(ERayTestSkillType),
		typeof(int),
		typeof(VectorLF3),
		typeof(Vector3),
		typeof(int)
	}, new ArgumentType[]
	{
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Ref,
		ArgumentType.Ref,
		ArgumentType.Normal
	})]
	public static void VerifyPlayerPlanetWillTakeDamage(int __result)
	{
		if (GameMain.data.localPlanet != null && __result == GameMain.data.localPlanet.id)
		{
			Interlocked.Exchange(ref takeDamageCountdown, 2700);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlayerAction_Combat), "ShootTarget")]
	public static void PlayerDoDamage()
	{
		Interlocked.Add(ref takeDamageCountdown, 240);
		if (takeDamageCountdown > 1800)
		{
			Interlocked.Exchange(ref takeDamageCountdown, 2700);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlayerAction_Combat), "Shoot_Missile")]
	public static void ShootMissileCompensation()
	{
		if (takeDamageCountdown < 1800)
		{
			Interlocked.Add(ref takeDamageCountdown, -30);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlayerAction_Combat), "Shoot_Cannon_Local")]
	public static void ShootCannonLocalCompensation()
	{
		if (takeDamageCountdown < 1800)
		{
			Interlocked.Add(ref takeDamageCountdown, -30);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlayerAction_Combat), "Shoot_Cannon_Space")]
	public static void ShootCannonSpaceCompensation()
	{
		if (takeDamageCountdown < 1800)
		{
			Interlocked.Add(ref takeDamageCountdown, -30);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(BGMController), "Playback")]
	public static void PlaybackPostPatch(int bgmIndex, float fadeOutTime, float fadeInTime, EPlaybackOrigin origin = EPlaybackOrigin.Begin, float offset = 0f)
	{
		if (Configs.enableBattleBGM && isOverriding)
		{
			if (!BGMController.HasBGM(bgmIndex))
			{
				bgmIndex = 0;
			}
			if (BGMController.instance != null && BGMController.instance.musics != null && bgmIndex >= 0 && bgmIndex < BGMController.instance.musics.Length && BGMController.instance.musics[bgmIndex] != null)
			{
				BGMController.instance.musics[bgmIndex].Stop();
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(BGMController), "UpdateLogic")]
	public static void BGMPassFilterPatch()
	{
		if (Configs.enableBattleBGM && isOverriding && UIGame.viewMode == EViewMode.Starmap)
		{
			VFListener.SetPassFilter(100f);
		}
	}

	public static void PlayNext(float fade = 0f)
	{
		if (nextMusic >= 0 && nextMusic < musicCnt)
		{
			if (lastMusic < 0 && BGMController.instance != null && BGMController.instance.musics != null && BGMController.HasBGM(BGMController.instance.playbackIndex))
			{
				BGMController.instance.fadeOutTimes[BGMController.instance.playbackIndex] = 1f;
				BGMController.instance.volsTar[BGMController.instance.playbackIndex] = 0f;
			}
			fadeOutTime = fade;
			fadeInTime = fade;
			isOverriding = true;
			lastMusic = currentMusic;
			currentMusic = nextMusic;
			AudioSource audioSource = battleMusics[nextMusic];
			audioSource.time = ((currentMusic >= beforeBattleBgmBeginNum) ? 0.3f : 0f);
			audioSource.Play();
			audioSource.loop = index2NameMap[currentMusic][0] == 'l';
			audioSource.volume = 0f;
		}
	}

	public static void SetWaveFinished()
	{
		if (currentMusic >= 0 && currentMusic < musicCnt)
		{
			battleMusics[currentMusic].loop = false;
		}
		nextPlayFinishMusic = true;
	}

	public static void MuteGameOriBgm()
	{
		if (lastMusic < 0 && BGMController.instance != null && BGMController.instance.musics != null && BGMController.HasBGM(BGMController.instance.playbackIndex))
		{
			BGMController.instance.fadeOutTimes[BGMController.instance.playbackIndex] = 0f;
			BGMController.instance.volsTar[BGMController.instance.playbackIndex] = 0f;
		}
	}

	public static bool atBarEnd(float time, float bpm)
	{
		float num = 60f / bpm * 4f;
		float num2 = time / num - (float)(int)(time / num);
		if (!(num2 <= 0.02f))
		{
			return num2 >= num - 0.03f;
		}
		return true;
	}
}
