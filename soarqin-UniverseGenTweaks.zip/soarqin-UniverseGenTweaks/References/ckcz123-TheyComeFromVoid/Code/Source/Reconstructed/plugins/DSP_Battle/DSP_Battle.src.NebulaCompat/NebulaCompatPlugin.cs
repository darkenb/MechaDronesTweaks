using System.Collections.Generic;
using System.IO;
using BepInEx;
using BepInEx.Bootstrap;
using HarmonyLib;
using NebulaAPI;
using NebulaAPI.GameState;
using NebulaAPI.Interfaces;
using crecheng.DSPModSave;

namespace DSP_Battle.src.NebulaCompat;

[BepInPlugin("Gnimaerd.DSP.plugin.TCMVNebulaCompat", "TCMVNebulaCompat", "0.0.1")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("com.ckcz123.DSP_Battle", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
{
	public const string GUID = "Gnimaerd.DSP.plugin.TCMVNebulaCompat";

	public const string NAME = "TCMVNebulaCompat";

	public const string VERSION = "0.0.1";

	public static IModCanSave TCFVSave;

	public string Version => "0.0.1";

	public bool CheckVersion(string hostVersion, string clientVersion)
	{
		return hostVersion.Equals(clientVersion);
	}

	public void Awake()
	{
	}

	public void Update()
	{
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	public static void InitAfterVFPreLoad()
	{
		if (!Chainloader.PluginInfos.TryGetValue("com.ckcz123.DSP_Battle", out var value))
		{
			return;
		}
		_ = value.Instance.GetType().Assembly;
		try
		{
			BaseUnityPlugin instance = value.Instance;
			TCFVSave = (IModCanSave)(object)((instance is IModCanSave) ? instance : null);
		}
		catch
		{
			Utils.Log("Error when init TCFVSave");
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(MP), "InitBlocker")]
	public static void MPBlockerInitPostfix()
	{
		IMultiplayerSession multiplayerSession = NebulaModAPI.MultiplayerSession;
		if (((multiplayerSession != null) ? multiplayerSession.LocalPlayer : null) != null)
		{
			MP.NebulaEnabled = true;
			if (NebulaModAPI.MultiplayerSession.LocalPlayer.IsClient)
			{
				MP.clientBlocker = true;
			}
			else
			{
				MP.clientBlocker = false;
			}
		}
	}

	public static void InitWhenLoad()
	{
		TCFVPacketProcessor.deferredPackets = new Dictionary<EDataType, TCFVPacket>();
		TCFVPacketProcessor.deferredPacketProcessSign = new Dictionary<EDataType, int>();
	}

	public static void OnPlayerJoined()
	{
		IMultiplayerSession multiplayerSession = NebulaModAPI.MultiplayerSession;
		if (((multiplayerSession != null) ? multiplayerSession.LocalPlayer : null) != null && NebulaModAPI.MultiplayerSession.LocalPlayer.IsHost)
		{
			Synchronizer.BroadcastTCFVAll();
		}
	}

	public void Export(BinaryWriter w)
	{
	}

	public void Import(BinaryReader r)
	{
		InitWhenLoad();
	}
}
