using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx.Configuration;
using UnityEngine;

namespace DSP_Battle;

public class Configs
{
	public const string versionString = "3.4.28";

	public static string qq = "694213906 & 141801294";

	public static bool developerMode = false;

	public static bool enableProliferator4 = false;

	public static bool enableBattleBGM = true;

	public static bool enableAlertTextGlowing = true;

	public static bool enableVoidInvasionUpdate = true;

	public static int versionWhenImporting = -1;

	public static int versionCode = 30251114;

	public static int difficulty = 0;

	public static double _bullet1Speed;

	public static int _bullet1Atk;

	public static double _bullet2Speed;

	public static int _bullet2Atk;

	public static double _bullet3Speed;

	public static int _bullet3Atk;

	public static double _bullet4Speed;

	public static int _bullet4Atk;

	public static double _missile1Speed;

	public static int _missile1Atk;

	public static int missile1Range;

	public static double _missile2Speed;

	public static int _missile2Atk;

	public static int missile2Range;

	public static double _missile3Speed;

	public static int _missile3Atk;

	public static int _lightSpearAtk;

	public static int missile3Range;

	public static int dropletAtk = 200000;

	public static double dropletSpd = 30000.0;

	public static double laserDamageReducePerAU = 0.2;

	public static int[] enemyIntensity = new int[10];

	public static int[] enemyHp = new int[10];

	public static float[] enemySpeed = new float[10];

	public static int[] enemyRange = new int[10];

	public static int[] enemyItemIds = new int[6] { 8040, 8041, 8042, 8043, 8044, 8044 };

	public static int[] enemyLandCnt = new int[5] { 1, 3, 5, 5, 10000 };

	public static int[] enemyFireInterval = new int[5] { 120, 60, 2147483647, 60, 60 };

	public static int[] enemyFireRange = new int[5] { 5000, 8000, 15000, 15000, 30000 };

	public static int[] enemyDamagePerBullet = new int[5] { 500, 500, 200000, 500, 2000 };

	public static int[] enemyIntensity2TypeMap = new int[24]
	{
		0, 0, 0, 0, 1, 1, 2, 2, 2, 3,
		3, 3, 3, 3, 3, 4, 4, 4, 4, 4,
		4, 4, 4, 4
	};

	public static int eliteDurationFrames = 10800;

	public static List<int> levelMap = new List<int>
	{
		1, 2, 5, 10, 15, 16, 18, 20, 22, 25,
		25, 30, 30, 30, 30, 35, 35, 35, 40, 40,
		45, 45, 50, 55, 60, 65, 70, 75, 80
	};

	public static List<int> assembleTimeMap = new List<int>
	{
		216000, 180000, 144000, 108000, 108000, 108000, 108000, 90000, 72000, 72000,
		72000, 72000, 54000, 54000, 54000, 54000, 36000
	};

	public static List<int> totalAssaultNumMap = new List<int>
	{
		4, 8, 10, 12, 15, 20, 25, 30, 40, 50,
		60, 70, 85, 100, 120, 130, 140, 150, 160, 170,
		180, 190, 200, 220, 240, 260, 280, 300, 340, 380,
		420, 460, 500, 550, 600, 650, 700, 750, 800, 900,
		1000, 1200, 1440, 1440, 1400, 1440, 1440, 1440, 1440, 1440,
		1440
	};

	public static List<float> voidEnemyTakeDamageFactor = new List<float>
	{
		1f, 0.9f, 0.8f, 0.7f, 0.7f, 0.7f, 0.6f, 0.6f, 0.6f, 0.58f,
		0.58f, 0.56f, 0.56f, 0.54f, 0.54f, 0.52f, 0.52f, 0.5f, 0.5f, 0.5f,
		0.5f, 0.5f, 0.49f, 0.48f, 0.47f, 0.46f, 0.45f, 0.44f, 0.43f, 0.42f,
		0.41f, 0.4f, 0.39f, 0.38f, 0.37f, 0.36f, 0.35f, 0.34f, 0.33f, 0.32f,
		0.31f, 0.3f, 0.29f, 0.28f, 0.27f, 0.26f, 0.25f, 0.25f, 0.25f, 0.25f,
		0.25f
	};

	public static List<int> rewardSPMap = new List<int>
	{
		2, 3, 4, 4, 5, 5, 6, 6, 6, 7,
		7, 7, 8, 8, 8, 9, 9, 9, 10, 10,
		10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
		20, 22, 24, 26, 28, 30, 30, 30, 30, 30,
		30
	};

	public static int _wormholeRange;

	public static int[] intensity;

	public static int[] coldTime;

	public static int[] expectationMatrices;

	public static double bulletSpeedScale = 1.0;

	public static double bulletAtkScale = 1.0;

	public static int wormholeRangeAdded = 0;

	public static long nextWaveFrameIndex = -1L;

	public static int nextWaveStarIndex = -1;

	public static int combatState = 0;

	public static long nextWaveDelay = 0L;

	public static long extraSpeedFrame = -1L;

	public static bool extraSpeedEnabled = false;

	public static int nextWaveIntensity = 0;

	public static int nextWaveWormCount = 0;

	public static int[] nextWaveEnemy = new int[10];

	public static int nextWaveElite = 0;

	public static int nextWaveMatrixExpectation = 0;

	public static int starCount = 100;

	public static int[] wavePerStar;

	public static bool isEnemyWeakenedByRelic = false;

	public static int relic2_17Activated = 0;

	public static int relic1_8Protection = 99;

	public static int shieldGenPerTick = 12;

	public static List<Tuple<int, int>> capacityPerGenerator = new List<Tuple<int, int>>
	{
		new Tuple<int, int>(0, 5000000),
		new Tuple<int, int>(5000000, 3000000),
		new Tuple<int, int>(10000000, 2000000),
		new Tuple<int, int>(30000000, 1000000),
		new Tuple<int, int>(50000000, 0)
	};

	public static int[] expToNextRank = new int[13]
	{
		20, 200, 1000, 5000, 30000, 200000, 500000, 1000000, 2000000, 10000000,
		2000000, 0, 0
	};

	public static float[] rewardTimeRatio = new float[14]
	{
		1f, 1f, 1.2f, 1.2f, 1.4f, 1.4f, 1.6f, 1.6f, 1.8f, 1.8f,
		2f, 2f, 2f, 2f
	};

	public static float[] expRatioByDifficulty = new float[3] { 0.75f, 1f, 1.5f };

	public static int expPerAlienMeta = 20;

	public static int totalWave => wavePerStar.Sum();

	public static double bullet1Speed => _bullet1Speed * bulletSpeedScale;

	public static double bullet2Speed => _bullet2Speed * bulletSpeedScale;

	public static double bullet3Speed => _bullet3Speed * bulletSpeedScale;

	public static double bullet4Speed => _bullet4Speed;

	public static int bullet1Atk => Mathf.RoundToInt((float)((double)_bullet1Atk * bulletAtkScale));

	public static int bullet2Atk => Mathf.RoundToInt((float)((double)_bullet2Atk * bulletAtkScale));

	public static int bullet3Atk => Mathf.RoundToInt((float)((double)_bullet3Atk * bulletAtkScale));

	public static int bullet4Atk => Mathf.RoundToInt((float)((double)_bullet4Atk * (1.0 + (bulletAtkScale - 1.0) * 2.0)));

	public static int lightSpearAtk => Mathf.RoundToInt((float)((double)_lightSpearAtk * (1.0 + (bulletAtkScale - 1.0) * 2.0)));

	public static double missile1Speed => _missile1Speed * (1.0 + (bulletSpeedScale - 1.0) * 0.5);

	public static int missile1Atk => Mathf.RoundToInt((float)((double)_missile1Atk * bulletAtkScale));

	public static double missile2Speed => _missile2Speed * (1.0 + (bulletSpeedScale - 1.0) * 0.5);

	public static int missile2Atk => Mathf.RoundToInt((float)((double)_missile2Atk * bulletAtkScale));

	public static double missile3Speed => _missile3Speed * (1.0 + (bulletSpeedScale - 1.0) * 0.5);

	public static int missile3Atk => Mathf.RoundToInt((float)((double)_missile3Atk * bulletAtkScale));

	public static int wormholeRange => _wormholeRange + wormholeRangeAdded;

	public static void Init(ConfigFile config)
	{
		_bullet1Speed = 7500.0;
		_bullet1Atk = 100;
		_bullet2Speed = 7500.0;
		_bullet2Atk = 300;
		_bullet3Speed = 7500.0;
		_bullet3Atk = 500;
		_bullet4Speed = 250000.0;
		_bullet4Atk = 10;
		_lightSpearAtk = 20000;
		_missile1Speed = 10000.0;
		_missile1Atk = 5000;
		missile1Range = 400;
		_missile2Speed = 10000.0;
		_missile2Atk = 20000;
		missile2Range = 500;
		_missile3Speed = 12000.0;
		_missile3Atk = 1500;
		missile3Range = 8000;
		enemyIntensity[0] = 1;
		enemyHp[0] = 4000;
		enemySpeed[0] = 1000f;
		enemyRange[0] = 20;
		enemyIntensity[1] = 4;
		enemyHp[1] = 20000;
		enemySpeed[1] = 1500f;
		enemyRange[1] = 40;
		enemyIntensity[2] = 6;
		enemyHp[2] = 10000;
		enemySpeed[2] = 3000f;
		enemyRange[2] = 60;
		enemyIntensity[3] = 12;
		enemyHp[3] = 100000;
		enemySpeed[3] = 1000f;
		enemyRange[3] = 120;
		enemyIntensity[4] = 15;
		enemyHp[4] = 80000;
		enemySpeed[4] = 1500f;
		enemyRange[4] = 100;
		_wormholeRange = 20000;
		_ = developerMode;
		intensity = new int[26]
		{
			2, 5, 10, 15, 20, 30, 50, 80, 100, 150,
			250, 300, 400, 500, 600, 800, 1000, 1100, 1500, 1800,
			2000, 2200, 2500, 3000, 3500, 4000
		};
		coldTime = new int[26]
		{
			60, 50, 50, 45, 45, 45, 40, 40, 40, 40,
			30, 30, 30, 30, 30, 20, 20, 20, 20, 20,
			15, 15, 15, 15, 15, 10
		};
		expectationMatrices = new int[29]
		{
			25, 35, 45, 55, 75, 100, 155, 205, 255, 305,
			310, 315, 320, 325, 330, 335, 340, 345, 350, 355,
			360, 380, 400, 425, 450, 500, 600, 700, 800
		};
		IntoOtherSave();
	}

	public static void Export(BinaryWriter w)
	{
		w.Write(versionCode);
		w.Write(difficulty);
		w.Write(bulletSpeedScale);
		w.Write(bulletAtkScale);
		w.Write(wormholeRangeAdded);
		w.Write(nextWaveFrameIndex);
		w.Write(nextWaveStarIndex);
		w.Write(combatState);
		w.Write(nextWaveDelay);
		w.Write(extraSpeedFrame);
		w.Write(extraSpeedEnabled);
		w.Write(nextWaveIntensity);
		w.Write(nextWaveWormCount);
		for (int i = 0; i < 10; i++)
		{
			w.Write(nextWaveEnemy[i]);
		}
		w.Write(starCount);
		for (int j = 0; j < starCount; j++)
		{
			w.Write(wavePerStar[j]);
		}
		w.Write(nextWaveMatrixExpectation);
		w.Write(nextWaveElite);
	}

	public static void Import(BinaryReader r)
	{
		int num = (versionWhenImporting = r.ReadInt32());
		difficulty = r.ReadInt32();
		bulletSpeedScale = r.ReadDouble();
		bulletAtkScale = r.ReadDouble();
		wormholeRangeAdded = r.ReadInt32();
		nextWaveFrameIndex = r.ReadInt64();
		nextWaveStarIndex = r.ReadInt32();
		combatState = r.ReadInt32();
		nextWaveDelay = r.ReadInt64();
		extraSpeedFrame = r.ReadInt64();
		extraSpeedEnabled = r.ReadBoolean();
		nextWaveIntensity = r.ReadInt32();
		nextWaveWormCount = r.ReadInt32();
		for (int i = 0; i < 10; i++)
		{
			nextWaveEnemy[i] = r.ReadInt32();
		}
		if (num >= 20220320)
		{
			starCount = r.ReadInt32();
			wavePerStar = new int[starCount];
			for (int j = 0; j < starCount; j++)
			{
				wavePerStar[j] = r.ReadInt32();
			}
		}
		else
		{
			starCount = Mathf.Max(GameMain.galaxy?.starCount ?? 90, 90) + 10;
			wavePerStar = new int[starCount];
			for (int k = 0; k < 100; k++)
			{
				wavePerStar[k] = r.ReadInt32();
			}
		}
		if (num >= 30220420)
		{
			nextWaveMatrixExpectation = r.ReadInt32();
		}
		else
		{
			nextWaveMatrixExpectation = expectationMatrices[0];
			if (combatState > 0 && nextWaveStarIndex >= 0)
			{
				nextWaveMatrixExpectation = expectationMatrices[Math.Min(expectationMatrices.Length - 1, wavePerStar[nextWaveStarIndex])];
			}
		}
		if (num >= 30221029)
		{
			nextWaveElite = r.ReadInt32();
		}
		else
		{
			nextWaveElite = 0;
		}
	}

	public static void IntoOtherSave()
	{
		difficulty = 0;
		bulletSpeedScale = 1.0;
		bulletAtkScale = 1.0;
		wormholeRangeAdded = 0;
		nextWaveFrameIndex = -1L;
		nextWaveStarIndex = -1;
		combatState = 0;
		nextWaveDelay = 0L;
		extraSpeedFrame = -1L;
		extraSpeedEnabled = false;
		nextWaveIntensity = 0;
		nextWaveWormCount = 0;
		nextWaveEnemy = new int[10];
		starCount = Mathf.Max(GameMain.galaxy?.starCount ?? 90, 90) + 10;
		wavePerStar = new int[starCount];
		nextWaveMatrixExpectation = expectationMatrices[0];
		nextWaveElite = 0;
	}
}
