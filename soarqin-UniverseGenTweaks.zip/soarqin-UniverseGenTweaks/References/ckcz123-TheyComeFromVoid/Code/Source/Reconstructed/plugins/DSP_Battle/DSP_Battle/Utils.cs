using System;
using System.Threading;
using UnityEngine;
using xiaoye97;

namespace DSP_Battle;

public static class Utils
{
	private static int seed = Environment.TickCount;

	private static readonly ThreadLocal<System.Random> randSeed = new ThreadLocal<System.Random>(() => new System.Random(Interlocked.Increment(ref seed)));

	private static System.Random rd = new System.Random();

	public static int UIActualHeight
	{
		get
		{
			if (DSPGame.globalOption.uiLayoutHeight <= 0)
			{
				return UICanvasScalerHandler.GetSuggestUILayoutHeight(DSPGame.globalOption.resolution.height);
			}
			return DSPGame.globalOption.uiLayoutHeight;
		}
	}

	public static int Rand()
	{
		return randSeed.Value.Next();
	}

	public static VectorLF3 RandPosDelta()
	{
		return new VectorLF3(randSeed.Value.NextDouble() - 0.5, randSeed.Value.NextDouble() - 0.5, randSeed.Value.NextDouble() - 0.5);
	}

	public static VectorLF3 RandPosDelta(int Seed)
	{
		System.Random random = new System.Random(Seed);
		Seed = RandNext();
		return new VectorLF3(random.NextDouble() - 0.5, random.NextDouble() - 0.5, random.NextDouble() - 0.5);
	}

	public static int RandInt(int min, int max)
	{
		return randSeed.Value.Next(min, max);
	}

	public static int RandNext()
	{
		return randSeed.Value.Next();
	}

	public static double RandDouble()
	{
		return randSeed.Value.NextDouble();
	}

	public static double RandDoubleBySeedDelta(int delta)
	{
		return RandDouble();
	}

	public static int RandIntBySeedDelta(int min, int max, int delta)
	{
		return RandInt(min, max);
	}

	public static void Check(int num = 0, string str = "check ")
	{
		DspBattlePlugin.logger.LogInfo(str + num);
	}

	public static void Log(string str, int perFrame = 1, int isWarning = 0)
	{
		if (GameMain.instance.timei % perFrame == 0L)
		{
			if (isWarning > 0)
			{
				DspBattlePlugin.logger.LogWarning(str);
			}
			else
			{
				DspBattlePlugin.logger.LogInfo(str);
			}
		}
	}

	public static string KMGFormat(long num)
	{
		if (num >= 1000000000000000L)
		{
			return ((double)num * 1.0 / 1000000000000000.0).ToString("G3") + " P";
		}
		if (num >= 1000000000000L)
		{
			return ((double)num * 1.0 / 1000000000000.0).ToString("G3") + " T";
		}
		if (num >= 1000000000)
		{
			return ((double)num * 1.0 / 1000000000.0).ToString("G3") + " G";
		}
		if (num >= 1000000)
		{
			return ((double)num * 1.0 / 1000000.0).ToString("G3") + " M";
		}
		if (num >= 1000)
		{
			return ((double)num * 1.0 / 1000.0).ToString("G3") + " k";
		}
		return num.ToString();
	}

	public static void UIItemUp(int itemId, int upCount, float forceWidth = 300f, int forceItemCount = -1)
	{
		if (GameMain.mainPlayer != null && !(UIRoot.instance == null) && upCount > 0)
		{
			UIItemup itemupTips = UIRoot.instance.uiGame.itemupTips;
			int num = GameMain.mainPlayer.package.GetItemCount(itemId);
			if (forceItemCount >= 0)
			{
				num = forceItemCount;
			}
			bool exist;
			UIItemupNode _this = itemupTips.CreateNode(itemId, out exist);
			SetItemupNodeData(ref _this, itemId, upCount, num - upCount, num, forceWidth);
			if (!exist)
			{
				itemupTips.itemups.Insert(0, _this);
				UIRoot.instance.uiGame.itemupTips.transform.SetAsLastSibling();
			}
			if (!itemupTips.active)
			{
				itemupTips._Open();
			}
		}
	}

	public static void SetItemupNodeData(ref UIItemupNode _this, int _itemId, int _getCnt, int _prevCnt, int _totalCnt, float forceWidth)
	{
		if (_this.fadeOutCalled)
		{
			Assert.CannotBeReached();
			return;
		}
		bool flag = _itemId != _this.itemId;
		_this.itemId = _itemId;
		_this.getCount += _getCnt;
		_this.prevCount = _prevCnt;
		_this.totalCount = _totalCnt;
		_this.displayCount = _this.prevCount;
		ItemProto itemProto = LDB.items.Select(_itemId);
		if (itemProto == null)
		{
			_this._Close();
			return;
		}
		_this.itemIconImage.sprite = itemProto.iconSprite;
		_this.getNumText.text = "+ " + _this.getCount;
		_this.itemNameText.text = itemProto.name;
		if (_this.displayCount > 0f)
		{
			_this.totalNumText.text = _this.displayCount.ToString("#,##0");
		}
		else
		{
			_this.totalNumText.text = "0";
		}
		_this.sizeTween.to = new Vector2(forceWidth, _this.sizeTween.to.y);
		if (flag)
		{
			for (int i = 0; i < _this.tweeners.Length; i++)
			{
				_this.tweeners[i].Play0To1();
			}
		}
		else
		{
			_this.tweeners[1].Play0To1();
			_this.tweeners[1].normalizedTime = 0.3f;
			_this.tweeners[2].Play0To1();
			_this.tweeners[2].normalizedTime = 0.5f;
		}
		_this.time = (flag ? 0f : 0.3f);
	}

	public static void CopyModelProto(int oriId, int id, Color? color = null)
	{
		ModelProto modelProto = LDB.models.Select(oriId);
		ModelProto modelProto2 = modelProto.Copy();
		modelProto2.Name = id.ToString();
		modelProto2.ID = id;
		PrefabDesc prefabDesc = modelProto.prefabDesc;
		GameObject gameObject = (prefabDesc.prefab ? prefabDesc.prefab : Resources.Load<GameObject>(modelProto.PrefabPath));
		GameObject gameObject2 = (prefabDesc.colliderPrefab ? prefabDesc.colliderPrefab : Resources.Load<GameObject>(modelProto._colliderPath));
		ref PrefabDesc prefabDesc2 = ref modelProto2.prefabDesc;
		prefabDesc2 = ((gameObject == null) ? PrefabDesc.none : ((gameObject2 == null) ? new PrefabDesc(id, gameObject) : new PrefabDesc(id, gameObject, gameObject2)));
		Material[][] lodMaterials = prefabDesc2.lodMaterials;
		foreach (Material[] array in lodMaterials)
		{
			if (array == null)
			{
				continue;
			}
			for (int j = 0; j < array.Length; j++)
			{
				ref Material reference = ref array[j];
				if (!(reference == null))
				{
					reference = new Material(reference);
					if (color.HasValue)
					{
						reference.SetColor("_Color", color.Value);
					}
				}
			}
		}
		prefabDesc2.modelIndex = id;
		prefabDesc2.hasBuildCollider = prefabDesc.hasBuildCollider;
		prefabDesc2.colliders = prefabDesc.colliders;
		prefabDesc2.buildCollider = prefabDesc.buildCollider;
		prefabDesc2.buildColliders = prefabDesc.buildColliders;
		prefabDesc2.colliderPrefab = prefabDesc.colliderPrefab;
		prefabDesc2.dragBuild = prefabDesc.dragBuild;
		prefabDesc2.dragBuildDist = prefabDesc.dragBuildDist;
		prefabDesc2.blueprintBoxSize = prefabDesc.blueprintBoxSize;
		prefabDesc2.roughHeight = prefabDesc.roughHeight;
		prefabDesc2.roughWidth = prefabDesc.roughWidth;
		prefabDesc2.roughRadius = prefabDesc.roughRadius;
		prefabDesc2.barHeight = prefabDesc.barHeight;
		prefabDesc2.barWidth = prefabDesc.barWidth;
		prefabDesc2.unitAssaultArriveRange = prefabDesc.unitAssaultArriveRange;
		prefabDesc2.unitAttackDamage0 = prefabDesc.unitAttackDamage0;
		prefabDesc2.unitAttackDamageInc0 = prefabDesc.unitAttackDamageInc0;
		prefabDesc2.unitAttackHeat0 = prefabDesc.unitAttackHeat0;
		prefabDesc2.unitAttackInterval0 = prefabDesc.unitAttackInterval0;
		prefabDesc2.unitAttackRange0 = prefabDesc.unitAttackRange0;
		prefabDesc2.unitColdSpeed = prefabDesc.unitColdSpeed;
		prefabDesc2.unitColdSpeedInc = prefabDesc.unitColdSpeedInc;
		prefabDesc2.unitEngageArriveRange = prefabDesc.unitEngageArriveRange;
		prefabDesc2.unitMarchMovementSpeed = prefabDesc.unitMarchMovementSpeed;
		prefabDesc2.unitMaxMovementSpeed = prefabDesc.unitMaxMovementSpeed;
		prefabDesc2.unitMaxMovementAcceleration = prefabDesc.unitMaxMovementAcceleration;
		modelProto2.sid = "";
		modelProto2.SID = "";
		LDBTool.PreAddProto((Proto)modelProto2);
	}

	public static ModelProto Copy(this ModelProto proto)
	{
		return new ModelProto
		{
			ObjectType = proto.ObjectType,
			RuinType = proto.RuinType,
			RendererType = proto.RendererType,
			HpMax = proto.HpMax,
			HpUpgrade = proto.HpUpgrade,
			HpRecover = proto.HpRecover,
			RuinId = proto.RuinId,
			RuinCount = proto.RuinCount,
			RuinLifeTime = proto.RuinLifeTime,
			PrefabPath = proto.PrefabPath,
			_colliderPath = proto._colliderPath
		};
	}
}
