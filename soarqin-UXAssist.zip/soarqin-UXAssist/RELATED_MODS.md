# Related mods and code references — soarqin-UXAssist

All listed copies are inside this mod folder. They are one-level reference copies with their own Source, InstalledPackage, metadata and English change notes. Required installed dependencies of those copies are flattened into the same RelatedMods directory; copies never recursively contain another RelatedMods directory.

Dependency declarations (including optional compatibility plugins), compiled member calls and native integration/test context are distinguished below. A shared native API touchpoint is not presented as a direct foreign-method call. Original game/BepInEx SDK files and uninstalled optional mods are not fabricated or downloaded. 

## CommonAPI-CommonAPI

Copy: `RelatedMods/CommonAPI-CommonAPI/`.

- **declared_hard_dependency**: Plugin-level dependency declaration; this may belong to an optional compatibility plugin.
- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Actual compiled code references

```text
System.Void UXAssist.Patches.GamePatch::OnInputUpdate()
  Callvirt -> System.Boolean CommonAPI.Systems.PressKeyBind::get_keyValue()
```

```text
System.Void UXAssist.Patches.PlayerPatch::OnInputUpdate()
  Callvirt -> System.Boolean CommonAPI.Systems.PressKeyBind::get_keyValue()
```

```text
System.Void UXAssist.Patches.PlayerPatch/ShortcutKeysForStarsName::OnInputUpdate()
  Callvirt -> System.Boolean CommonAPI.Systems.PressKeyBind::get_keyValue()
```

```text
System.Void UXAssist.Patches.Factory.FactoryPatch::OnInputUpdate()
  Callvirt -> System.Boolean CommonAPI.Systems.PressKeyBind::get_keyValue()
```

```text
System.Void UXAssist.Functions.UI.MenuButtonUI::OnInputUpdate()
  Callvirt -> System.Boolean CommonAPI.Systems.PressKeyBind::get_keyValue()
```

```text
CommonAPI.Systems.PressKeyBind UXAssist.Common.KeyBindings::RegisterKeyBinding(BuiltinKey)
  Call -> !!0 CommonAPI.Systems.CustomKeyBindSystem::RegisterKeyBindWithReturn<CommonAPI.Systems.PressKeyBind>(BuiltinKey)
```

```text
System.String UXAssist.Common.KeyBindings::GetKeyBindingText(CommonAPI.Systems.PressKeyBind)
  Ldfld -> BuiltinKey CommonAPI.Systems.PressKeyBind::defaultBind
```

```text
System.Boolean UXAssist.Common.KeyBindings::IsKeyPressing(CommonAPI.Systems.PressKeyBind)
  Ldfld -> BuiltinKey CommonAPI.Systems.PressKeyBind::defaultBind
```

### Code in this mod

`Source/Reconstructed/plugins/UXAssist/UXAssist/UXAssist.cs:23`

```csharp
namespace UXAssist;

[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "CustomKeyBindSystem" })]
```

`Source/Reconstructed/plugins/UXAssist/UXAssist.ModsCompat/CommonAPIWrapper.cs:11`

```csharp
	public static void Run(Harmony harmony)
	{
		if (ModCompatHelper.TryGetLoadedPluginInfo("dsp.common-api.CommonAPI", out var pluginInfo) && !(pluginInfo.Metadata.Version > new System.Version(1, 6, 7, 0)))
		{
			harmony.Patch(AccessTools.Method(typeof(GameOption), "InitKeys"), new HarmonyMethod(AccessTools.Method(typeof(CommonAPIWrapper), "PatchInitKeys"), 800));
```

`Source/EarlierWorkingSource/Common/ModFeatures/IModFeature.cs:15`

```csharp
/// <item><see cref="Init"/> runs <strong>eagerly</strong> at registration time — synchronously inside
/// <see cref="ModFeatureRegistry.Register{T}"/>, normally during the registering mod's BepInEx
/// <c>Awake</c> phase. It is the phase for early setup such as keybind registration via CommonAPI's
/// <c>CustomKeyBindSystem</c>, whose registered bindings are copied by the game's
/// <c>UIOptionWindow._OnCreate</c> only after all plugins finish loading. A late-discovered feature may
```

`Source/EarlierWorkingSource/ModsCompat/CommonAPIWrapper.cs:7`

```csharp
namespace UXAssist.ModsCompat;

public static class CommonAPIWrapper
{
    public static void Run(Harmony harmony)
```

`Source/EarlierWorkingSource/UXAssist.cs:25`

```csharp
namespace UXAssist;

[BepInDependency(CommonAPIPlugin.GUID)]
[BepInDependency(DSPModSavePlugin.MODGUID)]
[CommonAPISubmoduleDependency(nameof(CustomKeyBindSystem))]
```

### Code in the related copy

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs:16`

```csharp
namespace CommonAPI;

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
```

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs:14`

```csharp
[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
{
```

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/PowerNetworkHandler.cs:58`

```csharp
	public override string GetComponentType()
	{
		return "dsp.common-api.CommonAPI:PowerNetworkHandler";
	}

```

`RelatedMods/CommonAPI-CommonAPI/Source/EarlierWorkingSource/CommonAPIPlugin.cs:35`

```csharp
    {
        public const string ID = "CommonAPI";
        public const string GUID = "dsp.common-api.CommonAPI";
        public const string DISPNAME = "DSP Common API";

```

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/BaseSubmodule.cs:18`

```csharp
		{
			string name = GetType().Name;
			throw new InvalidOperationException(name + " is not loaded. Please use [CommonAPISubmoduleDependency(nameof(" + name + ")]");
		}
	}
```

## CommonAPI-DSPModSave

Copy: `RelatedMods/CommonAPI-DSPModSave/`.

- **declared_hard_dependency**: Plugin-level dependency declaration; this may belong to an optional compatibility plugin.
- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Code in this mod

`Source/Reconstructed/plugins/UXAssist/UXAssist/UXAssist.cs:24`

```csharp

[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "CustomKeyBindSystem" })]
[BepInPlugin("org.soardev.uxassist", "UXAssist", "1.6.3")]
```

`Source/EarlierWorkingSource/UXAssist.cs:26`

```csharp

[BepInDependency(CommonAPIPlugin.GUID)]
[BepInDependency(DSPModSavePlugin.MODGUID)]
[CommonAPISubmoduleDependency(nameof(CustomKeyBindSystem))]
[BepInPlugin(PluginInfo.PLUGIN_GUID, PluginInfo.PLUGIN_NAME, PluginInfo.PLUGIN_VERSION)]
```

### Code in the related copy

`RelatedMods/CommonAPI-DSPModSave/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs:15`

```csharp
namespace crecheng.DSPModSave;

[BepInPlugin("crecheng.DSPModSave", "DSP Mod Save", "1.2.3")]
public class DSPModSavePlugin : BaseUnityPlugin
{
```

`RelatedMods/CommonAPI-DSPModSave/Evidence/InitialPhase/check.cs:25`

```csharp
        string path = Path.Combine(root, "sample.moddsv");
        var sample = new SaveSample();
        var settingsType = typeof(DSPModSavePlugin).Assembly.GetType("crecheng.DSPModSave.ModSaveSettings");
        var settings = Activator.CreateInstance(settingsType, true);
        AccessTools.Field(settingsType, "mod").SetValue(settings, sample);
```

`RelatedMods/CommonAPI-DSPModSave/Source/EarlierWorkingSource/DSPModSavePlugin.cs:22`

```csharp
    public class DSPModSavePlugin : BaseUnityPlugin
    {
        public const string MODGUID = "crecheng.DSPModSave";
        public const string MODNAME = "DSP Mod Save";
        public const string MODID = "DSPModSave";
```

`RelatedMods/CommonAPI-DSPModSave/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs:12`

```csharp
	private static void EnterGame()
	{
		DSPModSavePlugin.logger.LogInfo("Enter New Game");
		foreach (ModSaveSettings value in DSPModSavePlugin.allModData.Values)
		{
```

`RelatedMods/CommonAPI-DSPModSave/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs:13`

```csharp
		if (__result)
		{
			DSPModSavePlugin.OnSave(saveName);
		}
	}
```

## IlldariFairlight-AutoLogisticsDroneSetup

Copy: `RelatedMods/IlldariFairlight-AutoLogisticsDroneSetup/`.

- **fix_integration_context**: Both initial-fill paths must preserve existing stock, native capacity and foreign-factory ownership.

### Code in this mod

`Source/Reconstructed/plugins/UXAssist/UXAssist.Functions/PlanetFunctions.cs:531`

```csharp
							}
						}
						int num30 = stationComponent.idleDroneCount + stationComponent.workDroneCount;
						if (num30 > 0)
						{
```

`Source/Reconstructed/plugins/UXAssist/UXAssist.Patches.Logistics/LogisticsPatch.cs:182`

```csharp
		if (factory != null && GameMain.mainPlayer != null && GameMain.mainPlayer.factory == factory && station?.workDroneDatas != null)
		{
			int num = MissingWorkers(station.isStellar ? AutoConfigILSDroneCount.Value : AutoConfigPLSDroneCount.Value, station.workDroneDatas.Length, station.idleDroneCount, station.workDroneCount);
			if (num > 0)
			{
```

`Source/Reconstructed/plugins/UXAssist/UXAssist.Patches.Logistics/RealtimeLogisticsInfoPanel.cs:471`

```csharp
			case EStationTipLayout.PlanetaryLogistics:
			{
				int num5 = stationComponent.idleDroneCount + stationComponent.workDroneCount;
				int idleDroneCount = stationComponent.idleDroneCount;
				_carrierIdleCountText[0].text = idleDroneCount.ToString();
```

`Evidence/InitialPhase/check.cs:53`

```csharp
        var factory=Empty<PlanetFactory>(); var planet=Empty<PlanetData>(); planet.factory=factory;
        Set(planet,"factoryLoaded",true);Set(player,"planetData",planet);
        var station=new StationComponent {idleDroneCount=3,workDroneCount=2,workDroneDatas=new DroneData[10],
            idleShipCount=2,workShipCount=1,workShipDatas=new ShipData[6],droneAutoReplenish=true,shipAutoReplenish=true};
        var bot=new DispenserComponent {idleCourierCount=3,workCourierCount=2,workCourierDatas=new CourierData[20],courierAutoReplenish=true};
```

`Source/EarlierWorkingSource/Functions/PlanetFunctions.cs:445`

```csharp
                        if (count > 0) AddReturnedItem(sc.storage[j].itemId, count, sc.storage[j].inc, returnedItems);
                    }
                    var droneCount = sc.idleDroneCount + sc.workDroneCount;
                    if (droneCount > 0) AddReturnedItem((int)Common.KnownItemId.Drone, droneCount, 0, returnedItems);
                    var shipCount = sc.idleShipCount + sc.workShipCount;
```

### Code in the related copy

`RelatedMods/IlldariFairlight-AutoLogisticsDroneSetup/Source/Reconstructed/plugins/AutoLogisticsDroneSetup/DSP_Mods/AutoLogisticsDroneSetup.cs:120`

```csharp
		if (station != null && desc != null && util != null)
		{
			int num = FillQuantity.Needed((station.workDroneDatas != null) ? station.workDroneDatas.Length : desc.stationMaxDroneCount, station.idleDroneCount, station.workDroneCount, desiredAmount);
			if (num > 0)
			{
```

`RelatedMods/IlldariFairlight-AutoLogisticsDroneSetup/Evidence/InitialPhase/check.cs:42`

```csharp
        var util = Activator.CreateInstance(typeof(AutoLogisticsDroneSetup).Assembly.GetType("DSP_Mods.StorageUtility"), true);
        var desc = new PrefabDesc {stationMaxDroneCount = 10, stationMaxShipCount = 10, dispenserMaxCourierCount = 10};
        var station = new StationComponent {idleDroneCount = 3, workDroneCount = 2, workDroneDatas = new DroneData[10],
            idleShipCount = 2, workShipCount = 1, workShipDatas = new ShipData[10], droneAutoReplenish = true, shipAutoReplenish = true};
        Fill("AddDrones", station, desc, util, 8);
```

`RelatedMods/IlldariFairlight-AutoLogisticsDroneSetup/Source/EarlierWorkingSource/AutoLogisticsDroneSetup.cs:114`

```csharp
            if (station == null || desc == null || util == null) return;
            int capacity = station.workDroneDatas != null ? station.workDroneDatas.Length : desc.stationMaxDroneCount;
            int need = FillQuantity.Needed(capacity, station.idleDroneCount, station.workDroneCount, desiredAmount);
            if (need > 0) station.idleDroneCount += util.RemoveItems(Drone, need);
        }
```

`RelatedMods/IlldariFairlight-AutoLogisticsDroneSetup/Source/Reconstructed/plugins/AutoLogisticsDroneSetup/DSP_Mods/StorageUtility.cs:139`

```csharp
				break;
			}
			StationComponent stationComponent = factory.transport.stationPool[i];
			if (stationComponent != null && stationComponent.id == i)
			{
```

`RelatedMods/IlldariFairlight-AutoLogisticsDroneSetup/Source/EarlierWorkingSource/StorageUtility.cs:22`

```csharp
	class StorageUtility
	{
		private PlayerPackageUtility PlayerPackageUtility = null;

		public enum Source
```

## blacksnipebiu-Auxilaryfunction

Copy: `RelatedMods/blacksnipebiu-Auxilaryfunction/`.

- **fix_integration_context**: UXAssist's station overlay resolves the updated AuxConfig.ShowStationInfo location; refill fixes also share native station stock.

### Code in this mod

`Source/Reconstructed/plugins/UXAssist/UXAssist.ModsCompat/AuxilaryfunctionWrapper.cs:27`

```csharp
			return;
		}
		if (!ModCompatHelper.TryGetFieldValue<ConfigEntry<bool>>(pluginInfo.Instance.GetType().Assembly.GetType("Auxilaryfunction.AuxConfig") ?? type, "ShowStationInfo", pluginInfo.Instance, out ShowStationInfo))
		{
			UXAssist.Logger.LogWarning("Failed to get ShowStationInfo from Auxilaryfunction");
```

`Evidence/InitialPhase/check.cs:23`

```csharp
        var built = typeof(LogisticsPatch).Assembly;
        var aux = Assembly.LoadFile(Path.GetFullPath("blacksnipebiu-Auxilaryfunction/Auxilaryfunction.dll"));
        var configType = aux.GetType("Auxilaryfunction.AuxConfig", true);
        Assert(configType.GetField("ShowStationInfo").FieldType == typeof(ConfigEntry<bool>),
            "current Auxilaryfunction station-overlay config is located in AuxConfig");
```

`Source/EarlierWorkingSource/ModsCompat/AuxilaryfunctionWrapper.cs:22`

```csharp
            return;
        }
        var configType = pluginInfo.Instance.GetType().Assembly.GetType("Auxilaryfunction.AuxConfig") ?? classType;
        if (!ModCompatHelper.TryGetFieldValue<ConfigEntry<bool>>(configType, "ShowStationInfo", pluginInfo.Instance, out ShowStationInfo))
        {
```

`Source/Reconstructed/plugins/UXAssist/UXAssist/UIConfigWindow.cs:533`

```csharp
		num2 += 27f;
		MyCheckBox realtimeLogisticsInfoPanelBarsCheckBox = wnd.AddCheckBox(num + 20f, num2, tab3, LogisticsConfigProvider.RealtimeLogisticsInfoPanelBarsEnabled, "Show status bars for storage items", 13);
		if (AuxilaryfunctionWrapper.ShowStationInfo != null)
		{
			AuxilaryfunctionWrapper.ShowStationInfo.SettingChanged += RealtimeLogisticsInfoPanelChanged;
```

`Source/EarlierWorkingSource/UIConfigWindow.cs:456`

```csharp
            y += 27f;
            var realtimeLogisticsInfoPanelBarsCheckBox = wnd.AddCheckBox(x + 20f, y, tab3, LogisticsConfigProvider.RealtimeLogisticsInfoPanelBarsEnabled, I18NKeys.ShowStatusBarsForStorageItems, 13);
            if (AuxilaryfunctionWrapper.ShowStationInfo != null)
            {
                AuxilaryfunctionWrapper.ShowStationInfo.SettingChanged += RealtimeLogisticsInfoPanelChanged;
```

### Code in the related copy

`RelatedMods/blacksnipebiu-Auxilaryfunction/Source/PortedWorkingSource/Auxilaryfunction/AuxConfig.cs:7`

```csharp
namespace Auxilaryfunction;

public static class AuxConfig
{
	public const string GUID = "cn.blacksnipe.dsp.Auxilaryfunction";
```

`RelatedMods/blacksnipebiu-Auxilaryfunction/Source/PortedWorkingSource/Auxilaryfunction/Auxilaryfunction.cs:68`

```csharp
	{
		_mainContext = SynchronizationContext.Current;
		AuxConfig.harmony = new Harmony("cn.blacksnipe.dsp.Auxilaryfunction");
		AuxConfig.harmony.PatchAll(typeof(SkipRenderPatch));
		AuxConfig.harmony.PatchAll(typeof(AuxilaryfunctionPatch));
```

`RelatedMods/blacksnipebiu-Auxilaryfunction/Source/PortedWorkingSource/Auxilaryfunction/AuxilaryfunctionPatch.cs:30`

```csharp
	public static void NewMinerComponentPatch(ref int __result, FactorySystem __instance)
	{
		if (AuxConfig.auto_supply_station.Value && __instance.factory.entityPool[__instance.minerPool[__result].entityId].protoId == 2316 && BuildTargetValues.IsConfigEnabled("大型采矿机采矿速率"))
		{
			__instance.minerPool[__result].speed = AuxConfig.veincollectorspeed.Value * 1000;
```

`RelatedMods/blacksnipebiu-Auxilaryfunction/Source/PortedWorkingSource/Auxilaryfunction/SkipRenderPatch.cs:11`

```csharp
	public static bool FactoryModelUpdatePatch()
	{
		return !AuxConfig.simulatorrender;
	}

```

`RelatedMods/blacksnipebiu-Auxilaryfunction/Source/PortedWorkingSource/Auxilaryfunction.Models/BuildTargetValues.cs:13`

```csharp
		get
		{
			return AuxConfig.auto_supply_drone.Value;
		}
		set
```

## jinxOAO-DSPCalculator

Copy: `RelatedMods/jinxOAO-DSPCalculator/`.

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder. Via: `starfi5h-BuildToolOpt`.

### Dependency references inside the copied mods

`RelatedMods/starfi5h-BuildToolOpt/Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/Compatibility.cs:137`

```csharp
		}

		public const string GUID = "com.GniMaerd.DSPCalculator";

		public static void Init(Harmony harmony)
```

`RelatedMods/starfi5h-BuildToolOpt/Source/EarlierWorkingSource/Compatibility.cs:65`

```csharp
        public static class DSPCalculator_Patch
        {
            public const string GUID = "com.GniMaerd.DSPCalculator";

            public static void Init(Harmony harmony)
```

### Code in the related copy

`RelatedMods/jinxOAO-DSPCalculator/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator/DSPCalculatorPlugin.cs:15`

```csharp
namespace DSPCalculator;

[BepInPlugin("com.GniMaerd.DSPCalculator", "DSPCalculator", "0.5.27")]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.LoShin.GenesisBook", BepInDependency.DependencyFlags.SoftDependency)]
```

`RelatedMods/jinxOAO-DSPCalculator/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator/Utils.cs:10`

```csharp
public static class Utils
{
	public static ManualLogSource logger => DSPCalculatorPlugin.logger;

	public static string KMG(double num)
```

`RelatedMods/jinxOAO-DSPCalculator/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.Bp/BpProcessor.cs:301`

```csharp
				bpCargoInfo.maxSorterDistance = (int)(solution.sortersAvailable.Last().speedPerMin / bpCargoInfo.beltSpeedRequiredPerAssembler);
			}
			if (DSPCalculatorPlugin.developerMode)
			{
				Utils.logger.LogInfo($"item{Utils.GetItemName(bpCargoInfo.itemId)} spd per factory {bpCargoInfo.beltSpeedRequiredPerAssembler} maxC{bpCargoInfo.maxSupportAssemblerCount} sorter max distance{bpCargoInfo.maxSorterDistance}.");
```

`RelatedMods/jinxOAO-DSPCalculator/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.Logic/RecipeInfo.cs:131`

```csharp
				return CalcDB.assemblerListByType[recipeNorm.type][0].ID;
			}
			Debug.LogError("DSPCalculator get assemblerId Error. no such aseembler that could match the recipe.");
			return -1;
		}
```

`RelatedMods/jinxOAO-DSPCalculator/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.Logic/SolutionTree.cs:256`

```csharp
						Debug.LogWarning($"cur的parent为0，这不正常，出现在itemId={itemId}");
					}
					if (DSPCalculatorPlugin.developerMode)
					{
						int itemId2 = itemNode.parents[0].itemId;
```

## nebula-NebulaMultiplayerModApi

Copy: `RelatedMods/nebula-NebulaMultiplayerModApi/`.

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder. Via: `CommonAPI-CommonAPI`.

### Dependency references inside the copied mods

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs:13`

```csharp

[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
```

### Code in the related copy

`RelatedMods/nebula-NebulaMultiplayerModApi/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs:15`

```csharp
[BepInPlugin("dsp.nebula-multiplayer-api", "NebulaMultiplayerModApi", "2.1.0.7")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class NebulaModAPI : BaseUnityPlugin
{
	public const string NEBULA_MODID = "dsp.nebula-multiplayer";
```

`RelatedMods/nebula-NebulaMultiplayerModApi/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/CollectionExtensions.cs:5`

```csharp
namespace NebulaAPI.DataStructures;

public static class CollectionExtensions
{
	public static Locker Lock(this ICollection collection)
```

## starfi5h-BuildToolOpt

Copy: `RelatedMods/starfi5h-BuildToolOpt/`.

- **fix_integration_context**: Replacement and auto-fill share native station inventory and capacity; excess-only refunds must preserve new stock.

### Code in this mod

`Source/Reconstructed/plugins/UXAssist/UXAssist.Functions/PlanetFunctions.cs:531`

```csharp
							}
						}
						int num30 = stationComponent.idleDroneCount + stationComponent.workDroneCount;
						if (num30 > 0)
						{
```

`Source/Reconstructed/plugins/UXAssist/UXAssist.Patches.Logistics/LogisticsPatch.cs:182`

```csharp
		if (factory != null && GameMain.mainPlayer != null && GameMain.mainPlayer.factory == factory && station?.workDroneDatas != null)
		{
			int num = MissingWorkers(station.isStellar ? AutoConfigILSDroneCount.Value : AutoConfigPLSDroneCount.Value, station.workDroneDatas.Length, station.idleDroneCount, station.workDroneCount);
			if (num > 0)
			{
```

`Source/Reconstructed/plugins/UXAssist/UXAssist.Patches.Logistics/RealtimeLogisticsInfoPanel.cs:471`

```csharp
			case EStationTipLayout.PlanetaryLogistics:
			{
				int num5 = stationComponent.idleDroneCount + stationComponent.workDroneCount;
				int idleDroneCount = stationComponent.idleDroneCount;
				_carrierIdleCountText[0].text = idleDroneCount.ToString();
```

`Evidence/InitialPhase/check.cs:53`

```csharp
        var factory=Empty<PlanetFactory>(); var planet=Empty<PlanetData>(); planet.factory=factory;
        Set(planet,"factoryLoaded",true);Set(player,"planetData",planet);
        var station=new StationComponent {idleDroneCount=3,workDroneCount=2,workDroneDatas=new DroneData[10],
            idleShipCount=2,workShipCount=1,workShipDatas=new ShipData[6],droneAutoReplenish=true,shipAutoReplenish=true};
        var bot=new DispenserComponent {idleCourierCount=3,workCourierCount=2,workCourierDatas=new CourierData[20],courierAutoReplenish=true};
```

`Source/EarlierWorkingSource/Functions/PlanetFunctions.cs:445`

```csharp
                        if (count > 0) AddReturnedItem(sc.storage[j].itemId, count, sc.storage[j].inc, returnedItems);
                    }
                    var droneCount = sc.idleDroneCount + sc.workDroneCount;
                    if (droneCount > 0) AddReturnedItem((int)Common.KnownItemId.Drone, droneCount, 0, returnedItems);
                    var shipCount = sc.idleShipCount + sc.workShipCount;
```

### Code in the related copy

`RelatedMods/starfi5h-BuildToolOpt/Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/ReplaceStationLogic.cs:101`

```csharp
			}
		}
		stationComponent.idleDroneCount = 0;
		stationComponent.idleShipCount = 0;
		stationComponent.warperCount = 0;
```

`RelatedMods/starfi5h-BuildToolOpt/Source/EarlierWorkingSource/Replace/ReplaceStationLogic.cs:83`

```csharp
				}
			}
			stationComponent.idleDroneCount = 0;
			stationComponent.idleShipCount = 0;
			stationComponent.warperCount = 0;
```

`RelatedMods/starfi5h-BuildToolOpt/Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/GalacticTransport_Patch.cs:87`

```csharp
		for (int i = 1; i < planetTransport.stationCursor; i++)
		{
			StationComponent stationComponent = planetTransport.stationPool[i];
			if (stationComponent?.storage == null || !stationComponent.isStellar)
			{
```

`RelatedMods/starfi5h-BuildToolOpt/Source/EarlierWorkingSource/Optimization/GalacticTransport_Patch.cs:121`

```csharp

		[HarmonyPrefix, HarmonyPriority(Priority.Low)]
		[HarmonyPatch(typeof(GalacticTransport), nameof(GalacticTransport.RemoveStationComponent))]
		static void RemoveILS_Prefix(ref bool __runOriginal, GalacticTransport __instance, int gid)
        {
```

## starfi5h-LogisticsBotsTweaks

Copy: `RelatedMods/starfi5h-LogisticsBotsTweaks/`.

- **fix_integration_context**: Refill must use expanded runtime courier arrays without replacing research or replenishment flags.

### Code in this mod

`Source/Reconstructed/plugins/UXAssist/UXAssist.Patches.Logistics/AutoConfigLogistics.cs:20`

```csharp
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.Start().MatchForward(false, new CodeMatch((CodeInstruction ci) => ci.IsLdloc()), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(DispenserComponent), "workCourierDatas")), new CodeMatch(OpCodes.Ldlen), new CodeMatch(OpCodes.Conv_I4));
			codeMatcher.Repeat(delegate(CodeMatcher m)
			{
```

`Source/Reconstructed/plugins/UXAssist/UXAssist.Patches.Logistics/LogisticsPatch.cs:255`

```csharp
	internal static void DispenserFillCouriers(PlanetFactory factory, DispenserComponent dispenser)
	{
		if (factory != null && GameMain.mainPlayer != null && GameMain.mainPlayer.factory == factory && dispenser?.workCourierDatas != null)
		{
			int num = MissingWorkers(AutoConfigDispenserCourierCount.Value, dispenser.workCourierDatas.Length, dispenser.idleCourierCount, dispenser.workCourierCount);
```

`Evidence/InitialPhase/check.cs:55`

```csharp
        var station=new StationComponent {idleDroneCount=3,workDroneCount=2,workDroneDatas=new DroneData[10],
            idleShipCount=2,workShipCount=1,workShipDatas=new ShipData[6],droneAutoReplenish=true,shipAutoReplenish=true};
        var bot=new DispenserComponent {idleCourierCount=3,workCourierCount=2,workCourierDatas=new CourierData[20],courierAutoReplenish=true};
        Call("StationFillDrones",factory,station);Call("StationFillShips",factory,station);Call("DispenserFillCouriers",factory,bot);
        Assert(station.idleDroneCount==8 && station.idleShipCount==5 && bot.idleCourierCount==18 && package.grids[2].count==35,
```

`Source/EarlierWorkingSource/Patches/Logistics/AutoConfigPatch.cs:43`

```csharp
            matcher.Start().MatchForward(false,
                new CodeMatch(ci => ci.IsLdloc()),
                new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(DispenserComponent), nameof(DispenserComponent.workCourierDatas))),
                new CodeMatch(OpCodes.Ldlen),
                new CodeMatch(OpCodes.Conv_I4)
```

`Source/EarlierWorkingSource/Patches/Logistics/LogisticsPatch.cs:195`

```csharp
    internal static void DispenserFillCouriers(PlanetFactory factory, DispenserComponent dispenser)
    {
        if (factory == null || GameMain.mainPlayer == null || GameMain.mainPlayer.factory != factory || dispenser?.workCourierDatas == null) return;
        var toFill = MissingWorkers(AutoConfigDispenserCourierCount.Value, dispenser.workCourierDatas.Length, dispenser.idleCourierCount, dispenser.workCourierCount);
        if (toFill > 0) dispenser.idleCourierCount += GameMain.data.mainPlayer.package.TakeItem((int)KnownItemId.Bot, toFill, out _);
```

### Code in the related copy

`RelatedMods/starfi5h-LogisticsBotsTweaks/Source/Reconstructed/plugins/LogisticsBotsTweaks/LogisticsBotsTweaks/Patch_Distributor.cs:33`

```csharp
	{
		int val = dispenserMaxCourierCount;
		CourierData[] workCourierDatas = component.workCourierDatas;
		int num = Math.Max(val, (workCourierDatas != null) ? workCourierDatas.Length : 0);
		int val2 = num;
```

`RelatedMods/starfi5h-LogisticsBotsTweaks/Evidence/InitialPhase/check.cs:36`

```csharp
        Assert(Math.Abs(history.logisticCourierSpeedModified - 68) < 0.001, "repeated load/unlock adjustment does not compound speed");
        distributor.GetField("dispenserMaxCourierCount").SetValue(null, 20);
        var component = new DispenserComponent {workCourierDatas = new CourierData[10], orders = new DeliveryLogisticOrder[10], holdupPackage = new DispenserStore[20], idleCourierCount = 3, workCourierCount = 2};
        component.workCourierDatas[1].itemId = 1001; component.holdupPackage[1].itemId = 1002; component.holdupPackage[1].count = 7;
        Call(distributor, "Expand", component);
```

`RelatedMods/starfi5h-LogisticsBotsTweaks/Source/EarlierWorkingSource/LogisticsBotsTweaks.cs:86`

```csharp
        public static void Expand(DispenserComponent component)
        {
            int count = Math.Max(dispenserMaxCourierCount, component.workCourierDatas?.Length ?? 0);
            count = Math.Max(count, component.orders?.Length ?? 0);
            count = Math.Max(count, (component.holdupPackage?.Length ?? 0) / 2);
```

## xiaoye97-LDBTool

Copy: `RelatedMods/xiaoye97-LDBTool/`.

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder. Via: `CommonAPI-CommonAPI`.

### Dependency references inside the copied mods

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs:17`

```csharp

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
```

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/ProtoRegistry.cs:81`

```csharp
		spriteFileExtensions = new string[3] { ".jpg", ".png", ".tif" };
		audioClipFileExtensions = new string[4] { ".mp3", ".ogg", ".waw", ".aif" };
		LDBTool.PostAddDataAction = (Action)Delegate.Combine(LDBTool.PostAddDataAction, new Action(OnPostAdd));
		LDBTool.EditDataAction = (Action<Proto>)Delegate.Combine(LDBTool.EditDataAction, new Action<Proto>(EditProto));
	}
```

`RelatedMods/CommonAPI-CommonAPI/Source/EarlierWorkingSource/CommonAPIPlugin.cs:30`

```csharp
    /// </summary>
    [BepInPlugin(GUID, DISPNAME, VERSION)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
```

### Code in the related copy

`RelatedMods/xiaoye97-LDBTool/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs:11`

```csharp
namespace xiaoye97;

public static class LDBTool
{
	public static Action PreAddDataAction;
```

`RelatedMods/xiaoye97-LDBTool/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs:11`

```csharp
namespace xiaoye97;

[BepInPlugin("me.xiaoye97.plugin.Dyson.LDBTool", "LDBTool", "3.0.4")]
public class LDBToolPlugin : BaseUnityPlugin
{
```

`RelatedMods/xiaoye97-LDBTool/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs:16`

```csharp
	internal static void InitIndex()
	{
		LDBToolPlugin.logger.LogDebug("Generating Proto type list:");
		protoTypes = (from domainAssembly in AppDomain.CurrentDomain.GetAssemblies()
			from assemblyType in GetTypesSafe(domainAssembly)
```

`RelatedMods/xiaoye97-LDBTool/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs:19`

```csharp
		if (__instance.recipeExecuteData == null)
		{
			LDBToolPlugin.logger.LogWarning($"Importing assembler {__instance.recipeType}: Can't find recipeId {__instance.recipeId}");
			__instance.recipeId = 0;
			__instance.recipeType = ERecipeType.None;
```

`RelatedMods/xiaoye97-LDBTool/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs:12`

```csharp
	private static void HistoryPatch(GameHistoryData __instance)
	{
		foreach (Proto item in LDBTool.TotalDict[ProtoIndex.GetIndex(typeof(RecipeProto))])
		{
			RecipeProto recipeProto = item as RecipeProto;
```

## Declared mods not installed in this profile

These are recorded declarations, not supplied copies or newly established requirements for the main plugin. Some belong to optional/inactive compatibility plugins.

- `testpostpleaseignore.dsp.planet_vein_utilization` for `org.soardev.uxassist` (soft).
