using System;
using System.IO;
using System.Collections;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using crecheng.DSPModSave;

sealed class SaveSample : IModCanSave
{
    public bool Fail;
    public int Loaded;
    public void Export(BinaryWriter writer) {writer.Write(731); if (Fail) throw new Exception("controlled export failure");}
    public void Import(BinaryReader reader) {Loaded = reader.ReadInt32();}
    public void IntoOtherSave() {throw new Exception("Unexpected missing-save fallback");}
}
static class Check
{
    static void Call(string method, params object[] args) {AccessTools.Method(typeof(DSPModSavePlugin), method).Invoke(null, args);}
    static int Main()
    {
        string root = Path.Combine(Path.GetTempPath(), "dsp-save-check-" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(root);
        string path = Path.Combine(root, "sample.moddsv");
        var sample = new SaveSample();
        var settingsType = typeof(DSPModSavePlugin).Assembly.GetType("crecheng.DSPModSave.ModSaveSettings");
        var settings = Activator.CreateInstance(settingsType, true);
        AccessTools.Field(settingsType, "mod").SetValue(settings, sample);
        AccessTools.Field(settingsType, "loadOrder").SetValue(settings, LoadOrder.Postload);
        var entries = (IDictionary)AccessTools.Field(typeof(DSPModSavePlugin), "allModData").GetValue(null); entries.Add("sample", settings);
        DSPModSavePlugin.logger = new BepInEx.Logging.ManualLogSource("Save check");
        object[] saveResult = {true, "missing-game"};
        AccessTools.Method(typeof(crecheng.DSPModSave.Patches.GameSave_Patch), "SaveCurrentGameResult").Invoke(null, saveResult);
        if ((bool)saveResult[0]) throw new Exception("Failed sidecar still reported as a successful save");
        GameSave.AllowRecursive = true;
        string nested = (string)AccessTools.Method(typeof(DSPModSavePlugin), "GetSavePath").Invoke(null, new object[] {"folder/sample"});
        if (!nested.EndsWith("folder/sample.moddsv") && !nested.EndsWith("folder\\sample.moddsv"))
            throw new Exception("Native recursive save path was flattened");
        GameSave.AllowRecursive = false;
        File.WriteAllText(path, "previous file"); Call("SaveToPath", path);
        byte[] good = File.ReadAllBytes(path); sample.Fail = true; bool failed = false;
        try {Call("SaveToPath", path);} catch (TargetInvocationException e) {failed = e.InnerException is InvalidDataException;}
        if (!failed || !good.SequenceEqual(File.ReadAllBytes(path)) || Directory.GetFiles(root, "*.tmp-*").Length != 0) throw new Exception("Export failure damaged previous sidecar");
        var streamField = AccessTools.Field(typeof(DSPModSavePlugin), "currentFileStream");
        streamField.SetValue(null, File.OpenRead(path)); Call("LoadData"); Call("CallImports", LoadOrder.Postload); Call("CloseLoad");
        if (sample.Loaded != 731 || streamField.GetValue(null) != null) throw new Exception("Format 1 roundtrip failed");
        foreach (int corruption in new[] {0, 1, 2})
        {
            byte[] bad = (byte[])good.Clone();
            using (var memory = new MemoryStream(bad)) using (var writer = new BinaryWriter(memory))
            {
                if (corruption == 0) {memory.Position = 3; writer.Write(2);}
                else if (corruption == 1) {memory.Position = 47; writer.Write(-1);}
                else {memory.Position = 51; using (var reader = new BinaryReader(memory, System.Text.Encoding.UTF8, true)) reader.ReadString(); writer.Write(-1L);}
            }
            string damaged = Path.Combine(root, "bad" + corruption + ".moddsv"); File.WriteAllBytes(damaged, bad); streamField.SetValue(null, File.OpenRead(damaged)); failed = false;
            try {Call("LoadData");} catch (TargetInvocationException e) {failed = e.InnerException is InvalidDataException;}
            finally {Call("CloseLoad");}
            if (!failed) throw new Exception("Invalid version/count/offset accepted");
            File.Delete(damaged);
        }
        File.Delete(path); Directory.Delete(root);
        Console.WriteLine("PASS format 1 file roundtrip, failed export preserves prior bytes and removes temp, invalid version/count/offset rejected, streams closed");
        return 0;
    }
}
