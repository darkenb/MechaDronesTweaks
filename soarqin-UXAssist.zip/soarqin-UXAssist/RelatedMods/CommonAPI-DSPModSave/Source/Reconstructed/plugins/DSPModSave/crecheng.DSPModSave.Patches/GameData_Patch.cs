using HarmonyLib;

namespace crecheng.DSPModSave.Patches;

[HarmonyPatch]
public class GameData_Patch
{
	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameData), "NewGame")]
	private static void EnterGame()
	{
		DSPModSavePlugin.logger.LogInfo("Enter New Game");
		foreach (ModSaveSettings value in DSPModSavePlugin.allModData.Values)
		{
			value.mod.IntoOtherSave();
		}
	}
}
