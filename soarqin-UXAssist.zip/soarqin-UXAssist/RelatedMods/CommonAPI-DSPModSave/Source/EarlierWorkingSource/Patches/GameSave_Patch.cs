using System;
using System.IO;
using HarmonyLib;

namespace crecheng.DSPModSave.Patches
{
    [HarmonyPatch]
    public class GameSave_Patch
    {
        public static void SaveCurrentGame(bool __result, string saveName)
        {
            if (!__result) return;

            DSPModSavePlugin.OnSave(saveName);
        }

        [HarmonyPostfix, HarmonyPatch(typeof(GameSave), "SaveCurrentGame")]
        private static void SaveCurrentGameResult(ref bool __result, string saveName)
        {
            if (__result) __result = DSPModSavePlugin.OnSave(saveName);
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(GameSave), "AutoSave")]
        public static void AutoSave(bool __result)
        {
            if (!__result) return;

            DSPModSavePlugin.OnAutoSave();
        }
        
        [HarmonyPrefix]
        [HarmonyPatch(typeof(GameSave), "LoadCurrentGame")]
        public static void PreLoadCurrentGame(bool __result, string saveName)
        {
            DSPModSavePlugin.OnPreLoad(saveName);
        }   
        
        [HarmonyPostfix]
        [HarmonyPatch(typeof(GameSave), "LoadCurrentGame")]
        public static void PostLoadCurrentGame(bool __result)
        {
            try { if (__result) DSPModSavePlugin.OnPostLoad(); }
            finally { DSPModSavePlugin.CloseLoad(); }
        }

        [HarmonyFinalizer, HarmonyPatch(typeof(GameSave), "LoadCurrentGame")]
        private static Exception CloseFailedLoad(Exception __exception)
        {
            if (__exception != null) DSPModSavePlugin.CloseLoad();
            return __exception;
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(UIGameSaveEntry), "DeleteSaveFile")]
        public static void PreDeleteSaveFile(UIGameSaveEntry __instance)
        {
            DSPModSavePlugin.OnDeleteSave(__instance.saveName);
        }
    }
}
