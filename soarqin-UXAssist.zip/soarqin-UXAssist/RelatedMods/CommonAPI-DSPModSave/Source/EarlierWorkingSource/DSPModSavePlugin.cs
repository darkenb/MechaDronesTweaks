using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;
using System.Text;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Logging;
using crecheng.DSPModSave.Patches;
using HarmonyLib;
using UnityEngine;

// ReSharper disable SuspiciousTypeConversion.Global

[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]
namespace crecheng.DSPModSave
{
    [BepInPlugin(MODGUID, MODNAME, VERSION)]
    public class DSPModSavePlugin : BaseUnityPlugin
    {
        public const string MODGUID = "crecheng.DSPModSave";
        public const string MODNAME = "DSP Mod Save";
        public const string MODID = "DSPModSave";
        public const string VERSION = "1.2.3";

        public static ManualLogSource logger;

        internal static Dictionary<string, ModSaveSettings> allModData = new Dictionary<string, ModSaveSettings>();

        private const string saveExt = ".moddsv";
        private const string autoSaveTmp = "_autosave_tmp";
        private const string autoSave0 = "_autosave_0";
        private const string autoSave1 = "_autosave_1";
        private const string autoSave2 = "_autosave_2";
        private const string autoSave3 = "_autosave_3";
        private const string lastExit = "_lastexit_";

        public const int SAVE_FILE_VERSION = 1;

        private void Start()
        {
            logger = Logger;
            Harmony harmony = new Harmony(MODGUID);
            
            harmony.PatchAll(typeof(GameData_Patch));
            harmony.PatchAll(typeof(GameSave_Patch));

            Init();
            logger.LogInfo("DSP Mod Save is initialized!");
        }

        private void Init()
        {
            foreach (var plugin in Chainloader.PluginInfos.Values)
            {
                RegisterModSaveHandler(plugin.Instance);
            }
        }

        public static void AddModSaveManually(BaseUnityPlugin mod)
        {
            RegisterModSaveHandler(mod);
        }

        public static void RemoveModSaveManually(BaseUnityPlugin mod)
        {
            if (!(mod is IModCanSave)) return;

            string GUID = mod.Info.Metadata.GUID;
            if (allModData.ContainsKey(GUID))
            {
                allModData.Remove(GUID);
            }
        }
        
        private static void RegisterModSaveHandler(BaseUnityPlugin mod)
        {
            if (!(mod is IModCanSave save)) return;

            string GUID = mod.Info.Metadata.GUID;
            if (allModData.ContainsKey(GUID)) return;

            ModSaveSettingsAttribute settingsAttribute = mod.GetType().GetCustomAttribute<ModSaveSettingsAttribute>();
            LoadOrder order = LoadOrder.Postload;

            if (settingsAttribute != null)
            {
                order = settingsAttribute.LoadOrder;
            }

            allModData.Add(GUID, new ModSaveSettings()
            {
                mod = save,
                loadOrder = order
            });
        }

        private static string lastSavedPath;

        internal static bool OnSave(string saveName)
        {
            lastSavedPath = null;
            if (DSPGame.Game == null)
            {
                logger.LogError("No game to save");
                return false;
            }

            if (allModData.Count == 0)
                return true;
            try
            {
                string path = GetSavePath(saveName);
                SaveToPath(path);
                lastSavedPath = path;
                return true;
            }
            catch (Exception exception)
            {
                logger.LogError(exception.Message);
                return false;
            }
        }

        internal static void OnAutoSave()
        {
            string text = GameConfig.gameSaveFolder + GameSave.AutoSaveTmp + saveExt;
            string text2 = GameConfig.gameSaveFolder + autoSave0 + saveExt;
            string text3 = GameConfig.gameSaveFolder + autoSave1 + saveExt;
            string text4 = GameConfig.gameSaveFolder + autoSave2 + saveExt;
            string text5 = GameConfig.gameSaveFolder + autoSave3 + saveExt;
            if (lastSavedPath != text || !File.Exists(text)) return;
            lastSavedPath = null;

            if (File.Exists(text5))
            {
                File.Delete(text5);
            }

            if (File.Exists(text4))
            {
                File.Move(text4, text5);
            }

            if (File.Exists(text3))
            {
                File.Move(text3, text4);
            }

            if (File.Exists(text2))
            {
                File.Move(text2, text3);
            }

            File.Move(text, text2);
        }

        private static FileStream currentFileStream;
        private static Dictionary<string, ModSaveEntry> saveEntries = new Dictionary<string, ModSaveEntry>();
        
        internal static void OnPreLoad(string saveName)
        {
            if (currentFileStream != null)
            {
                currentFileStream.Close();
                currentFileStream = null;
            }
            
            if (DSPGame.Game == null)
            {
                logger.LogError("No game to load");
                return;
            }

            string path = GetSavePath(saveName);
            if (!File.Exists(path))
            {
                logger.LogInfo(saveName + ": Game mod save not exist");
                foreach (var settings in allModData.Values)
                {
                    if (settings.loadOrder != LoadOrder.Preload) continue;
                    
                    settings.mod.IntoOtherSave();
                }

                return;
            }

            try
            {
                logger.LogInfo("Pre Load!");
                currentFileStream = new FileStream(path, FileMode.Open, FileAccess.Read);
                LoadData();
                CallImports(LoadOrder.Preload);
            }
            catch (Exception exception)
            {
                CloseLoad();
                logger.LogError(exception.Message);
                throw;
            }
        }

        internal static void OnPostLoad()
        {
            if (currentFileStream == null)
            {
                foreach (var settings in allModData.Values)
                {
                    if (settings.loadOrder != LoadOrder.Postload) continue;
                    
                    settings.mod.IntoOtherSave();
                }

                return;
            }
            
            logger.LogInfo("Post Load!");
            
            try
            {
                CallImports(LoadOrder.Postload);
            }
            catch (Exception exception)
            {
                logger.LogError(exception.Message);
                throw;
            }
            finally { CloseLoad(); }
        }

        internal static void OnDeleteSave(string saveName)
        {
            string path = GetSavePath(saveName);
            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }

        internal static void SaveData(FileStream fileStream)
        {
            using BinaryWriter binaryWriter = new BinaryWriter(fileStream, new UTF8Encoding(false), true);

            Dictionary<string, long> pos = new Dictionary<string, long>();
            binaryWriter.Write('M');
            binaryWriter.Write('O');
            binaryWriter.Write('D');
            binaryWriter.Write(SAVE_FILE_VERSION);
            binaryWriter.Write(0L);
            binaryWriter.Write(0L);
            binaryWriter.Write(0L);
            binaryWriter.Write(0L);
            binaryWriter.Write(0L);
            binaryWriter.Write(allModData.Count);

            foreach (var name in allModData)
            {
                binaryWriter.Write(name.Key);
                pos.Add(name.Key, fileStream.Position);
                binaryWriter.Write(0L);
                binaryWriter.Write(0L);
            }

            foreach (var data in allModData)
            {
                string name = data.Key;
                if (!pos.ContainsKey(name)) continue;

                long begin = fileStream.Position;
                try
                {
                    using MemoryStream ms = new MemoryStream();
                    using BinaryWriter binary = new BinaryWriter(ms);

                    data.Value.mod.Export(binary);
                    byte[] dataByte = ms.ToArray();
                    fileStream.Write(dataByte, 0, dataByte.Length);
                }
                catch (Exception ex)
                {
                    throw new InvalidDataException("Mod data export failed: " + data.Key, ex);
                }

                long end = fileStream.Position;
                fileStream.Seek(pos[name], SeekOrigin.Begin);
                binaryWriter.Write(begin);
                binaryWriter.Write(end);
                fileStream.Seek(0, SeekOrigin.End);
            }
        }
        
        internal static void LoadData()
        {
            using BinaryReader reader = new BinaryReader(currentFileStream, new UTF8Encoding(false), true);
            saveEntries.Clear();
            if (reader.ReadChar() != 'M' || reader.ReadChar() != 'O' || reader.ReadChar() != 'D')
                throw new InvalidDataException("Invalid mod save header");
            if (reader.ReadInt32() != SAVE_FILE_VERSION) throw new InvalidDataException("Unsupported mod save version");
            for (int i = 0; i < 5; i++) reader.ReadInt64();
            int count = reader.ReadInt32();
            if (count < 0 || count > (currentFileStream.Length - currentFileStream.Position) / 17)
                throw new InvalidDataException("Invalid mod entry count");
            var entries = new Dictionary<string, ModSaveEntry>();
            for (int i = 0; i < count; i++)
            {
                string name = reader.ReadString();
                long begin = reader.ReadInt64();
                long end = reader.ReadInt64();
                if (string.IsNullOrEmpty(name) || entries.ContainsKey(name)) throw new InvalidDataException("Duplicate/empty mod entry");
                entries.Add(name, new ModSaveEntry(name, begin, end));
            }
            long tableEnd = currentFileStream.Position;
            foreach (var entry in entries.Values)
                if (entry.begin < tableEnd || entry.end < entry.begin || entry.end > currentFileStream.Length || entry.end - entry.begin > int.MaxValue)
                    throw new InvalidDataException("Mod entry outside data region: " + entry.name);
            long previousEnd = tableEnd;
            foreach (var entry in System.Linq.Enumerable.OrderBy(entries.Values, e => e.begin))
            {
                if (entry.begin < previousEnd) throw new InvalidDataException("Overlapping mod entries");
                previousEnd = entry.end;
            }
            saveEntries = entries;
        }

        private static string GetSavePath(string saveName)
        {
            saveName = GameSave.AllowRecursive ? saveName.ValidPathedFileName() : saveName.ValidFileName();
            return GameConfig.gameSaveFolder + saveName + saveExt;
        }

        private static void SaveToPath(string path)
        {
            string temporary = path + ".tmp-" + Guid.NewGuid().ToString("N");
            try
            {
                using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    SaveData(stream);
                    stream.Flush(true);
                }
                if (File.Exists(path)) File.Replace(temporary, path, null, true);
                else File.Move(temporary, path);
            }
            finally { if (File.Exists(temporary)) File.Delete(temporary); }
        }

        internal static void CloseLoad()
        {
            currentFileStream?.Dispose();
            currentFileStream = null;
            saveEntries.Clear();
        }

        [SuppressMessage("ReSharper", "MustUseReturnValue")]
        private static void CallImports(LoadOrder currentState)
        {
            foreach (var pair in allModData)
            {
                if (pair.Value.loadOrder != currentState) continue;
                
                if (!saveEntries.ContainsKey(pair.Key))
                {
                    pair.Value.mod.IntoOtherSave();
                    continue;
                }

                ModSaveEntry e = saveEntries[pair.Key];
                currentFileStream.Seek(e.begin, SeekOrigin.Begin);
                byte[] b = new byte[e.end - e.begin];
                int offset = 0;
                while (offset < b.Length)
                {
                    int read = currentFileStream.Read(b, offset, b.Length - offset);
                    if (read == 0) throw new EndOfStreamException();
                    offset += read;
                }
                
                try
                {
                    using MemoryStream temp = new MemoryStream(b);
                    using BinaryReader binary = new BinaryReader(temp);

                    pair.Value.mod.Import(binary);
                }
                catch (Exception ex)
                {
                    throw new InvalidDataException("Mod data import failed: " + pair.Key, ex);
                }
            }
        }
    }
}
