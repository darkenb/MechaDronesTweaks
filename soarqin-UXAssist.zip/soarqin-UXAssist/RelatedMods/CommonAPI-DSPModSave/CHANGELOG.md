# CommonAPI-DSPModSave — detailed change report

Installed plugin version(s): **1.2.3**. Write and flush mod saves to a temporary file before atomic replacement; preserve prior saves on export failure and guard autosave rotation.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Atomic sidecar replacement and strict import — 1.2.3

Use the source matching installed 1.2.2. Preserve public API, assembly identity, `MOD` header and format version 1.

- Finish export in a uniquely named temporary file in the same directory and flush it to disk. Activate only a successful result through `File.Replace`/`File.Move`; export failure must not truncate the previous `.moddsv` or replace it with empty entries.
- Rotate autosaves only if that temporary save's mod sidecar was successfully written. Do not rotate a stale file left by an earlier failed write.
- Return false from native `SaveCurrentGame` if sidecar writing fails so native autosave rotation does not continue after failed export, while retaining the old public postfix call contract.
- Follow native `AllowRecursive` and `ValidPathedFileName` together for save/load/delete. Do not flatten sidecars of subdirectory saves into the root.
- Validate header/version, entry count, duplicate GUIDs, offsets outside the data region, reversed/oversized ranges and overlapping blocks. Validate the complete table before calling any mod Import.
- Read each data block completely. Clean up streams and temporary tables after preload/postload/native-load failure; preserve the original exception.
- Native vegetation/research-queue/lens save state remains the game's responsibility; do not redesign the mod sidecar for it.

Actual file-operation tests cover successful save/import, byte-for-byte preservation after export failure, temporary-file cleanup and rejection of corrupt tables. There is no general rollback of in-memory changes made by an individual mod's Import. The vanilla save and sidecar are not a single atomic transaction; complete multi-mod save/reload acceptance remains outstanding.

## Recorded source commits

- `aae2f110914c5ec5de32b7ac2ccea9b054b37cc6`

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
