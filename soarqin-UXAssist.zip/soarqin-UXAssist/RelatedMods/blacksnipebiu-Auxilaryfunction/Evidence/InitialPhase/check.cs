using System;
using System.Runtime.Serialization;
using HarmonyLib;

static class Check
{
    static T Empty<T>() => (T)FormatterServices.GetUninitializedObject(typeof(T));
    static void Set(object o, string name, object value) => (AccessTools.Field(o.GetType(), name) ?? AccessTools.Field(o.GetType(), "<"+name+">k__BackingField")).SetValue(o, value);
    static int Main()
    {
        var items = Empty<ItemProtoSet>(); AccessTools.Field(typeof(UnityEngine.Object), "m_CachedPtr").SetValue(items, new IntPtr(1));
        items.dataArray = new[] {new ItemProto {ID = 9911, FuelType = 4, HeatValue = 12345}};
        AccessTools.Field(typeof(ProtoSet<ItemProto>), "dataIndices").SetValue(items, new System.Collections.Generic.Dictionary<int,int> {{9911,0}});
        AccessTools.Field(typeof(LDB), "_items").SetValue(null, items);
        AccessTools.Field(typeof(StorageComponent), "staticLoaded").SetValue(null, true); StorageComponent.itemStackCount = new int[12000];
        var player = new Player(); var package = new StorageComponent(4); Set(player, "package", package);
        var delivery = new DeliveryPackage(); delivery.Init(); delivery.colCount = 1; delivery.rowCount = 2; delivery.unlocked = true;
        delivery.grids[4] = new DeliveryPackage.GRID {itemId = 9911, count = 4, inc = 12, stackSize = 100, stackSizeMultiplier = 1};
        Set(player, "deliveryPackage", delivery); Set(player, "packageUtility", new PlayerPackageUtility(player));
        var factory = Empty<PlanetFactory>(); Set(player, "planetData", new PlanetData {factory = factory, factoryLoaded = true});
        factory.powerSystem = Empty<PowerSystem>(); factory.powerSystem.genCursor = 2; factory.powerSystem.genPool = new PowerGeneratorComponent[2];
        factory.powerSystem.genPool[1] = new PowerGeneratorComponent {id = 1, fuelMask = 4, fuelId = 1803, fuelCount = 2};
        var helper = typeof(Auxilaryfunction.Auxilaryfunction).Assembly.GetType("Auxilaryfunction.NativeInventory");
        var has = AccessTools.Method(helper, "HasItem");
        if (!(bool)has.Invoke(null, new object[] {player, 9911})) throw new Exception("Active delivery fuel not recognized");
        var fill = AccessTools.Method(helper, "FillFuel");
        fill.Invoke(null, new object[] {player, factory, 1, 9911, 4});
        if (delivery.grids[4].count != 4) throw new Exception("Mismatched fuel consumed before validation");
        factory.powerSystem.genPool[1].fuelCount = 0;
        fill.Invoke(null, new object[] {player, factory, 1, 9911, 3});
        if (factory.powerSystem.genPool[1].fuelCount != 3 || factory.powerSystem.genPool[1].fuelInc != 9 || factory.powerSystem.genPool[1].fuelHeat != 12345 || delivery.grids[4].count != 1)
            throw new Exception("Native modded fuel/transfer/inc mismatch");
        fill.Invoke(null, new object[] {player, factory, 1, 9911, 3});
        if (delivery.grids[4].count != 1) throw new Exception("Repeated fill consumed stocked target");
        var missing = AccessTools.Method(helper, "Missing");
        if ((int)missing.Invoke(null, new object[] {10, 3, 2, 99}) != 5 || (int)missing.Invoke(null, new object[] {10, 3, 2, int.MinValue}) != 0 ||
            (int)missing.Invoke(null, new object[] {10, int.MaxValue, int.MaxValue, 99}) != 0)
            throw new Exception("Worker fill capacity or existing count overflow");
        Console.WriteLine("PASS native delivery-first fuel transfer preserves inc, accepts native modded fuel, rejects existing other fuel before consumption");
        return 0;
    }
}
