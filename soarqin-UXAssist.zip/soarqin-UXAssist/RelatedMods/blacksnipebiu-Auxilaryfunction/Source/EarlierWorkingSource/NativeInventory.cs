using System;

namespace Auxilaryfunction;

internal static class NativeInventory
{
    internal static int Missing(int capacity, int idle, int working, int target)
        => (int)Math.Max(0L, Math.Min((long)Math.Max(0, capacity), Math.Max(0, target)) - Math.Max(0L, idle) - Math.Max(0L, working));
    internal static bool HasItem(Player player, int itemId)
    {
        if (player == null || itemId <= 0) return false;
        if (player.package.GetItemCount(itemId) > 0 || (player.inhandItemId == itemId && player.inhandItemCount > 0)) return true;
        var delivery = player.deliveryPackage;
        if (delivery == null || !delivery.unlocked) return false;
        for (int i = 0; i < delivery.grids.Length; i++)
            if (delivery.IsGridActive(i) && delivery.grids[i].itemId == itemId && delivery.grids[i].count > 0) return true;
        return false;
    }

    internal static int Take(Player player, int itemId, int requested, out int inc)
    {
        inc = 0;
        if (player?.packageUtility == null || requested <= 0) return 0;
        int count = requested;
        player.packageUtility.TryTakeItemFromAllPackages(ref itemId, ref count, out inc, true);
        return count;
    }

    internal static void FillFuel(Player player, PlanetFactory factory, int generatorId, int itemId, int target)
    {
        if (player == null || player.factory != factory || factory?.powerSystem == null || generatorId <= 0 || generatorId >= factory.powerSystem.genCursor) return;
        ref var generator = ref factory.powerSystem.genPool[generatorId];
        var fuel = LDB.items.Select(itemId);
        if (target <= generator.fuelCount) return;
        if (generator.id != generatorId || generator.fuelMask != 4 || fuel == null || itemId > short.MaxValue ||
            fuel.HeatValue <= 0 || (fuel.FuelType & generator.fuelMask) == 0 || (generator.fuelCount > 0 && generator.fuelId != itemId)) return;
        int amount = Math.Min(Math.Max(0, target - generator.fuelCount), Math.Min(short.MaxValue - generator.fuelCount, (short.MaxValue - generator.fuelInc) / 10));
        int added = Take(player, itemId, amount, out int inc);
        if (added <= 0) return;
        if (generator.fuelCount == 0) generator.SetNewFuel(itemId, (short)added, (short)inc);
        else { generator.fuelCount += (short)added; generator.fuelInc += (short)inc; }
    }
}
