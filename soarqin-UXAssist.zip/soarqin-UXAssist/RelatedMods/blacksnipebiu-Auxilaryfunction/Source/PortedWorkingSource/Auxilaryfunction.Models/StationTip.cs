using Auxilaryfunction.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Auxilaryfunction.Models;

public class StationTip : MonoBehaviour
{
	public RectTransform RectTransform;

	public Transform[] Icons;

	public RectTransform[] IconRectTransforms;

	public Transform[] IconLocals;

	public Transform[] IconRemotes;

	public Transform[] countTexts;

	public Transform[] Icontexts;

	public Text[] CountText;

	public Text[] CountText2;

	public GameObject info_text;

	private void Start()
	{
	}

	public void Init()
	{
		RectTransform = GetComponent<RectTransform>();
		Icons = new Transform[13];
		IconLocals = new Transform[13];
		IconRemotes = new Transform[13];
		countTexts = new Transform[13];
		Icontexts = new Transform[3];
		CountText = new Text[3];
		CountText2 = new Text[3];
		IconRectTransforms = new RectTransform[13];
		info_text = base.transform.Find("info-text").gameObject;
		for (int i = 0; i < 3; i++)
		{
			Icontexts[i] = base.transform.Find("icontext" + i);
			CountText[i] = Icontexts[i].Find("countText").GetComponent<Text>();
			if (i != 2)
			{
				CountText2[i] = Icontexts[i].Find("countText2").GetComponent<Text>();
			}
		}
		for (int j = 0; j < 13; j++)
		{
			Icons[j] = base.transform.Find("icon" + j);
			IconLocals[j] = base.transform.Find("iconLocal" + j);
			IconRemotes[j] = base.transform.Find("iconremote" + j);
			countTexts[j] = base.transform.Find("countText" + j);
			IconRectTransforms[j] = Icons[j].GetComponent<RectTransform>();
			IconLocals[j].gameObject.SetActive(value: false);
			IconRemotes[j].gameObject.SetActive(value: false);
		}
		info_text.SetActive(value: false);
	}

	public void SetStationName(string stationName, int index)
	{
		Transform transform = Icons[index];
		Transform transform2 = countTexts[index];
		transform.gameObject.SetActive(value: false);
		for (int i = index; i < 13; i++)
		{
			IconLocals[i].gameObject.SetActive(value: false);
			IconRemotes[i].gameObject.SetActive(value: false);
			Icons[i].gameObject.SetActive(value: false);
			countTexts[i].gameObject.SetActive(value: false);
		}
		if (!string.IsNullOrEmpty(stationName))
		{
			Vector3 anchoredPosition3D = transform2.GetComponent<RectTransform>().anchoredPosition3D;
			transform2.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(90f, anchoredPosition3D.y, 0f);
			transform2.GetComponent<Text>().fontSize = 18;
			transform2.GetComponent<Text>().text = stationName;
			transform2.GetComponent<Text>().color = Color.white;
			transform2.gameObject.SetActive(value: true);
		}
		else
		{
			transform.gameObject.SetActive(value: false);
			transform2.gameObject.SetActive(value: false);
		}
	}

	public void SetItem(int itemId, int itemCount, int i, ELogisticStorage localLogic, ELogisticStorage remoteLogic, bool ShowStationInfoMode, bool IsStellarorCollector)
	{
		Transform transform = Icons[i];
		Vector3 anchoredPosition3D = IconRectTransforms[i].anchoredPosition3D;
		Transform transform2 = IconLocals[i];
		Transform transform3 = IconRemotes[i];
		Image component = transform2.GetComponent<Image>();
		Image component2 = transform3.GetComponent<Image>();
		Transform transform4 = countTexts[i];
		Text component3 = transform4.GetComponent<Text>();
		if (itemId > 0)
		{
			switch (localLogic)
			{
			case ELogisticStorage.Supply:
				component.sprite = GUIDraw.rightsprite;
				component.color = GUIDraw.BlueColor;
				component3.color = GUIDraw.BlueColor;
				break;
			case ELogisticStorage.Demand:
				component.sprite = GUIDraw.leftsprite;
				component.color = GUIDraw.OrangeColor;
				component3.color = GUIDraw.OrangeColor;
				break;
			case ELogisticStorage.None:
				component.sprite = GUIDraw.flatsprite;
				component.color = Color.gray;
				component3.color = Color.gray;
				break;
			}
			if (IsStellarorCollector)
			{
				switch (remoteLogic)
				{
				case ELogisticStorage.Supply:
					component2.sprite = GUIDraw.rightsprite;
					component2.color = GUIDraw.BlueColor;
					break;
				case ELogisticStorage.Demand:
					component2.sprite = GUIDraw.leftsprite;
					component2.color = GUIDraw.OrangeColor;
					break;
				case ELogisticStorage.None:
					component2.sprite = GUIDraw.flatsprite;
					component2.color = Color.gray;
					break;
				}
				transform3.gameObject.SetActive(value: true);
			}
			if (ShowStationInfoMode)
			{
				transform2.gameObject.SetActive(value: false);
				if (IsStellarorCollector)
				{
					transform3.GetComponent<RectTransform>().sizeDelta = new Vector2(30f, 30f);
					transform3.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(100f, anchoredPosition3D.y, 0f);
					transform4.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(70f, anchoredPosition3D.y, 0f);
				}
				else
				{
					transform3.gameObject.SetActive(value: false);
					transform4.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(90f, anchoredPosition3D.y, 0f);
				}
			}
			else
			{
				transform2.gameObject.SetActive(value: true);
				transform4.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(70f, anchoredPosition3D.y, 0f);
				if (IsStellarorCollector)
				{
					transform2.GetComponent<RectTransform>().sizeDelta = new Vector2(21f, 21f);
					transform3.GetComponent<RectTransform>().sizeDelta = new Vector2(21f, 21f);
					transform2.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(105f, anchoredPosition3D.y, 0f);
					transform3.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(105f, anchoredPosition3D.y - 15f, 0f);
				}
				else
				{
					transform3.gameObject.SetActive(value: false);
					transform2.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(100f, anchoredPosition3D.y, 0f);
					transform2.GetComponent<RectTransform>().sizeDelta = new Vector2(30f, 30f);
				}
			}
			transform.GetComponent<Image>().sprite = LDB.items.Select(itemId)?.iconSprite;
			transform.gameObject.SetActive(value: true);
			component3.text = itemCount.ToString("#,##0");
		}
		else
		{
			transform2.gameObject.SetActive(value: false);
			transform3.gameObject.SetActive(value: false);
			transform.gameObject.SetActive(value: false);
			component3.color = Color.white;
			component3.text = "无";
			int num = 70;
			num = ((!ShowStationInfoMode) ? 70 : ((!IsStellarorCollector) ? 90 : 70));
			component3.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(num, anchoredPosition3D.y, 0f);
		}
		transform4.gameObject.SetActive(value: true);
	}

	public void SetDroneShipWarp(int index, int itemId, int totalCount, int CurrentCount, int lastLine)
	{
		if (itemId == 0)
		{
			Icontexts[index].gameObject.SetActive(value: false);
			return;
		}
		if (index < 2)
		{
			CountText2[index].color = Color.white;
			CountText2[index].text = CurrentCount.ToString();
		}
		Icontexts[index].gameObject.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(index * 30, -30 - 30 * lastLine, 0f);
		Icontexts[index].GetComponent<Image>().sprite = LDB.items.Select(itemId).iconSprite;
		CountText[index].color = Color.white;
		CountText[index].text = totalCount.ToString();
		Icontexts[index].gameObject.SetActive(value: true);
	}
}
