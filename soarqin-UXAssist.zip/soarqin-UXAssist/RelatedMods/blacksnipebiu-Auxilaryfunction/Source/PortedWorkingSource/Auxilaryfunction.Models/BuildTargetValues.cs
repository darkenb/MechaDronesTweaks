using System.Collections.Generic;

namespace Auxilaryfunction.Models;

public class BuildTargetValues
{
	public static Dictionary<string, BuildConfig> buildConfigsDic;

	public static int StationDroneNumber
	{
		get
		{
			return AuxConfig.auto_supply_drone.Value;
		}
		set
		{
			AuxConfig.auto_supply_drone.Value = value;
		}
	}

	public static int StationShipNumber
	{
		get
		{
			return AuxConfig.auto_supply_ship.Value;
		}
		set
		{
			AuxConfig.auto_supply_ship.Value = value;
		}
	}

	public static float StationMaxPowerPertick
	{
		get
		{
			return AuxConfig.stationmaxpowerpertick.Value;
		}
		set
		{
			AuxConfig.stationmaxpowerpertick.Value = value;
		}
	}

	public static int StationDroneMaxDistance
	{
		get
		{
			return AuxConfig.stationdronedist.Value;
		}
		set
		{
			AuxConfig.stationdronedist.Value = value;
		}
	}

	public static int StationShipMaxDistance
	{
		get
		{
			return AuxConfig.stationshipdist.Value;
		}
		set
		{
			AuxConfig.stationshipdist.Value = value;
		}
	}

	public static double StationWarpEnableDistance
	{
		get
		{
			return AuxConfig.stationwarpdist.Value;
		}
		set
		{
			AuxConfig.stationwarpdist.Value = value;
		}
	}

	public static float StationDroneStartCarry
	{
		get
		{
			return AuxConfig.DroneStartCarry.Value;
		}
		set
		{
			AuxConfig.DroneStartCarry.Value = value;
		}
	}

	public static float StationShipStartCarry
	{
		get
		{
			return AuxConfig.ShipStartCarry.Value;
		}
		set
		{
			AuxConfig.ShipStartCarry.Value = value;
		}
	}

	public static int StationStartWarpNumber
	{
		get
		{
			return AuxConfig.auto_supply_warp.Value;
		}
		set
		{
			AuxConfig.auto_supply_warp.Value = value;
		}
	}

	public static int VeinCollectorSpeed
	{
		get
		{
			return AuxConfig.veincollectorspeed.Value;
		}
		set
		{
			AuxConfig.veincollectorspeed.Value = value;
		}
	}

	public static int AutoSupplyCourierNumber
	{
		get
		{
			return AuxConfig.auto_supply_Courier.Value;
		}
		set
		{
			AuxConfig.auto_supply_Courier.Value = value;
		}
	}

	public static bool IsConfigEnabled(string name)
	{
		if (buildConfigsDic.TryGetValue(name, out var value))
		{
			return value.IsEnabled;
		}
		return true;
	}

	static BuildTargetValues()
	{
		buildConfigsDic = new Dictionary<string, BuildConfig>();
		buildConfigsDic = new Dictionary<string, BuildConfig>
		{
			["填充飞机数量"] = new BuildConfig
			{
				Name = "填充飞机数量",
				LowLimit = 0f,
				UpperLimit = 100f,
				IsEnabled = true
			},
			["填充飞船数量"] = new BuildConfig
			{
				Name = "填充飞船数量",
				LowLimit = 0f,
				UpperLimit = 10f,
				IsEnabled = true
			},
			["最大充电功率"] = new BuildConfig
			{
				Name = "最大充电功率",
				LowLimit = 30f,
				UpperLimit = 300f,
				IsEnabled = true
			},
			["运输机最远路程"] = new BuildConfig
			{
				Name = "运输机最远路程",
				LowLimit = 20f,
				UpperLimit = 180f,
				IsEnabled = true
			},
			["运输船最远路程"] = new BuildConfig
			{
				Name = "运输船最远路程",
				LowLimit = 1f,
				UpperLimit = 61f,
				IsEnabled = true
			},
			["曲速启用路程"] = new BuildConfig
			{
				Name = "曲速启用路程",
				LowLimit = 0.5f,
				UpperLimit = 60f,
				IsEnabled = true
			},
			["运输机起送量"] = new BuildConfig
			{
				Name = "运输机起送量",
				LowLimit = 0.01f,
				UpperLimit = 1f,
				IsEnabled = true
			},
			["运输船起送量"] = new BuildConfig
			{
				Name = "运输船起送量",
				LowLimit = 0.01f,
				UpperLimit = 1f,
				IsEnabled = true
			},
			["翘曲填充数量"] = new BuildConfig
			{
				Name = "翘曲填充数量",
				LowLimit = 0f,
				UpperLimit = 50f,
				IsEnabled = true
			},
			["大型采矿机采矿速率"] = new BuildConfig
			{
				Name = "大型采矿机采矿速率",
				LowLimit = 10f,
				UpperLimit = 30f,
				IsEnabled = true
			},
			["填充配送机数量"] = new BuildConfig
			{
				Name = "填充配送机数量",
				LowLimit = 0f,
				UpperLimit = 10f,
				IsEnabled = true
			}
		};
	}
}
