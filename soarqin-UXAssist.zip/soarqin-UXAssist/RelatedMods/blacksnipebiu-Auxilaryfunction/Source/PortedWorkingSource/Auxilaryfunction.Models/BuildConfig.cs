namespace Auxilaryfunction.Models;

public struct BuildConfig
{
	public string Name { get; set; }

	public float LowLimit { get; set; }

	public float UpperLimit { get; set; }

	public bool IsEnabled { get; set; }
}
