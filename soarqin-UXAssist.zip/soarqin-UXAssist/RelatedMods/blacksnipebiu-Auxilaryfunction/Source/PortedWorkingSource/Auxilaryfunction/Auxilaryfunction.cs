using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using Auxilaryfunction.Models;
using Auxilaryfunction.Patch;
using Auxilaryfunction.Services;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;

namespace Auxilaryfunction;

[BepInPlugin("cn.blacksnipe.dsp.Auxilaryfunction", "Auxilaryfunction", "3.0.10")]
public class Auxilaryfunction : BaseUnityPlugin
{
	private SynchronizationContext _mainContext;

	public static bool autobuildgetitem;

	public static int automovetoPrebuildSecondElapseCounter;

	public static bool autoRemoveRuin;

	public static int autoRemoveRuinId = -1;

	public static bool GameDataImported;

	public static GUIDraw guidraw;

	public static bool HideDarkFogAssaultTip;

	public static bool HideDarkFogMonitor;

	public static int maxCount = 0;

	public static Player player;

	public static List<int> readyresearch;

	public static bool StartAutoMovetoDarkfog;

	public static bool StartAutoMovetounbuilt;

	public static int[,] stationcopyItem = new int[5, 6];

	public static GameObject stationTipRoot;

	public static Light SunLight;

	public static GameObject tipPrefab;

	public static GameObject TrashCanButton;

	public static StorageComponent TrashStorage;

	public static GameObject TrashStorageWindow;

	public static UIStorageWindow uiTrashStorageWindow;

	public bool firstStart;

	public void Start()
	{
		_mainContext = SynchronizationContext.Current;
		AuxConfig.harmony = new Harmony("cn.blacksnipe.dsp.Auxilaryfunction");
		AuxConfig.harmony.PatchAll(typeof(SkipRenderPatch));
		AuxConfig.harmony.PatchAll(typeof(AuxilaryfunctionPatch));
		AuxilaryTranslate.regallTranslate();
		AuxConfig.BindAll(base.Config);
		if (AuxConfig.closeplayerflyaudio.Value)
		{
			PlayerAudioMutePatch.Enable = true;
		}
		if (AuxConfig.CloseMilestone.Value)
		{
			AuxConfig.originUnlockVolumn = LDB.audios["unlock-1"].Volume;
			LDB.audios["unlock-1"].Volume = 0f;
		}
		AuxConfig.CloseMilestone.SettingChanged += delegate
		{
			LDB.audios["unlock-1"].Volume = (AuxConfig.CloseMilestone.Value ? 0f : AuxConfig.originUnlockVolumn);
			Debug.Log(LDB.audios["unlock-1"].Volume);
		};
		AuxConfig.closeplayerflyaudio.SettingChanged += delegate
		{
			PlayerAudioMutePatch.Enable = AuxConfig.closeplayerflyaudio.Value;
		};
		if (AuxConfig.autonavigation_bool.Value)
		{
			PlayerOperationPatch.Enable = true;
		}
		AuxConfig.autonavigation_bool.SettingChanged += delegate
		{
			PlayerOperationPatch.Enable = AuxConfig.autonavigation_bool.Value;
		};
		if (AuxConfig.SunLightOpen.Value)
		{
			SunLightPatch.Enable = AuxConfig.SunLightOpen.Value;
		}
		AuxConfig.SunLightOpen.SettingChanged += delegate
		{
			SunLightPatch.Enable = AuxConfig.SunLightOpen.Value;
		};
		GUIDraw.scrollPosition[0] = 0f;
		GUIDraw.dysonBluePrintscrollPosition[0] = 0f;
		if (AuxConfig.QuickKey.Value.MainKey == KeyCode.Alpha2 && AuxConfig.QuickKey.Value.Modifiers.Count() == 1 && AuxConfig.QuickKey.Value.Modifiers.ElementAt(0) == KeyCode.LeftAlt)
		{
			AuxConfig.QuickKey.Value = new KeyboardShortcut(KeyCode.LeftAlt, KeyCode.Alpha2);
		}
		readyresearch = new List<int>();
		GameObject original = AssetBundle.LoadFromStream(Assembly.GetExecutingAssembly().GetManifestResourceStream("Auxilaryfunction.Resources.auxilarypanel")).LoadAsset<GameObject>("AuxilaryPanel");
		GameObject panel = UnityEngine.Object.Instantiate(original, UIRoot.instance.overlayCanvas.transform);
		guidraw = new GUIDraw(Math.Max(5, Math.Min(AuxConfig.scale.Value, 35)), panel);
		DysonBluePrintDataService.LoadDysonBluePrintData();
		ThreadPool.QueueUserWorkItem(delegate
		{
			SecondEvent();
		});
	}

	private static void FindItemAndMove(int itemId, int itemCount)
	{
		if (AuxConfig.LocalPlanet == null || AuxConfig.LocalPlanet.factory == null || AuxConfig.LocalPlanet.gasItems != null || LDB.items == null || LDB.items.Select(itemId) == null)
		{
			return;
		}
		int num = player.package.grids.Length;
		int num2 = 0;
		if (player.package.grids[num - 1].count != 0)
		{
			player.package.Sort();
		}
		int num3 = num - 1;
		while (num3 >= 0 && player.package.grids[num3].count == 0)
		{
			num3--;
			num2++;
		}
		int num4 = LDB.items.Select(itemId).StackSize * num2;
		itemCount = ((num4 > itemCount) ? itemCount : num4);
		PlanetFactory factory = AuxConfig.LocalPlanet.factory;
		if (factory.transport != null && factory.transport.stationPool != null)
		{
			int num5 = 0;
			int num6 = 0;
			StationComponent[] stationPool = factory.transport.stationPool;
			foreach (StationComponent stationComponent in stationPool)
			{
				if (itemCount == 0)
				{
					break;
				}
				if (stationComponent != null && stationComponent.storage != null)
				{
					int count = itemCount;
					int itemId2 = itemId;
					stationComponent.TakeItem(ref itemId2, ref count, out var inc);
					num5 += count;
					itemCount -= count;
					num6 += inc;
				}
			}
			player.TryAddItemToPackage(itemId, num5, num6, throwTrash: false);
		}
		if (factory.factoryStorage == null || factory.factoryStorage.storagePool == null)
		{
			return;
		}
		if (factory.factoryStorage.storagePool != null)
		{
			StorageComponent[] storagePool = factory.factoryStorage.storagePool;
			foreach (StorageComponent storageComponent in storagePool)
			{
				if (itemCount == 0)
				{
					break;
				}
				if (storageComponent != null)
				{
					int inc2;
					int num7 = storageComponent.TakeItem(itemId, itemCount, out inc2);
					itemCount -= num7;
					if (num7 > 0)
					{
						player.TryAddItemToPackage(itemId, num7, inc2, throwTrash: false);
					}
				}
			}
		}
		if (factory.factoryStorage.tankPool == null)
		{
			return;
		}
		TankComponent[] tankPool = factory.factoryStorage.tankPool;
		for (int k = 0; k < tankPool.Length; k++)
		{
			TankComponent tankComponent = tankPool[k];
			if (itemCount == 0)
			{
				break;
			}
			if (tankComponent.id > 0 && tankComponent.fluidId > 0 && tankComponent.fluidCount > 0 && itemId == tankComponent.fluidId)
			{
				int num8 = ((tankComponent.fluidCount > itemCount) ? itemCount : tankComponent.fluidCount);
				int num9 = (int)((double)(tankComponent.fluidInc / tankComponent.fluidCount) + 0.5) * num8;
				factory.factoryStorage.tankPool[tankComponent.id].fluidCount -= num8;
				factory.factoryStorage.tankPool[tankComponent.id].fluidInc -= num9;
				itemCount -= num8;
				if (num8 > 0)
				{
					player.TryAddItemToPackage(itemId, num8, num9, throwTrash: false);
				}
			}
		}
	}

	private void AutoMoveToDarkfog()
	{
		autoRemoveRuinId = -1;
		if (GameMain.localPlanet == null || GameMain.mainPlayer == null || GameMain.mainPlayer.movementState != EMovementState.Fly || !StartAutoMovetoDarkfog)
		{
			return;
		}
		EnemyDFGroundSystem enemySystem = GameMain.localPlanet.factory.enemySystem;
		float num = 100000000f;
		DFGBaseComponent dFGBaseComponent = null;
		for (int i = 1; i < enemySystem.bases.cursor; i++)
		{
			if (enemySystem.bases[i] != null && enemySystem.bases[i].id == i && (autoRemoveRuin || enemySystem.CheckBaseCanRemoved(i) != 0))
			{
				Vector3 vector = GameMain.localPlanet.factory.enemyPool[enemySystem.bases[i].enemyId].pos;
				if (dFGBaseComponent == null || num > (vector - player.position).magnitude)
				{
					dFGBaseComponent = enemySystem.bases[i];
					num = (vector - player.position).magnitude;
				}
			}
		}
		if (dFGBaseComponent != null)
		{
			Vector3 targetPos = GameMain.localPlanet.factory.enemyPool[dFGBaseComponent.enemyId].pos;
			_mainContext.Post(delegate
			{
				GameMain.mainPlayer.Order(OrderNode.MoveTo(targetPos.normalized * GameMain.localPlanet.realRadius), multiple: false);
			}, null);
			if (autoRemoveRuin && enemySystem.CheckBaseCanRemoved(dFGBaseComponent.id) == 0)
			{
				autoRemoveRuinId = dFGBaseComponent.ruinId;
			}
		}
	}

	private void AutoMovetounbuilt()
	{
		if (!StartAutoMovetounbuilt || GameMain.localPlanet == null || GameMain.mainPlayer == null || GameMain.mainPlayer.movementState != EMovementState.Fly)
		{
			return;
		}
		automovetoPrebuildSecondElapseCounter++;
		if ((float)automovetoPrebuildSecondElapseCounter < AuxConfig.automovetoPrebuildSecondElapse.Value)
		{
			return;
		}
		automovetoPrebuildSecondElapseCounter -= (int)AuxConfig.automovetoPrebuildSecondElapse.Value;
		float num = 3000f;
		int lasthasitempd = -1;
		PrebuildData[] prebuildPool = GameMain.localPlanet.factory.prebuildPool;
		for (int i = 0; i < prebuildPool.Length; i++)
		{
			PrebuildData prebuildData = prebuildPool[i];
			if (prebuildData.id != 0 && prebuildData.itemRequired <= 0 && (lasthasitempd == -1 || num > (prebuildData.pos - GameMain.mainPlayer.position).magnitude))
			{
				lasthasitempd = prebuildData.id;
				num = (prebuildData.pos - GameMain.mainPlayer.position).magnitude;
			}
		}
		if (lasthasitempd == -1)
		{
			bool flag = true;
			PrebuildData[] prebuildPool2 = GameMain.localPlanet.factory.prebuildPool;
			for (int j = 0; j < prebuildPool2.Length; j++)
			{
				PrebuildData prebuildData2 = prebuildPool2[j];
				if (prebuildData2.id != 0 && prebuildData2.protoId != 0 && NativeInventory.HasItem(GameMain.mainPlayer, prebuildData2.protoId))
				{
					lasthasitempd = prebuildData2.id;
					flag = false;
					_mainContext.Post(delegate
					{
						GameMain.mainPlayer.Order(OrderNode.MoveTo(GameMain.localPlanet.factory.prebuildPool[lasthasitempd].pos.normalized * GameMain.localPlanet.realRadius), multiple: false);
					}, null);
					break;
				}
			}
			if (!flag || !autobuildgetitem)
			{
				return;
			}
			int[] warningCounts = GameMain.data.warningSystem.warningCounts;
			WarningData[] warningPool = GameMain.data.warningSystem.warningPool;
			List<int> list = new List<int>();
			int num2 = 0;
			int num3 = player.package.grids.Length;
			int num4 = num3 - 1;
			while (num4 >= 0 && player.package.grids[num4].count == 0)
			{
				num4--;
				num2++;
			}
			for (int num5 = 1; num5 < GameMain.data.warningSystem.warningCursor; num5++)
			{
				if (num2 <= 0)
				{
					break;
				}
				if (!list.Contains(warningPool[num5].detailId1))
				{
					if (NativeInventory.HasItem(player, warningPool[num5].detailId1))
					{
						break;
					}
					list.Add(warningPool[num5].detailId1);
					FindItemAndMove(warningPool[num5].detailId1, warningCounts[warningPool[num5].signalId]);
				}
			}
		}
		else if (lasthasitempd != -1 && lasthasitempd != 0 && lasthasitempd == GameMain.localPlanet.factory.prebuildPool[lasthasitempd].id)
		{
			_mainContext.Post(delegate
			{
				GameMain.mainPlayer.Order(OrderNode.MoveTo(GameMain.localPlanet.factory.prebuildPool[lasthasitempd].pos.normalized * GameMain.localPlanet.realRadius), multiple: false);
			}, null);
		}
	}

	private void AutoSaveTimeChange()
	{
		if (AuxConfig.autosavetimechange.Value && UIAutoSave.autoSaveTime != (float)AuxConfig.autosavetime.Value)
		{
			Debug.Log("AutoSaveTimeChange");
			DSPGame.globalOption.autoSaveTime = AuxConfig.autosavetime.Value;
			DSPGame.globalOption.Apply();
			UIAutoSave.autoSaveTime = AuxConfig.autosavetime.Value;
		}
	}

	private void BluePrintoptimize()
	{
		GUIDraw.blueprintopen = false;
		if (player?.controller?.actionBuild == null)
		{
			return;
		}
		PlayerAction_Build actionBuild = player.controller.actionBuild;
		if (actionBuild.blueprintCopyTool != null && actionBuild.blueprintCopyTool.active && actionBuild.blueprintCopyTool.bpPool != null)
		{
			GUIDraw.blueprintopen = true;
			BuildTool_BlueprintCopy blueprintCopyTool = actionBuild.blueprintCopyTool;
			if (AuxConfig.BluePrintSelectAll.Value && Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.A))
			{
				EntityData[] entityPool = AuxConfig.LocalPlanet.factory.entityPool;
				for (int i = 0; i < entityPool.Length; i++)
				{
					EntityData entityData = entityPool[i];
					if (entityData.id != 0)
					{
						blueprintCopyTool.preSelectObjIds.Add(entityData.id);
						blueprintCopyTool.selectedObjIds.Add(entityData.id);
					}
				}
				blueprintCopyTool.RefreshBlueprintData();
				blueprintCopyTool.DeterminePreviews();
			}
			if (AuxConfig.BluePrintDelete.Value && Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.X))
			{
				BuildPreview[] bpPool = blueprintCopyTool.bpPool;
				foreach (BuildPreview buildPreview in bpPool)
				{
					if (buildPreview == null || buildPreview.item == null || buildPreview.objId <= 0)
					{
						continue;
					}
					int stationId = AuxConfig.LocalPlanet.factory.entityPool[buildPreview.objId].stationId;
					if (stationId > 0)
					{
						StationComponent stationComponent = AuxConfig.LocalPlanet.factory.transport.stationPool[stationId];
						for (int k = 0; k < stationComponent.storage.Length; k++)
						{
							int upCount = player.TryAddItemToPackage(stationComponent.storage[k].itemId, stationComponent.storage[k].count, 0, throwTrash: true, buildPreview.objId);
							UIItemup.Up(stationComponent.storage[k].itemId, upCount);
						}
						stationComponent.storage = new StationStore[stationComponent.storage.Length];
						stationComponent.needs = new int[stationComponent.needs.Length];
					}
					actionBuild.DoDismantleObject(buildPreview.objId);
				}
				blueprintCopyTool.ClearSelection();
				blueprintCopyTool.ClearPreSelection();
				blueprintCopyTool.ResetBlueprint();
				blueprintCopyTool.ResetBuildPreviews();
				blueprintCopyTool.RefreshBlueprintData();
			}
		}
		if (actionBuild.blueprintPasteTool != null && actionBuild.blueprintPasteTool.active && actionBuild.blueprintPasteTool.bpPool != null)
		{
			BuildTool_BlueprintPaste blueprintPasteTool = actionBuild.blueprintPasteTool;
			if (Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.Z))
			{
				blueprintPasteTool.ResetBuildPreviews();
				blueprintPasteTool.ResetStatesOnClose();
				blueprintPasteTool.RefreshBlueprintUI();
				player.controller.OpenBlueprintCopyMode();
			}
		}
	}

	private void EnqueueTech()
	{
		try
		{
			int num = 0;
			while (num < readyresearch.Count && GameMain.history.techQueueLength < 7)
			{
				int techId = readyresearch[num];
				if (GameMain.history.TechUnlocked(techId))
				{
					readyresearch.RemoveAt(num);
					continue;
				}
				if (GameMain.history.TechInQueue(techId))
				{
					num++;
					continue;
				}
				if (!GameMain.history.CanEnqueueTech(techId))
				{
					readyresearch.RemoveAt(num);
					continue;
				}
				GameMain.history.EnqueueTech(techId);
				num++;
			}
		}
		catch
		{
		}
	}

	private void GameUpdate()
	{
		if (!GameDataImported)
		{
			player = null;
			firstStart = true;
			readyresearch.Clear();
			SpeedUpPatch.SpeedMultiple = 1f;
			GUIDraw.blueprintopen = false;
			AuxConfig.simulatorrender = false;
			PlayerOperationPatch.FlyStatus = false;
			PlayerOperationPatch.Enable = false;
			return;
		}
		if (GameMain.mainPlayer != null && player == null)
		{
			player = GameMain.mainPlayer;
			player.controller.actionInspect.onInspecteeChange += delegate(EObjectType _, int b)
			{
				if (b > 0)
				{
					guidraw.CloseTrashStorageWindow();
				}
			};
			if (AuxConfig.autonavigation_bool.Value)
			{
				PlayerOperationPatch.Enable = true;
			}
		}
		if (firstStart)
		{
			firstStart = false;
			PlayerOperationPatch.ClearFollow();
			BluePrintBatchModifyBuild.Init();
			return;
		}
		StartAndStopGame();
		BluePrintoptimize();
		SunLightSet();
		if (autoRemoveRuin && autoRemoveRuinId >= 0 && player?.controller?.actionBuild?.reformTool != null)
		{
			player.controller.actionBuild.reformTool.RemoveBasePit(autoRemoveRuinId);
		}
		autoRemoveRuinId = -1;
	}

	private void OnGUI()
	{
		guidraw.Draw();
	}

	private void SecondEvent()
	{
		int num = 0;
		while (true)
		{
			if (!GameDataImported)
			{
				Thread.Sleep(500);
				continue;
			}
			int value = AuxConfig.auto_add_techid.Value;
			if (AuxConfig.autoaddtech_bool.Value && value > 0 && GameMain.history != null && GameMain.history.techQueueLength == 0)
			{
				TechState techState = GameMain.history.techStates[value];
				if (techState.curLevel == techState.maxLevel)
				{
					value = 0;
					AuxConfig.auto_add_techid.Value = 0;
				}
				else if (techState.curLevel < AuxConfig.auto_add_techmaxLevel.Value)
				{
					if (guidraw.AutoUnlockTechInSandBox)
					{
						GameMain.history.UnlockTechUnlimited(value, unlockedDirect: true);
					}
					else
					{
						GameMain.history.EnqueueTech(value);
					}
				}
			}
			if (AuxConfig.automovetounbuilt.Value)
			{
				try
				{
					AutoMovetounbuilt();
				}
				catch (Exception ex)
				{
					UIMessageBox.Show(AuxConfig.ErrorTitle.getTranslate(), ex.ToString(), "确定".Translate(), 3, null);
				}
			}
			if (AuxConfig.automovetodarkfog.Value)
			{
				try
				{
					AutoMoveToDarkfog();
				}
				catch (Exception ex2)
				{
					Console.WriteLine(ex2.ToString());
				}
			}
			if (num >= 30)
			{
				try
				{
					TrashFunction();
				}
				catch
				{
				}
				num = 0;
			}
			num++;
			EnqueueTech();
			Thread.Sleep(1000);
		}
	}

	private void StartAndStopGame()
	{
		if (AuxConfig.Quickstop_bool.Value && Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.Space))
		{
			GameTickPatch.Enable = !GameTickPatch.Enable;
		}
	}

	private void SunLightSet()
	{
		if (!AuxConfig.SunLightOpen.Value || GameMain.localPlanet == null || GameMain.universeSimulator?.LocalStarSimulator()?.sunLight == null)
		{
			if (SunLight != null)
			{
				UnityEngine.Object.Destroy(SunLight.gameObject);
				SunLight = null;
			}
			return;
		}
		if (SunLight == null)
		{
			SunLight = UnityEngine.Object.Instantiate(GameMain.universeSimulator.LocalStarSimulator().sunLight, GameMain.mainPlayer.transform);
			SunLight.enabled = true;
			SunLight.transform.position = GameMain.mainPlayer.position + GameMain.mainPlayer.transform.up * 5f;
			SunLight.transform.rotation = Quaternion.LookRotation(-GameMain.mainPlayer.transform.up);
			SunLight.transform.localPosition = new Vector3(0f, 5f, 0f);
			SunLight.name = "PlayerLight";
			SunLight.intensity = 1f;
		}
		if (FactoryModel.whiteMode0)
		{
			SunLight.enabled = false;
		}
		else
		{
			SunLight.enabled = true;
		}
	}

	private void TrashFunction()
	{
		if (GameMain.data?.trashSystem == null)
		{
			return;
		}
		if (AuxConfig.autoabsorttrash_bool.Value)
		{
			TrashContainer container = GameMain.data.trashSystem.container;
			for (int i = 0; i < container.trashCursor; i++)
			{
				int item = container.trashObjPool[i].item;
				if (item > 0 && container.trashObjPool[i].expire < 0)
				{
					if (AuxConfig.onlygetbuildings.Value && !(LDB.items.Select(item)?.CanBuild ?? false))
					{
						container.RemoveTrash(i);
					}
					else
					{
						container.trashObjPool[i].expire = 35;
					}
				}
			}
		}
		if (AuxConfig.autocleartrash_bool.Value)
		{
			GameMain.data.trashSystem.ClearAllTrash();
		}
	}

	private void Update()
	{
		AutoSaveTimeChange();
		GameUpdate();
		HotkeyService.HandleQuickKeyChange();
		guidraw.GUIUpdate();
	}
}
