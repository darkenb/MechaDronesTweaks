namespace Auxilaryfunction;

public static class GameIds
{
	public const int Drone = 5001;

	public const int Vessel = 5002;

	public const int Courier = 5003;

	public const int Warper = 1210;

	public const int StarFuelA = 1803;

	public const int StarFuelB = 1804;

	public const int LogisticsStation = 2103;

	public const int InterstellarLogisticsStation = 2104;

	public const int OrbitalCollector = 2105;

	public const int LogisticsDispenser = 2107;

	public const int RayReceiver = 2208;

	public const int EnergyExchanger = 2209;

	public const int ArtificialStar = 2210;
}
