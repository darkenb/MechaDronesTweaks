namespace Auxilaryfunction;

public static class GameUi
{
	public const string SceneUIs = "UI Root/Overlay Canvas/In Game/Scene UIs";

	public const string VeinMarks = "UI Root/Overlay Canvas/In Game/Scene UIs/Vein Marks";

	public const string VeinTipPrefab = "UI Root/Overlay Canvas/In Game/Scene UIs/Vein Marks/vein-tips/vein-tip-prefab";

	public const string KeyTipPrefab = "UI Root/Overlay Canvas/In Game/Windows/Key Tips/tip-prefab";

	public const string EntityBriefIcon = "UI Root/Overlay Canvas/In Game/Top Tips/Entity Briefs/brief-info-top/brief-info/content/icons/icon";

	public const string GameMenuButton1Bg = "UI Root/Overlay Canvas/In Game/Game Menu/button-1-bg";

	public const string PlayerInventory = "UI Root/Overlay Canvas/In Game/Windows/Player Inventory";

	public const string StorageWindow = "UI Root/Overlay Canvas/In Game/Windows/Storage Window";

	public const string InfoText = "info-text";

	public const string Icon = "icon";

	public const string CountText = "countText";

	public const string CountText2 = "countText2";

	public const string IconLocal = "iconLocal";

	public const string IconRemote = "iconremote";

	public const string IconText = "icontext";

	public const string ShadowCountText = "count-text";

	public const string Bg = "bg";

	public const string Inc = "inc";

	public const string Button1Icon = "button-1/icon";

	public const string DragTrigger = "panel-bg/drag-trigger";

	public const string FilterGroup = "filter-group";

	public const string BansBar = "bans-bar";

	public const string SortBtn = "panel-bg/btn-box/sort-btn";

	public const string CloseWndBtn = "panel-bg/btn-box/close-wnd-btn";
}
