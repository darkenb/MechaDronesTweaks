namespace Auxilaryfunction;

internal class NumberTranslate
{
	public static string DistanceTranslate(double distance)
	{
		if (distance < 1599.5)
		{
			return distance.ToString("0") + " m";
		}
		if (distance < 2400000.0)
		{
			return (distance / 40000.0).ToString("0.00") + " AU";
		}
		return (distance / 2400000.0).ToString("0.00") + " " + "光年".Translate();
	}
}
