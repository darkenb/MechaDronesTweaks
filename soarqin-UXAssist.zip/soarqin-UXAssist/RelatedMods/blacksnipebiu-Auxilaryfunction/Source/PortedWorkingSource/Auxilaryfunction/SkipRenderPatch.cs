using HarmonyLib;

namespace Auxilaryfunction;

public class SkipRenderPatch
{
	[HarmonyPrefix]
	[HarmonyPatch(typeof(FactoryModel), "Update")]
	public static bool FactoryModelUpdatePatch()
	{
		return !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(FactoryModel), "LateUpdate")]
	public static bool FactoryModelLateUpdatePatch()
	{
		return !AuxConfig.norender_entity_bool.Value && !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(LogisticDroneRenderer), "Draw")]
	public static bool DroneDrawPatch()
	{
		return !AuxConfig.norender_shipdrone_bool.Value && !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(LogisticShipUIRenderer), "Draw")]
	public static bool LogisticShipUIRendererDrawPatch()
	{
		return !AuxConfig.norender_shipdrone_bool.Value && !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(LogisticCourierRenderer), "Draw")]
	public static bool CourierDrawPatch()
	{
		return !AuxConfig.norender_shipdrone_bool.Value && !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(LogisticShipRenderer), "Draw")]
	public static bool ShipDrawPatch()
	{
		return !AuxConfig.norender_shipdrone_bool.Value && !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(LabRenderer), "Render")]
	public static bool LabRendererPatch(LabRenderer __instance)
	{
		if (__instance.modelId == 70 || __instance.modelId == 455)
		{
			return !AuxConfig.norender_lab_bool.Value && !AuxConfig.simulatorrender;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(SectorModel), "LateUpdate")]
	public static bool EnemyDFGroundRendererRenderPatch()
	{
		return !AuxConfig.norender_DarkFog.Value && !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DysonSphere), "DrawModel")]
	public static bool DysonDrawModelPatch()
	{
		return !AuxConfig.norender_dysonshell_bool.Value && !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DysonSphere), "DrawPost")]
	public static bool DysonDrawPostPatch()
	{
		return !AuxConfig.norender_dysonswarm_bool.Value && !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIPowerGizmo), "DrawArea")]
	public static bool UIPowerGizmoDrawAreaPatch()
	{
		return !AuxConfig.norender_powerdisk_bool.Value && !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIDarkFogMonitor), "Determine")]
	public static bool UIDarkFogMonitorDetermine()
	{
		return !Auxilaryfunction.HideDarkFogMonitor && !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIDarkFogAssaultTip), "Determine")]
	public static bool UIDarkFogAssaultTipDetermine()
	{
		return !Auxilaryfunction.HideDarkFogAssaultTip && !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(CargoContainer), "Draw")]
	public static bool PathRenderingBatchDrawPatch()
	{
		return !AuxConfig.norender_beltitem.Value && !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIPowerGizmo), "DrawCover")]
	public static bool UIPowerGizmoDrawCoverPatch()
	{
		return !AuxConfig.norender_powerdisk_bool.Value && !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UniverseSimulator), "GameTick")]
	public static void UniverseSimulatorGameTickPatch(UniverseSimulator __instance)
	{
		if (!AuxConfig.simulatorchanging)
		{
			return;
		}
		int num = 0;
		__instance.backgroundStars.gameObject.SetActive(!AuxConfig.simulatorrender);
		while (__instance.planetSimulators != null && num < __instance.planetSimulators.Length)
		{
			if (__instance.planetSimulators[num] != null)
			{
				__instance.planetSimulators[num].gameObject.SetActive(!AuxConfig.simulatorrender);
			}
			num++;
		}
		num = 0;
		while (__instance.starSimulators != null && num < __instance.starSimulators.Length)
		{
			if (__instance.starSimulators[num] != null)
			{
				if (__instance.starSimulators[num].starData.type == EStarType.NeutronStar && Configs.builtin.neutronStarPrefab.streamRenderer != null)
				{
					num++;
					continue;
				}
				__instance.starSimulators[num].gameObject.SetActive(!AuxConfig.simulatorrender);
			}
			num++;
		}
		AuxConfig.simulatorchanging = false;
	}
}
