using Auxilaryfunction.Patch;
using BepInEx.Configuration;
using UnityEngine;

namespace Auxilaryfunction.Services;

public static class HotkeyService
{
	public static void HandleQuickKeyChange()
	{
		if (AuxConfig.upsquickset.Value && Input.GetKey(KeyCode.LeftShift))
		{
			if (Input.GetKey(KeyCode.KeypadPlus))
			{
				SpeedUpPatch.SpeedMultiple += 0.01f;
			}
			if (Input.GetKey(KeyCode.KeypadMinus))
			{
				SpeedUpPatch.SpeedMultiple -= 0.01f;
			}
			if ((double)SpeedUpPatch.SpeedMultiple < 0.01)
			{
				SpeedUpPatch.SpeedMultiple = 0.01f;
			}
			else if (SpeedUpPatch.SpeedMultiple > 10f)
			{
				SpeedUpPatch.SpeedMultiple = 10f;
			}
		}
		if (AuxConfig.ChangingQuickKey)
		{
			AuxConfig.ChangeBluePrintQuickKey = false;
			AuxConfig.ChangingBluePrintQuickKey = false;
		}
		else if (AuxConfig.ChangingBluePrintQuickKey)
		{
			AuxConfig.ChangeQuickKey = false;
			AuxConfig.ChangingQuickKey = false;
		}
		if (AuxConfig.ChangeQuickKey && !AuxConfig.ChangingBluePrintQuickKey)
		{
			SetMainQuickKey();
			AuxConfig.ChangingQuickKey = true;
		}
		else if (!AuxConfig.ChangeQuickKey && AuxConfig.ChangingQuickKey)
		{
			AuxConfig.QuickKey.Value = AuxConfig.tempShowWindow;
			AuxConfig.ChangingQuickKey = false;
		}
		if (AuxConfig.ChangeBluePrintQuickKey && !AuxConfig.ChangingQuickKey)
		{
			SetBluePrintQuickKey();
			AuxConfig.ChangingBluePrintQuickKey = true;
		}
		else if (!AuxConfig.ChangeBluePrintQuickKey && AuxConfig.ChangingBluePrintQuickKey)
		{
			AuxConfig.BluePrintShowWindow.Value = AuxConfig.tempBluePrintShowWindow;
			AuxConfig.ChangingBluePrintQuickKey = false;
		}
	}

	public static void SetBluePrintQuickKey()
	{
		if (TryBuildShortcutFromPressedKeys(out var shortcut))
		{
			AuxConfig.tempBluePrintShowWindow = shortcut;
		}
	}

	public static void SetMainQuickKey()
	{
		if (TryBuildShortcutFromPressedKeys(out var shortcut))
		{
			AuxConfig.tempShowWindow = shortcut;
		}
	}

	public static bool TryBuildShortcutFromPressedKeys(out KeyboardShortcut shortcut)
	{
		int num = 0;
		if (Input.GetKey(KeyCode.LeftShift))
		{
			num = 304;
		}
		else if (Input.GetKey(KeyCode.LeftControl))
		{
			num = 306;
		}
		else if (Input.GetKey(KeyCode.LeftAlt))
		{
			num = 308;
		}
		int num2 = 0;
		for (int i = 48; i <= 57; i++)
		{
			if (Input.GetKey((KeyCode)i))
			{
				num2 = i;
				break;
			}
		}
		if (num2 == 0)
		{
			for (int j = 97; j <= 122; j++)
			{
				if (Input.GetKey((KeyCode)j))
				{
					num2 = j;
					break;
				}
			}
		}
		if (num2 == 0)
		{
			for (int k = 282; k <= 291; k++)
			{
				if (Input.GetKey((KeyCode)k))
				{
					num2 = k;
					break;
				}
			}
		}
		if (num != 0 && num2 != 0)
		{
			shortcut = new KeyboardShortcut((KeyCode)num, (KeyCode)num2);
			return true;
		}
		if (num != 0 || num2 != 0)
		{
			KeyCode mainKey = (KeyCode)((num != 0) ? num : num2);
			shortcut = new KeyboardShortcut(mainKey);
			return true;
		}
		shortcut = AuxConfig.tempBluePrintShowWindow;
		return false;
	}
}
