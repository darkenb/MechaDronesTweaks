using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Auxilaryfunction.Services;

public class DysonBluePrintDataService
{
	public static TempDysonBlueprintData selectDysonBlueprintData = new TempDysonBlueprintData();

	public static List<TempDysonBlueprintData> tempDysonBlueprintData = new List<TempDysonBlueprintData>();

	public static void LoadDysonBluePrintData()
	{
		DysonBluePrintDataService.tempDysonBlueprintData.Clear();
		string text = new StringBuilder(GameConfig.overrideDocumentFolder).Append(GameConfig.gameName).Append("/DysonBluePrint/").ToString();
		if (!Directory.Exists(text))
		{
			Directory.CreateDirectory(text);
		}
		string[] files = Directory.GetFiles(text, "*.txt", SearchOption.AllDirectories);
		for (int i = 0; i < files.Length; i++)
		{
			try
			{
				string content = File.ReadAllText(files[i]);
				TempDysonBlueprintData tempDysonBlueprintData = new TempDysonBlueprintData
				{
					name = files[i].Substring(text.Length),
					path = files[i]
				};
				tempDysonBlueprintData.ReadDysonSphereBluePrint(content);
				if (tempDysonBlueprintData.type != EDysonBlueprintType.None)
				{
					DysonBluePrintDataService.tempDysonBlueprintData.Add(tempDysonBlueprintData);
				}
			}
			catch (Exception ex)
			{
				Debug.LogWarning("Failed to load dyson blueprint: " + files[i] + "\nError: " + ex.Message);
			}
		}
	}

	public static string ReaddataFromFile(string path)
	{
		if (selectDysonBlueprintData.path == "")
		{
			UIMessageBox.Show(AuxConfig.ErrorTitle.getTranslate(), "路径为空，请重新选择".getTranslate(), "确定".Translate(), 3, null);
			return "";
		}
		if (File.Exists(path))
		{
			try
			{
				return File.ReadAllText(path);
			}
			catch
			{
				UIMessageBox.Show(AuxConfig.ErrorTitle.getTranslate(), "文件读取失败".getTranslate(), "确定".Translate(), 3, null);
			}
		}
		UIMessageBox.Show(AuxConfig.ErrorTitle.getTranslate(), "文件不存在".getTranslate(), "确定".Translate(), 3, null);
		return "";
	}

	public static void RemoveLayerById(int Id)
	{
		DysonSphere dysonSphere = UIRoot.instance.uiGame.dysonEditor.selection.viewDysonSphere;
		if (dysonSphere == null)
		{
			return;
		}
		DysonSphereLayer layer = dysonSphere.layersIdBased[Id];
		if (layer == null)
		{
			return;
		}
		if (layer.nodeCount > 0 || layer.frameCount > 0 || layer.shellCount > 0)
		{
			UIMessageBox.Show("删除层级非空标题".Translate(), "删除层级非空描述".Translate(), "取消".Translate(), "确定".Translate(), 1, null, delegate
			{
				if (dysonSphere.layersSorted.Contains(layer))
				{
					layer?.RemoveAllStructure();
					dysonSphere.RemoveLayer(layer);
				}
			});
			VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
		}
		else
		{
			dysonSphere.RemoveLayer(layer);
		}
	}

	private static void ApplySingleLayerBlueprint(string data, DysonSphere dysonSphere, int id)
	{
		DysonBlueprintDataIOError dysonBlueprintDataIOError = new DysonBlueprintData().FromBase64String(data, EDysonBlueprintType.SingleLayer, dysonSphere, dysonSphere.layersIdBased[id]);
		if (dysonBlueprintDataIOError == DysonBlueprintDataIOError.OK)
		{
			VFAudio.Create("ui-click-1", null, Vector3.zero, play: true, 1, -1, -1L);
		}
		else if (dysonBlueprintDataIOError == DysonBlueprintDataIOError.StressExceed)
		{
			UIMessageBox.Show("戴森球蓝图纬度过高标题".Translate(), "戴森球蓝图纬度过高描述".Translate(), "确定".Translate(), 3, null);
			VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
		}
		else if (dysonBlueprintDataIOError >= DysonBlueprintDataIOError.TypeMismatchSphere)
		{
			string arg = "";
			switch (dysonBlueprintDataIOError)
			{
			case DysonBlueprintDataIOError.TypeMismatchSphere:
				arg = "戴森球".Translate();
				break;
			case DysonBlueprintDataIOError.TypeMismatchSwarm:
				arg = "戴森云".Translate();
				break;
			case DysonBlueprintDataIOError.TypeMismatchLayers:
				arg = "戴森壳".Translate();
				break;
			}
			string message = string.Format("戴森球蓝图类型不匹配描述".Translate(), arg, "戴森层级".Translate());
			UIMessageBox.Show("戴森球蓝图类型不匹配标题".Translate(), message, "确定".Translate(), 3, null);
			VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
		}
		else
		{
			UIMessageBox.Show("戴森球蓝图错误标题".Translate(), "戴森球蓝图错误描述".Translate(), "确定".Translate(), 3, null);
			VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
		}
	}

	private static void ApplyDysonLayersBlueprint(string data, DysonSphere dysonSphere)
	{
		DysonBlueprintDataIOError dysonBlueprintDataIOError = new DysonBlueprintData().FromBase64String(data, EDysonBlueprintType.Layers, dysonSphere);
		if (dysonBlueprintDataIOError == DysonBlueprintDataIOError.OK)
		{
			VFAudio.Create("ui-click-1", null, Vector3.zero, play: true, 1, -1, -1L);
		}
		else if (dysonBlueprintDataIOError == DysonBlueprintDataIOError.StressExceed)
		{
			UIMessageBox.Show("戴森球蓝图纬度过高标题".Translate(), "戴森球蓝图纬度过高描述".Translate(), "确定".Translate(), 3, null);
			VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
		}
		else if (dysonBlueprintDataIOError >= DysonBlueprintDataIOError.TypeMismatchSphere)
		{
			string arg = "";
			switch (dysonBlueprintDataIOError)
			{
			case DysonBlueprintDataIOError.TypeMismatchSingleLayer:
				arg = "戴森层级".Translate();
				break;
			case DysonBlueprintDataIOError.TypeMismatchSwarm:
				arg = "戴森云".Translate();
				break;
			}
			string message = string.Format("戴森球蓝图类型不匹配描述".Translate(), arg, "戴森壳".Translate());
			UIMessageBox.Show("戴森球蓝图类型不匹配标题".Translate(), message, "确定".Translate(), 3, null);
			VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
		}
		else
		{
			UIMessageBox.Show("戴森球蓝图错误标题".Translate(), "戴森球蓝图错误描述".Translate(), "确定".Translate(), 3, null);
			VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
		}
	}

	private static void ApplyDysonBlueprint(string data, DysonSphere dysonSphere)
	{
		DysonBlueprintDataIOError dysonBlueprintDataIOError = new DysonBlueprintData().FromBase64String(data, EDysonBlueprintType.DysonSphere, dysonSphere);
		if (dysonBlueprintDataIOError == DysonBlueprintDataIOError.OK)
		{
			VFAudio.Create("ui-click-1", null, Vector3.zero, play: true, 1, -1, -1L);
		}
		else if (dysonBlueprintDataIOError == DysonBlueprintDataIOError.StressExceed)
		{
			UIMessageBox.Show("戴森球蓝图纬度过高标题".Translate(), "戴森球蓝图纬度过高描述".Translate(), "确定".Translate(), 3, null);
			VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
		}
		else if (dysonBlueprintDataIOError >= DysonBlueprintDataIOError.TypeMismatchSphere)
		{
			string arg = "";
			switch (dysonBlueprintDataIOError)
			{
			case DysonBlueprintDataIOError.TypeMismatchSwarm:
				arg = "戴森云".Translate();
				break;
			case DysonBlueprintDataIOError.TypeMismatchLayers:
				arg = "戴森壳".Translate();
				break;
			case DysonBlueprintDataIOError.TypeMismatchSingleLayer:
				arg = "戴森层级".Translate();
				break;
			}
			string message = string.Format("戴森球蓝图类型不匹配描述".Translate(), arg, "戴森球无空格".Translate());
			UIMessageBox.Show("戴森球蓝图类型不匹配标题".Translate(), message, "确定".Translate(), 3, null);
			VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
		}
		else
		{
			UIMessageBox.Show("戴森球蓝图错误标题".Translate(), "戴森球蓝图错误描述".Translate(), "确定".Translate(), 3, null);
			VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
		}
	}

	private static void ApplySwarmBlueprint(string data, DysonSphere dysonSphere)
	{
		DysonBlueprintDataIOError dysonBlueprintDataIOError = new DysonBlueprintData().FromBase64String(data, EDysonBlueprintType.SwarmOrbits, dysonSphere);
		if (dysonBlueprintDataIOError == DysonBlueprintDataIOError.OK)
		{
			VFAudio.Create("ui-click-1", null, Vector3.zero, play: true, 1, -1, -1L);
		}
		else if (dysonBlueprintDataIOError >= DysonBlueprintDataIOError.TypeMismatchSphere)
		{
			string arg = "";
			switch (dysonBlueprintDataIOError)
			{
			case DysonBlueprintDataIOError.TypeMismatchSingleLayer:
				arg = "戴森层级".Translate();
				break;
			case DysonBlueprintDataIOError.TypeMismatchLayers:
				arg = "戴森壳".Translate();
				break;
			}
			string message = string.Format("戴森球蓝图类型不匹配描述".Translate(), arg, "戴森云".Translate());
			UIMessageBox.Show("戴森球蓝图类型不匹配标题".Translate(), message, "确定".Translate(), 3, null);
			VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
		}
		else
		{
			UIMessageBox.Show("戴森球蓝图错误标题".Translate(), "戴森球蓝图错误描述".Translate(), "确定".Translate(), 3, null);
			VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
		}
	}

	public static void ApplyDysonBlueprintManage(string data, DysonSphere dysonSphere, EDysonBlueprintType type, int id = -1)
	{
		if (data == "" || dysonSphere == null)
		{
			return;
		}
		switch (type)
		{
		case EDysonBlueprintType.SingleLayer:
			if (id == -1)
			{
				UIMessageBox.Show(AuxConfig.ErrorTitle.getTranslate(), "单层壳蓝图请选择层级".Translate(), "确定".Translate(), 3, null);
				VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
			}
			else
			{
				ApplySingleLayerBlueprint(data, dysonSphere, id);
			}
			break;
		case EDysonBlueprintType.Layers:
			UIMessageBox.Show("戴森球多层壳蓝图应用".Translate(), "确定应用多层壳蓝图吗？使用时鼠标最好不要放在戴森球上".Translate(), "取消".Translate(), "确定".Translate(), 1, null, delegate
			{
				ApplyDysonLayersBlueprint(data, dysonSphere);
			});
			break;
		case EDysonBlueprintType.SwarmOrbits:
			ApplySwarmBlueprint(data, dysonSphere);
			break;
		case EDysonBlueprintType.DysonSphere:
			ApplyDysonBlueprint(data, dysonSphere);
			break;
		}
	}
}
