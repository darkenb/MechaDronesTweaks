using System;
using HarmonyLib;
using UnityEngine;

namespace Auxilaryfunction.Patch;

public class PlayerOperationPatch
{
	private static Harmony _patch;

	private static bool enable;

	public static float t = 20f;

	public static int AuDis = 40000;

	public static bool FlyStatus;

	private static PlanetData focusPlanet;

	private static StarData focusStar;

	private static ESpaceGuideType guidetype;

	public static bool Enable
	{
		get
		{
			return enable;
		}
		set
		{
			if (enable != value)
			{
				enable = value;
				if (enable)
				{
					_patch = Harmony.CreateAndPatchAll(typeof(PlayerOperationPatch));
					return;
				}
				_patch.UnpatchSelf();
				FlyStatus = false;
				ClearFollow();
			}
		}
	}

	private static Mecha mecha => Auxilaryfunction.player.mecha;

	public static bool NeedNavigation => GameMain.mainPlayer.navigation.indicatorAstroId > 0 || GameMain.mainPlayer.navigation._indicatorMsgId > 0 || GameMain.mainPlayer.navigation._indicatorEnemyId > 0;

	private static double max_acc => Auxilaryfunction.player.controller.actionSail.max_acc;

	private static float maxSailSpeed => Auxilaryfunction.player.controller.actionSail.maxSailSpeed;

	private static float maxWarpSpeed => Auxilaryfunction.player.controller.actionSail.maxWarpSpeed;

	private static int indicatorAstroId => (Auxilaryfunction.player?.navigation?.indicatorAstroId).GetValueOrDefault();

	private static int indicatorMsgId => Auxilaryfunction.player.navigation.indicatorMsgId;

	private static int indicatorEnemyId => Auxilaryfunction.player.navigation.indicatorEnemyId;

	private static bool CanWarp => AuxConfig.LocalPlanet == null && AuxConfig.autowarpcommand.Value && !Auxilaryfunction.player.warping && mecha.coreEnergy > mecha.warpStartPowerPerSpeed * (double)maxWarpSpeed && Auxilaryfunction.player.mecha.thrusterLevel >= 3;

	public static void ClearFollow()
	{
		if (Auxilaryfunction.player?.navigation != null)
		{
			Auxilaryfunction.player.navigation.indicatorAstroId = 0;
			Auxilaryfunction.player.navigation.indicatorMsgId = 0;
			Auxilaryfunction.player.navigation.indicatorEnemyId = 0;
		}
		t = 20f;
		focusPlanet = null;
		focusStar = null;
		Debug.Log("Auxilaryfunction.ClearFollow");
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlayerController), "GetInput")]
	public static void Postfix(PlayerController __instance)
	{
		if (AuxConfig.autonavigation_bool.Value)
		{
			if (indicatorAstroId <= 1000000 && indicatorAstroId > 0)
			{
				if (indicatorAstroId % 100 != 0)
				{
					if (focusPlanet == null)
					{
						FlyStatus = true;
						focusPlanet = GameMain.galaxy.PlanetById(indicatorAstroId);
						guidetype = ESpaceGuideType.Planet;
					}
					else if (focusPlanet.id != indicatorAstroId)
					{
						FlyStatus = true;
						focusPlanet = GameMain.galaxy.PlanetById(indicatorAstroId);
						guidetype = ESpaceGuideType.Planet;
					}
				}
				else if (focusStar == null)
				{
					focusPlanet = null;
					FlyStatus = true;
					focusStar = GameMain.galaxy.StarById(indicatorAstroId / 100);
					guidetype = ESpaceGuideType.Star;
				}
				else if (focusStar.id != indicatorAstroId / 100)
				{
					FlyStatus = true;
					focusStar = GameMain.galaxy.StarById(indicatorAstroId / 100);
					guidetype = ESpaceGuideType.Star;
				}
			}
			else if (indicatorAstroId > 1000000)
			{
				if (focusPlanet != null || focusStar != null)
				{
					focusStar = null;
					focusPlanet = null;
				}
			}
			else if (indicatorAstroId == 0 && (focusPlanet != null || focusStar != null))
			{
				ClearFollow();
			}
		}
		if (!AuxConfig.autonavigation_bool.Value || !FlyStatus || !NeedNavigation)
		{
			return;
		}
		if (indicatorAstroId <= 1000000 && indicatorAstroId == AuxConfig.LocalPlanet?.id)
		{
			FlyStatus = false;
			return;
		}
		if (indicatorAstroId > 1000000 && !AuxConfig.AutoNavigateToDarkFogHive.Value)
		{
			FlyStatus = false;
			return;
		}
		if (!Auxilaryfunction.player.sailing)
		{
			FlyAwayPlanet();
			return;
		}
		VectorLF3 upos;
		if (focusPlanet != null)
		{
			upos = focusPlanet.uPosition;
		}
		else if (focusStar != null)
		{
			upos = focusStar.uPosition;
		}
		else if (indicatorAstroId > 1000000)
		{
			upos = GameMain.data.spaceSector.astros[indicatorAstroId - 1000000].uPos;
			guidetype = ESpaceGuideType.DFHive;
		}
		else if (indicatorEnemyId != 0)
		{
			ref EnemyData reference = ref GameMain.data.spaceSector.enemyPool[indicatorEnemyId];
			GameMain.data.spaceSector.TransformFromAstro_ref(reference.astroId, out upos, ref reference.pos);
			guidetype = ESpaceGuideType.DFCarrier;
		}
		else
		{
			if (indicatorMsgId == 0)
			{
				return;
			}
			if (indicatorMsgId > CosmicMessageProto.maxProtoId)
			{
				guidetype = ESpaceGuideType.DFCommunicator;
			}
			else
			{
				guidetype = ESpaceGuideType.CosmicMessage;
			}
			upos = GameMain.gameScenario.cosmicMessageManager.messages[Auxilaryfunction.player.navigation.indicatorMsgId].uPosition;
		}
		double magnitude = (Auxilaryfunction.player.uPosition - upos).magnitude;
		bool flag = magnitude > (double)(AuxConfig.autowarpdistance.Value * 2400000f) && CanWarp && mecha.coreEnergy * 100.0 / mecha.coreEnergyCap >= (double)AuxConfig.autowarpdistanceEnergyPercent.Value;
		bool flag2 = false;
		if (magnitude < 8000.0)
		{
			flag2 = true;
		}
		else if (magnitude < 100000.0 && guidetype == ESpaceGuideType.Star)
		{
			flag2 = true;
		}
		else if (magnitude < (double)(AuxConfig.AutoNavigateToDarkFogHiveKeepDistance.Value * 100 + 1000) && guidetype == ESpaceGuideType.DFHive)
		{
			flag2 = true;
		}
		if (Auxilaryfunction.player.warping && __instance.actionSail.currentWarpSpeed > 15000.0 && magnitude < (double)(AuDis * 70))
		{
			if (magnitude > (double)(AuDis * 26))
			{
				if (__instance.actionSail.currentWarpSpeed > (double)(AuDis * 120))
				{
					__instance.actionSail.warpSpeedControl -= 0.008;
				}
			}
			else if (magnitude > (double)(AuDis * 20))
			{
				if (__instance.actionSail.currentWarpSpeed > (double)(AuDis * 80))
				{
					__instance.actionSail.warpSpeedControl -= 0.008;
				}
			}
			else if (magnitude > (double)(AuDis * 15))
			{
				if (__instance.actionSail.currentWarpSpeed > (double)(AuDis * 40))
				{
					__instance.actionSail.warpSpeedControl -= 0.008;
				}
				if (__instance.actionSail.currentWarpSpeed > (double)(AuDis * 80))
				{
					__instance.actionSail.warpSpeedControl -= 0.016;
				}
			}
			else if (magnitude > (double)(AuDis * 6))
			{
				if (__instance.actionSail.currentWarpSpeed > (double)(AuDis * 20))
				{
					__instance.actionSail.warpSpeedControl -= 0.008;
				}
				if (__instance.actionSail.currentWarpSpeed > (double)(AuDis * 40))
				{
					__instance.actionSail.warpSpeedControl -= 0.016;
				}
			}
			else if (magnitude > (double)AuDis)
			{
				if (__instance.actionSail.currentWarpSpeed > (double)AuDis)
				{
					__instance.actionSail.warpSpeedControl -= 0.008;
				}
				if (__instance.actionSail.currentWarpSpeed > (double)(AuDis * 20))
				{
					__instance.actionSail.warpSpeedControl -= 0.016;
				}
			}
		}
		if (guidetype == ESpaceGuideType.DFHive)
		{
			Vector3 lpos = default(Vector3);
			GameMain.spaceSector.astros[indicatorAstroId - 1000000].VelocityU(ref lpos, out var uvel);
			FollowTaget(upos, uvel, targetIsStatic: false, isOrbit: true);
		}
		else if (magnitude > 100000.0)
		{
			FlyTo(upos);
		}
		else if (magnitude > 5000.0)
		{
			if (guidetype == ESpaceGuideType.Star)
			{
				FlyStatus = false;
			}
			FlyTo(upos);
		}
		else if (indicatorEnemyId != 0)
		{
			FollowTaget(upos, GameMain.data.spaceSector.enemyPool[indicatorEnemyId].vel, targetIsStatic: false);
		}
		else if (focusPlanet != null)
		{
			float radius = focusPlanet.radius;
			bool factoryLoaded = focusPlanet.factoryLoaded;
			if (magnitude < (double)(radius + 500f) && factoryLoaded)
			{
				FlyStatus = false;
			}
			else if (magnitude < (double)(radius + 1000f) && !factoryLoaded)
			{
				VectorLF3 normalized = (upos - Auxilaryfunction.player.uPosition).normalized;
				if (Vector3.Angle(Auxilaryfunction.player.uVelocity.normalized, normalized) < 10f)
				{
					Auxilaryfunction.player.uVelocity = normalized * (magnitude - (double)radius);
				}
				else if (Auxilaryfunction.player.uVelocity.magnitude < 1000.0)
				{
					Auxilaryfunction.player.uVelocity += normalized * max_acc;
					__instance.actionSail.UseSailEnergy(max_acc);
				}
			}
			else
			{
				FlyTo(upos);
			}
		}
		else if (guidetype == ESpaceGuideType.DFCommunicator)
		{
			FollowTaget(upos, default(VectorLF3), targetIsStatic: true);
		}
		if (Auxilaryfunction.player.warpCommand && flag2)
		{
			Auxilaryfunction.player.warpCommand = false;
		}
		if (flag && !flag2 && magnitude > 10000.0 && mecha.UseWarper())
		{
			Auxilaryfunction.player.warpCommand = true;
			Console.WriteLine("翘曲启动");
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PlayerControlGizmo), "AddOrderGizmo")]
	public static bool DisableAddOrderGizmo()
	{
		if (Auxilaryfunction.StartAutoMovetounbuilt)
		{
			return false;
		}
		return true;
	}

	private static void FollowTaget(VectorLF3 target, VectorLF3 targetVel, bool targetIsStatic, bool isOrbit = false)
	{
		double magnitude = (Auxilaryfunction.player.uPosition - target).magnitude;
		if (targetIsStatic)
		{
			VectorLF3 normalized = (target - Auxilaryfunction.player.uPosition).normalized;
			double magnitude2 = Auxilaryfunction.player.uVelocity.magnitude;
			VectorLF3 normalized2 = Auxilaryfunction.player.uVelocity.normalized;
			float num = Vector3.Dot(Auxilaryfunction.player.uVelocity, normalized);
			VectorLF3 vectorLF = ((magnitude < 300.0 || num < 0f) ? normalized2 : normalized);
			int num2 = ((num >= 0f) ? 1 : (-1));
			if (magnitude > 6000.0)
			{
				FlyTo(target);
			}
			else if (magnitude > 3000.0)
			{
				double num3 = (double)(1000 * num2) - magnitude2;
				double num4 = Math.Min(Math.Abs(num3), 10.0);
				num4 = ((num3 > 0.0) ? num4 : (0.0 - num4));
				Auxilaryfunction.player.uVelocity += vectorLF * num4;
				Auxilaryfunction.player.controller.actionSail.UseSailEnergy(num4);
			}
			else if (magnitude > 1500.0)
			{
				double num5 = (double)(300 * num2) - magnitude2;
				double num6 = Math.Min(Math.Abs(num5), 10.0);
				num6 = ((num5 > 0.0) ? num6 : (0.0 - num6));
				Auxilaryfunction.player.uVelocity += vectorLF * num6;
				Auxilaryfunction.player.controller.actionSail.UseSailEnergy(num6);
			}
			else if (magnitude > 300.0)
			{
				double num7 = (double)(200 * num2) - magnitude2;
				double num8 = Math.Min(Math.Abs(num7), 5.0);
				num8 = ((num7 > 0.0) ? num8 : (0.0 - num8));
				Auxilaryfunction.player.uVelocity += vectorLF * num8;
				Auxilaryfunction.player.controller.actionSail.UseSailEnergy(num8);
			}
			else if (magnitude > 5.0)
			{
				double num9 = magnitude * (double)num2 - magnitude2;
				double num10 = Math.Min(Math.Abs(num9), 5.0);
				num10 = ((num9 > 0.0) ? num10 : (0.0 - num10));
				Auxilaryfunction.player.uVelocity += vectorLF * num10;
				Auxilaryfunction.player.controller.actionSail.UseSailEnergy(num10);
			}
			Auxilaryfunction.player.uVelocity = vectorLF * Auxilaryfunction.player.uVelocity.magnitude;
			return;
		}
		if (!isOrbit)
		{
			VectorLF3 normalized3 = targetVel.normalized;
			VectorLF3 normalized4 = (target - Auxilaryfunction.player.uPosition).normalized;
			float num11 = Vector3.Dot(normalized3, normalized4);
			VectorLF3 vectorLF2 = ((magnitude < 300.0 || num11 < 0f) ? normalized3 : normalized4);
			int num12 = ((num11 >= 0f) ? 1 : (-1));
			double magnitude3 = targetVel.magnitude;
			double magnitude4 = Auxilaryfunction.player.uVelocity.magnitude;
			if (magnitude > 5000.0)
			{
				FlyTo(target);
			}
			else if (magnitude > 2000.0)
			{
				double num13 = magnitude3 - magnitude4 + (double)(800 * num12);
				double num14 = Math.Min(Math.Abs(num13), 5.0);
				num14 = ((num13 > 0.0) ? num14 : (0.0 - num14));
				Auxilaryfunction.player.uVelocity += vectorLF2 * num14;
				Auxilaryfunction.player.controller.actionSail.UseSailEnergy(num14);
			}
			else if (magnitude > 800.0)
			{
				double num15 = magnitude3 - magnitude4 + (double)(500 * num12);
				double num16 = Math.Min(Math.Abs(num15), 5.0);
				num16 = ((num15 > 0.0) ? num16 : (0.0 - num16));
				Auxilaryfunction.player.uVelocity += vectorLF2 * num16;
				Auxilaryfunction.player.controller.actionSail.UseSailEnergy(num16);
			}
			else if (magnitude > 400.0)
			{
				double num17 = magnitude3 - magnitude4 + (double)(300 * num12);
				double num18 = Math.Min(Math.Abs(num17), 5.0);
				num18 = ((num17 > 0.0) ? num18 : (0.0 - num18));
				Auxilaryfunction.player.uVelocity += vectorLF2 * num18;
				Auxilaryfunction.player.controller.actionSail.UseSailEnergy(num18);
			}
			else if (magnitude > 200.0)
			{
				double num19 = magnitude3 - magnitude4 + (double)(50 * num12);
				double num20 = Math.Min(Math.Abs(num19), 5.0);
				num20 = ((num19 > 0.0) ? num20 : (0.0 - num20));
				Auxilaryfunction.player.uVelocity += vectorLF2 * num20;
				Auxilaryfunction.player.controller.actionSail.UseSailEnergy(num20);
			}
			else
			{
				double num21 = magnitude3 - magnitude4;
				double num22 = Math.Min(Math.Abs(num21), 1.0);
				num22 = ((num21 > 0.0) ? num22 : (0.0 - num22));
				Auxilaryfunction.player.uVelocity += vectorLF2 * num22;
				Auxilaryfunction.player.controller.actionSail.UseSailEnergy(num22);
			}
			Auxilaryfunction.player.uVelocity = vectorLF2 * Auxilaryfunction.player.uVelocity.magnitude;
			return;
		}
		VectorLF3 normalized5 = targetVel.normalized;
		VectorLF3 normalized6 = (target - Auxilaryfunction.player.uPosition).normalized;
		VectorLF3 vectorLF3 = Vector3.Lerp(GameMain.mainPlayer.uVelocity.normalized, normalized5, 0.1f);
		double magnitude5 = targetVel.magnitude;
		double magnitude6 = Auxilaryfunction.player.uVelocity.magnitude;
		int num23 = AuxConfig.AutoNavigateToDarkFogHiveKeepDistance.Value * 100;
		if (magnitude > (double)(num23 + 1000))
		{
			FlyTo(target);
			return;
		}
		if (magnitude >= (double)(num23 + 200))
		{
			vectorLF3 = Vector3.Lerp(GameMain.mainPlayer.uVelocity.normalized, normalized6, 0.1f);
			if (magnitude5 >= magnitude6)
			{
				Auxilaryfunction.player.uVelocity += vectorLF3 * 3.0;
				Auxilaryfunction.player.controller.actionSail.UseSailEnergy(3.0);
			}
			else if (magnitude6 - 5.0 > magnitude5)
			{
				Auxilaryfunction.player.uVelocity -= vectorLF3 * 3.0;
				Auxilaryfunction.player.controller.actionSail.UseSailEnergy(3.0);
			}
		}
		else if (magnitude > (double)(num23 - 50) && magnitude < (double)(num23 + 200))
		{
			double num24 = magnitude5 - magnitude6;
			double num25 = Math.Min(Math.Abs(num24), 3.0);
			num25 = ((num24 > 0.0) ? num25 : (0.0 - num25));
			Auxilaryfunction.player.uVelocity += Auxilaryfunction.player.uVelocity.normalized * num25;
			Auxilaryfunction.player.controller.actionSail.UseSailEnergy(num25);
		}
		else
		{
			if (!(magnitude < (double)(num23 - 50)))
			{
				return;
			}
			bool value = AuxConfig.autoAddPlayerVel.Value;
			vectorLF3 = Vector3.Lerp(GameMain.mainPlayer.uVelocity.normalized, -normalized6, 0.1f);
			if (value && magnitude6 < magnitude5 + 150.0)
			{
				Auxilaryfunction.player.uVelocity += vectorLF3 * 3.0;
				Auxilaryfunction.player.controller.actionSail.UseSailEnergy(3.0);
			}
		}
		Auxilaryfunction.player.uVelocity = vectorLF3 * Auxilaryfunction.player.uVelocity.magnitude;
	}

	private static void FlyTo(VectorLF3 uPosition)
	{
		VectorLF3 vectorLF = (uPosition - Auxilaryfunction.player.uPosition).normalized;
		bool value = AuxConfig.autoAddPlayerVel.Value;
		if (GameMain.localStar != null)
		{
			PlanetData planetData = AuxConfig.LocalPlanet;
			double num = double.MaxValue;
			if (planetData == null)
			{
				PlanetData[] planets = GameMain.localStar.planets;
				foreach (PlanetData planetData2 in planets)
				{
					if (planetData2 != null)
					{
						double magnitude = (Auxilaryfunction.player.uPosition - planetData2.uPosition).magnitude;
						if (magnitude < num)
						{
							planetData = planetData2;
							num = magnitude;
						}
					}
				}
			}
			if (planetData != null && planetData != focusPlanet && num < 2000.0)
			{
				float num2 = Vector3.Dot((Auxilaryfunction.player.uPosition - planetData.uPosition).normalized, vectorLF);
				if (num2 >= 0f)
				{
					vectorLF = (Auxilaryfunction.player.uPosition - planetData.uPosition).normalized;
				}
				else
				{
					Vector3 lhs = Vector3.Cross(vectorLF, (Auxilaryfunction.player.uPosition - planetData.uPosition).normalized);
					vectorLF = -Vector3.Cross(lhs, (Auxilaryfunction.player.uPosition - planetData.uPosition).normalized).normalized;
				}
			}
		}
		vectorLF = Vector3.Lerp(Auxilaryfunction.player.uVelocity.normalized, vectorLF, 1f);
		if (Auxilaryfunction.player.uVelocity.magnitude + 5.0 >= (double)maxSailSpeed)
		{
			Auxilaryfunction.player.uVelocity = vectorLF * maxSailSpeed;
			return;
		}
		if (value)
		{
			Auxilaryfunction.player.uVelocity += vectorLF * 5.0;
			Auxilaryfunction.player.controller.actionSail.UseSailEnergy(5.0);
		}
		Auxilaryfunction.player.uVelocity = vectorLF * Auxilaryfunction.player.uVelocity.magnitude;
	}

	private static void FlyAwayPlanet()
	{
		PlayerController controller = Auxilaryfunction.player.controller;
		controller.input0.z = 1f;
		controller.input1.y += 1f;
		if (controller.actionFly.currentAltitude > 49f && (double)controller.horzSpeed < 12.5)
		{
			controller.velocity = (Auxilaryfunction.player.uPosition - AuxConfig.LocalPlanet.uPosition).normalized * t++;
		}
	}
}
