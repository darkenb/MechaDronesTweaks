using System;
using Auxilaryfunction.Models;
using UnityEngine;

namespace Auxilaryfunction.Services;

public static class LogisticsService
{
	public static void AddCourierToAllStar()
	{
		if (AuxConfig.LocalPlanet?.factory == null || Auxilaryfunction.player == null || Auxilaryfunction.player.factory != AuxConfig.LocalPlanet.factory || !BuildTargetValues.IsConfigEnabled("填充配送机数量"))
		{
			return;
		}
		int value = AuxConfig.auto_supply_Courier.Value;
		DispenserComponent[] dispenserPool = AuxConfig.LocalPlanet.factory.transport.dispenserPool;
		foreach (DispenserComponent dispenserComponent in dispenserPool)
		{
			if (dispenserComponent != null && dispenserComponent.id > 0)
			{
				CourierData[] workCourierDatas = dispenserComponent.workCourierDatas;
				int val = ((workCourierDatas != null) ? workCourierDatas.Length : 0);
				DeliveryLogisticOrder[] orders = dispenserComponent.orders;
				int num = NativeInventory.Missing(Math.Min(val, (orders != null) ? orders.Length : 0), dispenserComponent.idleCourierCount, dispenserComponent.workCourierCount, value);
				if (num > 0)
				{
					dispenserComponent.idleCourierCount += NativeInventory.Take(Auxilaryfunction.player, 5003, num, out var _);
				}
			}
		}
	}

	public static void AddDroneShipToStation()
	{
		if (AuxConfig.LocalPlanet?.factory == null || Auxilaryfunction.player == null || Auxilaryfunction.player.factory != AuxConfig.LocalPlanet.factory || AuxConfig.LocalPlanet.type == EPlanetType.Gas)
		{
			return;
		}
		bool flag = BuildTargetValues.IsConfigEnabled("填充飞机数量");
		bool flag2 = BuildTargetValues.IsConfigEnabled("填充飞船数量");
		bool flag3 = BuildTargetValues.IsConfigEnabled("翘曲填充数量");
		int value = AuxConfig.auto_supply_ship.Value;
		int value2 = AuxConfig.auto_supply_drone.Value;
		int value3 = AuxConfig.auto_supply_warp.Value;
		StationComponent[] stationPool = AuxConfig.LocalPlanet.factory.transport.stationPool;
		foreach (StationComponent stationComponent in stationPool)
		{
			if (stationComponent == null || stationComponent.isVeinCollector)
			{
				continue;
			}
			int inc;
			if (flag)
			{
				DroneData[] workDroneDatas = stationComponent.workDroneDatas;
				int num = ((workDroneDatas != null) ? workDroneDatas.Length : 0);
				int target = ((value2 > num) ? num : value2);
				int num2 = NativeInventory.Missing(num, stationComponent.idleDroneCount, stationComponent.workDroneCount, target);
				if (num2 > 0)
				{
					stationComponent.idleDroneCount += NativeInventory.Take(Auxilaryfunction.player, 5001, num2, out inc);
				}
			}
			if (flag2)
			{
				ShipData[] workShipDatas = stationComponent.workShipDatas;
				int num3 = NativeInventory.Missing(Math.Min(64, (workShipDatas != null) ? workShipDatas.Length : 0), stationComponent.idleShipCount, stationComponent.workShipCount, value);
				if (stationComponent.isStellar && num3 > 0)
				{
					stationComponent.idleShipCount += NativeInventory.Take(Auxilaryfunction.player, 5002, num3, out inc);
				}
			}
			if (flag3)
			{
				int num4 = NativeInventory.Missing(int.MaxValue, stationComponent.warperCount, 0, value3);
				if (num4 > 0)
				{
					stationComponent.warperCount += NativeInventory.Take(Auxilaryfunction.player, 1210, num4, out inc);
				}
			}
		}
	}

	public static void AddFuelToAllStar()
	{
		if (AuxConfig.LocalPlanet?.factory != null && Auxilaryfunction.player != null && Auxilaryfunction.player.factory == AuxConfig.LocalPlanet.factory)
		{
			PlanetFactory factory = AuxConfig.LocalPlanet.factory;
			for (int i = 1; i < factory.powerSystem.genCursor; i++)
			{
				NativeInventory.FillFuel(Auxilaryfunction.player, factory, i, AuxConfig.auto_supply_starfuelID.Value, AuxConfig.auto_supply_starfuel.Value);
			}
		}
	}

	public static void ChangeAllStationConfig()
	{
		if (AuxConfig.LocalPlanet == null || AuxConfig.LocalPlanet.factory == null || AuxConfig.LocalPlanet.factory.transport == null || AuxConfig.LocalPlanet.factory.transport.stationPool == null)
		{
			return;
		}
		bool flag = BuildTargetValues.IsConfigEnabled("运输机最远路程");
		bool flag2 = BuildTargetValues.IsConfigEnabled("最大充电功率");
		bool flag3 = BuildTargetValues.IsConfigEnabled("运输机起送量");
		bool flag4 = BuildTargetValues.IsConfigEnabled("曲速启用路程");
		bool flag5 = BuildTargetValues.IsConfigEnabled("运输船起送量");
		bool flag6 = BuildTargetValues.IsConfigEnabled("运输船最远路程");
		StationComponent[] stationPool = AuxConfig.LocalPlanet.factory.transport.stationPool;
		foreach (StationComponent stationComponent in stationPool)
		{
			if (stationComponent == null || stationComponent.isVeinCollector)
			{
				continue;
			}
			if (flag)
			{
				stationComponent.tripRangeDrones = Math.Cos((double)AuxConfig.stationdronedist.Value * Math.PI / 180.0);
			}
			if (flag2)
			{
				AuxConfig.LocalPlanet.factory.powerSystem.consumerPool[stationComponent.pcId].workEnergyPerTick = (long)AuxConfig.stationmaxpowerpertick.Value * 16667;
				if (AuxConfig.stationmaxpowerpertick.Value > 60f && !stationComponent.isStellar)
				{
					AuxConfig.LocalPlanet.factory.powerSystem.consumerPool[stationComponent.pcId].workEnergyPerTick = 1000020L;
				}
			}
			if (flag3)
			{
				stationComponent.deliveryDrones = ((AuxConfig.DroneStartCarry.Value == 0f) ? 1 : ((int)(AuxConfig.DroneStartCarry.Value * 10f) * 10));
			}
			if (stationComponent.isStellar)
			{
				if (flag4)
				{
					stationComponent.warpEnableDist = AuxConfig.stationwarpdist.Value * 40000.0;
				}
				if (flag5)
				{
					stationComponent.deliveryShips = ((AuxConfig.ShipStartCarry.Value == 0f) ? 1 : ((int)(AuxConfig.ShipStartCarry.Value * 10f) * 10));
				}
				if (flag6)
				{
					stationComponent.tripRangeShips = ((AuxConfig.stationshipdist.Value > 60) ? 24000000000L : (AuxConfig.stationshipdist.Value * 2400000));
				}
			}
		}
	}

	public static void ChangeAllVeinCollectorSpeedConfig()
	{
		if (AuxConfig.LocalPlanet == null || AuxConfig.LocalPlanet.type == EPlanetType.Gas || !BuildTargetValues.IsConfigEnabled("大型采矿机采矿速率"))
		{
			return;
		}
		StationComponent[] stationPool = AuxConfig.LocalPlanet.factory.transport.stationPool;
		foreach (StationComponent stationComponent in stationPool)
		{
			if (stationComponent != null && stationComponent.isVeinCollector)
			{
				AuxConfig.LocalPlanet.factory.factorySystem.minerPool[stationComponent.minerId].speed = AuxConfig.veincollectorspeed.Value * 1000;
			}
		}
	}

	public static void SetGasStation()
	{
		if (AuxConfig.LocalPlanet == null || AuxConfig.LocalPlanet.type != EPlanetType.Gas)
		{
			return;
		}
		PlanetFactory factory = AuxConfig.LocalPlanet.factory;
		int i;
		if (factory != null)
		{
			StationComponent[] stationPool = factory.transport.stationPool;
			for (i = 0; i < stationPool.Length; i++)
			{
				StationComponent stationComponent = stationPool[i];
				if (stationComponent != null && stationComponent.isCollector)
				{
					UIMessageBox.Show("铺满轨道采集器失败", "当前星球存在采集器，请先清空所有建筑", "确定", 3);
					return;
				}
			}
			if (factory.prebuildCount > 0)
			{
				UIMessageBox.Show("铺满轨道采集器失败", "当前星球存在采集器，请先清空所有建筑", "确定", 3);
				return;
			}
		}
		StorageComponent package = Auxilaryfunction.player.package;
		int num = 0;
		for (int j = 0; j < package.size; j++)
		{
			if (package.grids[j].itemId == 2105)
			{
				num += package.grids[j].count;
				if (num >= 40)
				{
					break;
				}
			}
		}
		if (num >= 40)
		{
			package.TakeItem(2105, 40, out i);
			for (int k = 0; k < 40; k++)
			{
				double num2 = 0.0;
				double num3 = 0.0;
				if (k % 10 == 0)
				{
					if (k < 20)
					{
						num2 = ((k == 0) ? Constant.posxz[0, 0] : (0.0 - Constant.posxz[0, 0]));
						num3 = ((k == 0) ? Constant.posxz[0, 1] : (0.0 - Constant.posxz[0, 1]));
					}
					else
					{
						num2 = ((k == 20) ? Constant.posxz[0, 1] : (0.0 - Constant.posxz[0, 1]));
						num3 = ((k == 20) ? Constant.posxz[0, 0] : (0.0 - Constant.posxz[0, 0]));
					}
				}
				else if (0 < k && k < 10)
				{
					num2 = Constant.posxz[k, 0];
					num3 = Constant.posxz[k, 1];
				}
				else if (k > 10 && k < 20)
				{
					num2 = 0.0 - Constant.posxz[k - 10, 0];
					num3 = Constant.posxz[k - 10, 1];
				}
				else if (k > 20 && k < 30)
				{
					num2 = Constant.posxz[k - 20, 0];
					num3 = 0.0 - Constant.posxz[k - 20, 1];
				}
				else if (k > 30)
				{
					num2 = 0.0 - Constant.posxz[k - 30, 0];
					num3 = 0.0 - Constant.posxz[k - 30, 1];
				}
				Vector3 vector = new Vector3((float)(num2 * (double)Auxilaryfunction.player.planetData.realRadius), 0f, (float)(num3 * (double)Auxilaryfunction.player.planetData.realRadius));
				Vector3 vector2 = 0.025f * vector.normalized * Auxilaryfunction.player.planetData.realRadius;
				Quaternion quaternion = Maths.SphericalRotation(vector, Auxilaryfunction.player.controller.actionBuild.clickTool.yaw);
				vector += vector2;
				PrebuildData prebuild = new PrebuildData
				{
					protoId = 2105,
					modelIndex = 117,
					pos = vector + quaternion * Vector3.zero,
					pos2 = vector + quaternion * Vector3.zero,
					rot = quaternion * Quaternion.identity,
					rot2 = quaternion * Quaternion.identity,
					pickOffset = 0,
					insertOffset = 0,
					recipeId = 0,
					filterId = 0,
					paramCount = 0
				};
				prebuild.InitParametersArray(0);
				Auxilaryfunction.player.controller.actionBuild.clickTool.factory.AddPrebuildDataWithComponents(prebuild);
			}
		}
		else
		{
			UIMessageBox.Show("铺满轨道采集器失败", "背包里没有40个采集器，请重新准备", "确定", 3);
		}
	}

	public static string GetLogisticText(ELogisticStorage logic, bool isStellar, bool careStellar)
	{
		string text = ((!careStellar) ? "" : (isStellar ? "星际" : "本地"));
		return (text + logic switch
		{
			ELogisticStorage.Demand => "需求", 
			ELogisticStorage.Supply => "供应", 
			_ => "仓储", 
		}).Translate();
	}
}
