using System;

namespace Auxilaryfunction.Services;

public class TempDysonBlueprintData
{
	public string path = "";

	public string name = "";

	public EDysonBlueprintType type;

	public string TypeName = "";

	private bool VerifyDysonBluePrintData(string Content)
	{
		if (Content.Length < 23 || Content.Substring(0, 5) != "DYBP:")
		{
			return false;
		}
		int num = Content.IndexOf('"');
		int num2 = Content.LastIndexOf('"');
		if (num == -1 || num2 == -1 || num2 < num + 32)
		{
			return false;
		}
		if (Content.Substring(5, num - 5).Split(new char[1] { ',' }).Length < 3 || (Math.Max(Content.Length - 36, 0) > num2 && !MD5F.Compute(Content.Substring(0, num2)).Equals(Content.Substring(num2 + 1, 32), StringComparison.Ordinal)))
		{
			return false;
		}
		return true;
	}

	public void ReadDysonSphereBluePrint(string Content)
	{
		if (VerifyDysonBluePrintData(Content))
		{
			int num = Content.IndexOf('"');
			string[] array = Content.Substring(5, num - 5).Split(new char[1] { ',' });
			type = (EDysonBlueprintType)int.Parse(array[3]);
			switch (type)
			{
			case EDysonBlueprintType.SingleLayer:
				TypeName = "单层壳";
				break;
			case EDysonBlueprintType.Layers:
				TypeName = "多层壳";
				break;
			case EDysonBlueprintType.SwarmOrbits:
				TypeName = "戴森云";
				break;
			case EDysonBlueprintType.DysonSphere:
				TypeName = "戴森球(包括壳、云)";
				break;
			}
		}
	}
}
