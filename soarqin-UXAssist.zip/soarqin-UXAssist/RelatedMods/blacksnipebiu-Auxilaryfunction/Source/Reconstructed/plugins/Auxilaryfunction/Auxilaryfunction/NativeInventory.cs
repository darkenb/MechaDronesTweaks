using System;

namespace Auxilaryfunction;

internal static class NativeInventory
{
	internal static int Missing(int capacity, int idle, int working, int target)
	{
		return (int)Math.Max(0L, Math.Min((long)Math.Max(0, capacity), (long)Math.Max(0, target)) - Math.Max(0L, idle) - Math.Max(0L, working));
	}

	internal static bool HasItem(Player player, int itemId)
	{
		if (player == null || itemId <= 0)
		{
			return false;
		}
		if (player.package.GetItemCount(itemId) > 0 || (player.inhandItemId == itemId && player.inhandItemCount > 0))
		{
			return true;
		}
		DeliveryPackage deliveryPackage = player.deliveryPackage;
		if (deliveryPackage == null || !deliveryPackage.unlocked)
		{
			return false;
		}
		for (int i = 0; i < deliveryPackage.grids.Length; i++)
		{
			if (deliveryPackage.IsGridActive(i) && deliveryPackage.grids[i].itemId == itemId && deliveryPackage.grids[i].count > 0)
			{
				return true;
			}
		}
		return false;
	}

	internal static int Take(Player player, int itemId, int requested, out int inc)
	{
		inc = 0;
		if (player?.packageUtility == null || requested <= 0)
		{
			return 0;
		}
		int count = requested;
		player.packageUtility.TryTakeItemFromAllPackages(ref itemId, ref count, out inc, deliveryFirst: true);
		return count;
	}

	internal static void FillFuel(Player player, PlanetFactory factory, int generatorId, int itemId, int target)
	{
		if (player == null || player.factory != factory || factory?.powerSystem == null || generatorId <= 0 || generatorId >= factory.powerSystem.genCursor)
		{
			return;
		}
		ref PowerGeneratorComponent reference = ref factory.powerSystem.genPool[generatorId];
		ItemProto itemProto = LDB.items.Select(itemId);
		if (target <= reference.fuelCount || reference.id != generatorId || reference.fuelMask != 4 || itemProto == null || itemId > 32767 || itemProto.HeatValue <= 0 || (itemProto.FuelType & reference.fuelMask) == 0 || (reference.fuelCount > 0 && reference.fuelId != itemId))
		{
			return;
		}
		int requested = Math.Min(Math.Max(0, target - reference.fuelCount), Math.Min(32767 - reference.fuelCount, (32767 - reference.fuelInc) / 10));
		int inc;
		int num = Take(player, itemId, requested, out inc);
		if (num > 0)
		{
			if (reference.fuelCount == 0)
			{
				reference.SetNewFuel(itemId, (short)num, (short)inc);
				return;
			}
			reference.fuelCount += (short)num;
			reference.fuelInc += (short)inc;
		}
	}
}
