using System;
using System.Collections.Generic;
using System.Linq;

namespace Auxilaryfunction.Models;

internal class BluePrintBatchModifyBuild
{
	public static List<int> objIds = new List<int>();

	public static Dictionary<int, int> buildIconsDictionary = new Dictionary<int, int>();

	public static bool NeedRefresh;

	public static ERemoteRoutePriority eRemoteRoutePriority;

	public static int BeltSignalIconId = 0;

	public static int BeltSignalNumber = 0;

	public static string ModifyStationName = "";

	public static bool[] StationGroup = new bool[30];

	public static bool StationGroupDirty = true;

	public static bool[] TurretConfigIsSelected = new bool[4];

	public static int[] TurretConfigs = new int[4];

	public static int SelectedTurretGroup = 0;

	public static BuildType CurrentSelectedBuildType;

	public static List<int> CurrentSelectedBuilds = new List<int>();

	public static StationStoreConfig[] stationStoreConfigs = new StationStoreConfig[5];

	private static string currentSelectedBuildName;

	public static List<int> CanModifyBuildList = new List<int>(18)
	{
		2103, 2104, 2105, 2208, 2209, 2302, 2303, 2308, 2309, 2310,
		2311, 2901, 3001, 3002, 3003, 3004, 3005, 3010
	};

	public static List<int> SmelterIDs = new List<int>(3) { 2302, 2315, 2319 };

	public static List<int> AssemblerMachineIDs = new List<int>(4) { 2303, 2304, 2305, 2318 };

	public static List<int> LabIDs = new List<int>(2) { 2901, 2902 };

	public static List<int> ChemicalIDs = new List<int>(2) { 2309, 2317 };

	public static List<int> Turrets = new List<int>(6) { 3001, 3002, 3003, 3004, 3005, 3010 };

	public static Dictionary<int, BuildType> itemBuildTypeDic = new Dictionary<int, BuildType>();

	public const int baseSmelter = 2302;

	public const int baseAssemblerMachine = 2303;

	public const int baseLab = 2901;

	public const int baseRefine = 2308;

	public const int baseChemical = 2309;

	public const int baseParticle = 2310;

	public const int Gaussturret = 3001;

	public const int Laserturret = 3002;

	public const int Cannonturret = 3003;

	public const int MagnetizedPlasmaturret = 3004;

	public const int Missileturret = 3005;

	public const int GroundPlasmaturret = 3010;

	public static List<int> turretpool = new List<int>();

	public static List<int> beltpools = new List<int>();

	public static List<int> powerexchangerpools = new List<int>();

	public static List<int> labpools = new List<int>();

	public static List<int> ejectorpools = new List<int>();

	public static List<int> powergenGammapools = new List<int>();

	public static List<int> stellarstations = new List<int>();

	public static List<int> normalstations = new List<int>();

	public static List<int> AssemblePools = new List<int>();

	public static List<int> ParticlePools = new List<int>();

	public static List<int> RefinePools = new List<int>();

	public static List<int> ChemicalPools = new List<int>();

	public static List<int> SmeltPools = new List<int>();

	public static List<int> FilterAssemblePools = new List<int>();

	public static List<int> Filterlabpools = new List<int>();

	public static BuildTool_BlueprintCopy blue_copy => GameMain.mainPlayer?.controller?.actionBuild?.blueprintCopyTool;

	public static string CurrentSelectedBuildName
	{
		get
		{
			return currentSelectedBuildName;
		}
		set
		{
			currentSelectedBuildName = value;
		}
	}

	public static void Init()
	{
		Reset();
		ResetStationConfig();
		itemBuildTypeDic.Clear();
		ItemProto[] dataArray = LDB.items.dataArray;
		foreach (ItemProto itemProto in dataArray)
		{
			PrefabDesc prefabDesc = itemProto.prefabDesc;
			BuildType buildType = BuildType.None;
			if (prefabDesc.isLab)
			{
				buildType = BuildType.Lab;
			}
			else if (prefabDesc.isEjector)
			{
				buildType = BuildType.Ejector;
			}
			else if (prefabDesc.isPowerExchanger)
			{
				buildType = BuildType.PowerExchanger;
			}
			else if (prefabDesc.gammaRayReceiver)
			{
				buildType = BuildType.PowergenGamma;
			}
			else if (prefabDesc.isStation && !prefabDesc.isStellarStation && !prefabDesc.isCollectStation && !prefabDesc.isVeinCollector)
			{
				buildType = BuildType.NormalStation;
			}
			else if (prefabDesc.isStellarStation)
			{
				buildType = BuildType.StellarStation;
			}
			else if (prefabDesc.isTurret)
			{
				buildType = BuildType.Turret;
			}
			else if (prefabDesc.isBelt)
			{
				buildType = BuildType.Belt;
			}
			else if (prefabDesc.assemblerRecipeType == ERecipeType.Assemble)
			{
				buildType = BuildType.Assemble;
			}
			else if (prefabDesc.assemblerRecipeType == ERecipeType.Smelt)
			{
				buildType = BuildType.Smelt;
			}
			else if (prefabDesc.assemblerRecipeType == ERecipeType.Chemical)
			{
				buildType = BuildType.Chemical;
			}
			else if (prefabDesc.assemblerRecipeType == ERecipeType.Refine)
			{
				buildType = BuildType.Refine;
			}
			else if (prefabDesc.assemblerRecipeType == ERecipeType.Particle)
			{
				buildType = BuildType.Particle;
			}
			if (buildType != BuildType.None)
			{
				itemBuildTypeDic.Add(itemProto.ID, buildType);
			}
		}
	}

	private static void AddBuildNumber(int itemId)
	{
		if (buildIconsDictionary.ContainsKey(itemId))
		{
			buildIconsDictionary[itemId]++;
		}
		else
		{
			buildIconsDictionary.Add(itemId, 1);
		}
	}

	public static void CheckBluePrint()
	{
		if (!NeedRefresh)
		{
			return;
		}
		NeedRefresh = false;
		turretpool.Clear();
		beltpools.Clear();
		powerexchangerpools.Clear();
		labpools.Clear();
		ejectorpools.Clear();
		powergenGammapools.Clear();
		stellarstations.Clear();
		normalstations.Clear();
		AssemblePools.Clear();
		ParticlePools.Clear();
		RefinePools.Clear();
		ChemicalPools.Clear();
		SmeltPools.Clear();
		objIds.Clear();
		buildIconsDictionary.Clear();
		PlanetData localPlanet = GameMain.localPlanet;
		BuildPreview[] bpPool = blue_copy.bpPool;
		foreach (BuildPreview buildPreview in bpPool)
		{
			if (buildPreview != null && buildPreview.item != null && buildPreview.objId > 0 && !objIds.Contains(buildPreview.objId))
			{
				objIds.Add(buildPreview.objId);
				PrefabDesc prefabDesc = buildPreview.item.prefabDesc;
				_ = 0;
				if (prefabDesc.isLab)
				{
					labpools.Add(localPlanet.factory.entityPool[buildPreview.objId].labId);
					AddBuildNumber(buildPreview.item.ID);
				}
				else if (prefabDesc.isEjector)
				{
					ejectorpools.Add(localPlanet.factory.entityPool[buildPreview.objId].ejectorId);
					AddBuildNumber(buildPreview.item.ID);
				}
				else if (prefabDesc.isPowerExchanger)
				{
					powerexchangerpools.Add(localPlanet.factory.entityPool[buildPreview.objId].powerExcId);
					AddBuildNumber(buildPreview.item.ID);
				}
				else if (prefabDesc.gammaRayReceiver)
				{
					powergenGammapools.Add(localPlanet.factory.entityPool[buildPreview.objId].powerGenId);
					AddBuildNumber(buildPreview.item.ID);
				}
				else if (prefabDesc.isStation && !prefabDesc.isStellarStation && !prefabDesc.isCollectStation && !prefabDesc.isVeinCollector)
				{
					normalstations.Add(localPlanet.factory.entityPool[buildPreview.objId].stationId);
					AddBuildNumber(buildPreview.item.ID);
				}
				else if (prefabDesc.isStellarStation)
				{
					stellarstations.Add(localPlanet.factory.entityPool[buildPreview.objId].stationId);
					AddBuildNumber(buildPreview.item.ID);
				}
				else if (prefabDesc.isTurret)
				{
					turretpool.Add(localPlanet.factory.entityPool[buildPreview.objId].turretId);
					AddBuildNumber(buildPreview.item.ID);
				}
				else if (prefabDesc.isBelt)
				{
					beltpools.Add(localPlanet.factory.entityPool[buildPreview.objId].id);
					AddBuildNumber(buildPreview.item.ID);
				}
				else if (prefabDesc.assemblerRecipeType == ERecipeType.Assemble)
				{
					AssemblePools.Add(localPlanet.factory.entityPool[buildPreview.objId].assemblerId);
					AddBuildNumber(buildPreview.item.ID);
				}
				else if (prefabDesc.assemblerRecipeType == ERecipeType.Smelt)
				{
					SmeltPools.Add(localPlanet.factory.entityPool[buildPreview.objId].assemblerId);
					AddBuildNumber(buildPreview.item.ID);
				}
				else if (prefabDesc.assemblerRecipeType == ERecipeType.Chemical)
				{
					ChemicalPools.Add(localPlanet.factory.entityPool[buildPreview.objId].assemblerId);
					AddBuildNumber(buildPreview.item.ID);
				}
				else if (prefabDesc.assemblerRecipeType == ERecipeType.Refine)
				{
					RefinePools.Add(localPlanet.factory.entityPool[buildPreview.objId].assemblerId);
					AddBuildNumber(buildPreview.item.ID);
				}
				else if (prefabDesc.assemblerRecipeType == ERecipeType.Particle)
				{
					ParticlePools.Add(localPlanet.factory.entityPool[buildPreview.objId].assemblerId);
					AddBuildNumber(buildPreview.item.ID);
				}
			}
		}
		if (CurrentSelectedBuilds.Count == 0 && buildIconsDictionary.Count > 0)
		{
			SelectItemId(buildIconsDictionary.First().Key);
		}
		OnFilterAssemblePoolsConditionChanged();
		StationGroupDirty = true;
	}

	public static void Reset()
	{
		CurrentSelectedBuilds.Clear();
		CurrentSelectedBuildName = "暂无选中设备".getTranslate();
		for (int i = 0; i < 4; i++)
		{
			TurretConfigs[i] = 0;
		}
	}

	public static void ResetStationConfig()
	{
		ModifyStationName = "";
		eRemoteRoutePriority = ERemoteRoutePriority.Ignore;
		stationStoreConfigs = new StationStoreConfig[5];
		for (int i = 0; i < 5; i++)
		{
			stationStoreConfigs[i] = new StationStoreConfig();
		}
	}

	public static void EnsureStationGroupCount(int count)
	{
		if (count <= 0)
		{
			count = 30;
		}
		if (StationGroup == null || StationGroup.Length != count)
		{
			Array.Resize(ref StationGroup, count);
		}
	}

	public static void SyncStationGroupFrom(StationComponent sc)
	{
		if (sc != null && StationGroup != null)
		{
			for (int i = 0; i < StationGroup.Length; i++)
			{
				StationGroup[i] = (sc.remoteGroupMask & (1L << i)) > 0;
			}
			eRemoteRoutePriority = sc.routePriority;
		}
	}

	public static void SelectItemId(int itemId)
	{
		if (CurrentSelectedBuilds.Contains(itemId))
		{
			UnSelectItemId(itemId);
		}
		else
		{
			CurrentSelectedBuilds.Add(itemId);
			CurrentSelectedBuildType = itemBuildTypeDic[itemId];
		}
		for (int num = CurrentSelectedBuilds.Count - 1; num >= 0; num--)
		{
			int key = CurrentSelectedBuilds[num];
			if (itemBuildTypeDic[key] != CurrentSelectedBuildType)
			{
				CurrentSelectedBuilds.RemoveAt(num);
			}
		}
		OnFilterAssemblePoolsConditionChanged();
	}

	public static void UnSelectItemId(int itemId)
	{
		if (CurrentSelectedBuilds.Contains(itemId))
		{
			CurrentSelectedBuilds.Remove(itemId);
		}
		if (CurrentSelectedBuilds.Count == 0)
		{
			CurrentSelectedBuildType = BuildType.None;
		}
		OnFilterAssemblePoolsConditionChanged();
	}

	private static void OnFilterAssemblePoolsConditionChanged()
	{
		PlanetData localPlanet = GameMain.localPlanet;
		FilterAssemblePools.Clear();
		Filterlabpools.Clear();
		List<int> list = CurrentSelectedBuildType switch
		{
			BuildType.Assemble => AssemblePools, 
			BuildType.Smelt => SmeltPools, 
			BuildType.Chemical => ChemicalPools, 
			BuildType.Particle => ParticlePools, 
			BuildType.Refine => RefinePools, 
			_ => new List<int>(), 
		};
		for (int i = 0; i < list.Count; i++)
		{
			int entityId = localPlanet.factory.factorySystem.assemblerPool[list[i]].entityId;
			short protoId = localPlanet.factory.entityPool[entityId].protoId;
			if (CurrentSelectedBuilds.Contains(protoId))
			{
				FilterAssemblePools.Add(list[i]);
			}
		}
		for (int j = 0; j < labpools.Count; j++)
		{
			int entityId2 = localPlanet.factory.factorySystem.labPool[labpools[j]].entityId;
			short protoId2 = localPlanet.factory.entityPool[entityId2].protoId;
			if (CurrentSelectedBuilds.Contains(protoId2))
			{
				Filterlabpools.Add(labpools[j]);
			}
		}
	}
}
