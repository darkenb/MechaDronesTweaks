using HarmonyLib;
using UnityEngine;

namespace Auxilaryfunction.Patch;

internal class SpeedUpPatch
{
	private static float speedMultiple;

	private static Harmony _patch;

	private static bool enable;

	public static float TargetFixedDeltaTime = 0.0166666f;

	public static bool Enable
	{
		get
		{
			return enable;
		}
		set
		{
			if (enable != value)
			{
				enable = value;
				if (enable)
				{
					_patch = Harmony.CreateAndPatchAll(typeof(SpeedUpPatch));
				}
				else
				{
					_patch.UnpatchSelf();
				}
			}
		}
	}

	public static float SpeedMultiple
	{
		get
		{
			return speedMultiple;
		}
		set
		{
			speedMultiple = value;
			TargetFixedDeltaTime = 1f / (speedMultiple * 60f);
			_ = Enable;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(FPSController), "Update")]
	public static void SpeedUp()
	{
		Time.fixedDeltaTime = TargetFixedDeltaTime;
	}
}
