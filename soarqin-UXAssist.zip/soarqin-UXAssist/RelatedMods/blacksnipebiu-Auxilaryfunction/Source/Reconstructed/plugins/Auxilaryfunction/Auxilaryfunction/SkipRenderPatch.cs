using HarmonyLib;

namespace Auxilaryfunction;

public class SkipRenderPatch
{
	[HarmonyPrefix]
	[HarmonyPatch(typeof(FactoryModel), "Update")]
	public static bool FactoryModelUpdatePatch()
	{
		return !AuxConfig.simulatorrender;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(FactoryModel), "LateUpdate")]
	public static bool FactoryModelLateUpdatePatch()
	{
		if (!AuxConfig.norender_entity_bool.Value)
		{
			return !AuxConfig.simulatorrender;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(LogisticDroneRenderer), "Draw")]
	public static bool DroneDrawPatch()
	{
		if (!AuxConfig.norender_shipdrone_bool.Value)
		{
			return !AuxConfig.simulatorrender;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(LogisticShipUIRenderer), "Draw")]
	public static bool LogisticShipUIRendererDrawPatch()
	{
		if (!AuxConfig.norender_shipdrone_bool.Value)
		{
			return !AuxConfig.simulatorrender;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(LogisticCourierRenderer), "Draw")]
	public static bool CourierDrawPatch()
	{
		if (!AuxConfig.norender_shipdrone_bool.Value)
		{
			return !AuxConfig.simulatorrender;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(LogisticShipRenderer), "Draw")]
	public static bool ShipDrawPatch()
	{
		if (!AuxConfig.norender_shipdrone_bool.Value)
		{
			return !AuxConfig.simulatorrender;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(LabRenderer), "Render")]
	public static bool LabRendererPatch(LabRenderer __instance)
	{
		if (__instance.modelId == 70 || __instance.modelId == 455)
		{
			if (!AuxConfig.norender_lab_bool.Value)
			{
				return !AuxConfig.simulatorrender;
			}
			return false;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(SectorModel), "LateUpdate")]
	public static bool EnemyDFGroundRendererRenderPatch()
	{
		if (!AuxConfig.norender_DarkFog.Value)
		{
			return !AuxConfig.simulatorrender;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DysonSphere), "DrawModel")]
	public static bool DysonDrawModelPatch()
	{
		if (!AuxConfig.norender_dysonshell_bool.Value)
		{
			return !AuxConfig.simulatorrender;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DysonSphere), "DrawPost")]
	public static bool DysonDrawPostPatch()
	{
		if (!AuxConfig.norender_dysonswarm_bool.Value)
		{
			return !AuxConfig.simulatorrender;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIPowerGizmo), "DrawArea")]
	public static bool UIPowerGizmoDrawAreaPatch()
	{
		if (!AuxConfig.norender_powerdisk_bool.Value)
		{
			return !AuxConfig.simulatorrender;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIDarkFogMonitor), "Determine")]
	public static bool UIDarkFogMonitorDetermine()
	{
		if (!Auxilaryfunction.HideDarkFogMonitor)
		{
			return !AuxConfig.simulatorrender;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIDarkFogAssaultTip), "Determine")]
	public static bool UIDarkFogAssaultTipDetermine()
	{
		if (!Auxilaryfunction.HideDarkFogAssaultTip)
		{
			return !AuxConfig.simulatorrender;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(CargoContainer), "Draw")]
	public static bool PathRenderingBatchDrawPatch()
	{
		if (!AuxConfig.norender_beltitem.Value)
		{
			return !AuxConfig.simulatorrender;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIPowerGizmo), "DrawCover")]
	public static bool UIPowerGizmoDrawCoverPatch()
	{
		if (!AuxConfig.norender_powerdisk_bool.Value)
		{
			return !AuxConfig.simulatorrender;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UniverseSimulator), "GameTick")]
	public static void UniverseSimulatorGameTickPatch(UniverseSimulator __instance)
	{
		if (!AuxConfig.simulatorchanging)
		{
			return;
		}
		int num = 0;
		__instance.backgroundStars.gameObject.SetActive(!AuxConfig.simulatorrender);
		while (__instance.planetSimulators != null && num < __instance.planetSimulators.Length)
		{
			if (__instance.planetSimulators[num] != null)
			{
				__instance.planetSimulators[num].gameObject.SetActive(!AuxConfig.simulatorrender);
			}
			num++;
		}
		num = 0;
		while (__instance.starSimulators != null && num < __instance.starSimulators.Length)
		{
			if (__instance.starSimulators[num] != null)
			{
				if (__instance.starSimulators[num].starData.type == EStarType.NeutronStar && Configs.builtin.neutronStarPrefab.streamRenderer != null)
				{
					num++;
					continue;
				}
				__instance.starSimulators[num].gameObject.SetActive(!AuxConfig.simulatorrender);
			}
			num++;
		}
		AuxConfig.simulatorchanging = false;
	}
}
