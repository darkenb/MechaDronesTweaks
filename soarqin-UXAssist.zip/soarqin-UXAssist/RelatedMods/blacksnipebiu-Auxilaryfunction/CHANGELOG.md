# blacksnipebiu-Auxilaryfunction — detailed change report

Installed plugin version(s): **3.0.10**. Preserve stock and runtime capacity during worker/warper/fuel refill; respect active delivery slots and native package priority.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Safe refill and construction material checks — 3.0.9

Use upstream source corresponding to installed 3.0.8.

- Fill only missing workers up to actual runtime capacity, retaining current idle/working stock. Foreign-factory creation cannot take items from the local player.
- Two warper-refill callbacks add to the same current stock instead of overwriting the earlier fill. Native package utilities retain delivery priority and proliferator data.
- Construction material checks include active/unlocked delivery grids and the held item.
- Before withdrawing artificial-star fuel, validate current fuel type, destination and native FuelType/HeatValue. The old path could withdraw stock and then reject it against a generator already containing different fuel. Support native-compatible modded fuel rather than only IDs 1803/1804; retain Int16 count/inc limits.
- Keep batch gamma-mode switching on native prototype `productId` for new lenses; do not replace current terrain/vegetation removal with an old custom path.

## Port onto current upstream — 3.0.10, 15 October

Reapply stock/capacity, factory ownership, native package/delivery, fuel validation and auto-build checks while retaining the updated panel/building settings and resource/icon bytes.

Focused CLR and game-Mono stock-transfer/fuel checks passed on the candidate and installed build. The port also retained assembly/public/GUID/dependency contracts and embedded resources. Live native UI, modded-fuel operation, lens behavior and auto-build acceptance remain outstanding.

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
