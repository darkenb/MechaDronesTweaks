# blacksnipebiu-Auxilaryfunction

Preserve stock and runtime capacity during worker/warper/fuel refill; respect active delivery slots and native package priority.

The analysis and proposed fixes in this handoff were developed with assistance from the GPT 6.1 Sol model. English documentation accompanies the code to explain what changed, why it changed, and the available validation results.

[Review map](REVIEW_GUIDE.md) · [Receiving package relationship index](../../RELATED_MODS.md) · [Detailed changes](CHANGELOG.md) · [Build/review notes](BUILD.md) · [Assembly metadata](metadata.json)

Prepared for maintainer review on 15 October 2026. This is a local modified build, not an official upstream release, published package or pull request.

Installed plugin version(s): **3.0.10**. Existing package manifest version: **3.0.9**. Manifest, plugin and assembly versions are separate; the original manifest is retained.

## Package layout

- `InstalledPackage/`: actual installed mod files and companion preloader when present.
- `Source/Reconstructed/`: full projects reconstructed from the exact installed assemblies.
- `Source/EarlierWorkingSource/`, `PortedWorkingSource/`, `UpstreamSnapshot/`: source snapshots when available; provenance is recorded separately.
- `Evidence/`: development helpers, focused check sources and structured validation/installation records.
- `Diffs/`: source-port patches and normalized structural IL comparison.
- `Baselines/`: previous binary and its provenance for review, not an automatic rollback.

## Plugin identifiers and declared dependencies

- `cn.blacksnipe.dsp.Auxilaryfunction` — Auxilaryfunction 3.0.10; dependencies: none declared on this plugin.

## Installed assembly hashes

| Recorded path | SHA-256 |
|---|---|
| `plugins/blacksnipebiu-Auxilaryfunction/Auxilaryfunction.dll` | `d7adc3e75eb7fb4930335ab99e24b847eed4cd9ac44147461fbb906ced0c6e4d` |

## Scope and limitations

Not every source project has been rebuilt. Historical compile/test evidence is limited to its recorded hashes. Headless/embedded-Mono checks do not establish real Unity UI, the user's world, all-mod startup, multiplayer or sustained-memory acceptance.
