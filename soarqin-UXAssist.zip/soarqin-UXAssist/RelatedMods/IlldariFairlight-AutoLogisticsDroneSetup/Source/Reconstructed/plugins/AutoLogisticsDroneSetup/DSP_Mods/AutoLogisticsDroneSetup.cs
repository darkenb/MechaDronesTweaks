using System;
using BepInEx;
using HarmonyLib;

namespace DSP_Mods;

[BepInPlugin("gimbalhawk.dsp.autoshuttlesetup", "AutoShuttleSetup", "1.8.2")]
public class AutoLogisticsDroneSetup : BaseUnityPlugin
{
	public const string pluginGuid = "gimbalhawk.dsp.autoshuttlesetup";

	public const string pluginName = "AutoShuttleSetup";

	public const string pluginVersion = "1.8.2";

	public static Item Drone = new Item
	{
		Id = 5001,
		Name = "Drone"
	};

	public static Item Vessel = new Item
	{
		Id = 5002,
		Name = "Vessel"
	};

	public static Item Bot = new Item
	{
		Id = 5003,
		Name = "Bot"
	};

	private static StorageUtility StorageUtility { get; set; }

	private static BuildMenuUIAddOn UI { get; set; }

	public void Awake()
	{
		ModConfig.InitConfig(base.Config);
		StorageUtility = new StorageUtility();
		Harmony.CreateAndPatchAll(typeof(AutoLogisticsDroneSetup));
		Harmony.CreateAndPatchAll(typeof(ModConfigWindow));
		DSP_Mods.Logger.Init(base.Logger, "AutoLogisticsDroneSetup");
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetTransport), "NewStationComponent")]
	public static void NewStationComponent_PostFix(PlanetTransport __instance, int _entityId, int _pcId, PrefabDesc _desc)
	{
		Player mainPlayer = GameMain.mainPlayer;
		if (mainPlayer == null || mainPlayer.factory != __instance.factory)
		{
			DSP_Mods.Logger.Instance.LogInfo("Couldn't find player");
			return;
		}
		EntityData entityData = __instance.factory.GetEntityData(_entityId);
		StationComponent stationComponent = __instance.stationPool[entityData.stationId];
		if (stationComponent == null)
		{
			DSP_Mods.Logger.Instance.LogInfo("Couldn't find station? That shouldn't happen");
		}
		else
		{
			if (stationComponent.isCollector)
			{
				return;
			}
			if (stationComponent.isStellar)
			{
				DSP_Mods.Logger.Instance.LogInfo("Interstellar logistics station built");
				if (ModConfig.DepositDronesILS.Value)
				{
					AddDrones(stationComponent, _desc, StorageUtility, ModConfig.DroneAmountILS.Value);
				}
				if (ModConfig.DepositVesselsILS.Value)
				{
					AddShips(stationComponent, _desc, StorageUtility, ModConfig.VesselAmountILS.Value);
				}
			}
			else
			{
				DSP_Mods.Logger.Instance.LogInfo("Planetary logistics station built");
				if (ModConfig.DepositDronesPLS.Value)
				{
					AddDrones(stationComponent, _desc, StorageUtility, ModConfig.DroneAmountPLS.Value);
				}
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetTransport), "NewDispenserComponent")]
	public static void NewDispenserComponent_PostFix(PlanetTransport __instance, int _entityId, int _pcId, PrefabDesc _desc)
	{
		Player mainPlayer = GameMain.mainPlayer;
		if (mainPlayer == null || mainPlayer.factory != __instance.factory)
		{
			DSP_Mods.Logger.Instance.LogInfo("Couldn't find player");
			return;
		}
		EntityData entityData = __instance.factory.GetEntityData(_entityId);
		DispenserComponent dispenserComponent = __instance.dispenserPool[entityData.dispenserId];
		if (dispenserComponent == null)
		{
			DSP_Mods.Logger.Instance.LogInfo("Couldn't find logistic dispenser? That shouldn't happen");
			return;
		}
		DSP_Mods.Logger.Instance.LogInfo("Logistics dispenser built");
		if (ModConfig.DepositBots.Value)
		{
			AddBots(dispenserComponent, _desc, StorageUtility, ModConfig.BotAmount.Value);
		}
	}

	private static void AddDrones(StationComponent station, PrefabDesc desc, StorageUtility util, int desiredAmount)
	{
		if (station != null && desc != null && util != null)
		{
			int num = FillQuantity.Needed((station.workDroneDatas != null) ? station.workDroneDatas.Length : desc.stationMaxDroneCount, station.idleDroneCount, station.workDroneCount, desiredAmount);
			if (num > 0)
			{
				station.idleDroneCount += util.RemoveItems(Drone, num);
			}
		}
	}

	private static void AddShips(StationComponent station, PrefabDesc desc, StorageUtility util, int desiredAmount)
	{
		if (station != null && desc != null && util != null)
		{
			int num = FillQuantity.Needed(Math.Min((station.workShipDatas != null) ? station.workShipDatas.Length : desc.stationMaxShipCount, 64), station.idleShipCount, station.workShipCount, desiredAmount);
			if (num > 0)
			{
				station.idleShipCount += util.RemoveItems(Vessel, num);
			}
		}
	}

	private static void AddBots(DispenserComponent dispenser, PrefabDesc desc, StorageUtility util, int desiredAmount)
	{
		if (dispenser != null && desc != null && util != null)
		{
			int num = FillQuantity.Needed((dispenser.workCourierDatas != null) ? dispenser.workCourierDatas.Length : desc.dispenserMaxCourierCount, dispenser.idleCourierCount, dispenser.workCourierCount, desiredAmount);
			if (num > 0)
			{
				dispenser.idleCourierCount += util.RemoveItems(Bot, num);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIBuildMenu), "OnCategoryButtonClick")]
	public static void OnCategoryButtonClick_Postfix(UIBuildMenu __instance)
	{
		if (__instance.currentCategory != 6)
		{
			if (UI != null)
			{
				UI.Hide();
			}
			return;
		}
		if (UI == null)
		{
			UI = BuildMenuUIAddOn.InitUI(__instance);
		}
		if (UI != null)
		{
			UI.Show();
		}
	}

	public void OnGUI()
	{
		if (ModConfigWindow.Visible)
		{
			ModConfigWindow.OnGUI();
		}
	}
}
