using UnityEngine;
using UnityEngine.UI;

namespace DSP_Mods;

public class BuildMenuUIAddOn : MonoBehaviour
{
	private GameObject ConfigButton;

	private Image ConfigIconImage;

	public static BuildMenuUIAddOn InitUI(UIBuildMenu buildMenu)
	{
		GameObject.Find("UI Root/Overlay Canvas/In Game/Function Panel/Build Menu/child-group");
		RectTransform component = buildMenu.GetComponent<RectTransform>();
		if (component == null)
		{
			return null;
		}
		Text textComponent = null;
		GameObject gameObject = GameObject.Find("UI Root/Overlay Canvas/In Game/Function Panel/Build Menu/child-group/button-1");
		if (gameObject != null)
		{
			textComponent = gameObject.GetComponent<RectTransform>().transform.Find("count")?.GetComponentInChildren<Text>();
		}
		BuildMenuUIAddOn buildMenuUIAddOn = component.gameObject.AddComponent<BuildMenuUIAddOn>();
		buildMenuUIAddOn.AddModComponents(component, textComponent);
		return buildMenuUIAddOn;
	}

	public void AddModComponents(RectTransform containerRect, Text textComponent)
	{
		InitConfigButton(containerRect, textComponent);
	}

	public void Show()
	{
		ConfigIconImage.gameObject.SetActive(value: true);
	}

	public void Hide()
	{
		ConfigIconImage.gameObject.SetActive(value: false);
	}

	private void InitConfigButton(RectTransform containerRect, Text textComponent)
	{
		ConfigButton = new GameObject("ALDS_Config");
		RectTransform rectTransform = ConfigButton.AddComponent<RectTransform>();
		rectTransform.SetParent(containerRect.transform, worldPositionStays: false);
		rectTransform.anchorMax = new Vector2(0f, 0.5f);
		rectTransform.anchorMin = new Vector2(0f, 0.5f);
		rectTransform.sizeDelta = new Vector2(20f, 20f);
		rectTransform.pivot = new Vector2(0f, 1f);
		rectTransform.anchoredPosition = new Vector2(210f, 25f);
		ClickableControl clickableControl = rectTransform.gameObject.AddComponent<ClickableControl>();
		clickableControl.HoverText = "Open AutoLogisticsDroneSetup config";
		if (textComponent != null)
		{
			Text text = Object.Instantiate(textComponent, containerRect.transform, worldPositionStays: true);
			RectTransform component = text.GetComponent<RectTransform>();
			containerRect.GetComponent<RectTransform>();
			component.anchorMax = new Vector2(0f, 0.5f);
			component.anchorMin = new Vector2(0f, 0.5f);
			component.sizeDelta = new Vector2(200f, 25f);
			component.pivot = new Vector2(0.5f, 1f);
			component.anchoredPosition = new Vector2(225f, 72f);
			clickableControl.TextObject = text;
		}
		ConfigIconImage = clickableControl.gameObject.AddComponent<Image>();
		ConfigIconImage.color = new Color(0.8f, 0.8f, 0.8f, 1f);
		GameObject gameObject = GameObject.Find("UI Root/Overlay Canvas/In Game/Game Menu/button-3-bg/button-3/icon");
		ConfigIconImage.sprite = gameObject.GetComponent<Image>().sprite;
		clickableControl.OnClick += delegate
		{
			ModConfigWindow.Visible = !ModConfigWindow.Visible;
		};
	}
}
