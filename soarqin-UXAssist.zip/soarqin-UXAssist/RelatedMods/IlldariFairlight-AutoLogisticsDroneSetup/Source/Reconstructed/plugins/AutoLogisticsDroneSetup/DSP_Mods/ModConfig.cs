using BepInEx.Configuration;

namespace DSP_Mods;

public static class ModConfig
{
	public static ConfigEntry<int> InventoryPriority;

	public static ConfigEntry<int> StoragePriority;

	public static ConfigEntry<int> StationsPriority;

	public static ConfigEntry<bool> DepositDronesPLS;

	public static ConfigEntry<bool> DepositDronesILS;

	public static ConfigEntry<bool> DepositVesselsILS;

	public static ConfigEntry<bool> DepositBots;

	public static ConfigEntry<int> DroneAmountPLS;

	public static ConfigEntry<int> DroneAmountILS;

	public static ConfigEntry<int> VesselAmountILS;

	public static ConfigEntry<int> BotAmount;

	public static ConfigFile ConfigFile;

	public static void InitConfig(ConfigFile config)
	{
		ConfigFile = config;
		InventoryPriority = config.Bind("Storage", "Inventory Priority", 1, "The priority of selecting from the player inventory. Lower numbers take precendence. Set to a negative number to disable");
		StoragePriority = config.Bind("Storage", "Storage Priority", 2, "The priority of selecting from storage chests. Lower numbers take precendence. Set to a negative number to disable");
		StationsPriority = config.Bind("Storage", "Stations Priority", 3, "The priority of selecting from stations. Lower numbers take precendence. Set to a negative number to disable");
		DepositDronesPLS = config.Bind("Planetary Logistics", "Deposit Drones", defaultValue: true, "Whether drones should automatically be added to a newly created Planetary Logistics Station");
		DroneAmountPLS = config.Bind("Planetary Logistics", "Planetary Drone Amount", -1, "How many drones should be added to a newly created Planetary Logistics Station. Numbers less than 0 or greater than the max are treated as the normal drone maximum");
		DepositDronesILS = config.Bind("Interstellar Logistics", "Deposit Drones", defaultValue: true, "Whether drones should automatically be added to a newly created Interstellar Logistics Station");
		DroneAmountILS = config.Bind("Interstellar Logistics", "Interstellar Drone Amount", -1, "How many drones should be added to a newly created Interstellar Logistics Station. Numbers less than 0 or greater than the max are treated as the normal drone maximum");
		DepositVesselsILS = config.Bind("Interstellar Logistics", "Deposit Vessels", defaultValue: true, "Whether vessels should automatically be added to a newly created Interstellar Logistics Station");
		VesselAmountILS = config.Bind("Interstellar Logistics", "Interstellar Vessel Amount", -1, "How many vessels should be added to a newly created Interstellar Logistics Station. Numbers less than 0 or greater than the max are treated as the normal drone maximum");
		DepositBots = config.Bind("Logistics Bots", "Deposit Bots", defaultValue: true, "Whether bots should automatically be added to a newly created logistics distrubution ports");
		BotAmount = config.Bind("Logistics Bots", "Bots Amount", -1, "How many bots should be added to a newly created distribution port. Numbers less than 0 or greater than the max are treated as the normal bot maximum");
	}

	public static void ResetAllToDefault()
	{
		foreach (ConfigDefinition key in ConfigFile.Keys)
		{
			ConfigEntryBase configEntryBase = ConfigFile[key];
			configEntryBase.BoxedValue = configEntryBase.DefaultValue;
		}
	}
}
