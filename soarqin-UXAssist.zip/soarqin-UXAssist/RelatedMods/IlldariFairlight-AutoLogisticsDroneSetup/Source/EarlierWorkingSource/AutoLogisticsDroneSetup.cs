using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;

namespace DSP_Mods
{
	[BepInPlugin(pluginGuid, pluginName, pluginVersion)]
	public class AutoLogisticsDroneSetup : BaseUnityPlugin
	{
		public const string pluginGuid = "gimbalhawk.dsp.autoshuttlesetup";
		public const string pluginName = "AutoShuttleSetup";
		public const string pluginVersion = "1.8.2";

		public static Item Drone = new Item() { Id = 5001, Name = "Drone" };
		public static Item Vessel = new Item() { Id = 5002, Name = "Vessel" };
		public static Item Bot = new Item() { Id = 5003, Name = "Bot" };

		private static StorageUtility StorageUtility { get; set; }
		private static BuildMenuUIAddOn UI { get; set; }

		public void Awake()
		{
			ModConfig.InitConfig(Config);

			StorageUtility = new StorageUtility();

			Harmony.CreateAndPatchAll(typeof(AutoLogisticsDroneSetup));
			Harmony.CreateAndPatchAll(typeof(ModConfigWindow));

			DSP_Mods.Logger.Init(Logger, "AutoLogisticsDroneSetup");
		}

		[HarmonyPostfix, HarmonyPatch(typeof(PlanetTransport), nameof(PlanetTransport.NewStationComponent))]
		public static void NewStationComponent_PostFix(PlanetTransport __instance, int _entityId, int _pcId, PrefabDesc _desc)
		{
			var player = GameMain.mainPlayer;
			if (player == null || player.factory != __instance.factory)
			{
				DSP_Mods.Logger.Instance.LogInfo("Couldn't find player");
				return;
			}

			var entity = __instance.factory.GetEntityData(_entityId);
			var station = __instance.stationPool[entity.stationId];
			if (station == null)
			{
				DSP_Mods.Logger.Instance.LogInfo("Couldn't find station? That shouldn't happen");
				return;
			}

			if (station.isCollector)
				return;

			if (station.isStellar)
			{
				DSP_Mods.Logger.Instance.LogInfo("Interstellar logistics station built");
				if (ModConfig.DepositDronesILS.Value)
				{
					AddDrones(station, _desc, StorageUtility, ModConfig.DroneAmountILS.Value);
				}

				if (ModConfig.DepositVesselsILS.Value)
				{
					AddShips(station, _desc, StorageUtility, ModConfig.VesselAmountILS.Value);
				}
			}
			else
			{
				DSP_Mods.Logger.Instance.LogInfo("Planetary logistics station built");
				if (ModConfig.DepositDronesPLS.Value)
				{
					AddDrones(station, _desc, StorageUtility, ModConfig.DroneAmountPLS.Value);
				}
			}
		}

		[HarmonyPostfix, HarmonyPatch(typeof(PlanetTransport), "NewDispenserComponent")]
		public static void NewDispenserComponent_PostFix(PlanetTransport __instance, int _entityId, int _pcId, PrefabDesc _desc)
		{
			var player = GameMain.mainPlayer;
			if (player == null || player.factory != __instance.factory)
			{
				DSP_Mods.Logger.Instance.LogInfo("Couldn't find player");
				return;
			}

			var entity = __instance.factory.GetEntityData(_entityId);
			var dispenser = __instance.dispenserPool[entity.dispenserId];
			if (dispenser == null)
			{
				DSP_Mods.Logger.Instance.LogInfo("Couldn't find logistic dispenser? That shouldn't happen");
				return;
			}

			DSP_Mods.Logger.Instance.LogInfo("Logistics dispenser built");

			if (ModConfig.DepositBots.Value)
			{
				AddBots(dispenser, _desc, StorageUtility, ModConfig.BotAmount.Value);
			}
		}

        private static void AddDrones(StationComponent station, PrefabDesc desc, StorageUtility util, int desiredAmount)
        {
            if (station == null || desc == null || util == null) return;
            int capacity = station.workDroneDatas != null ? station.workDroneDatas.Length : desc.stationMaxDroneCount;
            int need = FillQuantity.Needed(capacity, station.idleDroneCount, station.workDroneCount, desiredAmount);
            if (need > 0) station.idleDroneCount += util.RemoveItems(Drone, need);
        }
        private static void AddShips(StationComponent station, PrefabDesc desc, StorageUtility util, int desiredAmount)
        {
            if (station == null || desc == null || util == null) return;
            int capacity = station.workShipDatas != null ? station.workShipDatas.Length : desc.stationMaxShipCount;
            // Native vessel IDs use a 64-bit occupancy mask.
            capacity = Math.Min(capacity, 64);
            int need = FillQuantity.Needed(capacity, station.idleShipCount, station.workShipCount, desiredAmount);
            if (need > 0) station.idleShipCount += util.RemoveItems(Vessel, need);
        }
        private static void AddBots(DispenserComponent dispenser, PrefabDesc desc, StorageUtility util, int desiredAmount)
        {
            if (dispenser == null || desc == null || util == null) return;
            int capacity = dispenser.workCourierDatas != null ? dispenser.workCourierDatas.Length : desc.dispenserMaxCourierCount;
            int need = FillQuantity.Needed(capacity, dispenser.idleCourierCount, dispenser.workCourierCount, desiredAmount);
            if (need > 0) dispenser.idleCourierCount += util.RemoveItems(Bot, need);
        }

		[HarmonyPostfix, HarmonyPatch(typeof(UIBuildMenu), nameof(UIBuildMenu.OnCategoryButtonClick))]
		public static void OnCategoryButtonClick_Postfix(UIBuildMenu __instance)
		{
			var uiBuildMenu = __instance;

			// We only want to modify the logistics buildings category
			if (uiBuildMenu.currentCategory != 6)
			{
				if (UI != null)
				{
					UI.Hide();
				}

				return;
			}

			if (UI == null)
			{
				UI = BuildMenuUIAddOn.InitUI(uiBuildMenu);
			}

			if (UI != null)
			{
				UI.Show();
			}
		}

		public void OnGUI()
		{
			if (ModConfigWindow.Visible)
			{
				ModConfigWindow.OnGUI();
			}
		}
	}
}
