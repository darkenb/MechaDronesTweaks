# CommonAPI-CommonAPI

Update number-formatting calls and grow the model cache at the exact capacity boundary without losing existing entries.

The analysis and proposed fixes in this handoff were developed with assistance from the GPT 6.1 Sol model. English documentation accompanies the code to explain what changed, why it changed, and the available validation results.

[Review map](REVIEW_GUIDE.md) · [Receiving package relationship index](../../RELATED_MODS.md) · [Detailed changes](CHANGELOG.md) · [Build/review notes](BUILD.md) · [Assembly metadata](metadata.json)

Prepared for maintainer review on 15 October 2026. This is a local modified build, not an official upstream release, published package or pull request.

Installed plugin version(s): **1.6.8.0**. Existing package manifest version: **1.6.7**. Manifest, plugin and assembly versions are separate; the original manifest is retained.

## Package layout

- `InstalledPackage/`: actual installed mod files and companion preloader when present.
- `Source/Reconstructed/`: full projects reconstructed from the exact installed assemblies.
- `Source/EarlierWorkingSource/`, `PortedWorkingSource/`, `UpstreamSnapshot/`: source snapshots when available; provenance is recorded separately.
- `Evidence/`: development helpers, focused check sources and structured validation/installation records.
- `Diffs/`: source-port patches and normalized structural IL comparison.
- `Baselines/`: previous binary and its provenance for review, not an automatic rollback.

## Plugin identifiers and declared dependencies

- `dsp.common-api.CommonAPI` — DSP Common API 1.6.8.0; dependencies: me.xiaoye97.plugin.Dyson.LDBTool | hard; crecheng.DSPModSave | hard.
- `dsp.common-tools.common-api-nebula-compat` — Common API Nebula Compatibility 1.6.8.0; dependencies: dsp.nebula-multiplayer-api | hard; dsp.common-api.CommonAPI | hard.

## Installed assembly hashes

| Recorded path | SHA-256 |
|---|---|
| `plugins/CommonAPI-CommonAPI/CommonAPI.dll` | `d4554a63ce05c30903079742dd14e26b332ac5249888d4c6b979fd4f8302aed1` |
| `patchers/CommonAPI-CommonAPI/CommonAPIPreloader.dll` | `a4007a7e1e3188dd13c9e35bc2c8ecf3a2f3d23fe23365ef4130e56fd7d7a36e` |

## Scope and limitations

Not every source project has been rebuilt. Historical compile/test evidence is limited to its recorded hashes. Headless/embedded-Mono checks do not establish real Unity UI, the user's world, all-mod startup, multiplayer or sustained-memory acceptance.
