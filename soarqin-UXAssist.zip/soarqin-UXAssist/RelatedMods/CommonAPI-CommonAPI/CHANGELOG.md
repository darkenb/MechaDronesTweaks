# CommonAPI-CommonAPI — detailed change report

Installed plugin version(s): **1.6.8.0**. Update number-formatting calls and grow the model cache at the exact capacity boundary without losing existing entries.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Scheduler and prototype integrity — 1.6.8

The source corresponding to installed 1.6.7.1 was used with the actual 0.10.35.29104 game references. Old game DLLs from the source repository were not used. Assembly identity `CommonAPI, Version=1.6.7.0` was retained while plugin/file version became 1.6.8.0.

- Recompile ComponentSystem number formatting against the current `WriteKMG` signature.
- Grow the model-prototype cache when the model ID equals its length, preserving existing entries and avoiding a boundary index error for native/modded models.
- Move removed FactorySystem/PlanetFactory/CargoTraffic timing hooks to current GameLogic tasks. Invoke PowerUpdate after native BeforePower, PreUpdate before Facility, Update after LabOutput, and PostUpdate after Digital/Ruin but before FactoryEnd.
- Support the single-thread `threadCount=0` convention. In multithread mode, inspect each extension's applicable interface separately: dispatch parallel interfaces on each worker, otherwise once on the main thread, without double calls.
- Synchronize optional extension-stage entry/exit with the game barrier. Release the exit barrier in `finally` if a callback fails and retain the original native exception. The additional barriers' performance cost needs measurement in game.
- Move StarExtension drawing to `GameLogic.Draw` and Update to the DysonSphereRocket stage. Registered stars still tick without a rocket or DysonSphere object. Do not invent previously unbound star Pre/Power/Post callbacks.
- Remove the early return that skipped later extensions after the first parallel extension in serial fallback. Handle empty stores safely and inspect the relevant instance instead of the first planet/star.

Module-request behavior, public/protected signatures, plugin GUIDs, bundle, save format and existing preloader contract were preserved. The disposable publicized compile reference adds no native method changes or fields beyond the five installed preloaders' contracts; it is not shipped and does not require a preloader upgrade.

Checks cover current API/Harmony targets, public/protected contracts, native IL integrity, four-stage serial/parallel dispatch and actual `HybridBarrier` behavior with delayed workers, callback failure and release of the next stage. UI, graphics, rendering, other mods and performance remain game acceptance work. Existing extension services were adapted; no unnecessary new public service was added.

## Recorded source commits

- `87e5135e5325fc0d02b98ceb91347e406022618b`

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
