using System;
using System.Reflection;
using CommonAPI.Systems;

static class CapacityCheck
{
    static int Main()
    {
        var first = new ModelProto { ID = 1 };
        var array = new ModelProto[2];
        array[1] = first;
        object[] args = { array, array.Length };
        var ensure = typeof(ProtoRegistry).GetMethod("EnsureModelCapacity", BindingFlags.Static | BindingFlags.NonPublic);
        ensure.Invoke(null, args);
        array = (ModelProto[])args[0];
        if (array.Length < 3 || !ReferenceEquals(array[1], first)) throw new Exception("Exact-end model lost or out of bounds");
        array[2] = new ModelProto { ID = 2 };
        args = new object[] { array, 2 };
        ensure.Invoke(null, args);
        if (!ReferenceEquals(args[0], array)) throw new Exception("Existing model capacity unnecessarily replaced");
        Console.WriteLine("PASS exact-end model registration grows capacity and preserves existing prototypes");
        return 0;
    }
}
