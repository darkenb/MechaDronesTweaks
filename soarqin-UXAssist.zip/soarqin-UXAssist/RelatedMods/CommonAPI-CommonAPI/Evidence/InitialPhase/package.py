"""Build, validate and archive CommonAPI. Never install during phase development."""
import importlib.util
import json
from pathlib import Path
import subprocess
import zipfile

PHASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('commonapi_compile', PHASE / 'compile.py')
compiler = importlib.util.module_from_spec(spec)
spec.loader.exec_module(compiler)
b = compiler.build

def main():
    compiler.main()
    info = json.loads((PHASE / 'phase.json').read_text(encoding='utf-8'))
    output = b.OUTPUT / PHASE.name
    original = b.PLUGINS / info['folder'] / 'CommonAPI.dll'
    commands = [
        ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(PHASE / 'validate.ps1'), '-Game', str(b.GAME), '-Core', str(b.CORE), '-Original', str(original), '-Output', str(output), '-Report', str(PHASE / 'validation.json')],
        ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(PHASE.parent / 'audit.ps1'), '-Phase', PHASE.name]]
    log = (PHASE / 'compile.log').read_text(encoding='utf-8')
    for command in commands:
        check = subprocess.run(command, capture_output=True, text=True)
        log += check.stdout + check.stderr
        (PHASE / 'build.log').write_text(log, encoding='utf-8')
        if check.returncode:
            raise RuntimeError(log)
    if b.digest(original) != info['expected_original_sha256']:
        raise RuntimeError('Installed CommonAPI changed during build')
    audit = json.loads((PHASE / 'api-audit.json').read_text(encoding='utf-8-sig'))
    validation = json.loads((PHASE / 'validation.json').read_text(encoding='utf-8-sig'))
    target = output / 'CommonAPI.dll'
    manifest = json.loads((b.PLUGINS / info['folder'] / 'manifest.json').read_text(encoding='utf-8-sig'))
    manifest['version_number'] = info['version']
    (PHASE / 'manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
    result = dict(phase=4, folder=info['folder'], version=info['version'], assembly=info['assembly'],
                  original_relative_path=info['folder'] + '/CommonAPI.dll', original_sha256=b.digest(original),
                  game_sha256=b.digest(b.GAME / 'Assembly-CSharp.dll'), output_sha256=b.digest(target),
                  loose_output=str(target), compiled=True, checks_passed=True, runtime_tested=False, installed=False,
                  api_reference_count=audit['GameReferences'], harmony_patch_count=len(audit['Patches']), api_findings=len(audit['Problems']),
                  source_basis=info['source_basis'], validation=validation,
                  source_sha256={str(p.relative_to(PHASE)): b.digest(p) for p in b.phase_sources(PHASE)},
                  validation_source_sha256={name: b.digest(PHASE / name) for name in ('dispatch-check.cs', 'capacity-check.cs', 'validate.ps1')})
    (PHASE / 'build-result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    archive = PHASE / ('CommonAPI-CommonAPI-' + info['version'] + '.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        z.write(target, 'plugins/CommonAPI-CommonAPI/CommonAPI.dll')
        z.write(b.PLUGINS / info['folder'] / 'commonapi', 'plugins/CommonAPI-CommonAPI/commonapi')
        for path in sorted(PHASE.rglob('*')):
            if path.is_file() and path.suffix.lower() not in ('.zip', '.sha256', '.dll', '.pdb', '.pyc') and not any(part.lower() in ('__pycache__', 'obj', 'bin') for part in path.parts):
                z.write(path, str(path.relative_to(PHASE)))
        for name in ('README.md', 'icon.png'):
            path = b.PLUGINS / info['folder'] / name
            if path.exists(): z.write(path, name)
    with zipfile.ZipFile(archive) as z:
        if z.testzip(): raise RuntimeError('Package CRC failure')
        dlls = [name for name in z.namelist() if name.lower().endswith('.dll')]
        if dlls != ['plugins/CommonAPI-CommonAPI/CommonAPI.dll']: raise RuntimeError('Unexpected DLL in package')
        import hashlib
        if hashlib.sha256(z.read(dlls[0])).hexdigest() != b.digest(target): raise RuntimeError('Package DLL hash mismatch')
    archive.with_suffix('.zip.sha256').write_text(b.digest(archive) + '  ' + archive.name + '\n', encoding='ascii')
    print(log)
    print('Verified package:', archive)

if __name__ == '__main__':
    main()
