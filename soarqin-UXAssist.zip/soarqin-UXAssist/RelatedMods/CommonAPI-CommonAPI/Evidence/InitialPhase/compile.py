"""Compile CommonAPI without executing upstream deployment MSBuild targets."""
import importlib.util
from pathlib import Path
import subprocess
import sys

PHASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('phase_build', PHASE.parent / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)

def main():
    original = build.PLUGINS / 'CommonAPI-CommonAPI/CommonAPI.dll'
    if build.digest(original) != 'a4fa247f22bcf4fab69d780e0ed5a019288c4b5391b03aa9f73a2beea91b96f1':
        raise RuntimeError('Installed CommonAPI changed; revalidate upstream fixes')
    if build.digest(build.GAME / 'Assembly-CSharp.dll') != '6c122e5443e6843979b4064050dfcb5e0d75577a0b64f6ae4111290238b33c12':
        raise RuntimeError('Game baseline changed')
    target_dir = build.OUTPUT / PHASE.name
    preloader = target_dir / 'CommonAPIPreloader.dll'
    refs = build.references()
    refs += [build.CORE / 'Mono.Cecil.dll', build.CORE / 'Mono.Cecil.Rocks.dll']
    preloader_sources = sorted(p for p in (PHASE / 'preloader-src').rglob('*.cs') if not any(part.lower() in ('obj', 'bin') for part in p.parts))
    log = build.compile_cs(preloader_sources, preloader, refs)
    reference_dir = target_dir / 'reference'
    prepared = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(PHASE / 'prepare-reference.ps1'), '-Game', str(build.GAME), '-Core', str(build.CORE), '-Preloader', str(preloader), '-Output', str(reference_dir)], capture_output=True, text=True)
    log += prepared.stdout + prepared.stderr
    if prepared.returncode:
        raise RuntimeError(log)
    refs = [p for p in build.references() if p.name != 'Assembly-CSharp.dll']
    refs += [reference_dir / 'Assembly-CSharp.dll']
    refs += [build.CORE / p for p in ('Mono.Cecil.dll', 'Mono.Cecil.Rocks.dll', 'MonoMod.Utils.dll')]
    refs += [build.PLUGINS / p for p in ('CommonAPI-DSPModSave/DSPModSave.dll', 'nebula-NebulaMultiplayerModApi/NebulaAPI.dll', 'xiaoye97-LDBTool/LDBTool.dll')]
    try:
        log += build.compile_cs(build.phase_sources(PHASE), target_dir / 'CommonAPI.dll', refs)
        check_sources = sorted((PHASE / 'src/Util/Interfaces/Update').glob('*.cs'))
        check_sources += [PHASE / 'src/Util/ExtensionTickDispatch.cs', PHASE / 'dispatch-check.cs']
        check = target_dir / 'DispatchCheck.exe'
        log += build.compile_cs(check_sources, check, build.references(), executable=True)
        result = build.run_check(check, [build.GAME, build.CORE])
        log += result.stdout + result.stderr
        if result.returncode:
            raise RuntimeError('Dispatch checks failed')
        check = target_dir / 'CapacityCheck.exe'
        log += build.compile_cs([PHASE / 'capacity-check.cs'], check, refs + [target_dir / 'CommonAPI.dll'], executable=True)
        result = build.run_check(check, [reference_dir, build.GAME, build.CORE] + [p.parent for p in refs if p.parent.parent == build.PLUGINS])
        log += result.stdout + result.stderr
        if result.returncode:
            raise RuntimeError('Model capacity check failed')
    except RuntimeError as exc:
        log += str(exc)
        raise
    finally:
        (PHASE / 'compile.log').write_text(log, encoding='utf-8')
    print(log)

if __name__ == '__main__':
    main()
