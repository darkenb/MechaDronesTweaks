param([string]$Game, [string]$Core, [string]$Original, [string]$Output, [string]$Report)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $Core 'Mono.Cecil.dll')
$old = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Original)
$new = [Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $Output 'CommonAPI.dll'))
$gameAssembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $Game 'Assembly-CSharp.dll'))
$reference = [Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $Output 'reference/Assembly-CSharp.dll'))
try {
    if ($old.Name.FullName -ne $new.Name.FullName) { throw 'CommonAPI assembly identity changed' }
    $members = @{}
    foreach ($type in $new.MainModule.GetTypes()) {
        $members[$type.FullName] = $true
        foreach ($member in @($type.Methods) + @($type.Fields)) { $members[$member.FullName] = $true }
    }
    $checked = 0
    foreach ($type in $old.MainModule.GetTypes()) {
        if (-not ($type.IsPublic -or $type.IsNestedPublic -or $type.IsNestedFamily)) { continue }
        if (-not $members.ContainsKey($type.FullName)) { throw ('Removed public type: ' + $type.FullName) }
        foreach ($member in @($type.Methods) + @($type.Fields)) {
            if ($member.IsPublic -or $member.IsFamily -or $member.IsFamilyOrAssembly) {
                if (-not $members.ContainsKey($member.FullName)) { throw ('Removed public member: ' + $member.FullName) }
                $checked++
            }
        }
    }
    $oldTypes = @{}
    foreach ($type in $gameAssembly.MainModule.GetTypes()) { $oldTypes[$type.FullName] = $type }
    $methodCount = 0
    $injected = @()
    foreach ($type in $reference.MainModule.GetTypes()) {
        $oldType = $oldTypes[$type.FullName]
        if (-not $oldType) { throw ('Unexpected reference type: ' + $type.FullName) }
        $oldFields = @{}
        foreach ($field in $oldType.Fields) { $oldFields[$field.FullName] = $true }
        foreach ($field in $type.Fields) { if (-not $oldFields.ContainsKey($field.FullName)) { $injected += $field.FullName } }
        if ($type.Methods.Count -ne $oldType.Methods.Count) { throw 'Reference method count changed' }
        for ($index = 0; $index -lt $type.Methods.Count; $index++) {
            $before = $oldType.Methods[$index]; $after = $type.Methods[$index]
            if ($before.FullName -ne $after.FullName -or $before.HasBody -ne $after.HasBody) { throw 'Reference method signature changed' }
            if ($before.HasBody) {
                $beforeIL = ($before.Body.Instructions | ForEach-Object ToString) -join "`n"
                $afterIL = ($after.Body.Instructions | ForEach-Object ToString) -join "`n"
                if ($beforeIL -cne $afterIL) { throw ('Reference IL changed: ' + $before.FullName) }
                $methodCount++
            }
        }
    }
    $expected = @('System.Int32 EntityData::customId', 'System.Int32 EntityData::customType',
        'System.Collections.Generic.Dictionary`2<System.String,System.Object> EntityData::customData',
        'System.Collections.Generic.Dictionary`2<System.String,System.Object> PrefabDesc::customData',
        'ERecipeType ERecipeType::Custom')
    if (Compare-Object ($expected | Sort-Object) ($injected | Sort-Object)) { throw 'Unexpected preloader field injection' }
    $enum = $reference.MainModule.Types | Where-Object Name -eq ERecipeType
    if (($enum.Fields | Where-Object Name -eq Custom).Constant -ne 20) { throw 'Custom recipe enum value changed' }
    $result = @{ assembly_identity = $new.Name.FullName; public_members_preserved = $checked;
        native_method_bodies_unchanged = $methodCount; injected_fields = $injected; passed = $true }
    $result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $Report -Encoding UTF8
    Write-Output ('PASS: {0} public members preserved, {1} native IL bodies unchanged, five expected preloader fields.' -f $checked, $methodCount)
} finally { $old.Dispose(); $new.Dispose(); $gameAssembly.Dispose(); $reference.Dispose() }
