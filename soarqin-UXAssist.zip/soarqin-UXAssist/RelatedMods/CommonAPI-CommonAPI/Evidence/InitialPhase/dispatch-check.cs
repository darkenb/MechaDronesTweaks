using System;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Threading;
using CommonAPI;
class DispatchCheck
{
    class Serial : IPowerUpdate, IPreUpdate, IUpdate, IPostUpdate
    {
        public int[] calls = new int[4];
        public void PowerUpdate() { calls[0]++; }
        public void PreUpdate() { calls[1]++; }
        public void Update() { calls[2]++; }
        public void PostUpdate() { calls[3]++; }
    }
    class Parallel : Serial, IPowerUpdateMultithread, IPreUpdateMultithread, IUpdateMultithread, IPostUpdateMultithread
    {
        public int[,] workerCalls = new int[4, 4];
        void Record(int stage, int threads, int ordinal, int minimum) {
            if (threads != 4 || ordinal < 0 || ordinal >= threads || minimum != 4) throw new Exception("Invalid worker arguments");
            workerCalls[stage, ordinal]++;
        }
        public void PowerUpdateMultithread(int t, int o, int m) { Record(0, t, o, m); }
        public void PreUpdateMultithread(int t, int o, int m) { Record(1, t, o, m); }
        public void UpdateMultithread(int t, int o, int m) { Record(2, t, o, m); }
        public void PostUpdateMultithread(int t, int o, int m) { Record(3, t, o, m); }
    }
    static void Assert(bool condition, string message) { if (!condition) throw new Exception(message); }
    [MethodImpl(MethodImplOptions.NoInlining)]
    static void CheckBarrier() {
        var logic = (GameLogic)FormatterServices.GetUninitializedObject(typeof(GameLogic));
        var controller = (GameThreadController)FormatterServices.GetUninitializedObject(typeof(GameThreadController));
        var manager = (ThreadManager)FormatterServices.GetUninitializedObject(typeof(ThreadManager));
        var barrier = new HybridBarrier(5, 5);
        for (int i = 0; i < 5; i++) barrier.EnableParticipant(i);
        typeof(ThreadManager).GetField("<phaseBarrier>k__BackingField", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(manager, barrier);
        typeof(GameThreadController).GetField("<threadManager>k__BackingField", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(controller, manager);
        logic.threadController = controller;
        int ready = 0, callbacks = 0, errors = 0;
        Exception failure = null;
        var workers = new Thread[5];
        for (int index = 0; index < 5; index++) {
            int ordinal = index - 1;
            workers[index] = new Thread(() => {
                try {
                    if (ordinal == 2) Thread.Sleep(40);
                    Interlocked.Increment(ref ready);
                    try {
                        ExtensionTickDispatch.Synchronize(logic, ordinal, 4, () => {
                            Assert(Volatile.Read(ref ready) == 5, "Callback before native workers finished");
                            Interlocked.Increment(ref callbacks);
                            if (ordinal == -1) throw new InvalidOperationException("Injected extension failure");
                        });
                    } catch (InvalidOperationException) { Interlocked.Increment(ref errors); }
                    Assert(Volatile.Read(ref callbacks) == 5, "Next stage before all callbacks finished");
                    ExtensionTickDispatch.Synchronize(logic, ordinal, 4, () => Interlocked.Increment(ref callbacks));
                } catch (Exception error) { Interlocked.CompareExchange(ref failure, error, null); }
            });
            workers[index].IsBackground = true;
            workers[index].Start();
        }
        foreach (var worker in workers) Assert(worker.Join(5000), "Barrier deadlock");
        if (failure != null) throw failure;
        Assert(errors == 1 && callbacks == 10 && barrier.currentPhase == 4, "Failure release and consecutive phase counts");
        barrier.Dispose();
        Console.WriteLine("PASS: real game HybridBarrier, five participants, delayed worker, callback failure, release and next phase.");
    }
    static void Main(string[] args) {
        AppDomain.CurrentDomain.AssemblyResolve += (sender, eventArgs) => {
            string name = new AssemblyName(eventArgs.Name).Name + ".dll";
            foreach (string directory in args) {
                string path = Path.Combine(directory, name);
                if (File.Exists(path)) return Assembly.LoadFrom(path);
            }
            return null;
        };
        try {
            for (int stage = 0; stage < 4; stage++) {
                var serial = new Serial(); var multi = new Parallel();
                for (int ordinal = -1; ordinal < 4; ordinal++) {
                    ExtensionTickDispatch.Run(serial, stage, ordinal, 4, 4);
                    ExtensionTickDispatch.Run(multi, stage, ordinal, 4, 4);
                }
                Assert(serial.calls[stage] == 1, "Serial fallback must run once on main");
                Assert(multi.calls[stage] == 0, "No serial duplicate for multithread extension");
                for (int ordinal = 0; ordinal < 4; ordinal++) Assert(multi.workerCalls[stage, ordinal] == 1, "Every worker exactly once");
                ExtensionTickDispatch.Run(multi, stage, -1, 1, 4);
                ExtensionTickDispatch.Run(multi, stage, 0, 1, 4);
                Assert(multi.calls[stage] == 1, "Single-thread mode uses serial interface once");
                ExtensionTickDispatch.Run(serial, stage, -2, 4, 4);
                ExtensionTickDispatch.Run(serial, stage, 4, 4, 4);
                ExtensionTickDispatch.Run(serial, stage, -1, -1, 4);
                ExtensionTickDispatch.Run(null, stage, -1, 4, 4);
                Assert(serial.calls[stage] == 1, "Invalid scheduling must not invoke callback");
                ExtensionTickDispatch.Run(serial, stage, -1, 0, 4);
                Assert(serial.calls[stage] == 2, "Zero workers uses main-thread fallback");
            }
            Console.WriteLine("PASS: four stages, mixed serial/parallel, worker ordinals, no duplicate callbacks, single-thread fallback, invalid scheduling.");
            CheckBarrier();
        } catch (Exception error) { Console.Error.WriteLine(error); Environment.ExitCode = 1; }
    }
}
