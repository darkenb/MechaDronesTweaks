using System;

namespace CommonAPI
{
    internal static class ExtensionTickDispatch
    {
        internal static void Synchronize(GameLogic logic, int ordinal, int threads, Action callback)
        {
            if (threads <= 1) { if (ordinal == -1) callback(); return; }
            var barrier = logic.threadController.threadManager.phaseBarrier;
            int participant = ordinal + 1;
            barrier.SignalAndWait(participant);
            try { callback(); }
            finally { barrier.SignalAndWait(participant); }
        }
        internal static void Run(object extension, int stage, int ordinal, int threads, int minimum)
        {
            if (extension == null || threads < 0 || ordinal < -1) return;
            if (threads == 0) threads = 1;
            if (ordinal >= threads) return;
            bool parallel = threads > 1;
            bool main = ordinal == -1;
            switch (stage)
            {
                case 0:
                    if (parallel && extension is IPowerUpdateMultithread powerMulti) {
                        if (!main) powerMulti.PowerUpdateMultithread(threads, ordinal, minimum);
                    } else if (main && extension is IPowerUpdate power) power.PowerUpdate();
                    break;
                case 1:
                    if (parallel && extension is IPreUpdateMultithread preMulti) {
                        if (!main) preMulti.PreUpdateMultithread(threads, ordinal, minimum);
                    } else if (main && extension is IPreUpdate pre) pre.PreUpdate();
                    break;
                case 2:
                    if (parallel && extension is IUpdateMultithread updateMulti) {
                        if (!main) updateMulti.UpdateMultithread(threads, ordinal, minimum);
                    } else if (main && extension is IUpdate update) update.Update();
                    break;
                case 3:
                    if (parallel && extension is IPostUpdateMultithread postMulti) {
                        if (!main) postMulti.PostUpdateMultithread(threads, ordinal, minimum);
                    } else if (main && extension is IPostUpdate post) post.PostUpdate();
                    break;
            }
        }
    }
}
