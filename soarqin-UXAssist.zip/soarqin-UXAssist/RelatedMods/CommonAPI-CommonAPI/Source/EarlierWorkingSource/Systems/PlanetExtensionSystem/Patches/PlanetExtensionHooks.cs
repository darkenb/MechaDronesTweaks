﻿using System;
using CommonAPI.Systems;
using HarmonyLib;
// ReSharper disable InconsistentNaming
// ReSharper disable UnusedParameter.Global
// ReSharper disable RedundantAssignment

namespace CommonAPI.Patches
{


    [HarmonyPatch]
    public static class PlanetExtensionHooks
    {
        
        [HarmonyPostfix]
        [HarmonyPatch(typeof(FactoryModel), "OnCameraPostRender")]
        public static void OnRender(FactoryModel __instance)
        {
            if (__instance.planet == null || !__instance.planet.factoryLoaded || __instance.planet != GameMain.localPlanet) return;
            
            PlanetExtensionSystem.DrawUpdate(__instance.planet.factory);
        }

        // Synchronize only while this optional module is loaded. Native per-task errors
        // still reach the finalizer, so every participant releases the extension barrier.
        [HarmonyPatch(typeof(GameLogic), "OnGameLogicFrame")]
        [HarmonyPrefix]
        public static void BeforeFrame(GameLogic __instance, int iTask, int threadOrdinal, int threadCount,
            PlanetFactory[] ___factories, int ___factoryCount)
        {
            int stage = iTask == (int)EGameLogicTask.FactoryFacility ? 1 :
                iTask == (int)EGameLogicTask.FactoryEnd ? 3 : -1;
            if (stage < 0) return;
            ExtensionTickDispatch.Synchronize(__instance, threadOrdinal, threadCount,
                () => Dispatch(___factories, ___factoryCount, stage, threadOrdinal, threadCount));
        }

        [HarmonyPatch(typeof(GameLogic), "OnGameLogicFrame")]
        [HarmonyFinalizer]
        public static Exception AfterFrame(Exception __exception, GameLogic __instance, int iTask,
            int threadOrdinal, int threadCount, PlanetFactory[] ___factories, int ___factoryCount)
        {
            int stage = iTask == (int)EGameLogicTask.FactoryBeforePower ? 0 :
                iTask == (int)EGameLogicTask.FactoryLabOutput ? 2 : -1;
            if (stage < 0) return __exception;
            try {
                ExtensionTickDispatch.Synchronize(__instance, threadOrdinal, threadCount,
                    () => Dispatch(___factories, ___factoryCount, stage, threadOrdinal, threadCount));
            } catch (Exception callbackError) {
                return __exception == null ? callbackError : new AggregateException(__exception, callbackError);
            }
            return __exception;
        }

        // Binary compatibility entry points. Scheduling attributes now live on GameLogic hooks.
        public static void PowerTick(FactorySystem __instance, long time, bool isActive) { PlanetExtensionSystem.PowerUpdate(__instance.factory); }
        public static void PreUpdate(FactorySystem __instance, long time, bool isActive) { PlanetExtensionSystem.PreUpdate(__instance.factory); }
        public static void Update(FactorySystem __instance, long time, bool isActive) { PlanetExtensionSystem.Update(__instance.factory); }
        public static void PostUpdate(PlanetFactory __instance, long time) { PlanetExtensionSystem.PostUpdate(__instance); }
        public static void PostUpdateSinglethread() { PlanetExtensionSystem.PostUpdateOnlySinglethread(GameMain.data); }
        public static void PowerTickMultithread(FactorySystem __instance, long time, bool isActive, int _usedThreadCnt, int _curThreadIdx) { PlanetExtensionSystem.PowerUpdateMultithread(__instance.factory, _usedThreadCnt, _curThreadIdx, 4); }
        public static void PreUpdateMultithread(FactorySystem __instance, long time, bool isActive, int _usedThreadCnt, int _curThreadIdx) { PlanetExtensionSystem.PreUpdateMultithread(__instance.factory, _usedThreadCnt, _curThreadIdx, 4); }
        public static void UpdateMultithread(FactorySystem __instance, long time, bool isActive, int _usedThreadCnt, int _curThreadIdx) { PlanetExtensionSystem.UpdateMultithread(__instance.factory, _usedThreadCnt, _curThreadIdx, 4); }
        public static void PostUpdateMultithread(CargoTraffic __instance, bool presentCargos, int _usedThreadCnt, int _curThreadIdx) { PlanetExtensionSystem.PostUpdateMultithread(__instance.factory, _usedThreadCnt, _curThreadIdx, 4); }

        internal static void Dispatch(PlanetFactory[] factories, int count, int stage, int ordinal, int threads)
        {
            if (factories == null || (threads <= 1 && ordinal != -1)) return;
            for (int i = 0; i < Math.Min(count, factories.Length); i++)
            {
                var factory = factories[i];
                if (factory == null) continue;
                for (int j = 1; j < PlanetExtensionSystem.extensions.Count; j++)
                {
                    var storage = PlanetExtensionSystem.extensions[j];
                    if (storage == null) continue;
                    ExtensionTickDispatch.Run(storage.GetExtension(factory), stage, ordinal, threads, 4);
                }
            }
        }

        [HarmonyPatch(typeof(PlanetFactory), "CreateEntityLogicComponents")]
        [HarmonyPostfix]
        public static void AddComponents(int entityId, PrefabDesc desc, int prebuildId, PlanetFactory __instance)
        {
            PlanetExtensionSystem.CreateEntityComponents(__instance, entityId, desc, prebuildId);
        }

        [HarmonyPatch(typeof(PlanetFactory), "RemoveEntityWithComponents")]
        [HarmonyPrefix]
        public static void RemoveComponents(int id, PlanetFactory __instance)
        {
            PlanetExtensionSystem.RemoveEntityComponents(__instance, id);
        }
        
        [HarmonyPatch(typeof(GameData), "GetOrCreateFactory")]
        [HarmonyPostfix]
        public static void LoadNewPlanet(PlanetData planet)
        {
            PlanetExtensionSystem.InitNewPlanet(planet);
        }
    }
}
