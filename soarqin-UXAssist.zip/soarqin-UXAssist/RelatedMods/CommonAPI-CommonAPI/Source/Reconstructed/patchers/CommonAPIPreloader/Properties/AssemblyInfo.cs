using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyFileVersion("1.6.7.1")]
[assembly: AssemblyInformationalVersion("1.6.7.1+87e5135")]
[assembly: AssemblyCompany("CommonAPIPreloader")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyProduct("CommonAPIPreloader")]
[assembly: AssemblyTitle("CommonAPIPreloader")]
[assembly: AssemblyVersion("1.6.7.0")]
