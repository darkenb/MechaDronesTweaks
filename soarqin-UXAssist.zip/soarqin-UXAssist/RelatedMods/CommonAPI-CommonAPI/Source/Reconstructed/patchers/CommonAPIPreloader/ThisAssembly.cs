using System;
using System.CodeDom.Compiler;
using System.Diagnostics.CodeAnalysis;

[GeneratedCode("Nerdbank.GitVersioning.Tasks", "3.8.118.27059")]
[ExcludeFromCodeCoverage]
internal static class ThisAssembly
{
	internal const string AssemblyConfiguration = "Release";

	internal const string AssemblyFileVersion = "1.6.7.1";

	internal const string AssemblyInformationalVersion = "1.6.7.1+87e5135";

	internal const string AssemblyName = "CommonAPIPreloader";

	internal const string AssemblyTitle = "CommonAPIPreloader";

	internal const string AssemblyVersion = "1.6.7.0";

	internal static readonly DateTime GitCommitAuthorDate = new DateTime(638949475960000000L, DateTimeKind.Utc);

	internal static readonly DateTime GitCommitDate = new DateTime(638949475960000000L, DateTimeKind.Utc);

	internal const string GitCommitId = "87e5135e5325fc0d02b98ceb91347e406022618b";

	internal const bool IsPrerelease = false;

	internal const bool IsPublicRelease = true;

	internal const string RootNamespace = "CommonAPIPreloader";
}
