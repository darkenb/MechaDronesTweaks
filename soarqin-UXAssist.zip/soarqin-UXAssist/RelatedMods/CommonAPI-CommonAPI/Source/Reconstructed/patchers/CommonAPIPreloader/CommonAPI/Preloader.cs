using System.Collections.Generic;
using System.Linq;
using BepInEx.Logging;
using Mono.Cecil;
using Mono.Cecil.Rocks;

namespace CommonAPI;

public static class Preloader
{
	public static ManualLogSource logSource;

	public static IEnumerable<string> TargetDLLs { get; } = new string[1] { "Assembly-CSharp.dll" };

	public static void Initialize()
	{
		logSource = Logger.CreateLogSource("Common API Preloader");
	}

	public static void Patch(AssemblyDefinition assembly)
	{
		ModuleDefinition mainModule = assembly.MainModule;
		TypeDefinition typeDefinition = mainModule.Types.First((TypeDefinition t) => t.FullName == "EntityData");
		TypeDefinition typeDefinition2 = mainModule.Types.First((TypeDefinition t) => t.FullName == "PrefabDesc");
		TypeDefinition typeDefinition3 = mainModule.Types.First((TypeDefinition t) => t.FullName == "ERecipeType");
		if (typeDefinition == null || typeDefinition2 == null || typeDefinition3 == null)
		{
			logSource.LogInfo("Preloader patching failed!");
			return;
		}
		FieldDefinition item = new FieldDefinition("Custom", FieldAttributes.Public | FieldAttributes.Static | FieldAttributes.Literal | FieldAttributes.HasDefault, typeDefinition3)
		{
			Constant = 20
		};
		typeDefinition3.Fields.Add(item);
		typeDefinition.Fields.Add(new FieldDefinition("customId", FieldAttributes.Public, mainModule.ImportReference(typeof(int))));
		typeDefinition.Fields.Add(new FieldDefinition("customType", FieldAttributes.Public, mainModule.ImportReference(typeof(int))));
		typeDefinition.Fields.Add(new FieldDefinition("customData", FieldAttributes.Public, mainModule.ImportReference(typeof(Dictionary<, >)).MakeGenericInstanceType(mainModule.TypeSystem.String, mainModule.TypeSystem.Object)));
		typeDefinition2.Fields.Add(new FieldDefinition("customData", FieldAttributes.Public, mainModule.ImportReference(typeof(Dictionary<, >)).MakeGenericInstanceType(mainModule.TypeSystem.String, mainModule.TypeSystem.Object)));
		logSource.LogInfo("Preloader patching is successful!");
	}
}
