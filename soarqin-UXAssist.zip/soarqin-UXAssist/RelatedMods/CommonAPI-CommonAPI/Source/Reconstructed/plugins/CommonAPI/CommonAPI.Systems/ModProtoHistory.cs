using System;
using System.Collections.Generic;
using System.IO;
using CommonAPI.Patches;

namespace CommonAPI.Systems;

internal static class ModProtoHistory
{
	public static readonly Dictionary<string, List<int>> modMachines = new Dictionary<string, List<int>>();

	public static readonly Dictionary<string, List<int>> missingMachines = new Dictionary<string, List<int>>();

	private static readonly Dictionary<string, int> removedMachines = new Dictionary<string, int>();

	internal static void AddModMachine(string modGUID, int itemID)
	{
		if (modMachines.ContainsKey(modGUID))
		{
			if (!modMachines[modGUID].Contains(itemID))
			{
				modMachines[modGUID].Add(itemID);
			}
		}
		else
		{
			modMachines.Add(modGUID, new List<int> { itemID });
		}
	}

	internal static void AddMissingMachine(string modGUID, int itemID)
	{
		if (missingMachines.ContainsKey(modGUID))
		{
			if (!missingMachines[modGUID].Contains(itemID))
			{
				missingMachines[modGUID].Add(itemID);
				CommonAPIPlugin.logger.LogInfo($"Machine from {modGUID} mod with proto ID {itemID} is missing!");
			}
		}
		else
		{
			missingMachines.Add(modGUID, new List<int> { itemID });
			CommonAPIPlugin.logger.LogInfo($"Machine from {modGUID} mod with proto ID {itemID} is missing!");
		}
	}

	private static void IncrementRemoved(string modGUID)
	{
		if (removedMachines.ContainsKey(modGUID))
		{
			removedMachines[modGUID]++;
		}
		else
		{
			removedMachines.Add(modGUID, 1);
		}
	}

	internal static bool IsMachineMissing(int itemID, out string modGUID)
	{
		foreach (KeyValuePair<string, List<int>> missingMachine in missingMachines)
		{
			if (missingMachine.Value.Contains(itemID))
			{
				modGUID = missingMachine.Key;
				return true;
			}
		}
		modGUID = "";
		return false;
	}

	internal static void CheckMissingMachines()
	{
		CommonAPIPlugin.logger.LogInfo("Checking missing machines!");
		for (int i = 0; i < GameMain.data.factoryCount; i++)
		{
			PlanetFactory planetFactory = GameMain.data.factories[i];
			if (planetFactory == null)
			{
				continue;
			}
			for (int j = 1; j < planetFactory.entityCursor; j++)
			{
				if (planetFactory.entityPool[j].id != j)
				{
					continue;
				}
				int protoId = planetFactory.entityPool[j].protoId;
				if (IsMachineMissing(protoId, out var modGUID))
				{
					try
					{
						CommonAPIPlugin.logger.LogInfo($"Removing entity ID: {j}, proto ID: {protoId} from mod {modGUID}");
						planetFactory.RemoveEntityWithComponents(j, returnItems: false);
						IncrementRemoved(modGUID);
					}
					catch (Exception arg)
					{
						CommonAPIPlugin.logger.LogWarning($"Error while removing!\n{arg}");
					}
				}
			}
		}
	}

	internal static void DisplayRemovedMessage()
	{
		if (removedMachines.Count <= 0)
		{
			return;
		}
		string text = "";
		foreach (KeyValuePair<string, int> removedMachine in removedMachines)
		{
			if (removedMachine.Value > 0)
			{
				text = $"{text}\r\nRemoved {removedMachine.Value} machines from {removedMachine.Key} mod";
			}
		}
		if (!text.Equals(""))
		{
			UIMessageBox.Show("ModItemMissingWarnTitle".Translate(), "ModItemMissingWarnDesc".Translate() + text, "确定".Translate(), 0);
		}
	}

	internal static void Export(BinaryWriter w)
	{
		w.Write((byte)0);
		w.Write(ProtoRegistry.Instance.Loaded);
		if (!ProtoRegistry.Instance.Loaded)
		{
			return;
		}
		w.Write((byte)modMachines.Count);
		foreach (KeyValuePair<string, List<int>> modMachine in modMachines)
		{
			w.Write(modMachine.Key);
			w.Write((short)modMachine.Value.Count);
			foreach (int item in modMachine.Value)
			{
				w.Write(item);
			}
		}
	}

	internal static void Import(BinaryReader r)
	{
		removedMachines.Clear();
		ProtoSet_Patch.isEnabled = false;
		r.ReadByte();
		if (!r.ReadBoolean())
		{
			return;
		}
		int num = r.ReadByte();
		for (int i = 0; i < num; i++)
		{
			string text = r.ReadString();
			int num2 = r.ReadInt16();
			if (text.Equals("Unknown") || text.IsModInstalled())
			{
				for (int j = 0; j < num2; j++)
				{
					int num3 = r.ReadInt32();
					if (LDB.items.Select(num3) == null)
					{
						AddMissingMachine(text, num3);
					}
				}
			}
			else
			{
				for (int k = 0; k < num2; k++)
				{
					int itemID = r.ReadInt32();
					AddMissingMachine(text, itemID);
				}
			}
		}
		ProtoSet_Patch.isEnabled = true;
	}

	internal static void InitOnLoad()
	{
		removedMachines.Clear();
	}
}
