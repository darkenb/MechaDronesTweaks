using System;
using System.Linq;
using BepInEx.Configuration;
using HarmonyLib;

namespace CommonAPI;

public class AcceptableValueOptionsList : AcceptableValueBase
{
	public string[] AcceptableValues { get; }

	public AcceptableValueOptionsList(string[] acceptableValues)
		: base(typeof(string))
	{
		if (acceptableValues == null)
		{
			throw new ArgumentNullException("acceptableValues");
		}
		if (acceptableValues.Length == 0)
		{
			throw new ArgumentException("At least one acceptable value is needed", "acceptableValues");
		}
		AcceptableValues = acceptableValues;
	}

	public override object Clamp(object value)
	{
		if (!(value is string text))
		{
			return "";
		}
		return (from s in text.Split(new char[1] { ',' })
			select s.Trim() into s
			where AcceptableValues.Contains(s)
			select s).Join();
	}

	public override bool IsValid(object value)
	{
		if (!(value is string text))
		{
			return false;
		}
		return text.Split(new char[1] { ',' }).All((string s) => AcceptableValues.Contains(s.Trim()));
	}

	public override string ToDescriptionString()
	{
		return "# Acceptable values: " + string.Join(", ", AcceptableValues.Select((string x) => x.ToString()).ToArray()) + "\n# Multiple values can be set at the same time by separating them with , (e.g. Debug, Warning)";
	}
}
