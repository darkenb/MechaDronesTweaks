namespace CommonAPI.Systems;

public interface IPlanetExtension : ISerializeState
{
	void Init(PlanetFactory factory);
}
