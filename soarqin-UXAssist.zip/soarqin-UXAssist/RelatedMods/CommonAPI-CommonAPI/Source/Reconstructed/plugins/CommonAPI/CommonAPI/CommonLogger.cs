namespace CommonAPI;

public class CommonLogger
{
	public static ICommonLogger logger;

	public static void SetLogger(ICommonLogger _logger)
	{
		logger = _logger;
	}
}
