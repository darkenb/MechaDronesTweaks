using UnityEngine;

namespace CommonAPI.ShotScene;

public class TPCameraController : MonoBehaviour
{
	public Transform lookAt;

	public Camera camera;

	private float currentX = 70f;

	private float currentY = 40f;

	public float yAngleMin = 10f;

	public float yAngleMax = 85f;

	public float cameraDistance = 100f;

	public float minCameraDistance = 1f;

	public float scrollSensitivity = 20f;

	public float sensitivity = 3f;

	public Vector3 cameraOffset = new Vector3(0f, 2f, 0f);

	private float currentDistance;

	private void Start()
	{
		currentY = Mathf.Clamp(currentY, yAngleMin, yAngleMax);
		currentDistance = 10f;
		camera = GetComponent<Camera>();
	}

	public void RecalculatePosition()
	{
		if (!(lookAt == null))
		{
			Vector3 vector = new Vector3(0f, 0f, 0f - currentDistance);
			Quaternion quaternion = Quaternion.Euler(currentY, currentX, 0f);
			Vector3 vector2 = lookAt.position + cameraOffset;
			base.transform.position = vector2 + quaternion * vector;
			base.transform.LookAt(vector2);
		}
	}

	private void Update()
	{
		if (!GeneratorSceneController.pointerInside)
		{
			float num = (0f - Input.mouseScrollDelta.y) * scrollSensitivity;
			currentDistance += num * Time.deltaTime;
			currentDistance = Mathf.Clamp(currentDistance, minCameraDistance, cameraDistance);
			if (Input.GetMouseButton(0))
			{
				currentX += Input.GetAxis("Mouse X") * sensitivity;
				currentY += (0f - Input.GetAxis("Mouse Y")) * sensitivity;
				currentY = Mathf.Clamp(currentY, yAngleMin, yAngleMax);
			}
		}
	}

	private void LateUpdate()
	{
		RecalculatePosition();
	}
}
