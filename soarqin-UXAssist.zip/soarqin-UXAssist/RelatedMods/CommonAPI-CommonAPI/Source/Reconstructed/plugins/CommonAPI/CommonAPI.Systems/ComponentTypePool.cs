using System;

namespace CommonAPI.Systems;

public class ComponentTypePool : Pool<FactoryComponent>, IPoolable, ISerializeState
{
	public int id;

	public const float DT = 1f / 60f;

	private PlanetFactory factory;

	private int PoolTypeId;

	private FactoryComponent lastAddedComponent;

	private PrebuildData lastAddedData;

	private Action<FactoryComponent> _cachedInitUpdate;

	private Action<FactoryComponent> _cachedInitPowerUpdate;

	public ComponentTypePool(PlanetFactory factory, int type)
	{
		this.factory = factory;
		PoolTypeId = type;
		_cachedInitUpdate = _internalInitUpdate;
		_cachedInitPowerUpdate = _internalInitPowerUpdate;
	}

	public ComponentTypePool()
	{
	}

	public int AddComponent(int entityId, PrebuildData data = default(PrebuildData))
	{
		return AddPoolItem(new object[2] { entityId, data });
	}

	protected override FactoryComponent GetNewInstance()
	{
		return ComponentExtension.componentRegistry.GetNew(PoolTypeId);
	}

	public void OnPostComponentAdded()
	{
		if (lastAddedComponent != null)
		{
			lastAddedComponent.OnAdded(lastAddedData, factory);
			lastAddedComponent = null;
		}
	}

	protected override void InitPoolItem(FactoryComponent item, object[] data)
	{
		int num = (int)data[0];
		int powerConId = factory.entityPool[num].powerConId;
		item.entityId = num;
		item.pcId = powerConId;
		factory.entityPool[num].customId = item.id;
		factory.entityPool[num].customType = PoolTypeId;
		lastAddedComponent = item;
		lastAddedData = (PrebuildData)data[1];
	}

	protected override void RemovePoolItem(FactoryComponent item)
	{
		item.OnRemoved(factory);
		base.RemovePoolItem(item);
	}

	protected override Action<FactoryComponent> InitUpdate()
	{
		return _cachedInitUpdate;
	}

	private void _internalInitUpdate(FactoryComponent item)
	{
		PowerSystem powerSystem = factory.powerSystem;
		PowerConsumerComponent[] consumerPool = powerSystem.consumerPool;
		float[] networkServes = powerSystem.networkServes;
		AnimData[] entityAnimPool = factory.entityAnimPool;
		SignData[] entitySignPool = factory.entitySignPool;
		int[][] entityNeeds = factory.entityNeeds;
		int entityId = item.entityId;
		float power = networkServes[consumerPool[item.pcId].networkId];
		int updateResult = item.InternalUpdate(power, factory);
		item.UpdateAnimation(ref entityAnimPool[entityId], updateResult, power);
		entityAnimPool[entityId].power = power;
		item.UpdateSigns(ref entitySignPool[entityId], updateResult, power, factory);
		entityNeeds[entityId] = item.UpdateNeeds();
	}

	public Action<FactoryComponent> InitPowerUpdate()
	{
		return _cachedInitPowerUpdate;
	}

	private void _internalInitPowerUpdate(FactoryComponent item)
	{
		PowerConsumerComponent[] consumerPool = factory.powerSystem.consumerPool;
		item.UpdatePowerState(ref consumerPool[item.pcId]);
	}

	public int GetId()
	{
		return id;
	}

	public void SetId(int id)
	{
		this.id = id;
	}
}
