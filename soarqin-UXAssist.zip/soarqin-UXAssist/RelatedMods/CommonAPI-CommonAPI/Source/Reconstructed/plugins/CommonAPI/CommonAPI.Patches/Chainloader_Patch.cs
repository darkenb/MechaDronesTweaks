using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection.Emit;
using BepInEx;
using CommonAPI.Systems;
using HarmonyLib;

namespace CommonAPI.Patches;

public static class Chainloader_Patch
{
	private delegate T2 RefAction<T, out T2>(ref T arg);

	private const int OverrideKeysNewSize = 512;

	[HarmonyPatch(typeof(GameOption), "ImportXML")]
	[HarmonyPrefix]
	public static void AfterAllLoaded()
	{
		Array.Resize(ref VFInput.override_keys, 512);
		Array.Resize(ref DSPGame.globalOption.overrideKeys, 512);
		Array.Resize(ref DSPGame.globalOption.overrideKeysChanged, 512);
		CommonAPIPlugin.logger.LogDebug("Loading config file");
		string path = Paths.ConfigPath + "/CommonAPI/keybinds";
		try
		{
			FileStream fileStream = File.OpenRead(path);
			CustomKeyBindSystem.Import(new BinaryReader(fileStream));
			fileStream.Dispose();
			return;
		}
		catch (Exception)
		{
			CommonAPIPlugin.logger.LogDebug("keybinds not found, fallbacking to load legacy keybindmapping");
		}
		path = Paths.ConfigPath + "/CommonAPI/keybindmapping";
		try
		{
			FileStream fileStream2 = File.OpenRead(path);
			BinaryReader r = new BinaryReader(fileStream2);
			CustomKeyBindSystem.keyRegistry.Import(r);
			fileStream2.Dispose();
		}
		catch (Exception)
		{
			CommonAPIPlugin.logger.LogDebug("Error loading keybind file.");
		}
	}

	[HarmonyPatch(typeof(GameOption), "Apply")]
	[HarmonyPostfix]
	public static void SaveKeyBindsOnApplyOptions()
	{
		CommonAPIPlugin.logger.LogDebug("saving config file");
		Directory.CreateDirectory(Paths.ConfigPath + "/CommonAPI/");
		FileStream fileStream = File.Create(Paths.ConfigPath + "/CommonAPI/keybinds");
		CustomKeyBindSystem.Export(new BinaryWriter(fileStream));
		fileStream.Dispose();
	}

	[HarmonyPatch(typeof(GameOption), "InitKeys")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> PatchInitKeys(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator).MatchForward(false, new CodeMatch(OpCodes.Ldc_I4, 256));
		codeMatcher.Set(OpCodes.Ldc_I4, 512);
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(UIOptionWindow), "_OnOpen")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> PatchOverrideKeysLength(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator).MatchForward(false, new CodeMatch(OpCodes.Ldc_I4), new CodeMatch((CodeInstruction ci) => ci.IsStloc()), new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldflda, AccessTools.Field(typeof(UIOptionWindow), "tempOption")), new CodeMatch((CodeInstruction ci) => ci.IsLdloc()), new CodeMatch(OpCodes.Newarr, typeof(CombineKey)));
		codeMatcher.Set(OpCodes.Ldc_I4, 512);
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(GameOption), "ImportXML")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> MigrateIds(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator).MatchForward(true, new CodeMatch(OpCodes.Ldstr, "OverrideKeysId"), new CodeMatch(OpCodes.Callvirt), new CodeMatch(OpCodes.Callvirt), new CodeMatch(OpCodes.Ldloca_S));
		object operand = codeMatcher.Operand;
		int pos = codeMatcher.Clone().MatchForward(false, new CodeMatch(OpCodes.Stloc_S)).Advance(-3)
			.Pos;
		codeMatcher.CreateLabelAt(pos, out var label);
		codeMatcher.Advance(3).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloca_S, operand)).InsertAndAdvance(Transpilers.EmitDelegate<RefAction<int, bool>>(delegate(ref int oldId)
		{
			if (CustomKeyBindSystem.keyRegistry.removedIntIds.Contains(oldId))
			{
				CommonAPIPlugin.logger.LogDebug($"Discarding KeyBind ID: {oldId}");
				return false;
			}
			int num = CustomKeyBindSystem.keyRegistry.MigrateId(oldId);
			if (num != 0)
			{
				CommonAPIPlugin.logger.LogDebug($"Migrating KeyBind ID: {oldId} => {num}");
				oldId = num;
			}
			return true;
		}))
			.InsertAndAdvance(new CodeInstruction(OpCodes.Brfalse, label));
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(GameOption), "ExportXML")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> FixOverrideKeysExport(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator).MatchForward(true, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(GameOption), "overrideKeys")), new CodeMatch(OpCodes.Ldlen), new CodeMatch(OpCodes.Conv_I4), new CodeMatch((CodeInstruction ci) => ci.IsStloc()));
		codeMatcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldc_I4, 256), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(Math), "Min", new Type[2]
		{
			typeof(int),
			typeof(int)
		})));
		return codeMatcher.InstructionEnumeration();
	}
}
