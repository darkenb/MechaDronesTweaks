using System;
using System.Collections.Generic;
using System.IO;

namespace CommonAPI;

public class Registry : ISerializeState
{
	public Dictionary<string, int> idMap = new Dictionary<string, int>();

	public Dictionary<int, int> migrationMap = new Dictionary<int, int>();

	public HashSet<string> removedIds = new HashSet<string>();

	public HashSet<int> removedIntIds = new HashSet<int>();

	protected int lastId;

	protected bool throwErrorOnConflict;

	public Registry(int startId, bool throwErrorOnConflict)
	{
		lastId = startId - 1;
		this.throwErrorOnConflict = throwErrorOnConflict;
	}

	public Registry(int startId = 1)
		: this(startId, throwErrorOnConflict: false)
	{
	}

	protected virtual void OnItemRegistered(string key, int id, object item)
	{
	}

	public void InitUnitMigrationMap()
	{
		migrationMap.Clear();
		foreach (KeyValuePair<string, int> item in idMap)
		{
			migrationMap.Add(item.Value, item.Value);
		}
	}

	public int Register(string key, object item = null)
	{
		if (!idMap.TryGetValue(key, out var value))
		{
			OnItemRegistered(key, lastId + 1, item);
			idMap.Add(key, ++lastId);
			return lastId;
		}
		if (throwErrorOnConflict)
		{
			throw new InvalidOperationException("Failed to register object with key '" + key + "', because it is taken!");
		}
		return value;
	}

	public int GetUniqueId(string typeId)
	{
		if (idMap.TryGetValue(typeId, out var value))
		{
			return value;
		}
		throw new ArgumentException("Item with id " + typeId + " is not registered!");
	}

	public int MigrateId(int oldId)
	{
		if (!migrationMap.TryGetValue(oldId, out var value))
		{
			return 0;
		}
		return value;
	}

	public void Free()
	{
	}

	public void Export(BinaryWriter w)
	{
		w.Write((byte)0);
		w.Write(idMap.Count);
		foreach (KeyValuePair<string, int> item in idMap)
		{
			w.Write(item.Key);
			w.Write(item.Value);
		}
	}

	public void Import(BinaryReader r)
	{
		migrationMap.Clear();
		r.ReadByte();
		int num = r.ReadInt32();
		for (int i = 0; i < num; i++)
		{
			string text = r.ReadString();
			int num2 = r.ReadInt32();
			try
			{
				int uniqueId = GetUniqueId(text);
				migrationMap.Add(num2, uniqueId);
			}
			catch (ArgumentException)
			{
				removedIds.Add(text);
				removedIntIds.Add(num2);
			}
		}
	}
}
