using HarmonyLib;

namespace CommonAPI.Patches;

[HarmonyPatch]
internal static class EntityDataSetNullPatch
{
	[HarmonyPatch(typeof(EntityData), "SetNull")]
	[HarmonyPostfix]
	public static void SetNull(ref EntityData __instance)
	{
		__instance.customId = 0;
		__instance.customType = -1;
		__instance.customData = null;
	}
}
