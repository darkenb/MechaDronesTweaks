using System;
using CommonAPI.Systems;
using NebulaAPI;
using NebulaAPI.Interfaces;
using NebulaAPI.Networking;
using NebulaAPI.Packets;

namespace CommonAPI.Nebula;

[RegisterPacketProcessor]
public class StarExtensionDataProcessor : BasePacketProcessor<StarExtensionData>
{
	public override void ProcessPacket(StarExtensionData packet, INebulaConnection conn)
	{
		if (base.IsHost)
		{
			return;
		}
		StarData star = GameMain.galaxy.StarById(packet.starIndex + 1);
		IReaderProvider binaryReader = NebulaModAPI.GetBinaryReader(packet.binaryData);
		try
		{
			for (int i = 1; i < StarExtensionSystem.registry.data.Count; i++)
			{
				StarExtensionSystem.extensions[i].GetSystem(star).Import(binaryReader.BinaryReader);
			}
		}
		finally
		{
			((IDisposable)binaryReader)?.Dispose();
		}
	}
}
