using Mono.Cecil;

namespace CommonAPI;

public static class CecilExtension
{
	internal static bool IsSubTypeOf(this TypeDefinition typeDefinition, string typeFullName)
	{
		if (typeDefinition.FullName == typeFullName)
		{
			return true;
		}
		for (TypeDefinition typeDefinition2 = typeDefinition.BaseType?.Resolve(); typeDefinition2 != null; typeDefinition2 = typeDefinition2.BaseType?.Resolve())
		{
			if (typeDefinition2.FullName == typeFullName)
			{
				return true;
			}
		}
		return false;
	}
}
