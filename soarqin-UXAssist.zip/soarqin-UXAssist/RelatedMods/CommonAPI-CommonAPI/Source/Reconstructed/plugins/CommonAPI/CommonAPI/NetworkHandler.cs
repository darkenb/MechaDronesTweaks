using System;
using System.Collections.Generic;
using System.Linq;
using PowerNetworkStructures;
using UnityEngine;

namespace CommonAPI;

public abstract class NetworkHandler
{
	protected static List<int> _tmp_ints = new List<int>();

	protected static List<Node> _tmp_nodes = new List<Node>();

	protected PlanetFactory factory;

	public virtual NetworkHandler Prepare(PlanetFactory currentFactory)
	{
		factory = currentFactory;
		return this;
	}

	public abstract INetwork GetNetwork(int nodeId);

	protected abstract void RemoveNetwork(INetwork network);

	protected abstract void HandleNetworkMerge(INetwork first, INetwork second);

	protected abstract void SetNodeNetwork(Node node, INetwork network);

	protected abstract void HandleNodeRemoval(INetwork network, Node node);

	protected abstract INetwork CreateNewNetworkWith(List<Node> nodes);

	public abstract void UpdateVisualComponents(Node target);

	protected abstract bool CheckConnectionConditions(Node first, Node second, ref string errorMessage);

	public abstract string GetComponentType();

	public abstract bool IsRelatedTo(ItemProto proto);

	public abstract int GetNodeId(EntityData entity, Vector3 pos, Func<Node, bool> filter = null);

	public abstract NodeBounds GetNodeBounds(PrefabDesc prefab, int nodeId);

	public bool DisconnectAll(int nodeId)
	{
		INetwork network = GetNetwork(nodeId);
		Node nodeWithId = GetNodeWithId(nodeId);
		_tmp_nodes.Clear();
		foreach (Node conn in nodeWithId.conns)
		{
			_tmp_nodes.Add(conn);
			conn.conns.Remove(nodeWithId);
		}
		foreach (Node tmp_node in _tmp_nodes)
		{
			nodeWithId.conns.Remove(tmp_node);
		}
		_tmp_nodes.Clear();
		CreateNewNetworkWith(new List<Node> { nodeWithId });
		CheckForDisconnectedNetworks(network);
		UpdateVisualComponents(nodeWithId);
		return true;
	}

	public void DisconnectNodes(Node first, Node other)
	{
		first.conns.Remove(other);
		other.conns.Remove(first);
		INetwork network = GetNetwork(first.id);
		CheckForDisconnectedNetworks(network);
	}

	public bool ConnectNodes(Node first, Node second, ref string errorMessage)
	{
		if (!CheckConnectionConditions(first, second, ref errorMessage))
		{
			return false;
		}
		Algorithms.ListSortedAdd(first.conns, second);
		Algorithms.ListSortedAdd(second.conns, first);
		INetwork network = GetNetwork(first.id);
		INetwork network2 = GetNetwork(second.id);
		MergeNetworks(network, network2);
		return true;
	}

	public Node GetNodeWithId(int nodeId)
	{
		INetwork network = GetNetwork(nodeId);
		try
		{
			return network.GetNodes().First((Node node) => node.id == nodeId);
		}
		catch (InvalidOperationException)
		{
			throw new ArgumentException("Can't find network");
		}
	}

	public bool AreNodesConnected(Node firstNode, Node secondNode)
	{
		return firstNode.conns.Any((Node node) => node.id == secondNode.id);
	}

	private void MergeNetworks(INetwork firstNetwork, INetwork secondNetwork)
	{
		if (firstNetwork == null || secondNetwork == null || firstNetwork.GetId() == secondNetwork.GetId())
		{
			return;
		}
		foreach (Node node in secondNetwork.GetNodes())
		{
			SetNodeNetwork(node, firstNetwork);
		}
		Algorithms.ListSortedMerge(firstNetwork.GetNodes(), secondNetwork.GetNodes());
		HandleNetworkMerge(firstNetwork, secondNetwork);
		RemoveNetwork(secondNetwork);
	}

	public void CheckForDisconnectedNetworks(INetwork startNetwork)
	{
		INetwork network = startNetwork;
		int num = 0;
		do
		{
			List<Node> nodes = network.GetNodes();
			Algorithms.NodeDfs(nodes[0]);
			_tmp_nodes.Clear();
			for (int i = 0; i < nodes.Count; i++)
			{
				Node node = nodes[i];
				if (!node.flag)
				{
					_tmp_nodes.Add(node);
					HandleNodeRemoval(network, node);
					nodes.RemoveAt(i);
					i--;
				}
			}
			Algorithms.ClearNodeFlags(nodes);
			if (_tmp_nodes.Count == 0)
			{
				break;
			}
			network = CreateNewNetworkWith(_tmp_nodes);
		}
		while (num++ < 24);
		_tmp_nodes.Clear();
	}
}
