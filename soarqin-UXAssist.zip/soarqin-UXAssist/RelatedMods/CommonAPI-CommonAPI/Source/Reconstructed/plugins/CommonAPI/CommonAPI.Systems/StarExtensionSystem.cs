using System.Collections.Generic;
using System.IO;
using CommonAPI.Patches;

namespace CommonAPI.Systems;

public class StarExtensionSystem : BaseSubmodule
{
	public static List<StarExtensionStorage> extensions = new List<StarExtensionStorage>();

	public static TypeRegistry<IStarExtension, StarExtensionStorage> registry = new TypeRegistry<IStarExtension, StarExtensionStorage>();

	internal static StarExtensionSystem Instance => CommonAPIPlugin.GetModuleInstance<StarExtensionSystem>();

	internal override void SetHooks()
	{
		CommonAPIPlugin.harmony.PatchAll(typeof(StarExtensionHooks));
	}

	internal override void Load()
	{
		CommonAPIPlugin.registries.Add("CommonAPI:StarSystemsRegistry", registry);
	}

	public static void InitOnLoad()
	{
		if (Instance.Loaded)
		{
			CommonAPIPlugin.logger.LogInfo("Loading star extension system");
			_ = GameMain.data;
			extensions.Clear();
			extensions.Capacity = registry.data.Count + 1;
			extensions.Add(null);
			CommonAPIPlugin.logger.LogInfo($"Got {registry.data.Count} entries!");
			for (int i = 1; i < registry.data.Count; i++)
			{
				StarExtensionStorage starExtensionStorage = new StarExtensionStorage();
				starExtensionStorage.InitOnLoad(i);
				extensions.Add(starExtensionStorage);
			}
		}
	}

	public static void InitNewStar(StarData star)
	{
		for (int i = 1; i < registry.data.Count; i++)
		{
			extensions[i].InitNewStar(star);
		}
	}

	public static T GetExtension<T>(int starId, int systemId) where T : IStarExtension
	{
		Instance.ThrowIfNotLoaded();
		return GetExtension<T>(GameMain.galaxy.StarById(starId), systemId);
	}

	public static T GetExtension<T>(StarData star, int systemId) where T : IStarExtension
	{
		Instance.ThrowIfNotLoaded();
		if (systemId <= 0 || systemId >= extensions.Count)
		{
			return default(T);
		}
		return (T)extensions[systemId].GetSystem(star);
	}

	public static void DrawUpdate()
	{
		if (GameMain.data.localStar == null || DysonSphere.renderPlace != ERenderPlace.Universe)
		{
			return;
		}
		StarData localStar = GameMain.data.localStar;
		if (localStar != null)
		{
			for (int i = 1; i < extensions.Count; i++)
			{
				extensions[i].DrawUpdate(localStar);
			}
		}
	}

	public static void PreUpdate(StarData star)
	{
		if (star != null)
		{
			for (int i = 1; i < extensions.Count; i++)
			{
				extensions[i].PreUpdate(star);
			}
		}
	}

	public static void Update(StarData star)
	{
		if (star != null)
		{
			for (int i = 1; i < extensions.Count; i++)
			{
				extensions[i].Update(star);
			}
		}
	}

	public static void PreUpdateOnlySinglethread()
	{
		for (int i = 0; i < GameMain.galaxy.starCount; i++)
		{
			StarData starData = GameMain.galaxy.stars[i];
			if (starData == null)
			{
				continue;
			}
			for (int j = 1; j < extensions.Count; j++)
			{
				StarExtensionStorage starExtensionStorage = extensions[j];
				if (starExtensionStorage != null && !(starExtensionStorage.GetSystem(starData) is IPreUpdateMultithread))
				{
					starExtensionStorage.PreUpdate(starData);
				}
			}
		}
	}

	public static void UpdateOnlySinglethread()
	{
		for (int i = 0; i < GameMain.galaxy.starCount; i++)
		{
			StarData starData = GameMain.galaxy.stars[i];
			if (starData == null)
			{
				continue;
			}
			for (int j = 1; j < extensions.Count; j++)
			{
				StarExtensionStorage starExtensionStorage = extensions[j];
				if (starExtensionStorage != null && !(starExtensionStorage.GetSystem(starData) is IUpdateMultithread))
				{
					starExtensionStorage.Update(starData);
				}
			}
		}
	}

	public static void PreUpdateMultithread(StarData star, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		for (int i = 1; i < extensions.Count; i++)
		{
			extensions[i].PreUpdateMultithread(star, usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public static void UpdateMultithread(StarData star, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		for (int i = 1; i < extensions.Count; i++)
		{
			extensions[i].UpdateMultithread(star, usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public static void Import(BinaryReader r)
	{
		r.ReadInt32();
		if (r.ReadBoolean())
		{
			registry.ImportAndMigrate(extensions, r);
		}
	}

	public static void Export(BinaryWriter w)
	{
		w.Write(0);
		w.Write(Instance.Loaded);
		if (Instance.Loaded)
		{
			registry.ExportContainer(extensions, w);
		}
	}
}
