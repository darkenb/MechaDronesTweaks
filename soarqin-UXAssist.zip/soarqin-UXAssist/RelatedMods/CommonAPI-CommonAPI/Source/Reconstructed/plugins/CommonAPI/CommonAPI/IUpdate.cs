namespace CommonAPI;

public interface IUpdate
{
	void Update();
}
