using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using BepInEx.Configuration;
using HarmonyLib;

namespace CommonAPI;

public static class ConfigFileExtension
{
	public static Type configFile;

	public static PropertyInfo OrphanedEntriesProp;

	static ConfigFileExtension()
	{
		configFile = AccessTools.TypeByName("BepInEx.Configuration.ConfigFile");
		OrphanedEntriesProp = configFile.GetProperty("OrphanedEntries", AccessTools.all);
	}

	public static void MigrateConfig<T>(this ConfigFile file, string oldSection, string newSection, string[] keyFilter)
	{
		Dictionary<ConfigDefinition, string> dictionary = (Dictionary<ConfigDefinition, string>)OrphanedEntriesProp.GetValue(file);
		List<ConfigDefinition> list = new List<ConfigDefinition>();
		foreach (KeyValuePair<ConfigDefinition, string> item in dictionary)
		{
			string key = item.Key.Key;
			if (item.Key.Section.Equals(oldSection) && ((IList)keyFilter).Contains((object)key) && file.TryGetEntry(newSection, key, out ConfigEntry<T> entry))
			{
				entry.SetSerializedValue(item.Value);
				list.Add(item.Key);
				CommonAPIPlugin.logger.LogInfo("Migrating config from " + oldSection + ":" + key + " to " + newSection + ":" + key);
			}
		}
		foreach (ConfigDefinition item2 in list)
		{
			dictionary.Remove(item2);
		}
	}

	public static void MigrateConfig<T>(this ConfigFile file, string oldSection, string oldName, string newSection, string newName)
	{
		Dictionary<ConfigDefinition, string> dictionary = (Dictionary<ConfigDefinition, string>)OrphanedEntriesProp.GetValue(file);
		List<ConfigDefinition> list = new List<ConfigDefinition>();
		foreach (KeyValuePair<ConfigDefinition, string> item in dictionary)
		{
			ConfigDefinition key = item.Key;
			if (key.Section.Equals(oldSection) && key.Key.Equals(oldName) && file.TryGetEntry(newSection, newName, out ConfigEntry<T> entry))
			{
				entry.SetSerializedValue(item.Value);
				list.Add(key);
				CommonAPIPlugin.logger.LogInfo("Migrating config from " + oldSection + ":" + oldName + " to " + newSection + ":" + newName);
			}
		}
		foreach (ConfigDefinition item2 in list)
		{
			dictionary.Remove(item2);
		}
	}
}
