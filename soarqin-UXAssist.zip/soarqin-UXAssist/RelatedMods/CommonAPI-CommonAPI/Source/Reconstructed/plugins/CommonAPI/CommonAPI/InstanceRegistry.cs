using System;
using System.Collections.Generic;

namespace CommonAPI;

public class InstanceRegistry<T> : Registry
{
	public List<T> data = new List<T>();

	public InstanceRegistry()
	{
		data.Add(default(T));
	}

	public InstanceRegistry(int startId)
		: this(startId, throwErrorOnConflict: false)
	{
	}

	public InstanceRegistry(int startId, bool throwErrorOnConflict)
		: base(startId, throwErrorOnConflict)
	{
		for (int i = 0; i < startId; i++)
		{
			data.Add(default(T));
		}
	}

	public virtual int Register(string key, T item)
	{
		return Register(key, (object)item);
	}

	protected override void OnItemRegistered(string key, int id, object item)
	{
		if (item is T item2)
		{
			data.Add(item2);
			return;
		}
		throw new ArgumentException("Tried to register invalid type " + item.GetType().FullName + ", expected " + typeof(T).FullName);
	}
}
