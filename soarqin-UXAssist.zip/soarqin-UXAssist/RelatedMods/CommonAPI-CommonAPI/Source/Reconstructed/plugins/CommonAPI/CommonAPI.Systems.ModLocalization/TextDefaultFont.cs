using System.Reflection;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace CommonAPI.Systems.ModLocalization;

public class TextDefaultFont
{
	private static readonly FieldInfo FieldInfo_FontData = AccessTools.Field(typeof(Text), "m_FontData");

	public Font DefaultFont;

	public Text Reference;

	private FontData FontData;

	public TextDefaultFont(Text reference)
	{
		Reference = reference;
		FontData = (FontData)FieldInfo_FontData.GetValue(Reference);
		DefaultFont = FontData.font;
	}

	public void OnGetFont()
	{
		if (DefaultFont == null || FontData == null)
		{
			return;
		}
		int currentLanguageLCID = Localization.CurrentLanguageLCID;
		if (!LocalizationModule.extraDataEntires.ContainsKey(currentLanguageLCID))
		{
			return;
		}
		ExtraLanguageData extraLanguageData = LocalizationModule.extraDataEntires[currentLanguageLCID];
		if (extraLanguageData.customFont != null)
		{
			if (FontData.font != extraLanguageData.customFont)
			{
				FontData.font = extraLanguageData.customFont;
			}
		}
		else if (FontData.font != DefaultFont)
		{
			FontData.font = DefaultFont;
		}
	}

	public void UseCustomFontImmediate(Font fontToUse)
	{
		Reference.font = fontToUse;
	}
}
