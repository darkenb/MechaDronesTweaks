using System.Collections.Generic;
using UnityEngine;

namespace CommonAPI.Systems;

public static class CustomMachineUISystem
{
	public static List<CustomMachineWindow> windows = new List<CustomMachineWindow>();

	public static List<string> registeredPrefabs = new List<string>();

	public static int customInspectId;

	public static CustomMachineWindow openWindow;

	public static void RegisterWindow(string prefabPath)
	{
		if (!registeredPrefabs.Contains(prefabPath))
		{
			registeredPrefabs.Add(prefabPath);
			CommonAPIPlugin.logger.LogDebug("Registering machine window, prefab: " + prefabPath);
		}
	}

	public static void RefreshOpenWindow()
	{
		if (openWindow != null)
		{
			openWindow.OnIdChange();
		}
	}

	internal static void OnCreate(UIGame uiGame)
	{
		CommonAPIPlugin.logger.LogInfo("Loading custom UI's");
		Transform transform = uiGame.canvasGroup.transform.Find("Windows");
		if (transform == null)
		{
			return;
		}
		foreach (string registeredPrefab in registeredPrefabs)
		{
			GameObject gameObject = Resources.Load<GameObject>(registeredPrefab);
			if (gameObject == null)
			{
				CommonAPIPlugin.logger.LogError("Error loading UI prefab: " + registeredPrefab + "!");
				continue;
			}
			CustomMachineWindow component = Object.Instantiate(gameObject, transform, worldPositionStays: false).GetComponent<CustomMachineWindow>();
			component._Create();
			windows.Add(component);
		}
		registeredPrefabs.Clear();
	}

	internal static void OnPlayerInspecteeChange(UIGame uiGame, EObjectType objType, int objId)
	{
		PlanetFactory factory = GameMain.mainPlayer.factory;
		int componentId = -1;
		int protoId = 0;
		if (factory != null && objType == EObjectType.None && objId > 0)
		{
			componentId = factory.entityPool[objId].customType;
			protoId = factory.entityPool[objId].protoId;
		}
		CustomMachineWindow customMachineWindow = null;
		foreach (CustomMachineWindow window in windows)
		{
			if (window.ShouldOpen(componentId, protoId))
			{
				customMachineWindow = window;
				break;
			}
		}
		if (customMachineWindow == null)
		{
			return;
		}
		if (objId > 0 && customInspectId != objId)
		{
			if (customMachineWindow.DoCloseOtherWindows())
			{
				uiGame.ShutAllFunctionWindow();
			}
			if (customMachineWindow.DoClosePlayerInventory())
			{
				uiGame.ShutPlayerInventory();
			}
			customMachineWindow.Open(objId);
		}
		else if (objId == 0 && customInspectId > 0)
		{
			customMachineWindow.Close();
		}
		customInspectId = objId;
	}
}
