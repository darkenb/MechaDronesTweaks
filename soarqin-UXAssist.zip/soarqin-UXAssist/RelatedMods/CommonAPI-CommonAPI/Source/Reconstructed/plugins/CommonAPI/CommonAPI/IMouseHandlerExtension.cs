namespace CommonAPI;

public interface IMouseHandlerExtension<in T> : IPickerExtension<T>
{
	bool OnBoxMouseDown(T picker);

	void TestMouseIndex(T picker);
}
