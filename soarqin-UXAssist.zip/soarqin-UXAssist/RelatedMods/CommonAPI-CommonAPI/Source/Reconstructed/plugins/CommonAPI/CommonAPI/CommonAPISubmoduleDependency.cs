using System;

namespace CommonAPI;

[AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
public class CommonAPISubmoduleDependency : Attribute
{
	public string?[]? SubmoduleNames { get; }

	public CommonAPISubmoduleDependency(params string[] submoduleName)
	{
		SubmoduleNames = submoduleName;
	}
}
