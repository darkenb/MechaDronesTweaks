using UnityEngine;

namespace CommonAPI;

public struct NodeBounds
{
	public Vector3 center;

	public Vector3 size;

	public Vector3 nodePoint;
}
