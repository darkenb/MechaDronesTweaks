using System.Collections.Generic;
using System.IO;
using CommonAPI.Patches;

namespace CommonAPI.Systems;

public class CustomKeyBindSystem : BaseSubmodule
{
	internal static Dictionary<string, PressKeyBind> customKeys = new Dictionary<string, PressKeyBind>();

	internal static Registry keyRegistry;

	internal static CustomKeyBindSystem Instance => CommonAPIPlugin.GetModuleInstance<CustomKeyBindSystem>();

	internal override void SetHooks()
	{
		CommonAPIPlugin.harmony.PatchAll(typeof(KeyBindPatches));
		CommonAPIPlugin.harmony.PatchAll(typeof(Chainloader_Patch));
	}

	internal override void Load()
	{
		keyRegistry = new Registry(256);
	}

	public static void RegisterKeyBind<T>(BuiltinKey key) where T : PressKeyBind, new()
	{
		RegisterKeyBindWithReturn<T>(key);
	}

	public static T RegisterKeyBindWithReturn<T>(BuiltinKey key) where T : PressKeyBind, new()
	{
		Instance.ThrowIfNotLoaded();
		string key2 = "KEY" + key.name;
		int id = keyRegistry.Register(key2);
		key.id = id;
		T val = new T();
		val.Init(key);
		customKeys.Add(key2, val);
		return val;
	}

	public static ICollection<PressKeyBind> GetRegisteredKeybinds()
	{
		return customKeys.Values;
	}

	public static bool HasKeyBind(string id)
	{
		Instance.ThrowIfNotLoaded();
		string key = "KEY" + id;
		return customKeys.ContainsKey(key);
	}

	public static PressKeyBind GetKeyBind(string id)
	{
		Instance.ThrowIfNotLoaded();
		string key = "KEY" + id;
		if (customKeys.ContainsKey(key))
		{
			return customKeys[key];
		}
		return null;
	}

	public static void Export(BinaryWriter w)
	{
		w.Write((byte)0);
		long num = w.Seek(0, SeekOrigin.Current);
		w.Write(0);
		int num2 = 0;
		foreach (KeyValuePair<string, PressKeyBind> customKey in customKeys)
		{
			ref CombineKey reference = ref DSPGame.globalOption.overrideKeys[customKey.Value.defaultBind.id];
			if (!reference.IsNull())
			{
				num2++;
				w.Write(customKey.Key);
				w.Write(reference.keyCode);
				w.Write(reference.modifier);
				w.Write((byte)reference.action);
				w.Write(reference.noneKey);
			}
		}
		long num3 = w.Seek(0, SeekOrigin.Current);
		w.Seek((int)num, SeekOrigin.Begin);
		w.Write(num2);
		w.Seek((int)num3, SeekOrigin.Begin);
	}

	public static void Import(BinaryReader r)
	{
		r.ReadByte();
		int num = r.ReadInt32();
		for (int i = 0; i < num; i++)
		{
			string key = r.ReadString();
			int keyCode = r.ReadInt32();
			byte modifier = r.ReadByte();
			ECombineKeyAction action = (ECombineKeyAction)r.ReadByte();
			bool noneKey = r.ReadBoolean();
			if (customKeys.TryGetValue(key, out var value))
			{
				DSPGame.globalOption.overrideKeys[value.defaultBind.id] = new CombineKey(keyCode, modifier, action, noneKey);
			}
		}
	}
}
