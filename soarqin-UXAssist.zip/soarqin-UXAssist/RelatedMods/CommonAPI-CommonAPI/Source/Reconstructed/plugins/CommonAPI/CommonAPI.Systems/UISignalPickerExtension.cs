using System;
using System.Collections.Generic;
using CommonAPI.Systems.UI;
using UnityEngine;

namespace CommonAPI.Systems;

public class UISignalPickerExtension
{
	public static Func<int, bool> currentFilter;

	public static List<IPickerExtension<UISignalPicker>> extensions = new List<IPickerExtension<UISignalPicker>>();

	private static UIShowSignalTipExtension tipHandler;

	public static UISignalPicker PreparePicker()
	{
		PickerExtensionsSystem.Instance.ThrowIfNotLoaded();
		if (UIRoot.instance == null)
		{
			throw new PickerNotReadyException();
		}
		UISignalPicker signalPicker = UIRoot.instance.uiGame.signalPicker;
		if (!signalPicker.inited || signalPicker.active)
		{
			throw new PickerNotReadyException();
		}
		return signalPicker;
	}

	internal static UIShowSignalTipExtension GetTipExtension()
	{
		if (tipHandler == null)
		{
			tipHandler = new UIShowSignalTipExtension();
		}
		return tipHandler;
	}

	public static void Popup(Vector2 pos, Action<int> _onReturn, Func<int, bool> filter)
	{
		PickerExtensionsSystem.Instance.ThrowIfNotLoaded();
		try
		{
			extensions.Clear();
			extensions.Add(GetTipExtension());
			UISignalPicker uISignalPicker = PreparePicker();
			if (uISignalPicker == null)
			{
				_onReturn?.Invoke(0);
			}
			currentFilter = filter;
			uISignalPicker.onReturn = _onReturn;
			uISignalPicker._Open();
			uISignalPicker.pickerTrans.anchoredPosition = pos;
		}
		catch (PickerNotReadyException)
		{
			_onReturn?.Invoke(0);
		}
	}

	public static void Popup(Vector2 pos, IPickerExtension<UISignalPicker> extension)
	{
		PickerExtensionsSystem.Instance.ThrowIfNotLoaded();
		try
		{
			extensions.Clear();
			extensions.Add(GetTipExtension());
			extensions.Add(extension);
			UISignalPicker uISignalPicker = PreparePicker();
			extension.OnPopup(uISignalPicker);
			uISignalPicker._Open();
			uISignalPicker.pickerTrans.anchoredPosition = pos;
			extension.PostPopup(uISignalPicker);
		}
		catch (PickerNotReadyException)
		{
		}
	}
}
