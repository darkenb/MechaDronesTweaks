namespace CommonAPI;

public interface IPowerUpdateMultithread : IPowerUpdate
{
	void PowerUpdateMultithread(int usedThreadCount, int currentThreadIdx, int minimumCount);
}
