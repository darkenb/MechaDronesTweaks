using CommonAPI.Systems;
using NebulaAPI.Networking;
using NebulaAPI.Packets;

namespace CommonAPI.Nebula;

[RegisterPacketProcessor]
public class PlanetExtensionDataProcessor : BasePacketProcessor<PlanetExtensionData>
{
	public override void ProcessPacket(PlanetExtensionData packet, INebulaConnection conn)
	{
		if (!base.IsHost)
		{
			PlanetExtensionSystem.pendingData.Add(packet.planetId, packet.binaryData);
		}
	}
}
