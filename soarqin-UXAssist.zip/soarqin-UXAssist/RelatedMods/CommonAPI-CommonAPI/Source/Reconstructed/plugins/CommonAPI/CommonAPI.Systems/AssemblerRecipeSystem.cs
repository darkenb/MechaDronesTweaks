using System;
using System.Collections.Generic;
using CommonAPI.Patches;

namespace CommonAPI.Systems;

public class AssemblerRecipeSystem : BaseSubmodule
{
	internal static Registry recipeTypes = new Registry();

	internal static List<List<int>> recipeTypeLists = new List<List<int>>();

	internal static AssemblerRecipeSystem Instance => CommonAPIPlugin.GetModuleInstance<AssemblerRecipeSystem>();

	internal override Type[] Dependencies => new Type[3]
	{
		typeof(PickerExtensionsSystem),
		typeof(CustomDescSystem),
		typeof(ProtoRegistry)
	};

	internal override void SetHooks()
	{
		CommonAPIPlugin.harmony.PatchAll(typeof(AssemblerComponentPatch));
		CommonAPIPlugin.harmony.PatchAll(typeof(UIAssemblerWindowPatch));
	}

	internal override void Load()
	{
		CommonAPIPlugin.registries.Add("CommonAPI:RecipeTypeRegistry", recipeTypes);
		recipeTypeLists.Add(null);
	}

	public static bool IsRecipeTypeRegistered(int type)
	{
		Instance.ThrowIfNotLoaded();
		return type < recipeTypeLists.Count;
	}

	public static int RegisterRecipeType(string typeId)
	{
		Instance.ThrowIfNotLoaded();
		int num = recipeTypes.Register(typeId);
		if (num >= recipeTypeLists.Capacity)
		{
			recipeTypeLists.Capacity *= 2;
		}
		recipeTypeLists.Add(new List<int>());
		return num;
	}

	internal static void BindRecipeToType(RecipeProto recipe, int type)
	{
		Instance.ThrowIfNotLoaded();
		recipeTypeLists[type].Add(recipe.ID);
		Algorithms.ListSortedAdd(recipeTypeLists[type], recipe.ID);
	}
}
