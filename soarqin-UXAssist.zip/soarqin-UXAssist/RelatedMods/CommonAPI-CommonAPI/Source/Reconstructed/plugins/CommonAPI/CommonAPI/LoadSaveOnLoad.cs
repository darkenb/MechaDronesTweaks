using System;
using HarmonyLib;

namespace CommonAPI;

[HarmonyPatch]
public static class LoadSaveOnLoad
{
	internal static string saveName;

	internal static bool isValid
	{
		get
		{
			if (saveName != null)
			{
				return !saveName.Equals("");
			}
			return false;
		}
	}

	internal static string GetArg(string name)
	{
		string[] commandLineArgs = Environment.GetCommandLineArgs();
		for (int i = 0; i < commandLineArgs.Length; i++)
		{
			if (commandLineArgs[i] == name && commandLineArgs.Length > i + 1)
			{
				return commandLineArgs[i + 1];
			}
		}
		return null;
	}

	internal static void Init()
	{
		saveName = GetArg("loadSave");
		if (isValid)
		{
			DSPGame.LoadFile = saveName;
			CommonAPIPlugin.logger.LogInfo("Loading save " + saveName + " by default!");
		}
	}

	internal static void LoadSave()
	{
		if (isValid && GameSave.SaveExist(saveName))
		{
			DSPGame.StartGame(saveName);
		}
	}
}
