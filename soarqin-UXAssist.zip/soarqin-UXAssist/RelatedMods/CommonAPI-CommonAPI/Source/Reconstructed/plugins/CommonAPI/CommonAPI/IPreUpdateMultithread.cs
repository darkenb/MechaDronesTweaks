namespace CommonAPI;

public interface IPreUpdateMultithread : IPreUpdate
{
	void PreUpdateMultithread(int usedThreadCount, int currentThreadIdx, int minimumCount);
}
