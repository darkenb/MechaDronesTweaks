namespace CommonAPI;

public interface IUpdatePickerExtension<in T> : IPickerExtension<T>
{
	void OnUpdate(T picker);
}
