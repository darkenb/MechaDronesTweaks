namespace CommonAPI;

public interface ShowLocked
{
}
