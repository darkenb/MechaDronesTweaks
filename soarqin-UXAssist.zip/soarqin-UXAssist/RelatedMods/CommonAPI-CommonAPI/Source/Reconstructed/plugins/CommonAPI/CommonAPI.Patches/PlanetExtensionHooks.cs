using System;
using CommonAPI.Systems;
using HarmonyLib;

namespace CommonAPI.Patches;

[HarmonyPatch]
public static class PlanetExtensionHooks
{
	[HarmonyPostfix]
	[HarmonyPatch(typeof(FactoryModel), "OnCameraPostRender")]
	public static void OnRender(FactoryModel __instance)
	{
		if (__instance.planet != null && __instance.planet.factoryLoaded && __instance.planet == GameMain.localPlanet)
		{
			PlanetExtensionSystem.DrawUpdate(__instance.planet.factory);
		}
	}

	[HarmonyPatch(typeof(GameLogic), "OnGameLogicFrame")]
	[HarmonyPrefix]
	public static void BeforeFrame(GameLogic __instance, int iTask, int threadOrdinal, int threadCount, PlanetFactory[] ___factories, int ___factoryCount)
	{
		int stage = iTask switch
		{
			2801 => 3, 
			1601 => 1, 
			_ => -1, 
		};
		if (stage >= 0)
		{
			ExtensionTickDispatch.Synchronize(__instance, threadOrdinal, threadCount, delegate
			{
				Dispatch(___factories, ___factoryCount, stage, threadOrdinal, threadCount);
			});
		}
	}

	[HarmonyPatch(typeof(GameLogic), "OnGameLogicFrame")]
	[HarmonyFinalizer]
	public static Exception AfterFrame(Exception __exception, GameLogic __instance, int iTask, int threadOrdinal, int threadCount, PlanetFactory[] ___factories, int ___factoryCount)
	{
		int stage = iTask switch
		{
			1800 => 2, 
			1201 => 0, 
			_ => -1, 
		};
		if (stage < 0)
		{
			return __exception;
		}
		try
		{
			ExtensionTickDispatch.Synchronize(__instance, threadOrdinal, threadCount, delegate
			{
				Dispatch(___factories, ___factoryCount, stage, threadOrdinal, threadCount);
			});
			return __exception;
		}
		catch (Exception ex)
		{
			return (__exception == null) ? ex : new AggregateException(__exception, ex);
		}
	}

	public static void PowerTick(FactorySystem __instance, long time, bool isActive)
	{
		PlanetExtensionSystem.PowerUpdate(__instance.factory);
	}

	public static void PreUpdate(FactorySystem __instance, long time, bool isActive)
	{
		PlanetExtensionSystem.PreUpdate(__instance.factory);
	}

	public static void Update(FactorySystem __instance, long time, bool isActive)
	{
		PlanetExtensionSystem.Update(__instance.factory);
	}

	public static void PostUpdate(PlanetFactory __instance, long time)
	{
		PlanetExtensionSystem.PostUpdate(__instance);
	}

	public static void PostUpdateSinglethread()
	{
		PlanetExtensionSystem.PostUpdateOnlySinglethread(GameMain.data);
	}

	public static void PowerTickMultithread(FactorySystem __instance, long time, bool isActive, int _usedThreadCnt, int _curThreadIdx)
	{
		PlanetExtensionSystem.PowerUpdateMultithread(__instance.factory, _usedThreadCnt, _curThreadIdx, 4);
	}

	public static void PreUpdateMultithread(FactorySystem __instance, long time, bool isActive, int _usedThreadCnt, int _curThreadIdx)
	{
		PlanetExtensionSystem.PreUpdateMultithread(__instance.factory, _usedThreadCnt, _curThreadIdx, 4);
	}

	public static void UpdateMultithread(FactorySystem __instance, long time, bool isActive, int _usedThreadCnt, int _curThreadIdx)
	{
		PlanetExtensionSystem.UpdateMultithread(__instance.factory, _usedThreadCnt, _curThreadIdx, 4);
	}

	public static void PostUpdateMultithread(CargoTraffic __instance, bool presentCargos, int _usedThreadCnt, int _curThreadIdx)
	{
		PlanetExtensionSystem.PostUpdateMultithread(__instance.factory, _usedThreadCnt, _curThreadIdx, 4);
	}

	internal static void Dispatch(PlanetFactory[] factories, int count, int stage, int ordinal, int threads)
	{
		if (factories == null || (threads <= 1 && ordinal != -1))
		{
			return;
		}
		for (int i = 0; i < Math.Min(count, factories.Length); i++)
		{
			PlanetFactory planetFactory = factories[i];
			if (planetFactory == null)
			{
				continue;
			}
			for (int j = 1; j < PlanetExtensionSystem.extensions.Count; j++)
			{
				PlanetExtensionStorage planetExtensionStorage = PlanetExtensionSystem.extensions[j];
				if (planetExtensionStorage != null)
				{
					ExtensionTickDispatch.Run(planetExtensionStorage.GetExtension(planetFactory), stage, ordinal, threads, 4);
				}
			}
		}
	}

	[HarmonyPatch(typeof(PlanetFactory), "CreateEntityLogicComponents")]
	[HarmonyPostfix]
	public static void AddComponents(int entityId, PrefabDesc desc, int prebuildId, PlanetFactory __instance)
	{
		PlanetExtensionSystem.CreateEntityComponents(__instance, entityId, desc, prebuildId);
	}

	[HarmonyPatch(typeof(PlanetFactory), "RemoveEntityWithComponents")]
	[HarmonyPrefix]
	public static void RemoveComponents(int id, PlanetFactory __instance)
	{
		PlanetExtensionSystem.RemoveEntityComponents(__instance, id);
	}

	[HarmonyPatch(typeof(GameData), "GetOrCreateFactory")]
	[HarmonyPostfix]
	public static void LoadNewPlanet(PlanetData planet)
	{
		PlanetExtensionSystem.InitNewPlanet(planet);
	}
}
