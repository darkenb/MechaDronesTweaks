using System.Collections.Generic;
using CommonAPI.Systems;
using HarmonyLib;

namespace CommonAPI.Patches;

[HarmonyPatch]
internal static class StorageComponentPatch
{
	private static bool staticLoad;

	[HarmonyPatch(typeof(StorageComponent), "LoadStatic")]
	[HarmonyPostfix]
	public static void Postfix()
	{
		if (staticLoad)
		{
			return;
		}
		foreach (KeyValuePair<int, ItemProto> item in ProtoRegistry.items)
		{
			StorageComponent.itemIsFuel[item.Key] = item.Value.HeatValue > 0;
			StorageComponent.itemStackCount[item.Key] = item.Value.StackSize;
		}
		staticLoad = true;
	}
}
