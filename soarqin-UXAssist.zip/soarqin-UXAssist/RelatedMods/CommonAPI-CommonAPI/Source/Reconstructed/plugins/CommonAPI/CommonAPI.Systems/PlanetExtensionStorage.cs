using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CommonAPI.Systems;

public class PlanetExtensionStorage : ISerializeState
{
	public List<IPlanetExtension> extensions = new List<IPlanetExtension>();

	public int planetIndex;

	public void InitOnLoad(GameData data, int index)
	{
		extensions.Capacity = data.factoryCount;
		planetIndex = index;
		for (int i = 0; i < data.factoryCount; i++)
		{
			extensions.Add(PlanetExtensionSystem.registry.GetNew(index));
			extensions[i].Init(data.factories[i]);
		}
	}

	public void InitNewPlanet(PlanetData planet)
	{
		if (GetExtension(planet.factory) == null)
		{
			extensions.Capacity++;
			extensions.Add(PlanetExtensionSystem.registry.GetNew(planetIndex));
			extensions[planet.factory.index].Init(planet.factory);
		}
	}

	public IPlanetExtension GetExtension(PlanetFactory factory)
	{
		if (factory != null && factory.index >= 0 && factory.index < extensions.Count)
		{
			return extensions[factory.index];
		}
		return null;
	}

	public void DrawUpdate(PlanetFactory factory)
	{
		if (GetExtension(factory) is IDrawUpdate drawUpdate)
		{
			drawUpdate.Draw();
		}
	}

	public void PreUpdate(PlanetFactory factory)
	{
		if (GetExtension(factory) is IPreUpdate preUpdate)
		{
			preUpdate.PreUpdate();
		}
	}

	public void Update(PlanetFactory factory)
	{
		if (GetExtension(factory) is IUpdate update)
		{
			update.Update();
		}
	}

	public void PostUpdate(PlanetFactory factory)
	{
		if (GetExtension(factory) is IPostUpdate postUpdate)
		{
			postUpdate.PostUpdate();
		}
	}

	public void PowerUpdate(PlanetFactory factory)
	{
		if (GetExtension(factory) is IPowerUpdate powerUpdate)
		{
			powerUpdate.PowerUpdate();
		}
	}

	public bool PreUpdateSupportsMultithread()
	{
		if (extensions != null)
		{
			return extensions.Any((IPlanetExtension extension) => extension is IPreUpdateMultithread);
		}
		return false;
	}

	public bool UpdateSupportsMultithread()
	{
		if (extensions != null)
		{
			return extensions.Any((IPlanetExtension extension) => extension is IUpdateMultithread);
		}
		return false;
	}

	public bool PostUpdateSupportsMultithread()
	{
		if (extensions != null)
		{
			return extensions.Any((IPlanetExtension extension) => extension is IPostUpdateMultithread);
		}
		return false;
	}

	public bool PowerUpdateSupportsMultithread()
	{
		if (extensions != null)
		{
			return extensions.Any((IPlanetExtension extension) => extension is IPowerUpdateMultithread);
		}
		return false;
	}

	public void PreUpdateMultithread(PlanetFactory factory, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		if (GetExtension(factory) is IPreUpdateMultithread preUpdateMultithread)
		{
			preUpdateMultithread.PreUpdateMultithread(usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public void UpdateMultithread(PlanetFactory factory, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		if (GetExtension(factory) is IUpdateMultithread updateMultithread)
		{
			updateMultithread.UpdateMultithread(usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public void PostUpdateMultithread(PlanetFactory factory, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		if (GetExtension(factory) is IPostUpdateMultithread postUpdateMultithread)
		{
			postUpdateMultithread.PostUpdateMultithread(usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public void PowerUpdateMultithread(PlanetFactory factory, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		if (GetExtension(factory) is IPowerUpdateMultithread powerUpdateMultithread)
		{
			powerUpdateMultithread.PowerUpdateMultithread(usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public void Free()
	{
		foreach (IPlanetExtension extension in extensions)
		{
			extension.Free();
		}
		extensions.Clear();
		extensions = null;
	}

	public void Export(BinaryWriter w)
	{
		GameData data = GameMain.data;
		w.Write(0);
		for (int i = 0; i < data.factoryCount; i++)
		{
			extensions[i].Export(w);
		}
	}

	public void Import(BinaryReader r)
	{
		GameData data = GameMain.data;
		r.ReadInt32();
		extensions.Clear();
		extensions.Capacity = data.factoryCount;
		for (int i = 0; i < data.factoryCount; i++)
		{
			extensions.Add(PlanetExtensionSystem.registry.GetNew(planetIndex));
			extensions[i].Init(data.factories[i]);
			extensions[i].Import(r);
		}
	}
}
