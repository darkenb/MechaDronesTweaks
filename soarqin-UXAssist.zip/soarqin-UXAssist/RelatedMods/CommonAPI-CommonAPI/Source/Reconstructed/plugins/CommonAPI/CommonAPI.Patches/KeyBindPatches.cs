using System;
using System.Linq;
using CommonAPI.Systems;
using HarmonyLib;

namespace CommonAPI.Patches;

[HarmonyPatch]
public class KeyBindPatches
{
	[HarmonyPatch(typeof(UIOptionWindow), "_OnCreate")]
	[HarmonyPrefix]
	private static void AddKeyBind(UIOptionWindow __instance)
	{
		PressKeyBind[] array = CustomKeyBindSystem.customKeys.Values.ToArray();
		if (array.Length != 0)
		{
			int num = DSPGame.key.builtinKeys.Length;
			Array.Resize(ref DSPGame.key.builtinKeys, num + CustomKeyBindSystem.customKeys.Count);
			for (int i = 0; i < array.Length; i++)
			{
				DSPGame.key.builtinKeys[num + i] = array[i].defaultBind;
			}
		}
	}
}
