using UnityEngine;
using UnityEngine.EventSystems;

namespace CommonAPI;

public class UIWindowResize : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler
{
	[SerializeField]
	private EventTrigger resizeTrigger;

	[SerializeField]
	private RectTransform resizeTrans;

	public int resizeThreshold = 4;

	public Vector2 minSize;

	private bool mouseDown;

	private bool mouseOver;

	public bool pointerIn;

	private Vector2 resizeMouseBegin;

	private Vector2 resizeSizeDeltaBegin;

	private Vector2 resizeSizeDeltaWanted;

	public bool resizing { get; private set; }

	private void OnEnable()
	{
		EventTrigger.Entry entry = new EventTrigger.Entry
		{
			eventID = EventTriggerType.PointerDown
		};
		entry.callback.AddListener(OnPointerDown);
		resizeTrigger.triggers.Add(entry);
		EventTrigger.Entry entry2 = new EventTrigger.Entry
		{
			eventID = EventTriggerType.PointerUp
		};
		entry2.callback.AddListener(OnPointerUp);
		resizeTrigger.triggers.Add(entry2);
		EventTrigger.Entry entry3 = new EventTrigger.Entry
		{
			eventID = EventTriggerType.PointerEnter
		};
		entry3.callback.AddListener(OnPointerEnterResizeArea);
		resizeTrigger.triggers.Add(entry3);
		EventTrigger.Entry entry4 = new EventTrigger.Entry
		{
			eventID = EventTriggerType.PointerExit
		};
		entry4.callback.AddListener(OnPointerExitResizeArea);
		resizeTrigger.triggers.Add(entry4);
		if (resizeTrans == null)
		{
			resizeTrans = base.transform as RectTransform;
		}
	}

	private void OnDisable()
	{
		resizeTrigger.triggers.Clear();
		mouseDown = false;
		resizeMouseBegin = Vector2.zero;
		resizeSizeDeltaBegin = Vector2.zero;
		if (resizing)
		{
			resizeTrans.sizeDelta = new Vector2(Mathf.Round(resizeSizeDeltaWanted.x), Mathf.Round(resizeSizeDeltaWanted.y));
		}
		pointerIn = false;
	}

	private void OnApplicationFocus(bool focus)
	{
		if (!focus)
		{
			pointerIn = false;
		}
	}

	private void OnPointerDown(BaseEventData eventData)
	{
		mouseDown = true;
		UIRoot.ScreenPointIntoRect(Input.mousePosition, resizeTrans, out resizeMouseBegin);
		resizeSizeDeltaBegin = resizeTrans.sizeDelta;
		resizeSizeDeltaWanted = resizeTrans.sizeDelta;
		UICursor.SetCursor(ECursor.TargetIn);
	}

	private void OnPointerUp(BaseEventData eventData)
	{
		mouseDown = false;
		resizeMouseBegin = Vector2.zero;
		resizeSizeDeltaBegin = Vector2.zero;
	}

	private void OnPointerEnterResizeArea(BaseEventData eventData)
	{
		mouseOver = true;
	}

	private void OnPointerExitResizeArea(BaseEventData eventData)
	{
		mouseOver = false;
	}

	private void BringToFront()
	{
		int childCount = base.transform.parent.childCount;
		if (base.transform.GetSiblingIndex() < childCount - 1)
		{
			base.transform.SetAsLastSibling();
		}
	}

	private void Update()
	{
		if (mouseDown)
		{
			if (!Input.GetMouseButton(0) && !Input.GetMouseButton(1))
			{
				mouseDown = false;
			}
			UIRoot.ScreenPointIntoRect(Input.mousePosition, resizeTrans, out var rectPoint);
			Vector2 vector = rectPoint - resizeMouseBegin;
			if (Mathf.Abs(vector.x) + Mathf.Abs(vector.y) > (float)resizeThreshold)
			{
				resizing = true;
				resizeSizeDeltaWanted = resizeSizeDeltaBegin + new Vector2(vector.x, 0f - vector.y);
				resizeTrans.sizeDelta = new Vector2(Mathf.Round(Mathf.Max(resizeSizeDeltaWanted.x, minSize.x)), Mathf.Round(Mathf.Max(resizeSizeDeltaWanted.y, minSize.y)));
			}
			UICursor.SetCursor(ECursor.TargetIn);
		}
		else
		{
			resizing = false;
			resizeMouseBegin = Vector2.zero;
			resizeSizeDeltaBegin = Vector2.zero;
			if (mouseOver)
			{
				UICursor.SetCursor(ECursor.TargetOut);
			}
		}
		if (pointerIn && (Input.GetMouseButtonDown(0) || Input.GetMouseButtonDown(1)))
		{
			BringToFront();
		}
	}

	public void OnPointerEnter(PointerEventData eventData)
	{
		pointerIn = true;
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		pointerIn = false;
	}
}
