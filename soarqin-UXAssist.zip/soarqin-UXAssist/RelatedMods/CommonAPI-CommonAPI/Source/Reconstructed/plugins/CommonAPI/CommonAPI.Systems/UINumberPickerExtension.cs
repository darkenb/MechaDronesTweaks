using System;
using UnityEngine;
using UnityEngine.UI;

namespace CommonAPI.Systems;

public class UINumberPickerExtension : MonoBehaviour, IMouseHandlerExtension<UISignalPicker>, IPickerExtension<UISignalPicker>
{
	public Slider slider;

	public InputField field;

	private bool ignoreEvents;

	public bool requestBoth;

	public int lastSelectedIndex;

	public Action<int> onReturnSignal;

	public Action<int> onReturnCount;

	public Action<int, int> onReturnBoth;

	public int previousSignal;

	private static UINumberPickerExtension numberPanel;

	public int currentValue { get; private set; }

	public static UINumberPickerExtension GetExtension()
	{
		PickerExtensionsSystem.Instance.ThrowIfNotLoaded();
		UISignalPicker uISignalPicker = UISignalPickerExtension.PreparePicker();
		if (numberPanel == null)
		{
			numberPanel = UnityEngine.Object.Instantiate(CommonAPIPlugin.resource.bundle.LoadAsset<GameObject>("Assets/CommonAPI/UI/number-panel.prefab"), uISignalPicker.transform, worldPositionStays: false).GetComponent<UINumberPickerExtension>();
		}
		return numberPanel;
	}

	public static void Popup(Vector2 pos, Action<int> onItem, Action<int> onCount, int currentValue = 0, Func<int, bool> filterFunc = null)
	{
		PickerExtensionsSystem.Instance.ThrowIfNotLoaded();
		UINumberPickerExtension extension = GetExtension();
		extension.onReturnSignal = onItem;
		extension.onReturnCount = onCount;
		extension.currentValue = currentValue;
		UISignalPickerExtension.currentFilter = filterFunc;
		UISignalPickerExtension.Popup(pos, extension);
	}

	public static void Popup(Vector2 pos, Action<int, int> onBoth, int currentValue = 0, int currentItem = 0, Func<int, bool> filterFunc = null)
	{
		PickerExtensionsSystem.Instance.ThrowIfNotLoaded();
		UINumberPickerExtension extension = GetExtension();
		extension.onReturnSignal = null;
		extension.onReturnCount = null;
		extension.onReturnBoth = onBoth;
		extension.requestBoth = true;
		extension.currentValue = currentValue;
		extension.previousSignal = currentItem;
		UISignalPickerExtension.currentFilter = filterFunc;
		UISignalPickerExtension.Popup(pos, extension);
	}

	public static long Clamp(long value, long min, long max)
	{
		if (value >= min)
		{
			if (value <= max)
			{
				return value;
			}
			return max;
		}
		return min;
	}

	public void SetValue(int value)
	{
		ignoreEvents = true;
		currentValue = value;
		field.text = currentValue.ToString();
		slider.value = Mathf.Log10(currentValue);
		ignoreEvents = false;
	}

	public void SliderChanged(float newValue)
	{
		if (!ignoreEvents)
		{
			ignoreEvents = true;
			long value = Convert.ToInt64(Math.Pow(10.0, newValue));
			currentValue = (int)Clamp(value, -2147483648L, 2147483647L);
			field.text = currentValue.ToString();
		}
		ignoreEvents = false;
	}

	public void FieldChanged(string newValue)
	{
		if (!ignoreEvents)
		{
			ignoreEvents = true;
			long value = long.Parse(newValue);
			currentValue = (int)Clamp(value, -2147483648L, 2147483647L);
			field.text = currentValue.ToString();
			slider.value = Mathf.Log10(currentValue);
		}
		ignoreEvents = false;
	}

	public void SubmitClicked()
	{
		UISignalPicker signalPicker = UIRoot.instance.uiGame.signalPicker;
		VFInput.UseMouseLeft();
		signalPicker.onReturn = null;
		if (requestBoth)
		{
			onReturnBoth?.Invoke(signalPicker.selectedSignal, currentValue);
			signalPicker._Close();
		}
		else
		{
			signalPicker._Close();
			onReturnCount?.Invoke(currentValue);
		}
	}

	public bool OnBoxMouseDown(UISignalPicker picker)
	{
		if (!requestBoth || picker.hoveredIndex < 0)
		{
			return true;
		}
		lastSelectedIndex = picker.hoveredIndex;
		picker.selectedSignal = picker.signalArray[picker.hoveredIndex];
		VFInput.UseMouseLeft();
		return false;
	}

	public void TestMouseIndex(UISignalPicker picker)
	{
		if (requestBoth && lastSelectedIndex >= 0)
		{
			Vector2 anchoredPosition = new Vector2(lastSelectedIndex % 14 * 46 - 1, -Mathf.FloorToInt((float)lastSelectedIndex / 14f) * 46 + 1);
			picker.selImage.rectTransform.anchoredPosition = anchoredPosition;
			picker.selImage.gameObject.SetActive(value: true);
		}
	}

	public void Open(UISignalPicker picker)
	{
		base.gameObject.SetActive(value: true);
		((RectTransform)picker.transform).sizeDelta = new Vector2(692f, 696f);
	}

	public void Close(UISignalPicker picker)
	{
		requestBoth = false;
		base.gameObject.SetActive(value: false);
		((RectTransform)picker.transform).sizeDelta = new Vector2(692f, 614f);
	}

	public void OnPopup(UISignalPicker picker)
	{
		picker.onReturn = onReturnSignal;
	}

	public void PostPopup(UISignalPicker picker)
	{
		if (requestBoth && previousSignal != 0)
		{
			picker.currentType = GetTab(previousSignal);
			picker.RefreshIcons();
			picker.selectedSignal = previousSignal;
			for (int i = 0; i < picker.signalArray.Length; i++)
			{
				if (picker.signalArray[i] == previousSignal)
				{
					lastSelectedIndex = i;
					break;
				}
			}
		}
		SetValue(currentValue);
	}

	public int GetTab(int signalId)
	{
		if (signalId < 1000)
		{
			return 1;
		}
		if (signalId < 20000)
		{
			ItemProto itemProto = LDB.items.Select(signalId);
			if (itemProto == null)
			{
				return 1;
			}
			return itemProto.GridIndex / 1000 + 1;
		}
		if (signalId < 40000)
		{
			return 4;
		}
		if (signalId >= 60000)
		{
			return 1;
		}
		TechProto techProto = LDB.techs.Select(signalId - 40000);
		if (techProto == null)
		{
			return 5;
		}
		if (techProto.ID >= 2000)
		{
			return 6;
		}
		return 5;
	}
}
