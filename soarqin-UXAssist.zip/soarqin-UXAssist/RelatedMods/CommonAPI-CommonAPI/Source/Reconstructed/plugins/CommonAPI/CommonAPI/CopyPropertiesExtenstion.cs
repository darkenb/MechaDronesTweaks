using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace CommonAPI;

public static class CopyPropertiesExtenstion
{
	public static void CopyPropsTo<T1, T2>(this T1 source, ref T2 destination)
	{
		List<MemberInfo> members = GetMembers(source.GetType());
		List<MemberInfo> members2 = GetMembers(destination.GetType());
		foreach (MemberInfo sourceMember in members)
		{
			if (CanRead(sourceMember))
			{
				MemberInfo memberInfo = members2.FirstOrDefault((MemberInfo x) => x.Name.ToLower() == sourceMember.Name.ToLower());
				if (!(memberInfo == null) && CanWrite(memberInfo))
				{
					SetObjectValue(ref destination, memberInfo, GetMemberValue(source, sourceMember));
				}
			}
		}
	}

	private static void SetObjectValue<T>(ref T obj, MemberInfo member, object value)
	{
		object obj2 = (obj.GetType().IsValueType ? ((object)obj) : ((object)obj));
		SetMemberValue(ref obj2, member, value);
		obj = (T)obj2;
	}

	private static void SetMemberValue<T>(ref T obj, MemberInfo member, object value)
	{
		if (IsProperty(member))
		{
			PropertyInfo propertyInfo = (PropertyInfo)member;
			if (propertyInfo.SetMethod != null)
			{
				propertyInfo.SetValue(obj, value);
			}
		}
		else if (IsField(member))
		{
			((FieldInfo)member).SetValue(obj, value);
		}
	}

	private static object GetMemberValue(object obj, MemberInfo member)
	{
		object result = null;
		if (IsProperty(member))
		{
			PropertyInfo propertyInfo = (PropertyInfo)member;
			result = propertyInfo.GetValue(obj, (propertyInfo.GetIndexParameters().Count() == 1) ? new object[1] : null);
		}
		else if (IsField(member))
		{
			result = ((FieldInfo)member).GetValue(obj);
		}
		return result;
	}

	private static bool CanWrite(MemberInfo member)
	{
		if (!IsProperty(member))
		{
			return IsField(member);
		}
		return ((PropertyInfo)member).CanWrite;
	}

	private static bool CanRead(MemberInfo member)
	{
		if (!IsProperty(member))
		{
			return IsField(member);
		}
		return ((PropertyInfo)member).CanRead;
	}

	private static bool IsProperty(MemberInfo member)
	{
		return IsType(member.GetType(), typeof(PropertyInfo));
	}

	private static bool IsField(MemberInfo member)
	{
		return IsType(member.GetType(), typeof(FieldInfo));
	}

	private static bool IsType(Type type, Type targetType)
	{
		if (!(type == targetType))
		{
			return type.IsSubclassOf(targetType);
		}
		return true;
	}

	private static List<MemberInfo> GetMembers(Type type)
	{
		BindingFlags bindingAttr = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
		List<MemberInfo> list = new List<MemberInfo>();
		list.AddRange(type.GetProperties(bindingAttr));
		list.AddRange(type.GetFields(bindingAttr));
		return list;
	}
}
