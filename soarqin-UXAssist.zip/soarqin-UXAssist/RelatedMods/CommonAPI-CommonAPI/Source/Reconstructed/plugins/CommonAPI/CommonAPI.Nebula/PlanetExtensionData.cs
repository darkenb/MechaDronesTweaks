namespace CommonAPI.Nebula;

public class PlanetExtensionData
{
	public int planetId { get; set; }

	public byte[] binaryData { get; set; }

	public PlanetExtensionData()
	{
	}

	public PlanetExtensionData(int id, byte[] data)
	{
		planetId = id;
		binaryData = data;
	}
}
