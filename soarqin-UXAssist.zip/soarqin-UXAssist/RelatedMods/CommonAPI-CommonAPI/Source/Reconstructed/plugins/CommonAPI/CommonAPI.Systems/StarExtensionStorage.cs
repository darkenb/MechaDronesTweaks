using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CommonAPI.Systems;

public class StarExtensionStorage : ISerializeState
{
	public List<IStarExtension> extensions = new List<IStarExtension>();

	public int starIndex;

	public void InitOnLoad(int index)
	{
		extensions.Capacity = GameMain.galaxy.starCount;
		starIndex = index;
		for (int i = 0; i < GameMain.galaxy.starCount; i++)
		{
			extensions.Add(StarExtensionSystem.registry.GetNew(index));
			extensions[i].Init(GameMain.galaxy.stars[i]);
		}
	}

	public void InitNewStar(StarData star)
	{
		if (GetSystem(star) == null)
		{
			extensions.Capacity++;
			extensions.Add(StarExtensionSystem.registry.GetNew(starIndex));
			extensions[star.index].Init(GameMain.galaxy.stars[star.index]);
		}
	}

	public IStarExtension GetSystem(StarData star)
	{
		if (star != null && star.index >= 0 && star.index < extensions.Count)
		{
			return extensions[star.index];
		}
		return null;
	}

	public void DrawUpdate(StarData star)
	{
		if (GetSystem(star) is IDrawUpdate drawUpdate)
		{
			drawUpdate.Draw();
		}
	}

	public void PreUpdate(StarData star)
	{
		if (GetSystem(star) is IPreUpdate preUpdate)
		{
			preUpdate.PreUpdate();
		}
	}

	public void Update(StarData star)
	{
		if (GetSystem(star) is IUpdate update)
		{
			update.Update();
		}
	}

	public void PostUpdate(StarData star)
	{
		if (GetSystem(star) is IPostUpdate postUpdate)
		{
			postUpdate.PostUpdate();
		}
	}

	public void PowerUpdate(StarData star)
	{
		if (GetSystem(star) is IPowerUpdate powerUpdate)
		{
			powerUpdate.PowerUpdate();
		}
	}

	public bool PreUpdateSupportsMultithread()
	{
		if (extensions != null)
		{
			return extensions.Any((IStarExtension extension) => extension is IPreUpdateMultithread);
		}
		return false;
	}

	public bool UpdateSupportsMultithread()
	{
		if (extensions != null)
		{
			return extensions.Any((IStarExtension extension) => extension is IUpdateMultithread);
		}
		return false;
	}

	public bool PostUpdateSupportsMultithread()
	{
		if (extensions != null)
		{
			return extensions.Any((IStarExtension extension) => extension is IPostUpdateMultithread);
		}
		return false;
	}

	public bool PowerUpdateSupportsMultithread()
	{
		if (extensions != null)
		{
			return extensions.Any((IStarExtension extension) => extension is IPowerUpdateMultithread);
		}
		return false;
	}

	public void PreUpdateMultithread(StarData star, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		if (GetSystem(star) is IPreUpdateMultithread preUpdateMultithread)
		{
			preUpdateMultithread.PreUpdateMultithread(usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public void UpdateMultithread(StarData star, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		if (GetSystem(star) is IUpdateMultithread updateMultithread)
		{
			updateMultithread.UpdateMultithread(usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public void PostUpdateMultithread(StarData star, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		if (GetSystem(star) is IPostUpdateMultithread postUpdateMultithread)
		{
			postUpdateMultithread.PostUpdateMultithread(usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public void PowerUpdateMultithread(StarData star, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		if (GetSystem(star) is IPowerUpdateMultithread powerUpdateMultithread)
		{
			powerUpdateMultithread.PowerUpdateMultithread(usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public void Free()
	{
		foreach (IStarExtension extension in extensions)
		{
			extension.Free();
		}
		extensions.Clear();
		extensions = null;
	}

	public void Export(BinaryWriter w)
	{
		w.Write(0);
		CommonAPIPlugin.logger.LogInfo("Start star System storage Export");
		for (int i = 0; i < GameMain.galaxy.starCount; i++)
		{
			extensions[i].Export(w);
		}
	}

	public void Import(BinaryReader r)
	{
		_ = GameMain.data;
		CommonAPIPlugin.logger.LogInfo("Start System storage Import");
		r.ReadInt32();
		extensions.Clear();
		extensions.Capacity = GameMain.galaxy.starCount;
		for (int i = 0; i < GameMain.galaxy.starCount; i++)
		{
			extensions.Add(StarExtensionSystem.registry.GetNew(starIndex));
			extensions[i].Init(GameMain.galaxy.stars[i]);
			extensions[i].Import(r);
		}
	}
}
