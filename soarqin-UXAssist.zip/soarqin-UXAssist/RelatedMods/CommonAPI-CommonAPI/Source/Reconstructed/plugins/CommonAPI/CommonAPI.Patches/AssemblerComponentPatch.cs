using CommonAPI.Systems;
using HarmonyLib;

namespace CommonAPI.Patches;

[HarmonyPatch]
public static class AssemblerComponentPatch
{
	[HarmonyPatch(typeof(AssemblerComponent), "SetRecipe")]
	[HarmonyPrefix]
	public static bool CheckRecipe(ref AssemblerComponent __instance, int recpId, SignData[] signPool)
	{
		if (recpId > 0)
		{
			RecipeProto recipeProto = LDB.recipes.Select(recpId);
			if (recipeProto.Type == (ERecipeType)20)
			{
				int protoId = GameMain.localPlanet.factory.entityPool[__instance.entityId].protoId;
				int property = LDB.items.Select(protoId).prefabDesc.GetProperty<int>("CommonAPI:recipeType");
				if (!recipeProto.BelongsToType(property))
				{
					return false;
				}
			}
		}
		return true;
	}
}
