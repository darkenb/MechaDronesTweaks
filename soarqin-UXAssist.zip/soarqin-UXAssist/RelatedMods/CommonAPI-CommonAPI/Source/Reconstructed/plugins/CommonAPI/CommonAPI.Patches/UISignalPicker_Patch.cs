using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using CommonAPI.Systems;
using HarmonyLib;

namespace CommonAPI.Patches;

[HarmonyPatch]
public class UISignalPicker_Patch
{
	[HarmonyPatch(typeof(UISignalPicker), "RefreshIcons")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> AddItemFilter(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		MatchProto<SignalProto>(codeMatcher, (int i) => i);
		codeMatcher.Advance(30);
		MatchProto<ItemProto>(codeMatcher, (int i) => i);
		codeMatcher.Advance(30);
		MatchProto<ItemProto>(codeMatcher, (int i) => i);
		codeMatcher.Advance(30);
		codeMatcher.MatchForward(false, new CodeMatch((CodeInstruction x) => x.IsLdloc()), new CodeMatch((CodeInstruction x) => x.IsLdloc()), new CodeMatch(OpCodes.Ldelem_Ref), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(RecipeProto), "hasIcon")));
		MatchProto<RecipeProto>(codeMatcher, (int i) => i + 20000, noMatch: true, 2);
		codeMatcher.MatchForward(false, new CodeMatch((CodeInstruction x) => x.IsLdloc()), new CodeMatch((CodeInstruction x) => x.IsLdloc()), new CodeMatch(OpCodes.Ldelem_Ref), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(TechProto), "Published")));
		MatchProto<TechProto>(codeMatcher, (int i) => i + 40000, noMatch: true, 2);
		codeMatcher.MatchForward(false, new CodeMatch((CodeInstruction x) => x.IsLdloc()), new CodeMatch((CodeInstruction x) => x.IsLdloc()), new CodeMatch(OpCodes.Ldelem_Ref), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(TechProto), "Published")));
		MatchProto<TechProto>(codeMatcher, (int i) => i + 40000, noMatch: true, 2);
		return codeMatcher.InstructionEnumeration();
	}

	private static void MatchProto<T>(CodeMatcher matcher, Func<int, int> index, bool noMatch = false, int offset = 3) where T : Proto
	{
		if (!noMatch)
		{
			matcher.MatchForward(false, new CodeMatch((CodeInstruction x) => x.IsLdloc()), new CodeMatch((CodeInstruction x) => x.IsLdloc()), new CodeMatch(OpCodes.Ldelem_Ref), new CodeMatch((CodeInstruction x) => x.opcode == OpCodes.Ldfld && ((FieldInfo)x.operand).Name == "GridIndex"), new CodeMatch(OpCodes.Ldc_I4));
		}
		matcher.GetInstructionAndAdvance(out var opCode, out var operand).GetInstructionAndAdvance(out var opCode2, out var operand2).Advance(offset)
			.GetLabel(out var label)
			.Advance(-offset + 1)
			.InsertAndAdvance(Transpilers.EmitDelegate<Func<T, bool>>((T proto) => UISignalPickerExtension.currentFilter == null || UISignalPickerExtension.currentFilter(index(proto.ID))))
			.InsertAndAdvance(new CodeInstruction(OpCodes.Brfalse, label))
			.InsertAndAdvance(new CodeInstruction(opCode, operand))
			.InsertAndAdvance(new CodeInstruction(opCode2, operand2))
			.InsertAndAdvance(new CodeInstruction(OpCodes.Ldelem_Ref));
	}

	[HarmonyPatch(typeof(UISignalPicker), "Popup")]
	[HarmonyPrefix]
	public static void IgnoreFilter(UISignalPicker __instance)
	{
		UISignalPickerExtension.currentFilter = null;
		UISignalPickerExtension.extensions.Clear();
		UISignalPickerExtension.extensions.Add(UISignalPickerExtension.GetTipExtension());
	}

	[HarmonyPatch(typeof(UISignalPicker), "OnBoxMouseDown")]
	[HarmonyPrefix]
	public static bool OnBoxMouseDown(UISignalPicker __instance)
	{
		if (UISignalPickerExtension.extensions.Count == 0)
		{
			return true;
		}
		foreach (IPickerExtension<UISignalPicker> extension in UISignalPickerExtension.extensions)
		{
			if (extension is IMouseHandlerExtension<UISignalPicker> mouseHandlerExtension)
			{
				return mouseHandlerExtension.OnBoxMouseDown(__instance);
			}
		}
		return true;
	}

	[HarmonyPatch(typeof(UISignalPicker), "TestMouseIndex")]
	[HarmonyPostfix]
	public static void TestMouseIndex(UISignalPicker __instance)
	{
		if (UISignalPickerExtension.extensions.Count == 0)
		{
			return;
		}
		foreach (IPickerExtension<UISignalPicker> extension in UISignalPickerExtension.extensions)
		{
			if (extension is IMouseHandlerExtension<UISignalPicker> mouseHandlerExtension)
			{
				mouseHandlerExtension.TestMouseIndex(__instance);
			}
		}
	}

	[HarmonyPatch(typeof(UISignalPicker), "_OnOpen")]
	[HarmonyPostfix]
	public static void Open(UISignalPicker __instance)
	{
		if (UISignalPickerExtension.extensions.Count == 0)
		{
			return;
		}
		foreach (IPickerExtension<UISignalPicker> extension in UISignalPickerExtension.extensions)
		{
			extension.Open(__instance);
		}
	}

	[HarmonyPatch(typeof(UISignalPicker), "_OnClose")]
	[HarmonyPostfix]
	public static void Close(UISignalPicker __instance)
	{
		if (UISignalPickerExtension.extensions.Count == 0)
		{
			return;
		}
		foreach (IPickerExtension<UISignalPicker> extension in UISignalPickerExtension.extensions)
		{
			extension.Close(__instance);
		}
	}

	[HarmonyPatch(typeof(UISignalPicker), "_OnUpdate")]
	[HarmonyPostfix]
	public static void Update(UISignalPicker __instance)
	{
		if (UISignalPickerExtension.extensions.Count == 0)
		{
			return;
		}
		foreach (IPickerExtension<UISignalPicker> extension in UISignalPickerExtension.extensions)
		{
			if (extension is IUpdatePickerExtension<UISignalPicker> updatePickerExtension)
			{
				updatePickerExtension.OnUpdate(__instance);
			}
		}
	}
}
