namespace CommonAPI.Systems;

public class HoldKeyBind : PressKeyBind
{
	protected override bool ReadKey(CombineKey key)
	{
		return key.GetKey();
	}
}
