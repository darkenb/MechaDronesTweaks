using System;
using System.IO;
using CommonAPI.Systems;
using HarmonyLib;
using UnityEngine;

namespace CommonAPI.Patches;

[HarmonyPatch]
public static class CopyPastePatch
{
	[HarmonyPatch(typeof(BuildingParameters), "CopyFromFactoryObject")]
	[HarmonyPrefix]
	public static bool Copy(ref BuildingParameters __instance, int objectId, PlanetFactory factory, ref bool __result)
	{
		if (objectId <= 0)
		{
			return true;
		}
		int customId = factory.entityPool[objectId].customId;
		int customType = factory.entityPool[objectId].customType;
		if (customId == 0)
		{
			return true;
		}
		if (ComponentExtension.GetComponent(factory, customType, customId) is ICopyPasteSettings copyPasteSettings)
		{
			__instance.SetEmpty();
			__instance.type = BuildingType.Other;
			__instance.itemId = factory.entityPool[objectId].protoId;
			__instance.modelIndex = factory.entityPool[objectId].modelIndex;
			MemoryStream memoryStream = new MemoryStream();
			BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
			copyPasteSettings.WriteCopyData(binaryWriter);
			int num = (int)memoryStream.Length;
			int num2 = Mathf.CeilToInt((float)num / 4f);
			if (num2 * 4 != num)
			{
				int num3 = num2 * 4 - num;
				for (int i = 0; i < num3; i++)
				{
					binaryWriter.Write((byte)0);
				}
			}
			__instance.parameters = new int[num2 + 2];
			__instance.parameters[0] = customId;
			__instance.parameters[1] = customType;
			byte[] value = memoryStream.ToArray();
			for (int j = 0; j < num2; j++)
			{
				__instance.parameters[j + 2] = BitConverter.ToInt32(value, j * 4);
			}
			binaryWriter.Dispose();
			__result = true;
			return false;
		}
		return true;
	}

	[HarmonyPatch(typeof(BuildingParameters), "PasteToFactoryObject")]
	[HarmonyPrefix]
	public static bool Paste(ref BuildingParameters __instance, int objectId, PlanetFactory factory, ref bool __result)
	{
		if (objectId <= 0 || __instance.type != BuildingType.Other || __instance.parameters == null)
		{
			return true;
		}
		if (__instance.parameters.Length <= 2)
		{
			return true;
		}
		int num = __instance.parameters[0];
		int num2 = __instance.parameters[1];
		if (num <= 0)
		{
			return true;
		}
		int customId = factory.entityPool[objectId].customId;
		int customType = factory.entityPool[objectId].customType;
		if (customId <= 0)
		{
			return true;
		}
		if (ComponentExtension.GetComponent(factory, customType, customId) is ICopyPasteSettings copyPasteSettings)
		{
			int num3 = __instance.parameters.Length - 2;
			byte[] array = new byte[num3 * 4];
			for (int i = 0; i < num3; i++)
			{
				Array.Copy(BitConverter.GetBytes(__instance.parameters[i + 2]), 0, array, i * 4, 4);
			}
			MemoryStream memoryStream = new MemoryStream(array);
			BinaryReader binaryReader = new BinaryReader(memoryStream);
			FactoryComponent component = ComponentExtension.GetComponent(factory, num2, num);
			if (copyPasteSettings.CanPasteSettings(component, binaryReader))
			{
				memoryStream.Position = 0L;
				copyPasteSettings.PasteSettings(num2, binaryReader);
				binaryReader.Dispose();
				__result = true;
				return false;
			}
		}
		return true;
	}

	[HarmonyPatch(typeof(BuildingParameters), "CopiedTipText")]
	[HarmonyPrefix]
	public static bool CopyTipText(ref BuildingParameters __instance, ref string __result)
	{
		if (__instance.type == BuildingType.Other && __instance.parameters != null && __instance.parameters.Length > 1)
		{
			int num = __instance.parameters[0];
			int typeId = __instance.parameters[1];
			if (num > 0 && ComponentExtension.GetComponent(GameMain.mainPlayer.factory, typeId, num) is ICopyPasteSettings copyPasteSettings)
			{
				__result = copyPasteSettings.GetCopyMessage();
				return false;
			}
		}
		return true;
	}

	[HarmonyPatch(typeof(BuildingParameters), "PastedTipText")]
	[HarmonyPrefix]
	public static bool PasteTipText(ref BuildingParameters __instance, ref string __result)
	{
		if (__instance.type == BuildingType.Other && __instance.parameters != null && __instance.parameters.Length > 1)
		{
			int num = __instance.parameters[0];
			int typeId = __instance.parameters[1];
			if (num > 0 && ComponentExtension.GetComponent(GameMain.mainPlayer.factory, typeId, num) is ICopyPasteSettings copyPasteSettings)
			{
				__result = copyPasteSettings.GetPasteMessage();
				return false;
			}
		}
		return true;
	}
}
