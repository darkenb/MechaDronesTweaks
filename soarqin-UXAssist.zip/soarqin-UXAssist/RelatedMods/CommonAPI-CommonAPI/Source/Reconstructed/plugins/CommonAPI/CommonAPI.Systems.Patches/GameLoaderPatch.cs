using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;

namespace CommonAPI.Systems.Patches;

[HarmonyPatch]
public class GameLoaderPatch
{
	public delegate void RefAction<T1>(ref T1 arg1);

	[HarmonyPatch(typeof(GameLoader), "FixedUpdate")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> AddModificationWarn(IEnumerable<CodeInstruction> instructions)
	{
		return new CodeMatcher(instructions).MatchForward(false, new CodeMatch(OpCodes.Ldloc_0), new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(string), "IsNullOrEmpty")), new CodeMatch(OpCodes.Brtrue)).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloca_S, 0)).InsertAndAdvance(Transpilers.EmitDelegate<RefAction<string>>(delegate(ref string text)
		{
			if (UtilSystem.messageHandlers.Count > 0)
			{
				foreach (Func<string> messageHandler in UtilSystem.messageHandlers)
				{
					string text2 = messageHandler();
					if (!string.IsNullOrEmpty(text2))
					{
						text = text + "\r\n" + text2;
					}
				}
			}
		}))
			.InstructionEnumeration();
	}
}
