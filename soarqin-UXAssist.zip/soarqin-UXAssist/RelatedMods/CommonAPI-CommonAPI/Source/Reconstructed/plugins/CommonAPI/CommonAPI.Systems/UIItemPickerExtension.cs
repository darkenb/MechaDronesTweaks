using System;
using UnityEngine;

namespace CommonAPI.Systems;

public class UIItemPickerExtension
{
	public static Func<ItemProto, bool> currentFilter;

	public static bool showLocked;

	public static IPickerExtension<UIItemPicker> currentExtension;

	public static UIItemPicker PreparePicker()
	{
		PickerExtensionsSystem.Instance.ThrowIfNotLoaded();
		if (UIRoot.instance == null)
		{
			throw new PickerNotReadyException();
		}
		UIItemPicker itemPicker = UIRoot.instance.uiGame.itemPicker;
		if (!itemPicker.inited || itemPicker.active)
		{
			throw new PickerNotReadyException();
		}
		return itemPicker;
	}

	public static void Popup(Vector2 pos, Action<ItemProto> _onReturn, bool showLockedItems, Func<ItemProto, bool> filter)
	{
		PickerExtensionsSystem.Instance.ThrowIfNotLoaded();
		try
		{
			showLocked = showLockedItems;
			currentExtension = null;
			UIItemPicker uIItemPicker = PreparePicker();
			if (uIItemPicker == null)
			{
				_onReturn?.Invoke(null);
			}
			currentFilter = filter;
			uIItemPicker.onReturn = _onReturn;
			uIItemPicker._Open();
			uIItemPicker.pickerTrans.anchoredPosition = pos;
		}
		catch (PickerNotReadyException)
		{
			_onReturn?.Invoke(null);
		}
	}

	public static void Popup(Vector2 pos, Action<ItemProto> _onReturn, Func<ItemProto, bool> filter)
	{
		Popup(pos, _onReturn, showLockedItems: false, filter);
	}

	public static void Popup(Vector2 pos, IPickerExtension<UIItemPicker> extension)
	{
		PickerExtensionsSystem.Instance.ThrowIfNotLoaded();
		try
		{
			showLocked = extension is ShowLocked;
			currentExtension = extension;
			UIItemPicker uIItemPicker = PreparePicker();
			extension.OnPopup(uIItemPicker);
			uIItemPicker._Open();
			uIItemPicker.pickerTrans.anchoredPosition = pos;
			extension.PostPopup(uIItemPicker);
		}
		catch (PickerNotReadyException)
		{
		}
	}
}
