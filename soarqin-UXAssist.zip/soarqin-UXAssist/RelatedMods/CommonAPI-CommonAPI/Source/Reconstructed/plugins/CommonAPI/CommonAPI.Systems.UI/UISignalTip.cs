using System;
using UnityEngine;
using UnityEngine.UI;

namespace CommonAPI.Systems.UI;

public class UISignalTip : MonoBehaviour
{
	private static GameObject prefab;

	public Text nameText;

	public Text descText;

	public Image iconImage;

	public RectTransform trans;

	[NonSerialized]
	public int showingSignalId;

	private void OnDisable()
	{
		showingSignalId = 0;
	}

	public static UISignalTip Create(int signalId, int corner, Vector2 offset, Transform parent)
	{
		if (prefab == null)
		{
			prefab = CommonAPIPlugin.resource.bundle.LoadAsset<GameObject>("Assets/CommonAPI/UI/item-tooltip.prefab");
		}
		UISignalTip component = UnityEngine.Object.Instantiate(prefab, parent).GetComponent<UISignalTip>();
		component.SetTip(signalId, corner, offset, parent);
		return component;
	}

	public void SetTip(int signalId, int corner, Vector2 offset, Transform parent)
	{
		showingSignalId = signalId;
		trans.SetParent(parent, worldPositionStays: true);
		SignalProto signalProto = LDB.signals.Select(signalId);
		if (signalProto != null)
		{
			nameText.text = signalProto.name;
			descText.text = signalProto.description;
			iconImage.sprite = signalProto.iconSprite;
		}
		else
		{
			nameText.text = "Unknown Signal";
			descText.text = "";
			iconImage.sprite = null;
		}
		Vector2 vector;
		Vector2 pivot;
		switch (corner)
		{
		case 1:
			vector = new Vector2(0f, 0f);
			pivot = new Vector2(1f, 1f);
			break;
		case 2:
			vector = new Vector2(0.5f, 0f);
			pivot = new Vector2(0.5f, 1f);
			break;
		case 3:
			vector = new Vector2(1f, 0f);
			pivot = new Vector2(0f, 1f);
			break;
		case 4:
			vector = new Vector2(0f, 0.5f);
			pivot = new Vector2(1f, 0.5f);
			break;
		case 5:
			vector = new Vector2(0.5f, 0.5f);
			pivot = new Vector2(0.5f, 0.5f);
			break;
		case 6:
			vector = new Vector2(1f, 0.5f);
			pivot = new Vector2(0f, 0.5f);
			break;
		case 7:
			vector = new Vector2(0f, 1f);
			pivot = new Vector2(0f, 1f);
			break;
		case 8:
			vector = new Vector2(0.5f, 1f);
			pivot = new Vector2(0.5f, 0f);
			break;
		case 9:
			vector = new Vector2(1f, 1f);
			pivot = new Vector2(0f, 0f);
			break;
		default:
			vector = new Vector2(0.5f, 0.5f);
			pivot = new Vector2(0.5f, 0.5f);
			break;
		}
		RectTransform rectTransform = trans;
		Vector2 anchorMax = (trans.anchorMin = vector);
		rectTransform.anchorMax = anchorMax;
		trans.pivot = pivot;
		trans.anchoredPosition = offset;
		int num = ((!string.IsNullOrEmpty(descText.text)) ? ((int)descText.preferredHeight) : 0);
		int num2 = 61 + num;
		if (num2 <= 120)
		{
			num2 = 120;
		}
		trans.sizeDelta = new Vector2(290f, num2);
		trans.SetParent(UIRoot.instance.itemTipTransform, worldPositionStays: true);
		Rect rect = UIRoot.instance.itemTipTransform.rect;
		float num3 = Mathf.RoundToInt(rect.width);
		float num4 = Mathf.RoundToInt(rect.height);
		float num5 = trans.anchorMin.x * num3 + trans.anchoredPosition.x;
		float num6 = trans.anchorMin.y * num4 + trans.anchoredPosition.y;
		Rect rect2 = trans.rect;
		rect2.x += num5;
		rect2.y += num6;
		Vector2 zero = Vector2.zero;
		if (rect2.xMin < 0f)
		{
			zero.x -= rect2.xMin;
		}
		if (rect2.yMin < 0f)
		{
			zero.y -= rect2.yMin;
		}
		if (rect2.xMax > num3)
		{
			zero.x -= rect2.xMax - num3;
		}
		if (rect2.yMax > num4)
		{
			zero.y -= rect2.yMax - num4;
		}
		Vector2 anchoredPosition = trans.anchoredPosition;
		anchoredPosition += zero;
		trans.anchoredPosition = anchoredPosition;
		trans.localScale = new Vector3(1f, 1f, 1f);
	}
}
