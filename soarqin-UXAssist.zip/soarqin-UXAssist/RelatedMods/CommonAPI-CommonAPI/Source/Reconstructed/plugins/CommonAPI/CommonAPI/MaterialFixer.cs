using CommonAPI.Systems;
using UnityEngine;

namespace CommonAPI;

public class MaterialFixer : MonoBehaviour
{
	private static readonly int colorGlass = Shader.PropertyToID("_ColorGlass");

	private static readonly int vibrancy = Shader.PropertyToID("_Vibrancy");

	private static readonly int brightness = Shader.PropertyToID("_Brightness");

	private static readonly int flatten = Shader.PropertyToID("_Flatten");

	private void Start()
	{
		if (!Application.isEditor)
		{
			Material material = ProtoRegistry.CreateMaterial("UI/TranslucentImage", "trs-mat", "#00000000", null, new string[1] { "_EMISSION" });
			material.SetFloat(colorGlass, 1f);
			material.SetFloat(vibrancy, 1.1f);
			material.SetFloat(brightness, -0.5f);
			material.SetFloat(flatten, 0.005f);
			TranslucentImage[] componentsInChildren = GetComponentsInChildren<TranslucentImage>(includeInactive: true);
			foreach (TranslucentImage obj in componentsInChildren)
			{
				obj.material = material;
				obj.spriteBlending = 0.7f;
			}
		}
	}
}
