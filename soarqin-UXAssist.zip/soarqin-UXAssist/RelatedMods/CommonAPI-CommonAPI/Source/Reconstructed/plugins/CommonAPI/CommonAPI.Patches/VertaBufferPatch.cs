using System.IO;
using CommonAPI.Systems;
using HarmonyLib;

namespace CommonAPI.Patches;

[HarmonyPatch]
internal static class VertaBufferPatch
{
	[HarmonyPatch(typeof(VertaBuffer), "LoadFromFile")]
	[HarmonyPrefix]
	public static bool Prefix(ref string filename)
	{
		foreach (ResourceData modResource in ProtoRegistry.modResources)
		{
			if (filename.ToLower().Contains(modResource.keyWord.ToLower()) && modResource.HasVertaFolder())
			{
				string text = modResource.vertaFolder + "/" + filename;
				if (File.Exists(text))
				{
					filename = text;
					CommonAPIPlugin.logger.LogDebug("Loading registered verta file " + filename);
					break;
				}
			}
		}
		return true;
	}
}
