namespace CommonAPI;

public interface IPostUpdate
{
	void PostUpdate();
}
