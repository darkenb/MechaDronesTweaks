namespace CommonAPI.Nebula;

public class StarExtensionLoadRequest
{
	public int starIndex { get; set; }

	public StarExtensionLoadRequest()
	{
	}

	public StarExtensionLoadRequest(int starIndex)
	{
		this.starIndex = starIndex;
	}
}
