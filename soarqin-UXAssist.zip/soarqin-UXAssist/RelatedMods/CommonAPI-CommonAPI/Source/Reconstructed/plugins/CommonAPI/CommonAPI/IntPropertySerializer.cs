using System;
using System.IO;

namespace CommonAPI;

public class IntPropertySerializer : IPropertySerializer
{
	public static readonly IntPropertySerializer instance = new IntPropertySerializer();

	public void Export(object obj, BinaryWriter w)
	{
		w.Write((int)obj);
	}

	public object Import(BinaryReader r)
	{
		return r.ReadInt32();
	}

	public Type GetTargetType()
	{
		return typeof(int);
	}
}
