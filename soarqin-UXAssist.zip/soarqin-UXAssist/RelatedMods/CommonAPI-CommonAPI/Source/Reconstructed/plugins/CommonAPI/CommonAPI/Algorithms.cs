using System;
using System.Collections.Generic;
using PowerNetworkStructures;

namespace CommonAPI;

public static class Algorithms
{
	public static void NodeDfs(Node n)
	{
		n.flag = true;
		int count = n.conns.Count;
		for (int i = 0; i < count; i += 30)
		{
			int num = 0;
			for (int j = 0; j < 30; j++)
			{
				int num2 = i + j;
				if (num2 >= count)
				{
					break;
				}
				if (!n.conns[num2].flag)
				{
					num |= 1 << j;
				}
				n.conns[num2].flag = true;
			}
			for (int k = 0; k < 30; k++)
			{
				int num3 = i + k;
				if (num3 >= count)
				{
					break;
				}
				if ((num & (1 << k)) > 0)
				{
					NodeDfs(n.conns[num3]);
				}
			}
		}
	}

	public static void ClearNodeFlags(List<Node> l)
	{
		foreach (Node item in l)
		{
			item.flag = false;
		}
	}

	public static void ListSortedMerge<T>(List<T> a, List<T> b) where T : IComparable<T>
	{
		int count = b.Count;
		int i = 0;
		for (int j = 0; j < count; j++)
		{
			int count2 = a.Count;
			T val = b[j];
			bool flag = false;
			for (; i < count2; i++)
			{
				if (a[i].CompareTo(val) == 0)
				{
					flag = true;
					break;
				}
				if (a[i].CompareTo(val) > 0)
				{
					a.Insert(i, val);
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				a.Add(val);
				i = a.Count;
			}
		}
	}

	public static void ListSortedMerge(List<Node> a, List<Node> b)
	{
		int count = b.Count;
		int i = 0;
		for (int j = 0; j < count; j++)
		{
			int count2 = a.Count;
			Node node = b[j];
			bool flag = false;
			for (; i < count2; i++)
			{
				if (a[i].id == node.id)
				{
					flag = true;
					break;
				}
				if (a[i].id > node.id)
				{
					a.Insert(i, node);
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				a.Add(node);
				i = a.Count;
			}
		}
	}

	public static void ListSortedAdd<T>(List<T> l, T n) where T : IComparable<T>
	{
		int count = l.Count;
		bool flag = false;
		for (int i = 0; i < count; i++)
		{
			if (l[i].CompareTo(n) == 0)
			{
				flag = true;
				break;
			}
			if (l[i].CompareTo(n) > 0)
			{
				l.Insert(i, n);
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			l.Add(n);
		}
	}

	public static void ListSortedAdd(List<Node> l, Node n)
	{
		int count = l.Count;
		bool flag = false;
		for (int i = 0; i < count; i++)
		{
			if (l[i].id == n.id)
			{
				flag = true;
				break;
			}
			if (l[i].id > n.id)
			{
				l.Insert(i, n);
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			l.Add(n);
		}
	}
}
