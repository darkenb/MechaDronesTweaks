using HarmonyLib;

namespace CommonAPI;

[HarmonyPatch]
public static class VFPreloadPatch
{
	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	[HarmonyPostfix]
	public static void OnMainMenuOpen()
	{
		CommonAPIPlugin.CheckIfUsedOnRightGameVersion();
		LoadSaveOnLoad.LoadSave();
	}
}
