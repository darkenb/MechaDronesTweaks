using System;
using CommonAPI.Systems;
using HarmonyLib;

namespace CommonAPI.Patches;

[HarmonyPatch]
public static class StarExtensionHooks
{
	public static void DrawCall(GameData __instance, int frame)
	{
		StarExtensionSystem.DrawUpdate();
	}

	public static void PowerTickMultithread(DysonSphere __instance, int _usedThreadCnt, int _curThreadIdx)
	{
		StarExtensionSystem.UpdateMultithread(__instance.starData, _usedThreadCnt, _curThreadIdx, 12);
	}

	[HarmonyPatch(typeof(GameLogic), "Draw")]
	[HarmonyPostfix]
	public static void DrawCall()
	{
		StarExtensionSystem.DrawUpdate();
	}

	[HarmonyPatch(typeof(GameLogic), "OnGameLogicFrame")]
	[HarmonyFinalizer]
	public static Exception UpdateFrame(Exception __exception, GameLogic __instance, int iTask, int threadOrdinal, int threadCount, GalaxyData ___galaxy)
	{
		if (iTask != 3351)
		{
			return __exception;
		}
		try
		{
			ExtensionTickDispatch.Synchronize(__instance, threadOrdinal, threadCount, delegate
			{
				if (___galaxy != null && ___galaxy.stars != null)
				{
					StarData[] stars = ___galaxy.stars;
					foreach (StarData starData in stars)
					{
						if (starData != null)
						{
							for (int j = 1; j < StarExtensionSystem.extensions.Count; j++)
							{
								StarExtensionStorage starExtensionStorage = StarExtensionSystem.extensions[j];
								if (starExtensionStorage != null)
								{
									ExtensionTickDispatch.Run(starExtensionStorage.GetSystem(starData), 2, threadOrdinal, threadCount, 12);
								}
							}
						}
					}
				}
			});
			return __exception;
		}
		catch (Exception ex)
		{
			return (__exception == null) ? ex : new AggregateException(__exception, ex);
		}
	}
}
