# Historical harness sources

Shared compile/Mono/API harness source is copied into this mod folder so a reviewer need not obtain another handoff folder to inspect it. Historical scripts retain their original path/config assumptions and are not a one-click portable build. Supply game/BepInEx/dependency references and adapt paths as described in BUILD.md. No game/runtime binary is included.

The analysis and proposed fixes in this handoff were developed with assistance from the GPT 6.1 Sol model. English documentation accompanies the code to explain what changed, why it changed, and the available validation results.
