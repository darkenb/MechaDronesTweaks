# soarqin-UXAssist — detailed change report

Installed plugin version(s): **1.6.3**. Respect runtime worker capacity, native package priority and stock/inc; reject inventory consumption for foreign factories.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Stock-preserving refill — 1.6.2

Retain upstream 1.6.1 reform/restore support for brush sizes 11–30, new lenses, buffer fixes and soil progression.

- Respect runtime worker-array capacities, including LogisticsBotsTweaks expansions. Account for idle/working workers and preserve native auto-replenishment flags, remaining stock and inc. Guard arithmetic and avoid extra consumption on repeated fill.
- Prevent foreign-factory callbacks from consuming local inventory.
- Replace inaccessible internal RGB helpers with the same RGB/alpha calculation and protected `Slider.Set` with native `SetValueWithoutNotify`.

Native storage checks passed for capacity, idempotence, inc and foreign factories. Preserve all 24 embedded visuals by name/bytes, 1,139 public contract entries and GUID. The phase checked 1,164 API references and 172 Harmony targets. Do not disable other mods' options wholesale or rewrite already fixed upstream reform/lens behavior.

## Compatibility repair — 1.6.3, 4 October

Resolve Auxilaryfunction's new `AuxConfig.ShowStationInfo` location for the station-info overlay. Match a real `BinaryReader.ReadInt32` method reference in the MilkyWay cache transpiler. Both were checked against current DLL/game instructions, with resources and save behavior retained. Real UI, terrain reform/restore and runtime Harmony coexistence still require game acceptance.

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
