namespace MechaDronesTweaks;
public static class PluginInfo
{
    public const string PLUGIN_GUID = "org.soardev.mechadronestweaks";
    public const string PLUGIN_NAME = "MechaDronesTweaks";
    public const string PLUGIN_VERSION = "1.1.5";
}
