using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("1.1.4.0")]
[module: RefSafetyRules(11)]
