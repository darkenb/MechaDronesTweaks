using System;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;

namespace MechaDronesTweaks;

[BepInPlugin("org.soardev.mechadronestweaks", "MechaDronesTweaks", "1.1.5")]
[BepInDependency("com.dkoppstein.plugin.DSP.FastDrones", BepInDependency.DependencyFlags.SoftDependency)]
public class MechaDronesTweaksPlugin : BaseUnityPlugin
{
	public new static readonly ManualLogSource Logger = BepInEx.Logging.Logger.CreateLogSource("MechaDronesTweaks");

	private readonly Harmony _harmony = new Harmony("org.soardev.mechadronestweaks");

	public MechaDronesTweaksPlugin()
	{
		try
		{
			if (FastDronesRemover.Run(_harmony))
			{
				Logger.LogInfo("Unpatch FastDrones - OK");
			}
		}
		catch (Exception arg)
		{
			Logger.LogWarning($"Failed to unpatch FastDrones: {arg}");
		}
	}

	public void Awake()
	{
		MechaDronesTweaks.UseFixedSpeed = base.Config.Bind("MechaDrones", "UseFixedSpeed", MechaDronesTweaks.UseFixedSpeed, "Use fixed speed for mecha drones").Value;
		MechaDronesTweaks.SkipStage1 = base.Config.Bind("MechaDrones", "SkipStage1", MechaDronesTweaks.SkipStage1, "Skip 1st stage of working mecha drones (flying away from mecha in ~1/3 speed for several frames)").Value;
		MechaDronesTweaks.RemoveSpeedLimitForStage1 = base.Config.Bind("MechaDrones", "RemoveSpeedLimitForStage1", MechaDronesTweaks.RemoveSpeedLimitForStage1, "Remove speed limit for 1st stage (has a speed limit @ ~10m/s originally)").Value;
		MechaDronesTweaks.FixedSpeed = base.Config.Bind("MechaDrones", "FixedSpeed", MechaDronesTweaks.FixedSpeed, new ConfigDescription("Fixed speed for mecha drones, working only when UseFixedSpeed is enabled", new AcceptableValueRange<float>(6f, 1000f))).Value;
		MechaDronesTweaks.SpeedMultiplier = base.Config.Bind("MechaDrones", "SpeedMultiplier", MechaDronesTweaks.SpeedMultiplier, new ConfigDescription("Speed multiplier for mecha drones, working only when UseFixedSpeed is disabled", new AcceptableValueRange<float>(1f, 10f))).Value;
		MechaDronesTweaks.EnergyMultiplier = base.Config.Bind("MechaDrones", "EnergyMultiplier", MechaDronesTweaks.EnergyMultiplier, new ConfigDescription("Energy consumption multiplier for mecha drones", new AcceptableValueRange<float>(0f, 1f))).Value;
		_harmony.PatchAll(typeof(MechaDronesTweaks));
	}
}
