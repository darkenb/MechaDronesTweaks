using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;

namespace MechaDronesTweaks;

public static class MechaDronesTweaks
{
	public static bool UseFixedSpeed;

	public static bool SkipStage1;

	public static bool RemoveSpeedLimitForStage1 = true;

	public static float FixedSpeed = 300f;

	public static float SpeedMultiplier = 4f;

	public static float EnergyMultiplier = 0.1f;

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(ConstructionSystem), "UpdateDrones")]
	[HarmonyPatch(typeof(UIMechaWindow), "UpdateProps")]
	[HarmonyPatch(typeof(UITechTree), "RefreshDataValueText")]
	private static IEnumerable<CodeInstruction> UITechTreeRefreshDataValueText_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		FieldInfo speedField = AccessTools.Field(typeof(GameHistoryData), "constructionDroneSpeed");
		MethodInfo calculate = AccessTools.Method(typeof(MechaDronesTweaks), "GetDroneSpeed");
		LocalBuilder temporary = generator.DeclareLocal(typeof(float));
		return new CodeMatcher(instructions, generator).MatchForward(false, new CodeMatch((CodeInstruction i) => (i.opcode == OpCodes.Ldfld || i.opcode == OpCodes.Ldflda) && i.OperandIs(speedField))).Repeat(delegate(CodeMatcher m)
		{
			bool num = m.Opcode == OpCodes.Ldflda;
			m.SetAndAdvance(OpCodes.Call, calculate);
			if (num)
			{
				m.InsertAndAdvance(new CodeInstruction(OpCodes.Stloc, temporary), new CodeInstruction(OpCodes.Ldloca, temporary));
			}
		}).InstructionEnumeration();
	}

	private static float GetDroneSpeed(GameHistoryData history)
	{
		if (!UseFixedSpeed)
		{
			return history.constructionDroneSpeed * SpeedMultiplier;
		}
		return FixedSpeed;
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(ConstructionModuleComponent), "EjectBaseDrone")]
	[HarmonyPatch(typeof(ConstructionModuleComponent), "EjectMechaDrone")]
	private static IEnumerable<CodeInstruction> MechaUpdateTargets_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
		if (!SkipStage1)
		{
			return codeMatcher.InstructionEnumeration();
		}
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldc_I4_1), new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(DroneComponent), "stage"))).Opcode = OpCodes.Ldc_I4_2;
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(ConstructionSystem), "UpdateDrones")]
	private static IEnumerable<CodeInstruction> MechaUpdateDrones_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
		if (EnergyMultiplier >= 1f)
		{
			return codeMatcher.InstructionEnumeration();
		}
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(ModeConfig), "droneEnergyPerMeter"))).Advance(1).Insert(new CodeInstruction(OpCodes.Ldc_R8, (double)EnergyMultiplier), new CodeInstruction(OpCodes.Mul));
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(DroneComponent), "InternalUpdate", new Type[]
	{
		typeof(CraftData),
		typeof(PlanetFactory),
		typeof(Vector3),
		typeof(float),
		typeof(float),
		typeof(double),
		typeof(double),
		typeof(double),
		typeof(double),
		typeof(float)
	}, new ArgumentType[]
	{
		ArgumentType.Ref,
		ArgumentType.Normal,
		ArgumentType.Ref,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Ref,
		ArgumentType.Ref,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Out
	})]
	[HarmonyPatch(typeof(DroneComponent), "InternalUpdate", new Type[]
	{
		typeof(CraftData),
		typeof(PlanetFactory),
		typeof(Vector3),
		typeof(float),
		typeof(float),
		typeof(long),
		typeof(double),
		typeof(double),
		typeof(float)
	}, new ArgumentType[]
	{
		ArgumentType.Ref,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Ref,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Out
	})]
	private static IEnumerable<CodeInstruction> MechaDroneUpdate_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
		if (RemoveSpeedLimitForStage1)
		{
			codeMatcher.MatchForward(false, new CodeMatch((CodeInstruction instr) => instr.opcode == OpCodes.Ldc_R4 && instr.OperandIs(1f)), new CodeMatch((CodeInstruction instr) => instr.opcode == OpCodes.Ldc_R4 && instr.OperandIs(3f)));
			codeMatcher.Advance(1).Operand = 10000f;
		}
		if (!UseFixedSpeed && Math.Abs(SpeedMultiplier - 1f) < 0.01f)
		{
			return codeMatcher.InstructionEnumeration();
		}
		codeMatcher.Start().MatchForward(false, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldc_R4), new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(DroneComponent), "progress")));
		codeMatcher.Repeat(delegate(CodeMatcher m)
		{
			if (m.InstructionAt(1).OperandIs(0f))
			{
				m.InstructionAt(3).labels = m.Labels;
				m.RemoveInstructions(3);
			}
			else if (m.InstructionAt(1).OperandIs(1f))
			{
				m.Advance(1).Operand = 0f;
				m.Advance(2);
			}
		});
		codeMatcher.Start().MatchForward(false, new CodeMatch((CodeInstruction instr) => instr.opcode == OpCodes.Ldc_R4 && instr.OperandIs(0.5f)));
		codeMatcher.Repeat(delegate(CodeMatcher m)
		{
			if (UseFixedSpeed)
			{
				if (FixedSpeed > 75f)
				{
					m.Operand = 0.5f * FixedSpeed / 75f;
				}
			}
			else
			{
				m.Operand = 0.5f * SpeedMultiplier;
			}
		});
		return codeMatcher.InstructionEnumeration();
	}
}
