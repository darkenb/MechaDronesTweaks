using System;
using BepInEx.Bootstrap;
using HarmonyLib;

namespace MechaDronesTweaks;

internal class FastDronesRemover
{
	public const string FastDronesGuid = "com.dkoppstein.plugin.DSP.FastDrones";

	private const string FastDronesVersion = "0.0.5";

	public static bool Run(Harmony harmony)
	{
		if (!Chainloader.PluginInfos.TryGetValue("com.dkoppstein.plugin.DSP.FastDrones", out var value) || value.Metadata.Version.ToString() != "0.0.5")
		{
			return false;
		}
		Type type = value.Instance.GetType().Assembly.GetType("com.dkoppstein.plugin.DSP.FastDrones.FastDronesPlugin");
		harmony.Patch(AccessTools.Method(type, "Start"), new HarmonyMethod(typeof(FastDronesRemover).GetMethod("PatchFastDronesStart")));
		return true;
	}

	public static bool PatchFastDronesStart()
	{
		return false;
	}
}
