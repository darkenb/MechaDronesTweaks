using System;
using System.Linq;
using HarmonyLib;
using Tweaks = MechaDronesTweaks.MechaDronesTweaks;

static class Check
{
    static int Main()
    {
        foreach (var mode in new[] {0, 1, 2})
        {
            Tweaks.UseFixedSpeed = mode == 1;
            Tweaks.SkipStage1 = mode == 1;
            Tweaks.RemoveSpeedLimitForStage1 = mode != 2;
            Tweaks.SpeedMultiplier = mode == 2 ? 1f : 4f;
            Tweaks.EnergyMultiplier = mode == 2 ? 1f : 0.1f;
            var generator = new System.Reflection.Emit.DynamicMethod("test", typeof(void), Type.EmptyTypes).GetILGenerator();
            var bindings = new[] {
                new[] {"ConstructionSystem", "UpdateDrones", "UITechTreeRefreshDataValueText_Transpiler"},
                new[] {"UIMechaWindow", "UpdateProps", "UITechTreeRefreshDataValueText_Transpiler"},
                new[] {"UITechTree", "RefreshDataValueText", "UITechTreeRefreshDataValueText_Transpiler"},
                new[] {"ConstructionModuleComponent", "EjectBaseDrone", "MechaUpdateTargets_Transpiler"},
                new[] {"ConstructionModuleComponent", "EjectMechaDrone", "MechaUpdateTargets_Transpiler"},
                new[] {"ConstructionSystem", "UpdateDrones", "MechaUpdateDrones_Transpiler"},
                new[] {"DroneComponent", "InternalUpdate", "MechaDroneUpdate_Transpiler"}
            };
            int count = 0;
            foreach (var binding in bindings)
            {
                var targetType = typeof(GameMain).Assembly.GetType(binding[0]);
                var methods = targetType.GetMethods(System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic).Where(m => m.Name == binding[1]);
                foreach (var method in methods)
                {
                    var original = PatchProcessor.GetOriginalInstructions(method, generator);
                    var transpiler = AccessTools.Method(typeof(Tweaks), binding[2]);
                    var output = ((System.Collections.Generic.IEnumerable<CodeInstruction>)transpiler.Invoke(null, new object[] {original, generator})).ToList();
                    if (output.Count == 0) throw new Exception("Empty patched body " + method);
                    if (binding[2] == "UITechTreeRefreshDataValueText_Transpiler" && !output.Any(i => i.Calls(AccessTools.Method(typeof(Tweaks), "GetDroneSpeed"))))
                        throw new Exception("Native research speed read not patched: " + method);
                    if (binding[2] == "MechaUpdateDrones_Transpiler" && mode != 2 && output.Count != original.Count + 2)
                        throw new Exception("Native flight energy read not patched");
                    count++;
                }
            }
            if (count != 8) throw new Exception("Expected eight transpiler applications including both native drone overloads: " + count);
            Console.WriteLine("PASS actual native IL transpilers: mode " + mode + ", both drone overloads");
        }
        var history = new GameHistoryData {constructionDroneSpeed = 30f};
        Tweaks.UseFixedSpeed = false; Tweaks.SpeedMultiplier = 4f;
        var calculate = AccessTools.Method(typeof(Tweaks), "GetDroneSpeed");
        if ((float)calculate.Invoke(null, new object[] {history}) != 120f || history.constructionDroneSpeed != 30f) throw new Exception("Native research speed changed");
        Tweaks.UseFixedSpeed = true; Tweaks.FixedSpeed = 300f;
        if ((float)calculate.Invoke(null, new object[] {history}) != 300f || history.constructionDroneSpeed != 30f) throw new Exception("Fixed UI speed calculation");
        Console.WriteLine("PASS research speed preserved in both display modes");
        return 0;
    }
}
